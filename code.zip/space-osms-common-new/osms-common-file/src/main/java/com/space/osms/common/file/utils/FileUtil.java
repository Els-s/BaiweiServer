package com.space.osms.common.file.utils;

import com.space.osms.common.core.utils.StringUtil;
import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import javax.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.multipart.MultipartFile;

/**
 * 文件上传工具类。
 */
@Slf4j
public class FileUtil {

    /**
     * 阿里云文件上传。
     *
     * @param file         上传的文件
     * @param tenementCode 租户代码
     * @param projectCode  项目代码
     * @return 返回文件全路径
     */
    public static String ossUpload(MultipartFile file, String tenementCode, String projectCode) {
        return ossUpload(file, tenementCode, projectCode, "");
    }

    /**
     * 阿里云文件上传(指定桶)。
     *
     * @param file         上传的文件
     * @param tenementCode 租户代码
     * @param projectCode  项目代码
     * @return 返回文件全路径
     */
    public static String ossUpload(MultipartFile file, String tenementCode, String projectCode, String bucketName) {
        log.info("阿里云文件上传参数：file:{},tenementCode:{},projectCode:{},bucketName:{}",
                file != null ? file.getName() : "文件为NULL", tenementCode, projectCode, bucketName);
        String pathFileName = "";
        String path;
        if (StringUtil.isEmpty(tenementCode)) {
            tenementCode = "tenementCode";
        }
        if (StringUtil.isEmpty(projectCode)) {
            projectCode = "project";
        }
        pathFileName += tenementCode + File.separator + projectCode + File.separator;
        try {
            path = AliYunUtil.ossUpload(file, pathFileName, bucketName);
        } catch (Exception e) {
            log.error("图片上传失败：{}", e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("图片上传失败", e);
        }
        return path;
    }


    /**
     * 图片下载。
     *
     * @param response response对象
     * @param filePath 文件路径
     */
    public static void downLoadImage(HttpServletResponse response, String filePath) {
        try {
            File file = new File(filePath);
            response.setHeader("Content-Disposition", "attachment;filename=" + file.getName());
            FileInputStream fileInputStream = new FileInputStream(file);
            OutputStream out = response.getOutputStream();
            int len;
            byte[] by = new byte[1024 * 10];
            while ((len = fileInputStream.read(by)) > 0) {
                out.write(by, 0, len);
            }
            out.close();
            fileInputStream.close();
        } catch (Exception e) {
            log.error("图片下载失败：{}", e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("图片下载失败", e);
        }

    }
}

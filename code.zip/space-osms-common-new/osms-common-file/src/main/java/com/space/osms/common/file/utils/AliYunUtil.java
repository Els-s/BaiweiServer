package com.space.osms.common.file.utils;

import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClient;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.common.utils.BinaryUtil;
import com.aliyun.oss.common.utils.IOUtils;
import com.aliyun.oss.model.CannedAccessControlList;
import com.aliyun.oss.model.CreateBucketRequest;
import com.aliyun.oss.model.GenericResult;
import com.aliyun.oss.model.OSSObject;
import com.aliyun.oss.model.ProcessObjectRequest;
import com.aliyun.oss.model.PutObjectResult;
import com.space.osms.common.core.utils.DateUtil;
import com.space.osms.common.core.utils.StringUtil;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.Formatter;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.multipart.MultipartFile;

/**
 * 阿里云文件上传。
 *
 * @Date 2020-01-20
 * @since 1.0
 */
@Slf4j
public class AliYunUtil {

    /**
     * 万筑科技 公共 常量（秘钥相关）。
     */
    private static final String ACCESS_KEY_ID_LONG = "LTAI4GJxiRYcFTUzWPkKcRVq";
    private static final String ACCESS_KEY_SECRET_LONG = "kwT5ThNC9RtRyqZE1CmPF7rN2fDCVs";
    /**
     * oss 常量。
     */
    public static final String OSS_ENDPOINT = "https://oss-cn-beijing.aliyuncs.com";
    public static final String OSS_BUCKET_NAME = "space-osms";
    /**
     * 默认存储路径（桶下一层）
     */
    private static final String DEFAULT_PATH = "osms-public";
    /**
     * 配置允许生成多种分辨率格式。
     * <p>
     * 加,,保证唯一性
     */
    private static final String FILE_FORMAT = ",jpg,png,gif,bmp,jpeg,";

    /**
     * 使用默认的桶上传文件(上传路径默认)。
     *
     * @param file 文件
     * @return 返回存储的全路径
     */
    public static String ossUpload(MultipartFile file) {
        return ossUpload(file, DEFAULT_PATH, OSS_BUCKET_NAME);
    }

    /**
     * 使用默认的桶上传文件。
     *
     * @param file 文件
     * @param path 存储的文件路径（后半段）
     * @return 返回存储的全路径
     */
    public static String ossUpload(MultipartFile file, String path) {
        return ossUpload(file, path, OSS_BUCKET_NAME);
    }

    /**
     * 文件上传。
     *
     * @param file       文件
     * @param path       存储的文件路径（后半段）
     * @param bucketName oss 桶名称（为空时使用默认的：space-osms）
     * @return 返回存储的全路径
     */
    public static String ossUpload(MultipartFile file, String path, String bucketName) {
        if (StringUtil.isEmpty(bucketName)) {
            bucketName = OSS_BUCKET_NAME;
        }
        OSSClient ossClient = new OSSClient(OSS_ENDPOINT, ACCESS_KEY_ID_LONG, ACCESS_KEY_SECRET_LONG);
        //判断BucketName存不存在，不存在就创建
        OSS ossClientBucketNameExists = new OSSClientBuilder()
                .build(OSS_ENDPOINT, ACCESS_KEY_ID_LONG, ACCESS_KEY_SECRET_LONG);
        boolean exists = ossClientBucketNameExists.doesBucketExist(bucketName);
        if (!exists) {
            // 创建CreateBucketRequest对象。
            CreateBucketRequest createBucketRequest = new CreateBucketRequest(bucketName);
            ossClient.createBucket(createBucketRequest);
            ossClient.setBucketAcl(bucketName, CannedAccessControlList.PublicRead);
        }
        InputStream is = null;
        try {
            is = file.getInputStream();
        } catch (IOException e) {
            e.printStackTrace();
        }
        String fileName = file.getOriginalFilename();
        String suffixName = StringUtil.getSuffixName(fileName);
        String date = DateUtil.parseStr(new Date(), DateUtil.YYYYMMDDHHMMSS);
        // 上传内容到指定的存储空间（bucketName）并保存为指定的文件名称（objectName）。
        String objectName = path + File.separator + date + "_" + fileName;
        PutObjectResult result = ossClient.putObject(bucketName, objectName, is);
        // 调用ossClient.getObject返回一个OSSObject实例，该实例包含文件内容及文件元信息。
        OSSObject ossObject = ossClient.getObject(bucketName, objectName);
        String uri = ossObject.getResponse().getUri();
        //图片生成不同分辨率格式的
        try {
            if (suffixName.indexOf(FILE_FORMAT) >= 0) {
                List<String> resolutions = new ArrayList<>();
                resolutions.add("670,280");
                resolutions.add("750,560");
                resolutions.add("315,236");
                resolutions.add("200,150");
                resolutions.add("750,560");
                resolutions.add("315,236");
                resolutions.add("200,150");
                for (String resolution : resolutions) {
                    String[] resolutionsArr = resolution.split(",");
                    StringBuilder sbStyle = new StringBuilder();
                    Formatter styleFormatter = new Formatter(sbStyle);
                    String styleType =
                            "image/resize,m_fixed,w_" + resolutionsArr[0] + ",h_" + resolutionsArr[1];
                    String targetImage =
                            objectName + "_" + resolutionsArr[0] + "*" + resolutionsArr[1] + "." + suffixName;
                    styleFormatter.format("%s|sys/saveas,o_%s,b_%s", styleType,
                            BinaryUtil.toBase64String(targetImage.getBytes()),
                            BinaryUtil.toBase64String(bucketName.getBytes()));
                    ProcessObjectRequest request = new ProcessObjectRequest(bucketName, objectName,
                            sbStyle.toString());
                    GenericResult processResult = ossClient.processObject(request);
                    String json = IOUtils
                            .readStreamAsString(processResult.getResponse().getContent(), "UTF-8");
                    processResult.getResponse().getContent().close();
                }
            }
        } catch (IOException e) {
            log.error("阿里云上传文件失败：{}", e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("阿里云上传文件失败.", e);
        } finally {
            ossClient.shutdown();
        }
        return uri;
    }
}

package com.space.osms.common.core.constant;

/**
 * 通用常量信息。
 *
 * @version 1.0
 * @date 2022-01-25
 */
public class Constants {

    /**
     * UTF-8 字符集。
     */
    public static final String UTF8 = "UTF-8";

    /**
     * GBK 字符集。
     */
    public static final String GBK = "GBK";

    /**
     * 成功标记。
     */
    public static final String OK_CODE = "200";

}

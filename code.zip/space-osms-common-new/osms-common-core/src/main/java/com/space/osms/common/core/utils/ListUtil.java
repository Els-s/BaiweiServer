package com.space.osms.common.core.utils;

import java.util.List;

/**
 * list操作工具类。
 *
 * @date 2022-02-10
 * @Version 1.0
 */
public class ListUtil {

    /**
     * List<String> 转换成String，英文逗号隔开。
     *
     * @param list
     * @return str
     */
    public static String listToString(List<String> list) {
        if (list == null || list.size() == 0) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (String s : list) {
            sb.append(s).append(",");
        }
        String str = sb.toString();
        return str.substring(0, str.length() - 1);
    }

}

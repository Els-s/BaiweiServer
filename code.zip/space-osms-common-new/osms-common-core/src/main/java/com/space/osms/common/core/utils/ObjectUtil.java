package com.space.osms.common.core.utils;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;

/**
 * 对象判断。
 *
 * @date 2022-01-20
 * @Version 1.0
 */
public class ObjectUtil extends cn.hutool.core.util.ObjectUtil {

    /**
     * 只要存在null值，立即返回true。
     *
     * @param values 对象值。
     * @return true or false。
     * @since 1.0
     */
    public static boolean isAnyEmpty(final Object... values) {
        if (values != null) {
            for (Object obj : values) {
                if (obj == null) {
                    return true;
                } else if (obj instanceof CharSequence) {
                    if (StringUtils.isBlank((CharSequence) obj)) {
                        return true;
                    }
                } else if (obj instanceof Collection) {
                    if (((Collection) obj).isEmpty()) {
                        return true;
                    }

                } else if (obj instanceof Map) {
                    if (((Map) obj).isEmpty()) {
                        return true;
                    }
                } else if (obj.getClass().isArray()) {
                    if (Array.getLength(obj) == 0) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}

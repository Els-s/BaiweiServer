package com.space.osms.common.core.page;


import com.space.osms.common.core.utils.ServletUtil;
import java.io.Serializable;

/**
 * 表格数据处理。
 */
public class TableSupport implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 当前记录起始索引。
     */
    public static final String PAGE_NUM = "pageNo";

    /**
     * 每页显示记录数。
     */
    public static final String PAGE_SIZE = "pageSize";


    /**
     * 封装分页对象。
     */
    public static PageDomain getPageDomain() {
        PageDomain pageDomain = new PageDomain();
        pageDomain.setPageNo(ServletUtil.getParameterOrHeaderToInt(PAGE_NUM));
        pageDomain.setPageSize(ServletUtil.getParameterOrHeaderToInt(PAGE_SIZE));
        return pageDomain;
    }

    /**
     * 构建分页请求。
     * <p>
     * 从request的params（高优先级）、header里面拿pageNo和pageSize
     * <p>
     * 都拿不到则不分页
     */
    public static PageDomain buildPageRequest() {
        return getPageDomain();
    }
}

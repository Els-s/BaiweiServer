package com.space.osms.common.core.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;

/**
 * 加密工具类。
 *
 * @date 2022-01-25
 * @Version 1.0
 */
@Slf4j
public class EncryptUtil {

    /**
     * 加密方式。
     */
    private static final String KEY_ALGORITHM = "AES";

    /**
     * AES加密常量。
     */
    private static final String DEFAULT_CIPHER_ALGORITHM = "AES/ECB/PKCS5Padding";
    /**
     * 返回加密长度。
     */
    private static final int MAX_LENGTH = 32;
    /**
     * 加盐长度。
     */
    private static final Integer SALT_LENGTH = 12;

    /**
     * 不加盐MD5加密。
     *
     * @param plainText 加密对象
     * @return 32位小写字符
     * @since 1.0
     */
    public static String md5Encode(String plainText) {
        if (plainText == null) {
            log.warn("加密对象为Null。");
            plainText = "";
        }
        String md5code = "";
        try {
            byte[] secretBytes = MessageDigest.getInstance("MD5").digest(plainText.getBytes());
            // 16进制数字
            md5code = new String(new Hex().encode(secretBytes));
            // 如果生成数字未满32位，需要补0
            for (int i = 0; i < MAX_LENGTH - md5code.length(); i++) {
                md5code += "0";
            }
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return md5code;
    }

    /**
     * 加盐MD5加密(随机盐)。
     *
     * @param plainText 加密对象
     * @return 32位小写字符
     * @since 1.0
     */
    public static String md5EnCodeBySalt(String plainText) {
        Random random = new Random();
        StringBuilder salt = new StringBuilder(SALT_LENGTH);
        salt.append(random.nextInt(99999999)).append(random.nextInt(99999999));
        int len = salt.length();
        if (len < SALT_LENGTH) {
            for (int i = 0; i < SALT_LENGTH - len; i++) {
                salt.append("0");
            }
        }
        return md5Encode(plainText + salt);
    }

    /**
     * 指定盐MD5加密。
     *
     * @param plainText 加密对象
     * @return 32位小写字符
     * @since 1.0
     */
    public static String md5EnCodeAppointSalt(String plainText, String salt) {
        if (StringUtil.isEmpty(salt)) {
            salt = "salt";
        }
        return md5Encode(plainText + salt);
    }

    /**
     * AES 加密操作。
     *
     * @param content  待加密内容
     * @param password 加密密码
     * @return 返回Base64转码后的加密数据
     * @since 1.0
     */
    public static String aesEnCode(String content, String password) {
        try {
            Cipher cipher = Cipher.getInstance(DEFAULT_CIPHER_ALGORITHM);
            byte[] byteContent = content.getBytes("utf-8");
            // 初始化为加密模式的密码器
            cipher.init(Cipher.ENCRYPT_MODE, getSecretKey(password));
            // 加密
            byte[] result = cipher.doFinal(byteContent);
            // 通过Base64转码返回
            return Base64.encodeBase64String(result);
        } catch (Exception ex) {
            log.error("AES 加密失败。", ex.getMessage());
            ex.printStackTrace();
        }
        return null;
    }

    /**
     * 生成加密秘钥。
     *
     * @param password 加密密码
     * @since 1.0
     */
    private static SecretKeySpec getSecretKey(final String password) {
        // 返回生成指定算法密钥生成器的 KeyGenerator 对象
        KeyGenerator kg;
        try {
            kg = KeyGenerator.getInstance(KEY_ALGORITHM);
            SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG");
            secureRandom.setSeed(password.getBytes());
            kg.init(128, secureRandom);
            // 生成一个密钥
            SecretKey secretKey = kg.generateKey();
            // 转换为AES专用密钥
            return new SecretKeySpec(secretKey.getEncoded(), KEY_ALGORITHM);
        } catch (NoSuchAlgorithmException ex) {
            log.error("获取加密秘钥失败。", ex.getMessage());
            ex.printStackTrace();
        }
        return null;
    }
}

package com.space.osms.common.core.page;


import java.io.Serializable;
import lombok.Data;

/**
 * 分页数据对象。
 *
 * @date 2022-01-20
 * @since 1.0
 */
@Data
public class PageDomain implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
     * 当前记录起始索引。
     */
    private Integer pageNo;

    /**
     * 每页显示记录数。
     */
    private Integer pageSize;

}

package com.space.osms.common.core.exception;

import cn.space.base.enums.exception.AbstractBaseExceptionEnum;

/**
 * 工具类异常
 *
 * @date 2022-01-20
 * @Version 1.0
 */
public class UtilException extends BaseException {

    public UtilException(String code, String msg) {
        super(code, msg);
    }

    public UtilException(String msg) {
        super("util", msg);
    }

    public UtilException(String msg, Exception e) {
        super("util", msg + e.getMessage());
    }

    public UtilException(AbstractBaseExceptionEnum resultEnum) {
        super(resultEnum);
    }
}

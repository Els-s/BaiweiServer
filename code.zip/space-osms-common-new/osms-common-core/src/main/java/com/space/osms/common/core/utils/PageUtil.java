package com.space.osms.common.core.utils;

import com.github.pagehelper.PageHelper;
import com.space.osms.common.core.page.PageDomain;
import com.space.osms.common.core.page.TableSupport;

/**
 * 分页工具类。
 *
 * @date 2022-01-20
 * @Version 1.0
 */
public class PageUtil {

    /**
     * 开启分页。
     * <p>
     * 从request的params（高优先级）、header里面拿pageNo和pageSize
     * <p>
     * 都拿不到则不分页
     *
     * @since 1.0
     */
    public static void startPage() {
        PageDomain pageDomain = TableSupport.buildPageRequest();
        Integer pageNum = pageDomain.getPageNo();
        Integer pageSize = pageDomain.getPageSize();
        if (StringUtil.isNotNull(pageNum) && StringUtil.isNotNull(pageSize)) {
            PageHelper.startPage(pageNum, pageSize);
        }
    }
}

package com.space.osms.common.core.utils;

import com.github.dozermapper.core.DozerBeanMapperBuilder;
import com.github.dozermapper.core.Mapper;
import java.util.ArrayList;
import java.util.List;

/**
 * Dozer对象拷贝工具。
 *
 * @date 2022-01-20
 * @Version 1.0
 */
public class DozerBeanUtil {

    public static final Mapper MAPPER = DozerBeanMapperBuilder.buildDefault();

    /**
     * 对象拷贝，相同名称的对象值拷贝。
     *
     * @param dest 拷贝的目标对象
     * @param src  拷贝返回的对象
     * @since 1.0
     */
    public static void copyProperties(Object dest, Object src) {
        MAPPER.map(dest, src);
    }

    /**
     * 对象拷贝，相同名称的对象值拷贝。
     *
     * @param dest  拷贝的目标对象
     * @param clazz 拷贝到对象的Class
     * @return 返回拷贝后的对象
     * @since 1.0
     */
    public static <T> T transitionType(Object dest, Class<T> clazz) {
        return MAPPER.map(dest, clazz);
    }

    /**
     * 对象列表的类型转换。
     *
     * @param tags   原对象
     * @param sClass 目标对象的class
     * @return 目标对象的List
     * @since 1.0
     */
    public static <T, S> List<S> transitionTypeList(List<T> tags, Class<S> sClass) {
        List<S> ts = new ArrayList<>();
        tags.forEach(d ->
                ts.add(transitionType(d, sClass))
        );
        return ts;
    }
}

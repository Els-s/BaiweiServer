package com.space.osms.common.core.utils;

import com.alibaba.fastjson.JSONObject;
import java.io.IOException;
import java.nio.charset.Charset;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.net.ssl.SSLContext;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.util.EntityUtils;

/**
 * Http请求工具类。
 *
 * @date 2022-1-20
 * @Version 1.0
 */
@Slf4j
public class HttpUtil {

    private static PoolingHttpClientConnectionManager connMgr;
    private static RequestConfig requestConfig;
    private static final String PARAMS_JSON = "JSON";
    private static final String PARAMS_MAP = "MAP";
    private static final int MAX_TIMEOUT = 50000;
    private static final String HTTP_TYPE = "https";
    private static final String EN_CODE = "UTF-8";

    static {
        // 设置连接池
        connMgr = new PoolingHttpClientConnectionManager();
        // 设置连接池大小
        connMgr.setMaxTotal(200);
        connMgr.setDefaultMaxPerRoute(connMgr.getMaxTotal());
        // Validate connections after 1 sec of inactivity
        connMgr.setValidateAfterInactivity(5000);
        RequestConfig.Builder configBuilder = RequestConfig.custom();
        // 设置连接超时
        configBuilder.setConnectTimeout(MAX_TIMEOUT);
        // 设置读取超时
        configBuilder.setSocketTimeout(MAX_TIMEOUT);
        // 设置从连接池获取连接实例的超时
        configBuilder.setConnectionRequestTimeout(MAX_TIMEOUT);
        requestConfig = configBuilder.build();
    }

    /**
     * post请求，JSON传输body参数，header传Authorization=token。
     *
     * @param apiUrl   调用Api全路径。
     * @param jsonData json类型的body数据。
     * @param token    请求token。
     * @return JSONObject。
     * @since 1.0
     */
    public static JSONObject postJsonByTokenHandler(String apiUrl, String jsonData,
            String token) {
        Map<String, Object> headerMaps = new HashMap<>();
        if (StringUtil.isNotEmpty(token)) {
            headerMaps.put("Authorization", token);
        }
        return doPost(apiUrl, PARAMS_JSON, null, jsonData, getHeaders(headerMaps));
    }

    /**
     * json格式Body的Post请求。
     *
     * @param apiUrl     调用Api全路径。
     * @param jsonData   json类型的body数据。
     * @param headerMaps 请求Header Map  K-V(可以存放token)。
     * @return JSONObject。
     * @since 1.0
     */
    public static JSONObject postJsonHandler(String apiUrl, String jsonData,
            Map<String, Object> headerMaps) {
        return doPost(apiUrl, PARAMS_JSON, null, jsonData, getHeaders(headerMaps));
    }

    /**
     * post请求，JSON传输body参数，headder只有Token的：Authorization=token。
     *
     * @param apiUrl    调用Api全路径。
     * @param paramMaps Map类型的body数据。
     * @param token     请求token。
     * @return JSONObject
     * @since 1.0
     */
    public static JSONObject postMapByTokenHandler(String apiUrl,
            Map<String, Object> paramMaps, String token) {
        Map<String, Object> headerMaps = new HashMap<>();
        if (StringUtil.isNotEmpty(token)) {
            headerMaps.put("Authorization", token);
        }
        return doPost(apiUrl, PARAMS_MAP, paramMaps, "", getHeaders(headerMaps));
    }

    /**
     * map格式的body的Post请求。
     *
     * @param apiUrl     调用Api全路径。
     * @param paramMaps  Map类型的body数据。
     * @param headerMaps 请求Header Map  K-V(可以存放token)。
     * @return JSONObject。
     * @since 1.0
     */
    public static JSONObject postMapHandler(String apiUrl,
            Map<String, Object> paramMaps, Map<String, Object> headerMaps) {
        return doPost(apiUrl, PARAMS_MAP, paramMaps, "", getHeaders(headerMaps));
    }

    /**
     * map格式的Get请求(单独token，无其他header)。
     *
     * @param apiUrl    调用Api全路径。
     * @param paramMaps Map类型的body数据。
     * @param token     请求Header Map  K-V。
     * @return JSONObject。
     * @since 1.0
     */
    public static JSONObject getMapByTokenHandler(String apiUrl,
            Map<String, Object> paramMaps, String token) {
        Map<String, Object> headerMaps = new HashMap<>();
        if (StringUtil.isNotEmpty(token)) {
            headerMaps.put("Authorization", token);
        }
        return doGet(apiUrl, paramMaps, getHeaders(headerMaps));
    }

    /**
     * map格式的Get请求。
     *
     * @param apiUrl     调用Api全路径。
     * @param paramMaps  Map类型的body数据。
     * @param headerMaps 请求Header Map  K-V。
     * @return JSONObject。
     * @since 1.0
     */
    public static JSONObject getMapHandler(String apiUrl,
            Map<String, Object> paramMaps, Map<String, Object> headerMaps) {
        return doGet(apiUrl, paramMaps, getHeaders(headerMaps));
    }

    /**
     * 发送 GET 请求，参数Map：K-V形式。
     *
     * @param apiUrl 全路径。
     * @param params 请求参数。
     * @return JSONObject。
     * @since 1.0
     */
    private static JSONObject doGet(String apiUrl, Map<String, Object> params, Header[] headers) {
        apiUrl += buildParam(params);
        String result = null;
        HttpClient httpClient;
        if (apiUrl.startsWith(HTTP_TYPE)) {
            httpClient = HttpClients.custom().setSSLSocketFactory(createSslConnSocketFactory())
                    .setConnectionManager(connMgr).setDefaultRequestConfig(requestConfig).build();
        } else {
            httpClient = HttpClients.createDefault();
        }
        try {
            HttpGet httpGet = new HttpGet(apiUrl);
            if (headers != null && headers.length > 0) {
                httpGet.setHeaders(headers);
            }
            HttpResponse response = httpClient.execute(httpGet);
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                result = EntityUtils.toString(entity, EN_CODE);
            }
            int statusCode = response.getStatusLine().getStatusCode();
            if (HttpStatus.SC_OK != statusCode) {
                return errorData(apiUrl, result);
            }
        } catch (IOException e) {
            e.printStackTrace();
            return errorMsg(apiUrl, e.getMessage());
        }
        return JSONObject.parseObject(result);
    }

    /**
     * 构建GetURL的参数。
     *
     * @since 1.0
     */
    private static StringBuffer buildParam(Map<String, Object> params) {
        StringBuffer param = new StringBuffer();
        int i = 0;
        if (ObjectUtil.isNotEmpty(params)) {
            for (Map.Entry<String, Object> entry : params.entrySet()) {
                String key = entry.getKey();
                Object value = entry.getValue();
                if (i == 0) {
                    param.append("?");
                } else {
                    param.append("&");
                }
                param.append(key).append("=").append(value);
                i++;
            }
        }
        return param;
    }


    /**
     * 发送 POST 请求，JSON形式，接收端需要支持json形式，否则取不到数据。
     *
     * @param apiUrl 请求全路径。
     * @param json   json对象。
     * @return JSONObject。
     * @since 1.0
     */
    private static JSONObject doPost(String apiUrl, String paramType, Map<String, Object> params, String json,
            Header[] headers) {
        CloseableHttpClient httpClient;
        if (apiUrl.startsWith(HTTP_TYPE)) {
            httpClient = HttpClients.custom().setSSLSocketFactory(createSslConnSocketFactory())
                    .setConnectionManager(connMgr).setDefaultRequestConfig(requestConfig).build();
        } else {
            httpClient = HttpClients.createDefault();
        }
        String result = null;
        HttpPost httpPost = new HttpPost(apiUrl);
        if (null != headers && headers.length > 0) {
            httpPost.setHeaders(headers);
        }
        CloseableHttpResponse response = null;
        try {
            httpPost.setConfig(requestConfig);
            if (PARAMS_JSON.equals(paramType)) {
                StringEntity stringEntity = new StringEntity(json, EN_CODE);
                stringEntity.setContentEncoding(EN_CODE);
                stringEntity.setContentType("application/json");
                httpPost.setEntity(stringEntity);
            } else {
                List<NameValuePair> pairList = getNameValueList(params);
                if (pairList.size() > 0) {
                    httpPost.setEntity(new UrlEncodedFormEntity(pairList, Charset.forName(EN_CODE)));
                }
            }
            response = httpClient.execute(httpPost);
            int statusCode = response.getStatusLine().getStatusCode();
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                result = EntityUtils.toString(entity, EN_CODE);
            }
            if (HttpStatus.SC_OK != statusCode) {
                return errorData(apiUrl, result);
            }
        } catch (IOException e) {
            e.printStackTrace();
            return errorMsg(apiUrl, e.getMessage());
        } finally {
            if (response != null) {
                try {
                    EntityUtils.consume(response.getEntity());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return JSONObject.parseObject(result);
    }

    /**
     * 创建SSL安全连接。
     *
     * @since 1.0
     */
    private static SSLConnectionSocketFactory createSslConnSocketFactory() {
        SSLConnectionSocketFactory sslSf = null;
        try {
            SSLContext sslContext = new SSLContextBuilder().loadTrustMaterial(null,
                    (TrustStrategy) (chain, authType) -> true).build();
            sslSf = new SSLConnectionSocketFactory(sslContext, (arg0, arg1) -> true);
        } catch (GeneralSecurityException e) {
            e.printStackTrace();
        }
        return sslSf;
    }

    /**
     * 构建nameValueList。
     *
     * @param params 请求Map参数。
     * @return NameValuePair List。
     * @since 1.0
     */
    private static List<NameValuePair> getNameValueList(Map<String, Object> params) {
        if (params == null) {
            return new ArrayList<>();
        }
        List<NameValuePair> pairList = new ArrayList<>(params.size());
        for (Map.Entry<String, Object> entry : params.entrySet()) {
            NameValuePair pair = new BasicNameValuePair(entry.getKey(),
                    entry.getValue() != null ? entry.getValue().toString() : "");
            pairList.add(pair);
        }
        return pairList;
    }

    /**
     * 请求headder值转换。
     *
     * @param params 请求Map类型的header。
     * @return Header[]。
     * @since 1.0
     */
    private static Header[] getHeaders(Map<String, Object> params) {
        if (null == params || params.size() == 0) {
            return null;
        }
        Header[] headers = new Header[params.size()];
        int i = 0;
        for (Map.Entry<String, Object> entry : params.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();
            BasicHeader header = new BasicHeader(key,
                    ObjectUtil.isEmpty(value) ? "" : value.toString());
            headers[i++] = header;
        }
        return headers;
    }

    /**
     * 异常调用返回值统一处理。
     *
     * @param url      请求全路径。
     * @param errorMsg 异常描述。
     * @return JSONObject。
     * @since 1.0
     */
    private static JSONObject errorMsg(String url, String errorMsg) {
        return error(url, errorMsg, "");
    }

    /**
     * 异常调用返回值统一处理。
     *
     * @param url  请求全路径。
     * @param data 返回非200的数据。
     * @return JSONObject
     * @since 1.0
     */
    private static JSONObject errorData(String url, String data) {
        return error(url, "", data);
    }

    /**
     * 异常调用返回值统一处理。
     *
     * @param url      请求全路径。
     * @param errorMsg 异常描述。
     * @param data     返回非200的数据。
     * @return JSONObject
     * @since 1.0
     */
    private static JSONObject error(String url, String errorMsg, String data) {
        JSONObject error = new JSONObject();
        error.put("code", "500");
        error.put("msg", "http调用接口" + url + "异常：" + errorMsg);
        error.put("data", data);
        return error;
    }
}

package com.space.osms.common.core.utils;

import lombok.extern.slf4j.Slf4j;

/**
 * 编码生成工具。
 *
 * @date 2022-01-25
 * @Version 1.0
 */
@Slf4j
public class CodeGenerateUtil {

    /**
     * 编码默认前缀
     */
    public static final String DEFAULT_PREFIX = "OSMS";
    /**
     * 编码默认前缀
     */
    public static final String REPLENISH_PREFIX = "SPACEOSMSO";
    /**
     * 编码默认前缀。
     */
    public static final int DEFAULT_LENGTH = 4;
    /**
     * 编码默认最长前缀。
     */
    public static final int MAX_LENGTH = 10;

    /**
     * 生成带前缀（默认转成大写）的时间戳编号。
     * <p>
     * 高并发下生成唯一编号慎用（推荐使用IdGenerateUtil.getInstance.nextCode()）
     *
     * @param prefix 编号前缀
     * @since 1.0
     */
    public static String buildPrefixCode(String prefix) {
        if (StringUtil.isEmpty(prefix)) {
            prefix = DEFAULT_PREFIX;
        }
        return prefix.toUpperCase() + System.currentTimeMillis();
    }

    /**
     * 名称格式化成4位字母(不足四位的补默认字符)。
     *
     * @param name 字符名称
     * @return 大写的四位字符
     * @since 1.0
     */
    public static String buildNameCode(String name) {
        return buildNameCode(name, DEFAULT_LENGTH);
    }

    /**
     * 名称格式化（指定位数，位数不足则补充字母）。
     *
     * @param name 字符名称
     * @return 大写的指定位数字符
     * @since 1.0
     */
    public static String buildNameCode(String name, int size) {
        if (StringUtil.isEmpty(name) && size == DEFAULT_LENGTH) {
            name = DEFAULT_PREFIX;
        }
        if (size > MAX_LENGTH) {
            log.warn("指定位数{}字符超过最大限制{}", size, MAX_LENGTH);
            size = MAX_LENGTH;
        }
        //过滤统一的特殊字符
        name = StringUtil.cleanSpecialStr(name);
        String code = PinYinUtil.headerChar(name);
        int length = code.length();
        if (length > size) {
            return code.substring(0, size);
        } else if (length < size) {
            int mix = size - length;
            code = code + REPLENISH_PREFIX.substring(0, mix);
        }
        return code;
    }
}

package com.space.osms.common.core.exception;

import cn.space.base.enums.exception.AbstractBaseExceptionEnum;

/**
 * 业务异常定义
 *
 * @date 2022-01-20
 * @Version 1.0
 */
public class SpaasException extends BaseException {

    public SpaasException(String code, String msg) {
        super(code, msg);
    }

    public SpaasException(String msg) {
        super("spaas", msg);
    }

    public SpaasException(AbstractBaseExceptionEnum resultEnum) {
        super(resultEnum);
    }
}

package com.space.osms.common.core.exception;

import cn.space.base.enums.exception.AbstractBaseExceptionEnum;

/**
 * 基础异常。
 *
 * @date 2022-01-20
 * @Version 1.0
 */
public class BaseException extends RuntimeException {

    private static final long serialVersionUID = 1L;
    private String code;
    private String msg;

    public BaseException(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public BaseException(AbstractBaseExceptionEnum resultEnum) {
        this.code = String.valueOf(resultEnum.getCode());
        this.msg = resultEnum.getMsg();
    }

    public String getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}

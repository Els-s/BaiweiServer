package com.space.osms.common.core.domain;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * 分布式Id生成器对象。
 *
 * @date 2022-01-24
 * @Version 1.0
 */
public class IdGenerate {

    /**
     * 开始时间截 (2018-01-01)
     */
    private static final long START_TIME_CUT = 1514736000000L;
    /**
     * 机器id所占的位数
     */
    private static final long WORKER_ID_BITS = 8L;
    /**
     * 序列在id中占的位数
     */
    private static final long SEQUENCE_BITS = 12L;
    /**
     * 毫秒级别时间截占的位数
     */
    private static final long TIMESTAMP_BITS = 41L;
    /**
     * 生成发布方式所占的位数
     */
    private static final long GET_METHOD_BITS = 2L;
    /**
     * 支持的最大机器id，结果是255 (这个移位算法可以很快的计算出几位二进制数所能表示的最大十进制数)
     */
    private static final long MAX_WORKER_ID = -1L ^ (-1L << WORKER_ID_BITS);
    /**
     * 生成序列向左移8位(8)
     */
    private static final long SEQUENCE_SHIFT = WORKER_ID_BITS;
    /**
     * 时间截向左移20位(12+8)
     */
    private static final long TIMESTAMP_SHIFT = SEQUENCE_BITS + WORKER_ID_BITS;
    /**
     * 生成发布方式向左移61位(41+12+8)
     */
    private static final long GET_METHOD_SHIFT = TIMESTAMP_BITS + SEQUENCE_BITS + WORKER_ID_BITS;
    /**
     * 工作机器ID(0~255)
     */
    private long workerId = 0L;
    /**
     * 生成序列的掩码，这里为4095 (0b111111111111=0xfff=4095)
     */
    private static final long SEQUENCE_MASK = -1L ^ (-1L << SEQUENCE_BITS);
    /**
     * 毫秒内序列(0~4095)
     */
    private long sequence = 0L;
    /**
     * 上次生成ID的时间截
     */
    private long lastTimestamp = -1L;
    /**
     * 2位生成发布方式，0代表嵌入式发布、1代表中心服务器发布模式、2代表rest发布方式、3代表保留未用
     */
    private long getMethod = 0L;
    /**
     * 成发布方式的掩码，这里为3 (0b11=0x3=3)
     */
    private long maxGetMethod = -1L ^ (-1L << GET_METHOD_BITS);
    /**
     * 重入锁
     */
    private Lock lock = new ReentrantLock();

    /**
     * 构造函数。
     * <p>
     * IdGenerateUtil使用的参数是method:1,workerId:255,业务系统尽量不要使用。
     *
     * @param getMethod 发布方式 0代表嵌入式发布、1代表中心服务器发布模式、2代表rest发布方式、3代表保留未用 (0~3)
     * @param workerId  工作ID (0~255)
     * @since 1.0
     */
    public IdGenerate(long getMethod, long workerId) {
        if (getMethod > maxGetMethod || getMethod < 0) {
            throw new IllegalArgumentException(
                    String.format("getMethod can't be greater than %d or less than 0", maxGetMethod));
        }
        if (workerId > MAX_WORKER_ID || workerId < 0) {
            throw new IllegalArgumentException(
                    String.format("worker Id can't be greater than %d or less than 0", MAX_WORKER_ID));
        }
        this.getMethod = getMethod;
        this.workerId = workerId;
    }

    /**
     * 获得下一个ID (该方法是线程安全的)。
     *
     * @return SnowflakeId
     * @since 1.0
     */
    private long nextId() {
        long timestamp = timeGen();
        //如果当前时间小于上一次ID生成的时间戳，说明系统时钟回退过这个时候应当抛出异常
        if (timestamp < lastTimestamp) {
            throw new RuntimeException(
                    String.format("Clock moved backwards.  Refusing to generate id for %d milliseconds",
                            lastTimestamp - timestamp));
        }
        //如果是同一时间生成的，则进行毫秒内序列
        if (lastTimestamp == timestamp) {
            lock.lock();
            try {
                sequence = (sequence + 1) & SEQUENCE_MASK;
                //毫秒内序列溢出
                if (sequence == 0) {
                    //阻塞到下一个毫秒,获得新的时间戳
                    timestamp = tilNextMillis(lastTimestamp);
                }
            } finally {
                lock.unlock();
            }
        }
        //时间戳改变，毫秒内序列重置
        else {
            sequence = 0L;
        }
        //上次生成ID的时间截
        lastTimestamp = timestamp;
        //移位并通过或运算拼到一起组成64位的ID
        // 生成方式占用2位，左移61位
        return (getMethod << GET_METHOD_SHIFT)
                // 时间差占用41位，最多69年，左移20位
                | ((timestamp - START_TIME_CUT) << TIMESTAMP_SHIFT)
                // 毫秒内序列，取值范围0-4095
                | (sequence << SEQUENCE_SHIFT)
                // 工作机器，取值范围0-255
                | workerId;
    }

    /**
     * 生成带前缀的String类型的Id。
     *
     * @param prefix 前缀
     * @since 1.0
     */
    public String nextCode(String prefix) {
        StringBuilder sb = new StringBuilder(prefix);
        long id = nextId();
        sb.append(id);
        return sb.toString();
    }

    /**
     * 生成String的Id。[19位数字]
     */
    public String nextString() {
        return Long.toString(nextId());
    }

    /**
     * 生成多个String类型的Id[19位数字]。
     *
     * @param nums 生成Id数量
     * @since 1.0
     */
    public String[] nextString(int nums) {
        String[] ids = new String[nums];
        for (int i = 0; i < nums; i++) {
            ids[i] = nextString();
        }
        return ids;
    }

    /**
     * 生成多个Long类型的Id。
     *
     * @param nums 数量
     * @since 1.0
     */
    private long[] nextId(int nums) {
        long[] ids = new long[nums];
        for (int i = 0; i < nums; i++) {
            ids[i] = nextId();
        }
        return ids;
    }

    /**
     * 生成多个带业务前缀的Id。
     *
     * @param prefix 业务前缀
     * @param nums   生成数量
     * @since 1.0
     */
    public String[] nextCode(String prefix, int nums) {
        String[] ids = new String[nums];
        for (int i = 0; i < nums; i++) {
            ids[i] = nextCode(prefix);
        }
        return ids;
    }

    /**
     * 返回16进制String类型的Id。[16位]
     *
     * @param
     * @return
     */
    public String nextHexString() {
        return Long.toHexString(nextId());
    }

    /**
     * 阻塞到下一个毫秒，直到获得新的时间戳。
     *
     * @param lastTimestamp 上次生成ID的时间截
     * @return 当前时间戳
     */
    protected long tilNextMillis(long lastTimestamp) {
        long timestamp = timeGen();
        while (timestamp <= lastTimestamp) {
            timestamp = timeGen();
        }
        return timestamp;
    }

    /**
     * 返回以毫秒为单位的当前时间。
     *
     * @return 当前时间(毫秒)
     */
    protected long timeGen() {
        return System.currentTimeMillis();
    }
}

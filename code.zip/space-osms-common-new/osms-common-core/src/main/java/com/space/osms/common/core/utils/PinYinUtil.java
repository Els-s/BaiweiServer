package com.space.osms.common.core.utils;

import lombok.extern.slf4j.Slf4j;
import net.sourceforge.pinyin4j.PinyinHelper;
import net.sourceforge.pinyin4j.format.HanyuPinyinCaseType;
import net.sourceforge.pinyin4j.format.HanyuPinyinOutputFormat;
import net.sourceforge.pinyin4j.format.HanyuPinyinToneType;
import net.sourceforge.pinyin4j.format.HanyuPinyinVCharType;
import net.sourceforge.pinyin4j.format.exception.BadHanyuPinyinOutputFormatCombination;

/**
 * 拼音处理工具类。
 *
 * @version 1.0
 * @date 2022-01-25
 */
@Slf4j
public class PinYinUtil {

    /**
     * 获取大写全拼。
     *
     * @param str 目标汉字（普通字符也行）。
     * @return 全拼
     * @since 1.0
     */
    public static String fullPinYinBig(String str) {
        return fullPinYin(str, HanyuPinyinCaseType.UPPERCASE);
    }

    /**
     * 获取小写全拼。
     *
     * @param str 目标汉字（普通字符也行）。
     * @return 全拼
     * @since 1.0
     */
    public static String fullPinYinLittle(String str) {
        return fullPinYin(str, HanyuPinyinCaseType.LOWERCASE);
    }

    /**
     * 得到汉字首字母的拼音（大写）。
     *
     * @param str 汉字字符
     * @return 拼音首字母(大写)
     * @since 1.0
     */
    public static String headerChar(String str) {
        if (StringUtil.isEmpty(str)) {
            log.warn("获取汉字拼音方法：获取汉字为空。");
            return "";
        }
        StringBuilder convert = new StringBuilder();
        for (int i = 0; i < str.length(); i++) {
            char word = str.charAt(i);
            String[] pinYinArray = PinyinHelper.toHanyuPinyinStringArray(word);
            if (pinYinArray != null) {
                convert.append(pinYinArray[0].charAt(0));
            } else {
                convert.append(word);
            }
        }
        return convert.toString().toUpperCase();
    }

    /**
     * 指定大小写格式得到全拼。
     *
     * @param str      目标汉字（普通字符也行）。
     * @param caseType 大/小写 类型
     * @return 全拼
     * @since 1.0
     */
    private static String fullPinYin(String str, HanyuPinyinCaseType caseType) {
        if (StringUtil.isEmpty(str)) {
            log.warn("获取汉字拼音方法：获取汉字为空。");
            return "";
        }
        //默认大写
        if (caseType == null) {
            caseType = HanyuPinyinCaseType.UPPERCASE;
        }
        char[] t1 = str.toCharArray();
        String[] t2;
        HanyuPinyinOutputFormat t3 = new HanyuPinyinOutputFormat();
        t3.setCaseType(caseType);
        t3.setToneType(HanyuPinyinToneType.WITHOUT_TONE);
        t3.setVCharType(HanyuPinyinVCharType.WITH_V);
        StringBuilder t4 = new StringBuilder();
        try {
            for (char c : t1) {
                //是用来判断是不是中文的一个条件，采用的是unicode编码
                if (Character.toString(c).matches("[\\u4E00-\\u9FA5]+")) {
                    t2 = PinyinHelper.toHanyuPinyinStringArray(c, t3);
                    t4.append(t2[0]);
                } else {
                    t4.append(c);
                }
            }
            return t4.toString();
        } catch (BadHanyuPinyinOutputFormatCombination badHanyuPinyinOutputFormatCombination) {
            badHanyuPinyinOutputFormatCombination.printStackTrace();
        }
        return t4.toString();
    }
}

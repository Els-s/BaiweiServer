package com.space.osms.common.core.page;

import java.io.Serializable;
import java.util.List;
import lombok.Data;

/**
 * 表格分页数据对象。
 */
@Data
public class TableDataInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 当前页。
     */
    private Integer pageNo;
    /**
     * 每页行数。
     */
    private Integer pageSize;
    /**
     * 总记录数。
     */
    private Long totalCount;
    /**
     * 总页数。
     */
    private Integer totalPage;
    /**
     * 列表数据。
     */
    private List<?> list;

    /**
     * 表格数据对象。
     */
    public TableDataInfo() {
    }

    /**
     * 分页
     *
     * @param list  列表数据
     * @param total 总记录数
     */
    public TableDataInfo(List<?> list, long total) {
        this.list = list;
        this.totalCount = total;
    }
}

package com.space.osms.common.core.utils;

import cn.hutool.core.date.DateUnit;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import org.apache.commons.lang3.time.DateFormatUtils;

/**
 * 时间工具类。
 *
 * @version 1.0
 * @date 2022.01.20
 */
public class DateUtil extends org.apache.commons.lang3.time.DateUtils {

    public static final String YYYY = "yyyy";
    public static final String YYYY_MM = "yyyy-MM";
    public static final String YYYY_MM_DD = "yyyy-MM-dd";
    public static final String YYYYMMDDHHMMSS = "yyyyMMddHHmmss";
    public static final String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
    public static final String HHMM = "HH:mm";
    private static String[] parsePatterns = {
            "yyyy-MM-dd", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm", "yyyy-MM",
            "yyyy/MM/dd", "yyyy/MM/dd HH:mm:ss", "yyyy/MM/dd HH:mm", "yyyy/MM",
            "yyyy.MM.dd", "yyyy.MM.dd HH:mm:ss", "yyyy.MM.dd HH:mm", "yyyy.MM"};


    /**
     * 日期路径 即年/月/日 如2018/08/08。按照日期生成路径用到。
     *
     * @since 1.0
     */
    public static final String datePath() {
        return DateFormatUtils.format(new Date(), "yyyy/MM/dd");
    }

    /**
     * 获取String类型的当前时间，时间格式指定format。
     *
     * @since 1.0
     */
    public static final String parseStr(Date date, String format) {
        return DateFormatUtils.format(date, format);
    }

    /**
     * 时间格式化，时间格式类型：yyyy-MM-dd HH:mm:ss。
     *
     * @since 1.0
     */
    public static final String parseStr(Date date) {
        return DateFormatUtils.format(date, YYYY_MM_DD_HH_MM_SS);
    }

    /**
     * 日期型字符串转化为日期 格式。
     *
     * @since 1.0
     */
    public static Date parseDate(String str) {
        if (StringUtil.isEmpty(str)) {
            return null;
        }
        try {
            return parseDate(str, parsePatterns);
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 获取过去第几天的日期。
     *
     * @param past 过去天数
     * @since 1.0
     */
    public static String getPastDate(int past) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.DAY_OF_YEAR, calendar.get(Calendar.DAY_OF_YEAR) - past);
        Date today = calendar.getTime();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        String result = format.format(today);
        return result;
    }

    /**
     * 获取几个月的日期。
     *
     * @param month -1过去1个月，1 将来一个月
     * @param day   -1过去1天，1 后面一天  0当前日期
     * @since 1.0
     */
    public static String stepDay(int month, int day) {
        Calendar c = Calendar.getInstance();
        Date today = c.getTime();
        c.setTime(today);
        //（month为负几就是获取前几个月的时间）
        c.add(Calendar.MONTH, month);
        //(-1是获取前一天的，-3就是获取前三天的)
        c.add(Calendar.DATE, day);
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        String result = format.format(c.getTime());
        return result;
    }

    /**
     * 计算两个时间差。
     *
     * @return X天X小时X分钟X秒
     * @since 1.0
     */
    public static String getDateDiffFormat(Date endDate, Date nowDate) {
        String diffFormat = "";
        long nd = 1000 * 24 * 60 * 60;
        long nh = 1000 * 60 * 60;
        long nm = 1000 * 60;
        long ns = 1000;
        // 获得两个时间的毫秒时间差异
        long diff = endDate.getTime() - nowDate.getTime();
        // 计算差多少天
        long day = diff / nd;
        if (day > 0) {
            diffFormat += day + "天";
        } else {
            diffFormat += "0天";
        }
        // 计算差多少小时
        long hour = diff % nd / nh;
        if (hour > 0) {
            diffFormat += hour + "小时";
        } else {
            diffFormat += "0小时";
        }
        // 计算差多少分钟
        long min = diff % nd % nh / nm;
        if (min > 0) {
            diffFormat += min + "分钟";
        } else {
            diffFormat += "0分钟";
        }
        // 计算差多少秒
        long sec = diff % nd % nh % nm / ns;
        if (sec > 0) {
            diffFormat += sec + "秒";
        } else {
            diffFormat += "0秒";
        }
        if ("0天0小时0分钟0秒".equals(diffFormat)) {
            diffFormat = "0秒";
        }
        return diffFormat;
    }

    /**
     * 与当前时间对比获取差值：
     * <p>
     * 差值大于24小时显示YYYY_MM_DD_HH_MM_SS
     * <p>
     * 差值大于等于1小时显示HHMM
     * <p>
     * 差值大于等于1分钟显示"n分钟前"
     * <p>
     * 差值大于等于1秒显示"n秒前"
     *
     * @param: date 时间
     * @since 1.0
     */
    public static String getDateNowDiff(Date date) {
        SimpleDateFormat sdfYMD = new SimpleDateFormat(YYYY_MM_DD_HH_MM_SS);
        SimpleDateFormat sdfHM = new SimpleDateFormat(HHMM);
        int between = (int) cn.hutool.core.date.DateUtil.between(date, new Date(), DateUnit.SECOND);
        StringBuilder builder = new StringBuilder();
        int h = between / 3600;
        int m = (between % 3600) / 60;
        int s = (between % 3600) % 60;
        if (h > 24) {
            return builder.append(sdfYMD.format(date)).toString();
        } else if (h > 0) {
            return builder.append(sdfHM.format(date)).toString();
        } else if (m > 0) {
            return builder.append(m).append("分钟前").toString();
        } else {
            return builder.append(s).append("秒前").toString();
        }
    }
}

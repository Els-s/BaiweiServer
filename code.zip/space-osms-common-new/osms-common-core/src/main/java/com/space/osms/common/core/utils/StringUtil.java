package com.space.osms.common.core.utils;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * 字符串工具类
 *
 * @since 1.0
 */
@Slf4j
public class StringUtil extends StringUtils {

    /**
     * 空字符串。
     */
    private static final String NULL_STR = "";

    /**
     * 定义特殊字符[正则表达式]。
     */
    private static final String REG_EX = "[\\s~·`!！@#￥$%^……&*（()）\\-——\\-_=+【\\[\\]】｛{}｝\\|、\\\\；;：:‘'“”\"，,《<。.》>、/？?]";

    /**
     * 将特殊符号连接的字符串替换成英文逗号。
     * <p>
     * 特殊符号包括："、，;；"，可以扩展
     *
     * @param str 字符对象
     * @return 替换后的字符对象
     * @since 1.0
     */
    public static String replaceSpecialStr(String str) {
        if (isEmpty(str)) {
            return "";
        }
        Pattern p = Pattern.compile(REG_EX);
        Matcher m = p.matcher(str);
        return m.replaceAll(",");
    }

    /**
     * 清除特殊字符。
     * <p>
     * 特殊符号包括："、，;；"，可以扩展
     *
     * @param str 字符对象
     * @return 替换后的字符对象
     * @since 1.0
     */
    public static String cleanSpecialStr(String str) {
        if (isEmpty(str)) {
            return "";
        }
        Pattern p = Pattern.compile(REG_EX);
        Matcher m = p.matcher(str);
        return m.replaceAll("");
    }

    /**
     * * 判断一个字符串是否为空串。
     *
     * @param str String
     * @return true：为空 false：非空
     */
    public static boolean isEmpty(String str) {
        return isNull(str) || NULL_STR.equals(str.trim());
    }

    /**
     * 判断一个字符串是否为非空串。
     *
     * @param str String
     * @return true：非空串 false：空串
     */
    public static boolean isNotEmpty(String str) {
        return !isEmpty(str);
    }

    /**
     * * 判断一个对象是否为空
     *
     * @param object Object
     * @return true：为空 false：非空
     */
    public static boolean isNull(Object object) {
        return object == null;
    }

    /**
     * 判断一个对象是否非空。
     *
     * @param object Object
     * @return true：非空 false：空
     */
    public static boolean isNotNull(Object object) {
        return !isNull(object);
    }


    /**
     * 去掉所有空格
     */
    public static String trim(String str) {
        if (isNull(str)) {
            return "";
        }
        return str.replaceAll(" ", "");
    }


    /**
     * 是否包含字符串【验证strs中的某一个和str一样】。
     *
     * @param str  验证字符串
     * @param strs 字符串组
     * @return 包含返回true
     */
    public static boolean inStringIgnoreCase(String str, String... strs) {
        if (str != null && strs != null) {
            for (String s : strs) {
                if (str.equalsIgnoreCase(trim(s))) {
                    return true;
                }
            }
        }
        return false;
    }


    /**
     * String 转 HashMap
     *
     * @param strs 输入字符
     * @return 输出HashMap
     */
    public static HashMap<String, String> stringToMap(String strs) {
        HashMap<String, String> map = new HashMap<>();
        if (isEmpty(strs)) {
            return map;
        }
        try {
            Gson gson = new Gson();
            map = gson.fromJson(strs, new TypeToken<HashMap<String, String>>() {
            }.getType());
        } catch (JsonSyntaxException e) {
            log.error("String转Map异常:{}", strs);
        }
        return map;
    }

    /**
     * String转换成 List<String>，String需要字符隔开。
     *
     * @param str
     * @return List<String>
     */
    public static List<String> stringToList(String str) {
        List<String> list = new ArrayList<>();
        if (isNotEmpty(str)) {
            list = Arrays.asList(str.split(","));
        }
        return list;
    }

    /**
     * 获取文件后缀名。
     *
     * @param fileName 文件名称
     * @return 返回后缀名（不带.例如：jpg,xls,doc等等）
     */
    public static String getSuffixName(String fileName) {
        if (isEmpty(fileName)) {
            return "";
        }
        String[] split = fileName.split("\\.");
        String suffix = split[split.length - 1];
        return suffix;
    }
}

package com.space.osms.common.core.exception;

import cn.space.base.enums.exception.AbstractBaseExceptionEnum;

/**
 * 业务异常。
 *
 * @date 2022-01-20
 * @Version 1.0
 */
public class BusinessException extends BaseException {

    public BusinessException(String code, String msg) {
        super(code, msg);
    }

    public BusinessException(AbstractBaseExceptionEnum resultEnum) {
        super(resultEnum);
    }
}

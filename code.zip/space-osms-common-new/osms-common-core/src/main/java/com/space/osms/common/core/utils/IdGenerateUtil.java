package com.space.osms.common.core.utils;

import com.space.osms.common.core.domain.IdGenerate;

/**
 * 默认构造分布式Id生成器。
 *
 * @date 2022-02-08
 * @Version 1.0
 */
public class IdGenerateUtil {

    /**
     * 私有构造函数
     */
    private IdGenerateUtil() {
    }

    /**
     * 全局静态访问点
     */
    public static IdGenerate getInstance() {
        return IdGenerateClass.INSTANCE;
    }

    /**
     * 内部静态类方式初始化
     */
    private static class IdGenerateClass {

        private static final IdGenerate INSTANCE = new IdGenerate(1, 255);
    }

}

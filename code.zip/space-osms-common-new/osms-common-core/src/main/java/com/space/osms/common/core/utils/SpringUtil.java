package com.space.osms.common.core.utils;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.stereotype.Component;

/**
 * Spring的Bean管理工具类。
 *
 * @version 1.0
 * @date 2022-01-20
 */
@Component
public final class SpringUtil implements BeanFactoryPostProcessor {

    /**
     * Spring应用上下文环境。
     *
     * @since 1.0
     */
    private static ConfigurableListableBeanFactory beanFactory;

    @Override
    public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {
        SpringUtil.beanFactory = beanFactory;
    }

    /**
     * 根据Bean的name获取对象。
     *
     * @param name bean的名称
     * @return Object 一个以所给名字注册的bean的实例
     * @throws BeansException
     * @since 1.0
     */
    @SuppressWarnings("unchecked")
    public static <T> T getBean(String name) throws BeansException {
        return (T) beanFactory.getBean(name);
    }

    /**
     * 获取类型为requiredType的对象。
     *
     * @param requiredType
     * @return bean
     * @throws BeansException
     * @since 1.0
     */
    public static <T> T getBean(Class<T> requiredType) throws BeansException {
        T result = (T) beanFactory.getBean(requiredType);
        return result;
    }

    /**
     * 如果BeanFactory包含一个与所给名称匹配的bean定义，则返回true。
     *
     * @param name bean的名称
     * @return boolean
     * @since 1.0
     */
    public static boolean containsBean(String name) {
        return beanFactory.containsBean(name);
    }

    /**
     * 判断以给定名字注册的bean是否是单例（isSingleton）。
     *
     * @param name bean的名称
     * @return boolean
     * @throws NoSuchBeanDefinitionException
     * @since 1.0
     */
    public static boolean isSingleton(String name) throws NoSuchBeanDefinitionException {
        return beanFactory.isSingleton(name);
    }

    /**
     * 根据bean注册的类型名称拿bean。
     *
     * @param name 类型名称
     * @return Class 注册对象的类型
     * @throws NoSuchBeanDefinitionException
     * @since 1.0
     */
    public static Class<?> getType(String name) throws NoSuchBeanDefinitionException {
        return beanFactory.getType(name);
    }

    /**
     * 如果给定的bean名字在bean定义中有别名，则返回这些别名。
     *
     * @param name beanName
     * @throws NoSuchBeanDefinitionException
     * @since 1.0
     */
    public static String[] getAliases(String name) throws NoSuchBeanDefinitionException {
        return beanFactory.getAliases(name);
    }
}

package com.space.osms.common.core.utils;

import cn.hutool.core.convert.Convert;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 * 客户端工具类。
 *
 * @version 1.0
 * @date 2022-01-20
 */
public class ServletUtil {

    /**
     * 获取String参数。
     *
     * @since 1.0
     */
    public static String getParameter(String name) {
        return getRequest().getParameter(name);
    }

    /**
     * 带默认值：获取String参数。
     *
     * @since 1.0
     */
    public static String getParameter(String name, String defaultValue) {
        return Convert.toStr(getRequest().getParameter(name), defaultValue);
    }

    /**
     * 从header或者params里面获取Integer参数。
     *
     * @since 1.0
     */
    public static Integer getParameterOrHeaderToInt(String name) {
        String value = getRequest().getParameter(name);
        if (StringUtil.isEmpty(value)) {
            value = getRequest().getHeader(name);
        }
        return Convert.toInt(value);
    }

    /**
     * 带返默认值：获取Integer参数从params里面。
     *
     * @since 1.0
     */
    public static Integer getParameterToInt(String name, Integer defaultValue) {
        return Convert.toInt(getRequest().getParameter(name), defaultValue);
    }

    /**
     * 获取request。
     *
     * @since 1.0
     */
    public static HttpServletRequest getRequest() {
        try {
            return getRequestAttributes().getRequest();
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 从请求头获取token。
     *
     * @since 1.0
     */
    public static String getToken() {
        HttpServletRequest request = getRequest();
        if (request != null) {
            return request.getHeader("Authorization");
        }
        return "";
    }

    /**
     * 获取response。
     *
     * @since 1.0
     */
    public static HttpServletResponse getResponse() {
        try {
            return getRequestAttributes().getResponse();
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 获取请求的Attributes。
     *
     * @since 1.0
     */
    public static ServletRequestAttributes getRequestAttributes() {
        try {
            RequestAttributes attributes = RequestContextHolder.getRequestAttributes();
            return (ServletRequestAttributes) attributes;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 获取请求的header值。
     *
     * @since 1.0
     */
    public static Map<String, String> getHeaders() {
        Map<String, String> map = new LinkedHashMap<>();
        Enumeration<String> enumeration = getRequest().getHeaderNames();
        if (enumeration != null) {
            while (enumeration.hasMoreElements()) {
                String key = enumeration.nextElement();
                String value = getRequest().getHeader(key);
                map.put(key, value);
            }
        }
        return map;
    }

    /**
     * 是否是Ajax异步请求。
     *
     * @since
     */
    public static boolean isAjaxRequest(HttpServletRequest request) {
        String accept = request.getHeader("accept");
        if (accept != null && accept.indexOf("application/json") != -1) {
            return true;
        }

        String xRequestedWith = request.getHeader("X-Requested-With");
        if (xRequestedWith != null && xRequestedWith.indexOf("XMLHttpRequest") != -1) {
            return true;
        }

        String uri = request.getRequestURI();
        if (StringUtil.inStringIgnoreCase(uri, ".json", ".xml")) {
            return true;
        }

        String ajax = request.getParameter("__ajax");
        if (StringUtil.inStringIgnoreCase(ajax, "json", "xml")) {
            return true;
        }
        return false;
    }
}

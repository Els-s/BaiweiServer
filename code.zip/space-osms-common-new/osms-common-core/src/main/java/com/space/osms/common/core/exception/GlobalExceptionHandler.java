package com.space.osms.common.core.exception;

import cn.space.base.result.Response;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 全局异常处理。
 *
 * @date 2022-01-20
 * @Version 1.0
 */
@ControllerAdvice
@Slf4j
@Order(1)
public class GlobalExceptionHandler {

    @ExceptionHandler(BusinessException.class)
    @ResponseBody
    public Response businessException(BusinessException e) {
        log.error("业务调用异常:" + e.getMsg(), e);
        return Response.error(e.getCode(), e.getMsg());
    }

    @ExceptionHandler(Exception.class)
    @ResponseBody
    public Response handleException(Exception ex) {
        log.error(ex.getMessage(), ex);
        return Response.error("500", "服务异常，请稍后重试。");
    }
}

package com.space.osms.common.core.utils;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockHttpServletRequest;


/**
 * IP地址获取单元测试类。
 *
 * @date 2022-02-08
 * @Version 1.0
 */
@DisplayName("Ip地址工具")
class IpUtilTest {

    @DisplayName("获取请求的IP地址")
    @Test
    void getIpAddr() {
        MockHttpServletRequest request = new MockHttpServletRequest();
        Assertions.assertTrue("127.0.0.1".equals(IpUtil.getIpAddr(request)));
    }

}

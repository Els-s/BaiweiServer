package com.space.osms.common.core.utils;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;


/**
 * 拼音工具类单元测试。
 *
 * @date 2022-01-25
 * @Version 1.0
 */
@DisplayName("汉字转拼音工具类")
class PinYinUtilTest {

    @DisplayName("获取汉字大写全拼")
    @Test
    void fullPinYinBig() {
        String yyfwBig = PinYinUtil.fullPinYinBig("运营服务");
        Assertions.assertTrue("YUNYINGFUWU".equals(yyfwBig));
    }

    @DisplayName("获取汉字小写全拼")
    @Test
    void fullPinYinLittle() {
        String yyfwLittle = PinYinUtil.fullPinYinLittle("运营服务");
        Assertions.assertTrue("yunyingfuwu".equals(yyfwLittle));
    }

    @DisplayName("获取汉字首字母（大写）")
    @Test
    void headerChar() {
        String yyfwBig = PinYinUtil.headerChar("运营服务");
        Assertions.assertTrue("YYFW".equals(yyfwBig));
    }
}

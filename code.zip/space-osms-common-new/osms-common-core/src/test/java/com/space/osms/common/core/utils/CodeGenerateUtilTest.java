package com.space.osms.common.core.utils;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;


/**
 * 编码生成工具类单元测试。
 *
 * @date 2022-01-25
 * @Version 1.0
 */
@DisplayName("编码生成工具类")
class CodeGenerateUtilTest {

    @DisplayName("带前缀的编码生成")
    @Test
    void buildPrefixCode() {
        String code = CodeGenerateUtil.buildPrefixCode("test");
        Assertions.assertTrue(code.length() == 17 && code.indexOf("TEST") > -1);
        String code1 = CodeGenerateUtil.buildPrefixCode("");
        Assertions.assertTrue(code1.length() == 17 && code1.indexOf("OSMS") > -1);

    }

    @DisplayName("按照输入生成4位前缀(首字母)")
    @Test
    void buildNameCode() {
        String code = CodeGenerateUtil.buildNameCode("运营服务");
        Assertions.assertTrue("YYFW".equals(code));
    }

    @DisplayName("按照指定位数生成前缀")
    @Test
    void testBuildNameCode() {
        String code = CodeGenerateUtil.buildNameCode("运营服务", 6);
        Assertions.assertTrue("YYFWSP".equals(code));
        String code2 = CodeGenerateUtil.buildNameCode("运营服务", 12);
        Assertions.assertTrue("YYFWSPACEO".equals(code2));
        String code3 = CodeGenerateUtil.buildNameCode("", 4);
        Assertions.assertTrue("OSMS".equals(code3));
        String code4 = CodeGenerateUtil.buildNameCode("运营服务TT", 4);
        Assertions.assertTrue("YYFW".equals(code4));
    }
}

package com.space.osms.common.core.utils;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;


/**
 * Id生成器单元测试。
 *
 * @date 2022-02-08
 * @Version 1.0
 */
@DisplayName("Id生成器")
class IdGenerateUtilTest {

    @DisplayName("获取实例生成Id")
    @RepeatedTest(10)
    void getInstance() {
        String id1 = IdGenerateUtil.getInstance().nextString();
        String id2 = IdGenerateUtil.getInstance().nextString();
        String id3 = IdGenerateUtil.getInstance().nextString();
        System.out.println(id1);
        System.out.println(id2);
        System.out.println(id3);
        Assertions.assertTrue(id1.length() == id2.length());
        Assertions.assertTrue(id2.length() == id3.length());
        Assertions.assertTrue(id1.substring(0, 14).equals(id2.substring(0, 14)));
    }
}

package com.space.osms.common.core.utils;

import com.space.osms.common.core.utils.domain.UserTest;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Dozer对象拷贝工具单元测试。
 *
 * @date 2022-02-08
 * @Version 1.0
 */
@DisplayName("Dozer对象拷贝工具测试")
class DozerBeanUtilTest {

    @DisplayName("对象拷贝")
    @Test
    void copyProperties() {
        UserTest user = new UserTest();
        user.setAddress("testAddress");
        user.setName("testName");
        UserTest userCopy = new UserTest();
        DozerBeanUtil.copyProperties(user, userCopy);
        Assertions.assertTrue(user.getName().equals(userCopy.getName()));
    }

    @DisplayName("根据Class转换对象")
    @Test
    void transitionType() {
        UserTest user = new UserTest();
        user.setAddress("testAddress");
        user.setName("testName");
        UserTest userCopy = DozerBeanUtil.transitionType(user, UserTest.class);
        Assertions.assertTrue(user.getName().equals(userCopy.getName()));
    }

    @Test
    void transitionTypeList() {
        List<UserTest> userTests = new ArrayList<>();
        UserTest user1 = new UserTest();
        user1.setAddress("testAddress");
        user1.setName("testName");
        UserTest user = new UserTest();
        user.setAddress("testAddress");
        user.setName("testName");
        userTests.add(user);
        userTests.add(user1);
        List<UserTest> userTestVOList = DozerBeanUtil.transitionTypeList(userTests, UserTest.class);
        Assertions.assertTrue(userTestVOList.size() == 2);
    }

}

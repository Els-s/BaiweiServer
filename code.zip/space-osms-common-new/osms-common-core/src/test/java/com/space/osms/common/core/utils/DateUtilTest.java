package com.space.osms.common.core.utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;


/**
 * 时间工具类单元测试。
 *
 * @date 2022-01-20 11:19
 * @Version 1.0
 */
@DisplayName("时间工具类")
class DateUtilTest {

    @DisplayName("获取当前时间路径")
    @Test
    void datePath() {
        String strPath = DateUtil.datePath();
        String[] strPaths = strPath.split("/");
        Assertions.assertTrue(strPaths.length == 3);
    }

    @DisplayName("String转换成日期")
    @Test
    void parseDate() {
        String strDate = "2022-10-20 01:02:30";
        Assertions.assertTrue(DateUtil.parseDate("strDate") == null);
        Assertions.assertTrue(DateUtil.parseDate("") == null);
        Date date = DateUtil.parseDate(strDate);
        Assertions.assertTrue(strDate.equals(DateUtil.parseStr(date)));
    }

    @DisplayName("时间格式化（指定类型）")
    @Test
    void getStringDate() {
        String strDate = "2022-10-20 01:02:30";
        String strDate1 = DateUtil.parseStr(DateUtil.parseDate(strDate), DateUtil.YYYY_MM_DD_HH_MM_SS);
        String strDate2 = DateUtil.parseStr(DateUtil.parseDate(strDate), DateUtil.YYYY);
        String strDate3 = DateUtil.parseStr(DateUtil.parseDate(strDate), DateUtil.YYYY_MM);
        String strDate4 = DateUtil.parseStr(DateUtil.parseDate(strDate), DateUtil.YYYY_MM_DD);
        String strDate5 = DateUtil.parseStr(DateUtil.parseDate(strDate), DateUtil.YYYYMMDDHHMMSS);
        Assertions.assertTrue(strDate.equals(strDate1) && "2022".equals(strDate2)
                && "2022-10".equals(strDate3) && "2022-10-20".equals(strDate4)
                && "20221020010230".equals(strDate5));
    }

    @DisplayName("时间格式化（默认类型）")
    @Test
    void testGetStringDate() {
        String strDate = "2022-10-20 01:02:30";
        String stringDate = DateUtil.parseStr(DateUtil.parseDate(strDate));
        Assertions.assertTrue(strDate.equals(stringDate));
    }

    @DisplayName("获取两个时间的差值（X天X小时X分钟X秒格式输出）")
    @Test
    void getDateDiffFormat() {
        String strDate1 = "2022-11-20 01:33:34";
        String strDate2 = "2022-10-20 02:02:30";
        String strDate3 = "2022-11-20 01:33:34";
        String dateDiffFormat = DateUtil.getDateDiffFormat(DateUtil.parseDate(strDate1), DateUtil.parseDate(strDate2));
        String dateDiffFormat1 = DateUtil.getDateDiffFormat(DateUtil.parseDate(strDate1), DateUtil.parseDate(strDate3));
        Assertions.assertTrue("30天23小时31分钟4秒".equals(dateDiffFormat));
        Assertions.assertTrue("0秒".equals(dateDiffFormat1));
    }

    @DisplayName("和当前时间做对比格式化")
    @Test
    void getNowDateDiff() {
        long l = System.currentTimeMillis();
        long l1 = l + 25 * 60 * 60 * 1000;
        long l2 = l + 2 * 60 * 60 * 1000;
        long l3 = l + 2 * 60 * 1000;
        long l4 = l + 2 * 1000;
        Assertions.assertTrue(DateUtil.getDateNowDiff(new Date(l1)).indexOf(":") > -1);
        Assertions.assertTrue(DateUtil.getDateNowDiff(new Date(l2)).indexOf(":") > -1);
        Assertions.assertTrue(DateUtil.getDateNowDiff(new Date(l3)).indexOf("分钟前") > -1);
        Assertions.assertTrue(DateUtil.getDateNowDiff(new Date(l4)).indexOf("秒前") > -1);
    }

    @DisplayName("获取过去第几天的日期。")
    @Test
    void getPastDate() {
        int pastNum = 2;
        long l = System.currentTimeMillis() - pastNum * 24 * 60 * 60 * 1000;
        String s = DateUtil.parseStr(new Date(l), DateUtil.YYYY_MM_DD);
        Assertions.assertTrue(s.equals(DateUtil.getPastDate(pastNum)));

    }

    @DisplayName("获取几个月的日期")
    @Test
    void stepDay() {
        int month = -2;
        int day = 0;
        Calendar c = Calendar.getInstance();
        Date today = c.getTime();
        c.setTime(today);
        //（month为负几就是获取前几个月的时间）
        c.add(Calendar.MONTH, month);
        //(-1是获取前一天的，-3就是获取前三天的)
        c.add(Calendar.DATE, day);
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        String result = format.format(c.getTime());
        System.out.println(result);
        Assertions.assertTrue(result.equals(DateUtil.stepDay(month, day)));

    }
}

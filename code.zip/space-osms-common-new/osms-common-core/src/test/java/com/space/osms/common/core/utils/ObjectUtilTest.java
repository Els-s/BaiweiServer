package com.space.osms.common.core.utils;

import java.util.ArrayList;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;


/**
 * Object类判断Empty。
 *
 * @date 2022-01-26
 * @Version 1.0
 */
@DisplayName("Object类判断Empty")
class ObjectUtilTest {

    @DisplayName("存在Empty")
    @Test
    void isAnyEmpty() {
        Assertions.assertTrue(ObjectUtil.isAnyEmpty("test", new ArrayList<>(), 1));
    }
}

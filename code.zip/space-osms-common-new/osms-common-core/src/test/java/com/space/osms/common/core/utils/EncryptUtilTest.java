package com.space.osms.common.core.utils;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;


/**
 * Md5加密方法单元测试。
 *
 * @Author ChenYou
 * @date 2022-01-25
 * @Version 1.0
 */
@DisplayName("Md5加密工具类")
class EncryptUtilTest {

    @DisplayName("普通加密")
    @Test
    void md5Encode() {
        Assertions.assertTrue("098f6bcd4621d373cade4e832627b4f6".equals(EncryptUtil.md5Encode("test")));
    }

    @DisplayName("随机盐加密")
    @Test
    void md5EnCodeBySalt() {
        Assertions.assertTrue(!"098f6bcd4621d373cade4e832627b4f6".equals(EncryptUtil.md5EnCodeBySalt("test")));
    }

    @DisplayName("指定盐加密")
    @Test
    void md5EnCodeAppointSalt() {
        Assertions.assertTrue(
                "05a671c66aefea124cc08b76ea6d30bb".equals(EncryptUtil.md5EnCodeAppointSalt("test", "test")));
        Assertions.assertTrue("315240c61218a4a861ec949166a85ef0".equals(EncryptUtil.md5EnCodeAppointSalt("test", "")));
    }

}

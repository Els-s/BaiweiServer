package com.space.osms.common.core.utils.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * 测试类对象。
 *
 * @date 2022-02-08
 * @Version 1.0
 */
@Getter
@Setter
public class UserTest {

    private String name;
    private String address;
}

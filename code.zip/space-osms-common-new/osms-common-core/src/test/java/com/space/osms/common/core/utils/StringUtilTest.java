package com.space.osms.common.core.utils;

import java.util.HashMap;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;


/**
 * 字符串工具类单元测试。
 *
 * @date 2022-02-08
 * @Version 1.0
 */
@DisplayName("字符串工具类")
class StringUtilTest {

    @DisplayName("替换特殊字符为英文逗号")
    @Test
    void replaceSpecialStr() {
        String str = "1!1@1#1$1%1^1&1*1";
        String strNew = StringUtil.replaceSpecialStr(str);
        System.out.println(strNew.split(",").length);
        Assertions.assertTrue(strNew.split(",").length == 9);
    }

    @DisplayName("清理特殊字符")
    @Test
    void cleanSpecialStr() {
        String str = "1!1@1#1$1%1^1&1*1";
        String strNew = StringUtil.cleanSpecialStr(str);
        Assertions.assertTrue(strNew.length() == 9);
    }

    @DisplayName("判断是否为空")
    @Test
    void isEmpty() {
        Assertions.assertTrue(StringUtil.isEmpty(""));
        Assertions.assertTrue(StringUtil.isEmpty(null));
        Assertions.assertTrue(StringUtil.isEmpty(" "));
        Assertions.assertTrue(!StringUtil.isEmpty("te"));
    }

    @DisplayName("判断是否不为空")
    @Test
    void isNotEmpty() {
        Assertions.assertTrue(!StringUtil.isNotEmpty(""));
        Assertions.assertTrue(!StringUtil.isNotEmpty(null));
        Assertions.assertTrue(!StringUtil.isNotEmpty(" "));
        Assertions.assertTrue(StringUtil.isNotEmpty("te"));
    }

    @DisplayName("判断是否为null")
    @Test
    void isNull() {
        Assertions.assertTrue(StringUtil.isNull(null));
        Assertions.assertTrue(!StringUtil.isNull(""));
        Assertions.assertTrue(!StringUtil.isNull("test"));
    }

    @DisplayName("判断是否不为null")
    @Test
    void isNotNull() {
        Assertions.assertTrue(!StringUtil.isNotNull(null));
        Assertions.assertTrue(StringUtil.isNotNull(""));
        Assertions.assertTrue(StringUtil.isNotNull("test"));
    }

    @DisplayName("去掉所有空格")
    @Test
    void trim() {
        String str = "   t  e  s t  ";
        String strNew = StringUtil.trim(str);
        Assertions.assertTrue("test".equals(strNew));
    }

    @DisplayName("验证字符串是否存在字符串组里面")
    @Test
    void inStringIgnoreCase() {
        String str1 = "t";
        String str2 = "t2";
        String str3 = "t";
        Assertions.assertTrue(StringUtil.inStringIgnoreCase(str1, str2, str3));
    }

    @DisplayName("String转Map")
    @Test
    void stringToMap() {
        String strs = "{'name':'test','address':'addressTest'}";
        HashMap<String, String> map = StringUtil.stringToMap(strs);
        Assertions.assertTrue("test".equals(map.get("name")));
        Assertions.assertTrue("addressTest".equals(map.get("address")));
    }

    @DisplayName("String转List")
    @Test
    void stringToList() {
        String strs = "t,e,s,t";
        List<String> list = StringUtil.stringToList(strs);
        Assertions.assertTrue(list.size() == 4);
    }

    @DisplayName("获取文件后缀名称(不带.)")
    @Test
    void getSuffixName() {
        String str = "test.png";
        Assertions.assertTrue("png".equals(StringUtil.getSuffixName(str)));
    }
}

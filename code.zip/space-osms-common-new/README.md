## 公共模块介绍
###
~~~
版本介绍说明：所有组件版本从1.0.0开始
上传Maven私服使用版本（对应POM文件要修改版本）：
ALPHA：内部测试版（基础依赖测试阶段，其他人暂时不要使用）
SNAPSHOT：快照版（可以使用，但是还在改进阶段，其他人临时使用但是后期要使用RELEASE）
RELEASE：发行版（正常使用，如果有BUG可以发布新版本或者BUILD版本）
BUILD：发行版本的修正版
~~~
### osms-common-core 公共核心包
~~~
公共核心包，包括：
常用工具类（util）
公共配置类（config）
常量定义（constant）
公共注解（annotation）
公共枚举（emums）
公共分页（page）
公共异常（exception）
公共实体（domain）
~~~
***
### osms-common-file 文件处理包
~~~
文件处理包，包括：
OSS文件上传下载
二维码生成、解析
~~~
***
### osms-common-redis redis使用包
~~~
redis统一使用封装：
定义公共配置和统一使用规则
~~~
***
### osms-common-mybatis-plus Mybatis-Plus使用配置
~~~
Mybatis-Plus统一配置：
~~~

***
### osms-common-swagger 定义统一的swagger
~~~
swagger统一配置：需要手动注入配置EnableCustomSwagger2
~~~

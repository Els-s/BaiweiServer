package com.space.osms.mybatisplus.config;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.handlers.MetaObjectHandler;
import com.space.osms.common.core.utils.ServletUtil;
import com.space.osms.common.core.utils.StringUtil;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.reflection.MetaObject;
import org.springframework.stereotype.Component;

/**
 * 处理新增和更新的基础数据填充，配合BaseEntity，BaseController和MyBatisPlusConfig使用。
 *
 * @date 2022-01-20
 * @since 1.0
 */
@Slf4j
@Component
public class MetaHandler implements MetaObjectHandler {

    private static final String NO_SERVLET = "NO_SERVLET_SYSTEM";

    /**
     * 新增数据执行。
     *
     * @since 1.0
     */
    @Override
    public void insertFill(MetaObject metaObject) {
        if (ObjectUtil.isNull(this.getFieldValByName("createTime", metaObject))) {
            this.setFieldValByName("createTime", new Date(), metaObject);
        }
        if (ObjectUtil.isNull(this.getFieldValByName("updateTime", metaObject))) {
            this.setFieldValByName("updateTime", new Date(), metaObject);
        }
        if (ObjectUtil.isNull(this.getFieldValByName("createBy", metaObject))) {
            String userName = getRequestValueByName("userName");
            if (!NO_SERVLET.equals(userName) && StringUtil.isNotEmpty(userName)) {
                this.setFieldValByName("createBy", userName, metaObject);
                this.setFieldValByName("updateBy", userName, metaObject);
            }
        }
        if (ObjectUtil.isNull(this.getFieldValByName("tenementCode", metaObject))) {
            String tenementCode = getRequestValueByName("tenementCode");
            if (!NO_SERVLET.equals(tenementCode) && StringUtil.isNotEmpty(tenementCode)) {
                this.setFieldValByName("tenementCode", tenementCode, metaObject);
            }
        }
    }

    /**
     * 更新数据执行。
     *
     * @since 1.0
     */
    @Override
    public void updateFill(MetaObject metaObject) {
        this.setFieldValByName("updateTime", new Date(), metaObject);
        String userName = getRequestValueByName("userName");
        if (!NO_SERVLET.equals(userName) && StringUtil.isNotEmpty(userName)) {
            this.setFieldValByName("updateBy", userName, metaObject);
        }
    }

    /**
     * 从request里面获取userName信息（基于BaseController）。
     *
     * @since 1.0
     */
    private String getRequestValueByName(String name) {
        String nameValue;
        HttpServletRequest request;
        try {
            request = ServletUtil.getRequest();
            if (null != request) {
                nameValue = request.getHeader(name);
                if (StringUtil.isEmpty(nameValue)) {
                    nameValue = (String) request.getAttribute(name);
                    if (StringUtil.isEmpty(nameValue)) {
                        nameValue = ServletUtil.getParameter(name);
                    }
                }
            } else {
                return NO_SERVLET;
            }
        } catch (Exception e) {
            log.error("获取{}信息失败。{}", name, e.getMessage());
            e.printStackTrace();
            return "获取数据异常";
        }
        if (StringUtil.isEmpty(nameValue)) {
            nameValue = "游客";
        }
        return nameValue;
    }
}

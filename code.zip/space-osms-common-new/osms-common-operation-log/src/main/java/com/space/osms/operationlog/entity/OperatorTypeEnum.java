package com.space.osms.operationlog.entity;

import lombok.Getter;

/**
 * 业务操作类型
 *
 * @author ChenYou
 */
@Getter
public enum OperatorTypeEnum {
    /**
     * 其它
     */
    OTHER("other", "其他类型"),
    /**
     * 查看详情
     */
    DETAIL("detail", "查看详情"),
    /**
     * 列表查看
     */
    LIST("list", "列表查询"),
    /**
     * 新增
     */
    INSERT("insert", "新增"),
    /**
     * 修改
     */
    UPDATE("update", "修改"),
    /**
     * 删除
     */
    DELETE("delete", "删除"),
    /**
     * 导出
     */
    EXPORT("export", "导出"),
    /**
     * 导入
     */
    IMPORT("import", "导入"),
    /**
     * 支付
     */
    PAY("pay", "支付"),
    /**
     * 退款
     */
    REFUND("reFund", "退款"),
    /**
     * 下单
     */
    PLACE_ORDER("placeOrder", "下单");
    private String code;
    private String info;

    OperatorTypeEnum(String code, String info) {
        this.code = code;
        this.info = info;
    }

    public static String getInfoValue(String code) {
        OperatorTypeEnum[] values = OperatorTypeEnum.values();
        for (OperatorTypeEnum value : values) {
            if (value.getCode().equals(code)) {
                return value.getInfo();
            }
        }
        return "暂无";
    }
}

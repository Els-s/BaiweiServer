package com.space.osms.operationlog.entity;

import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 操作日志DTO对象。
 *
 * @date 2022-03-12
 */
@Data
public class SysOperatorLogDTO {

    /**
     * 应用代码
     */
    private String moduleCode;
    /**
     * 模块标题
     */
    private String title;
    /**
     * 操作类型 add，delete，update，import，export，other
     */
    private String operatorType;
    /**
     * 方法名称
     */
    private String method;
    /**
     * 请求方式
     */
    private String requestMethod;
    /**
     * 请求URL
     */
    private String operatorUrl;
    /**
     * 主机地址
     */
    private String operatorIp;
    /**
     * 操作地点
     */
    private String operatorLocation;
    /**
     * 请求参数
     */
    private String operatorParam;
    /**
     * 返回参数
     */
    private String jsonResult;
    /**
     * 操作状态 normal-正常，exception-异常
     */
    private String operatorState;
    /**
     * 错误消息
     */
    private String errorMsg;
    /**
     * 租户编码
     */
    private String tenementCode;
    /**
     * 园区编码
     */
    private String projectCode;
    /**
     * 企业编码
     */
    private String companyCode;
    /**
     * 创建人
     */
    private String createBy;
    /**
     * 更新人
     */
    private String updateBy;

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("moduleCode", getModuleCode())
                .append("title", getTitle())
                .append("operatorType", getOperatorType())
                .append("method", getMethod())
                .append("requestMethod", getRequestMethod())
                .append("operatorUrl", getOperatorUrl())
                .append("operatorIp", getOperatorIp())
                .append("operatorLocation", getOperatorLocation())
                .append("operatorParam", getOperatorParam())
                .append("jsonResult", getJsonResult())
                .append("operatorState", getOperatorState())
                .append("errorMsg", getErrorMsg())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("companyCode", getCompanyCode())
                .append("createBy", getCreateBy())
                .append("updateBy", getUpdateBy())
                .toString();
    }

}

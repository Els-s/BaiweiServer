package com.space.osms.operationlog.entity;

import lombok.Getter;

/**
 * 操作状态
 *
 * @author ChenYou
 */
@Getter
public enum OperatorStateEnum {
    /**
     * 成功
     */
    SUCCESS("success", "成功"),
    /**
     * 失败
     */
    FAIL("fail", "失败");

    private String code;
    private String info;

    OperatorStateEnum(String code, String info) {
        this.code = code;
        this.info = info;
    }

    public static String getInfoValue(String code) {
        OperatorStateEnum[] values = OperatorStateEnum
                .values();
        for (OperatorStateEnum value : values) {
            if (value.getCode().equals(code)) {
                return value.getInfo();
            }
        }
        return "暂无";
    }
}

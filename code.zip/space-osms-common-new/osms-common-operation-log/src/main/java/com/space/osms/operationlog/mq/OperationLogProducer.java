package com.space.osms.operationlog.mq;

import com.space.osms.common.core.utils.ObjectUtil;
import com.space.osms.operationlog.entity.SysOperatorLogDTO;
import org.apache.rocketmq.spring.core.RocketMQTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 日志生产者。
 *
 * @date 2022-03-12
 * @Version 1.0
 */
@Component
public class OperationLogProducer {

    @Autowired
    private RocketMQTemplate rocketMQTemplate;
    private static final String LOG_TOPIC_NAME = "space_osms_operation_log";

    /**
     * 发送单向消息 参数1： topic:tag 参数2:  消息体 可以为一个对象
     */
    public void sendOneWay(SysOperatorLogDTO log) {
        if (ObjectUtil.isNotEmpty(log)) {
            rocketMQTemplate.sendOneWay(LOG_TOPIC_NAME, log.toString());
        }
    }

}

package com.space.lightapp.annotation.aop;

import cn.hutool.core.util.StrUtil;
import cn.space.portal.sdk.caller.TokenCaller;
import cn.space.portal.sdk.io.ResponseData;
import com.alibaba.fastjson.JSON;
import com.space.lightapp.exception.AuthException;
import com.space.osms.common.core.utils.ServletUtil;
import javax.servlet.http.HttpServletRequest;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

/**
 * 仅鉴权接口token
 *
 * @Author kangmj
 * @date 2021-10-25 20:00
 * @Version 1.0
 */
@Aspect
@Component
public class AuthTokenAspect {

    @Before("@annotation(com.space.lightapp.annotation.unit.AuthToken)")
    public void before() {
        HttpServletRequest req = ServletUtil.getRequest();
        if (null == req) {
            throw new AuthException("请求异常。");
        }
        String token = req.getHeader(HttpHeaders.AUTHORIZATION);
        if (StrUtil.isBlank(token)) {
            throw new AuthException("Authorization信息为空。");
        }
        ResponseData responseData = TokenCaller.checkToken(token);
        if (!ResponseData.DEFAULT_SUCCESS_CODE.equals(responseData.getCode())) {
            throw new AuthException(JSON.toJSONString(responseData));
        }
    }
}

package com.space.lightapp.enums;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.space.lightapp.enums.seri.ActivitySignStatusEnumDeserializer;
import com.space.lightapp.enums.seri.ActivityStatusEnumDeserializer;
import com.space.lightapp.enums.seri.StatusTypeEnumDeserializer;
import lombok.Getter;

public class ActivityEnum {

    /**
     * 活动状态
     */
    @Getter
    @JsonFormat(shape = JsonFormat.Shape.OBJECT)
    @JsonDeserialize(using = ActivityStatusEnumDeserializer.class)
    public enum ActivityStatus {
        /**
         * UN_BEGIN:未开始 RUNNING:进行中 FINISH:已结束
         */
        UN_BEGIN("unBegin", "未开始"),
        RUNNING("running", "进行中"),
        SUSPEND("suspend", "暂停中"),
        FINISH("finish", "已结束"),
        ;

        private String code;
        private String name;

        ActivityStatus(String code, String name) {
            this.code = code;
            this.name = name;
        }
    }

    /**
     * 活动分类
     */
    @Getter
    @JsonFormat(shape = JsonFormat.Shape.OBJECT)
    @JsonDeserialize(using = StatusTypeEnumDeserializer.class)
    public enum StatusType {
        /**
         * USING:活动中 STOP:历史活动
         */
        USING("using", "活动中"),
        STOP("stop", "历史活动"),
        ;

        private String code;
        private String name;

        StatusType(String code, String name) {
            this.code = code;
            this.name = name;
        }
    }

    /**
     * 活动报名状态
     */
    @Getter
    @JsonFormat(shape = JsonFormat.Shape.OBJECT)
    @JsonDeserialize(using = StatusTypeEnumDeserializer.class)
    public enum ActivityApply {
        /**
         * NO_NEED:无需报名 APPLY:报名中 UN_BEGIN:报名未开始 STOP:报名已结束
         */
        NO_NEED("noNeed", "无需报名"),
        APPLY("apply", "报名中"),
        UN_BEGIN("unBegin", "报名未开始"),
        STOP("stop", "报名已结束"),
        ;

        private String code;
        private String name;

        ActivityApply(String code, String name) {
            this.code = code;
            this.name = name;
        }
    }


    /**
     * 活动签到状态
     */
    @Getter
    @JsonFormat(shape = JsonFormat.Shape.OBJECT)
    @JsonDeserialize(using = ActivitySignStatusEnumDeserializer.class)
    public enum ActivitySignStatus {
        /**
         * NO_SIGN:无需签到 UN_BEGIN:签到未开始 SIGNING:签到进行中 STOP:签到已结束
         */
        NO_SIGN("noSign", "无需签到"),
        UN_BEGIN("unBegin", "签到未开始"),
        SIGNING("signing", "签到进行中"),
        STOP("stop", "签到已结束"),
        ;

        private String code;
        private String name;

        ActivitySignStatus(String code, String name) {
            this.code = code;
            this.name = name;
        }
    }


}

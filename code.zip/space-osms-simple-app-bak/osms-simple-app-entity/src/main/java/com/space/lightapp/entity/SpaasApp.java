package com.space.lightapp.entity;

import java.util.List;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * 轻应用 对象 light_app
 *
 * @author ChenYou
 * @date 2021-09-27
 */
@Data
@Accessors(chain = true)
public class SpaasApp {

    /**
     * 模块名称
     */
    private String moduleName;
    /**
     * 模块代码
     */
    private String moduleCode;
    /**
     * 子应用名称
     */
    private String appName;
    /**
     * 应用名称Id（轻应用LightAppId）
     */
    private Long appId;
    /**
     * 子应用代码（取统一任务中心编码）
     */
    private String appTaskCode;
    /**
     * 服务图片
     */
    private String iconUrl;
    /**
     * 处理中数量
     */
    private Long processIng;
    /**
     * 已完结数量
     */
    private Long finished;
    /**
     * 数据列表
     */
    private List data;
    /**
     * 用户是否有权限访问
     */
    private boolean hasAuth;
    /**
     * 服务小类型
     */
    private String appLittleType;
    /**
     * 总数量
     */
    private Long totalCount;

    public SpaasApp() {
    }

    public SpaasApp(String moduleName, String moduleCode, String appName, String appTaskCode) {
        this.moduleCode = moduleCode;
        this.moduleName = moduleName;
        this.appName = appName;
        this.appTaskCode = appTaskCode;
    }
}

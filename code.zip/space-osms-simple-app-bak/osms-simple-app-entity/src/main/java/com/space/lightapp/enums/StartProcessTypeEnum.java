package com.space.lightapp.enums;

/**
 * 流程启动类型
 *
 * @Author ChenYou
 * @date 2022-01-14 15:51
 * @Version 1.0
 */
public enum StartProcessTypeEnum {
    //启动流程类型
    REFUND("re_fund", "退款"),
    COMPANY_PAY("company_pay", "企业结算"),
    //可能是配送，可能是议价（业务自己定义的）
    SERVER_TYPE("server_type", "分类流程");

    private String code;
    private String info;

    StartProcessTypeEnum(String code, String info) {
        this.code = code;
        this.info = info;
    }


    public String getCode() {
        return code;
    }

    public String getInfo() {
        return info;
    }

    public static String getInfoValue(Integer code) {
        StartProcessTypeEnum[] values = StartProcessTypeEnum.values();
        for (StartProcessTypeEnum value : values) {
            if (value.getCode().equals(code)) {
                return value.getInfo();
            }
        }
        return "暂无";
    }
}

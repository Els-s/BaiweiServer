package com.space.lightapp.entity.dto.order;

import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * 订单中心-订单商品明细表
 */
@Data
@Accessors(chain = true)
public class OrderRefundDetailDTO implements Serializable {


    @ApiModelProperty(value = "主键")
    private Long id;
    @ApiModelProperty(value = "订单编号")
    private String orderNo;
    @ApiModelProperty(value = "订单编号")
    private String orderDetailNo;

    /**
     * 退款详情只关注 商品编码、商品编码
     */
    @ApiModelProperty(value = "商品编码")
    private String goodsCode;
    @ApiModelProperty(value = "商品名称")
    private String goodsName;
    @ApiModelProperty(value = "商品规格编码")
    private String specificationCode;
    @ApiModelProperty(value = "商品规格名称")
    private String specificationName;
    @ApiModelProperty(value = "单价")
    private String unitPrice;
    @ApiModelProperty(value = "数量")
    private String count;
    @ApiModelProperty(value = "优惠金额")
    private String coupon;
    @ApiModelProperty(value = "已支付金额")
    private String payAmount;
    @ApiModelProperty(value = "退款金额")
    private String refundAmount;
    @ApiModelProperty(value = "可退款金额")
    private String enableRefundAmount;

    /**
     * =========
     */
    @ApiModelProperty(value = "实际价格")
    private String actualPrice;
    @ApiModelProperty(value = "费项编码")
    private String feeInternalCode;
    @ApiModelProperty(value = "时长")
    private String duration;
    @ApiModelProperty(value = "原价")
    private String originalPrice;
    @ApiModelProperty(value = "改价")
    private String alterPrice;
    @ApiModelProperty(value = "已退款金额")
    private String retiredAmount;

}

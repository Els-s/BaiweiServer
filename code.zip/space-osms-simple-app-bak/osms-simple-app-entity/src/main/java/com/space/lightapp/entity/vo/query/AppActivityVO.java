package com.space.lightapp.entity.vo.query;

import com.space.lightapp.base.BaseFieldDTO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * 活动查询参数
 */
@Getter
@Setter
@ApiModel(description = "活动查询参数")
public class AppActivityVO extends BaseFieldDTO {

    /**
     * 状态类型：using：进行中； stop：已结束
     */
    private String statusType;
    private Long activityId;
}

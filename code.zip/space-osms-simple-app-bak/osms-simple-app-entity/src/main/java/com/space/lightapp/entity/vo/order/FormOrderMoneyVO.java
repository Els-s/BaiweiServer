package com.space.lightapp.entity.vo.order;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @author JiangHao
 * @version 1.0
 * @date 2021/11/18 0018 17:32
 * @description
 */
@Data
@Accessors(chain = true)
@ApiModel(description = "表单订单金额设置")
public class FormOrderMoneyVO {

    /**
     * 订单金额
     */
    private String orderMoney;
    /**
     * 订单详情
     */
    private String orderDetail;
    /**
     * 审批后金额
     */
    private String agreeMoney;
    /**
     * 审批备注信息
     */
    private String remark;
    /**
     * 公司信息， 企业管理员时需配置
     */
    private String companyId;

    private String companyName;
    private String companyAddress;
}

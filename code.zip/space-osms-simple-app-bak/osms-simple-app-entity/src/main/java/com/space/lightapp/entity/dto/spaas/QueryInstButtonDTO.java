package com.space.lightapp.entity.dto.spaas;

import lombok.Builder;
import lombok.Data;

/**
 * 查询流程按钮
 *
 * @Author Els
 * @date 2022-03-11 15:11
 * @Version 1.0
 */
@Data
@Builder
public class QueryInstButtonDTO {
    private String tenementCode;
    private String projectCode;
    private String insId;
    private String taskId;
}

package com.space.lightapp.entity;

import cn.hutool.core.date.DateTime;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.space.lightapp.base.FormBaseEntity;
import com.space.lightapp.entity.vo.LightAppServerDataVO;
import com.space.lightapp.enums.BusinessStateEnum;
import com.space.lightapp.enums.PayWayEnum;
import com.space.lightapp.enums.SourceEnum;
import com.space.osms.common.core.utils.DozerBeanUtil;
import com.space.osms.common.file.annotation.Excel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 填答服务数据 对象 light_app_server_data
 *
 * @author ChenYou
 * @date 2021-11-04
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("light_app_server_data")
@ApiModel(description = "填答服务数据")
public class LightAppServerData extends FormBaseEntity {

    private static final long serialVersionUID = -7945730133290009128L;
    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long serverDataId;
    /**
     * 轻应用小分类
     */
    private String appLittleType;
    /**
     * 服务Id
     */
    private Long serverId;
    /**
     * 订单中心订单编号
     */
    @Excel(name = "订单编号")
    private String extOrderCode;
    /**
     * 客户姓名
     */
    @Excel(name = "客户姓名")
    private String customerName;
    /**
     * 手机号码
     */
    @Excel(name = "手机号码")
    private String customerPhone;
    /**
     * openId
     */
    private String openId;
    /**
     * 是否订阅:未订阅 已订阅
     */
    private String subscribe;
    /**
     * 企业地址
     */
    private String customerAddress;
    /**
     * 收货地址详情JSON
     */
    private String receiveDetail;
    /**
     * 订单总价
     */
    private BigDecimal orderMoney;
    /**
     * 结算方式
     */
    private String payWay;
    /**
     * 支付方式(0-线上)
     */
    private String paymentWay;
    /**
     * 支付企业 cashPay 现结，companyPay 企业周期结算
     */
    private String payCompany;
    /**
     * 购买数量
     */
    private Long buyNum;
    /**
     * 退款数量（包含完成和进行中）
     */
    private Long refundNum;
    /**
     * 服务/配送数量（包含完成和进行中）
     */
    private Long deliveryNum;
    /**
     * 服务/未配送数量
     */
    @TableField(exist = false)
    private Long unDeliveryNum;
    /**
     * 服务时长
     */
    private Integer duration;
    /**
     * 规格
     */
    private String specification;
    /**
     * 计算公式
     */
    private String formula;
    /**
     * 应付金额
     */
    private BigDecimal buyMoney;
    /**
     * 结算状态
     */
    private Integer taxStatus;

    /**
     * 排序 排序字段
     */
    private Integer orderNum;
    /**
     * 是否禁用 0禁用，1启用；默认1
     */
    private Boolean status;
    /**
     * 备注
     */
    private String remark;
    /**
     * 订单中心创建订单结果 1-创建成功，-1-创建失败，0-未创建
     */
    private Integer createOrderStatus;
    /**
     * 逻辑删除 0有效，1被删除；默认0
     */
    private Boolean delFlag;
    /**
     * 服务代码
     */
    @TableField(exist = false)
    private String serverCode;
    /**
     * 服务名称
     */
    @TableField(exist = false)
    private String serverName;

    /**
     * 搜索开始时间
     */
    @TableField(exist = false)
    private String startTime;
    /**
     * 搜索结束时间
     */
    @TableField(exist = false)
    private String endTime;

    /**
     * 增值服务状态
     */
    //支付中  待支付、支付中、支付失败、企业支付申请中
    //待派送  受理中
    //退款中  退款审批完成、退款中、退款审核中、待退款、退款审批不通过、
    //已取消  下单审批不通过、支付超时、已关闭、已退款
    //已完成  订单完成
    @ApiModelProperty(value = "增值服务状态：1支付中，2待派送，3退款中，4已取消，5已完成")
    @TableField(exist = false)
    private String businessStateType;

    @TableField(exist = false)
    private List<String> businessStateTypeList;

    @TableField(exist = false)
    private String companyName;

    /**
     * 是否显示配送记录按钮
     */
    @TableField(exist = false)
    private Boolean allowDeliverySign = false;

    /**
     * 是否显示申请配送按钮
     */
    @TableField(exist = false)
    private Boolean allowApplyDelivery = false;


    /**
     * Entity转Vo
     *
     * @return Vo对象
     * @date 2021-11-04
     */
    public LightAppServerDataVO toVo() {
        LightAppServerDataVO vo = DozerBeanUtil
                .transitionType(this, LightAppServerDataVO.class);
        //状态值翻译
        vo.setBusinessStateVo(BusinessStateEnum.getInfoValue(vo.getBusinessState()));
        vo.setPayWayVo(PayWayEnum.getInfoValue(vo.getPayWay()));
        vo.setSourceVo(SourceEnum.getInfoValue(vo.getSource()));
        vo.setCreateDate(new DateTime(vo.getCreateTime()).toString());
        return vo;
    }

    /**
     * List-Entity转List-Vo
     *
     * @return List-Vo对象
     * @date 2021-11-04
     */
    public List<LightAppServerDataVO> toListVo(List<LightAppServerData> lightAppServerData) {
        List<LightAppServerDataVO> list = new ArrayList<>();
        lightAppServerData.forEach(t -> list.add(t.toVo()));
        return list;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("serverDataId", getServerDataId())
                .append("lightAppId", getLightAppId())
                .append("appMarketTypeCode", getAppMarketTypeCode())
                .append("appLittleType", getAppLittleType())
                .append("serverId", getServerId())
                .append("customerName", getCustomerName())
                .append("customerPhone", getCustomerPhone())
                .append("buyNum", getBuyNum())
                .append("buyMoney", getBuyMoney())
                .append("orderCode", getOrderCode())
                .append("formSetId", getFormSetId())
                .append("formId", getFormId())
                .append("source", getSource())
                .append("content", getContent())
                .append("processId", getProcessId())
                .append("processNodeUser", getProcessNodeUser())
                .append("dataId", getDataId())
                .append("appCode", getAppCode())
                .append("businessState", getBusinessState())
                .append("processState", getProcessState())
                .append("processStartStatus", getProcessStartStatus())
                .append("taskId", getTaskId())
                .append("spaceInfo", getSpaceInfo())
                .append("spaceCode", getSpaceCode())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("companyCode", getCompanyCode())
                .append("remark", getRemark())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

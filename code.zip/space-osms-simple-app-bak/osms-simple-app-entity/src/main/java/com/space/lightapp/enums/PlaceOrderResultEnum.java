package com.space.lightapp.enums;

/**
 * 下单返回状态码
 *
 * @Author Els
 * @date 2021-11-25 17:22
 * @Version 1.0
 */
public enum PlaceOrderResultEnum {
    // 下单返回状态码
    WEIXIN_PAY(0, "微信支付"),
    ORDER_ACCEPT_ING(1, "已提交，受理中"),
    PAY_FAILED(2, "支付异常"),
    COMPANY_PAY_WITH_PROCESS(3, "已提交，待企业管理员审核"),
    SERVER_FAILED(4, "提交失败"),
    COMPANY_PAY_NO_PROCESS(5, "已开始企业支付"),
    VALET_ORDER_PAY_WAIT(6, "订单已提交，待支付"),
    ;
    private Integer code;
    private String info;

    PlaceOrderResultEnum(Integer code, String info) {
        this.code = code;
        this.info = info;
    }

    public Integer getCode() {
        return code;
    }

    public String getInfo() {
        return info;
    }
}

package com.space.lightapp.entity;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.space.lightapp.base.BaseEntity;
import com.space.lightapp.entity.vo.LightAppServerVO;
import com.space.osms.common.core.utils.DozerBeanUtil;
import com.space.osms.common.core.utils.StringUtil;
import io.swagger.annotations.ApiModel;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 服务设置 对象 light_app_server
 *
 * @author ChenYou
 * @date 2021-11-04
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("light_app_server")
@ApiModel(description = "服务设置 ")
public class LightAppServer extends BaseEntity {

    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long serverId;
    /**
     * 轻应用Id
     */
    private Long lightAppId;
    /**
     * 轻应用小分类
     */
    private String appLittleType;
    /**
     * 服务名称
     */
    private String serverName;
    /**
     * 服务代码
     */
    private String serverCode;
    /**
     * 任务中心唯一编码
     */
    private String taskTypeCode;
    /**
     * 服务分类
     */
    private String serverTypeId;
    /**
     * 服务分类名称
     */
    @TableField(exist = false)
    private String serverTypeName;
    /**
     * 服务海报
     */
    private String serverIcon;
    /**
     * 标签提示 1不显示，2免费，3价格面议
     */
    private Integer tagHint;
    /**
     * 商品编号
     */
    private String goodsCode;
    /**
     * 商品名称
     */
    private String goodsName;
    /**
     * 商品详情(存的JSON)
     */
    private String goodsDetail;
    /**
     * 规格
     */
    private String specification;
    /**
     * 单位
     */
    private String unitName;
    /**
     * 是否固定定价 价格类型：1固定定价，2沟通定价
     */
    private Integer priceType;
    /**
     * 标准单价
     */
    private String price;
    /**
     * 咨询电话
     */
    private String hotline;
    /**
     * 计算公式
     */
    private String formula;
    /**
     * 图片 多个图片用英文逗号隔开
     */
    private String photoList;
    /**
     * 服务状态 draft草稿，upLine上架，downLine下架
     */
    private String serverState;
    /**
     * 服务内容是否开启 0不开启，1开启；默认开启
     */
    private Boolean openContent;
    /**
     * 服务内容
     */
    private String serverContent;
    /**
     * 常见问题是否开启 0不开启，1开启；默认开启
     */
    private Boolean openIssue;
    /**
     * 常见问题
     */
    private String issue;
    /**
     * 排序 排序字段
     */
    private Integer orderNum;
    /**
     * 是否禁用 0禁用，1启用；默认1
     */
    private Boolean status;
    /**
     * 备注
     */
    private String remark;
    /**
     * 逻辑删除 0有效，1被删除；默认0
     */
    private Boolean delFlag;

    /**
     * Entity转Vo
     *
     * @return Vo对象
     * @date 2021-11-04
     */
    public LightAppServerVO toVo() {
        LightAppServerVO lightAppServerVO = DozerBeanUtil.transitionType(this, LightAppServerVO.class);
        lightAppServerVO.setServerIconList(StringUtil.stringToList(this.getServerIcon()));
        lightAppServerVO.setPhotoLists(StringUtil.stringToList(this.getPhotoList()));
        if (StrUtil.isBlank(lightAppServerVO.getGoodsCode())) {
            lightAppServerVO.setGoodsCode(lightAppServerVO.getServerCode());
        }
        lightAppServerVO.setUpdateUser(lightAppServerVO.getUpdateBy());
        lightAppServerVO
                .setCreateDate(new DateTime(lightAppServerVO.getCreateTime()).toString());
        lightAppServerVO.setStatusVo(lightAppServerVO.getStatus() ? "下架" : "上架");
        return lightAppServerVO;
    }

    /**
     * List-Entity转List-Vo
     *
     * @return List-Vo对象
     * @date 2021-11-04
     */
    public List<LightAppServerVO> toListVo(List<LightAppServer> lightAppServer) {
        List<LightAppServerVO> list = new ArrayList<>();
        lightAppServer.forEach(t -> list.add(t.toVo()));
        return list;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("serverId", getServerId())
                .append("serverName", getServerName())
                .append("serverCode", getServerCode())
                .append("taskTypeCode", getTaskTypeCode())
                .append("serverTypeId", getServerTypeId())
                .append("serverIcon", getServerIcon())
                .append("tagHint", getTagHint())
                .append("goodsCode", getGoodsCode())
                .append("goodsName", getGoodsName())
                .append("specification", getSpecification())
                .append("unitName", getUnitName())
                .append("priceType", getPriceType())
                .append("price", getPrice())
                .append("hotline", getHotline())
                .append("formula", getFormula())
                .append("photoList", getPhotoList())
                .append("serverState", getServerState())
                .append("openContent", getOpenContent())
                .append("serverContent", getServerContent())
                .append("openIssue", getOpenIssue())
                .append("issue", getIssue())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("companyCode", getCompanyCode())
                .append("remark", getRemark())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

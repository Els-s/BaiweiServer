package com.space.lightapp.entity.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.io.Serializable;
import java.util.Date;

@Data
@ApiModel(description = "应用服务 ")
public class FormInstRelDTO implements Serializable {

    /**
     * 主键：关联关系ID
     */
    @ApiModelProperty(value = "主键：关联关系ID")
    private Long relId;

    private String instId; //实例ID
    private String alisa; //表单别名
    private String dataId; //数据ID
    private String userPhone; //报单人-手机号
    private String userCode; //报单人-用户编码
    private String appMarkTypeCode; //应用类型
    private String createBy; //
    private Date createTime; //创建人
    private Date updateTime; //更新时间

}



package com.space.lightapp.entity.vo;

import com.space.lightapp.base.BaseVO;
import com.space.lightapp.entity.PushInformationSet;
import com.space.lightapp.entity.vo.message.InfoManageVO;
import com.space.osms.common.core.utils.DozerBeanUtil;
import com.space.osms.common.core.utils.ListUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 发布资讯 Vo对象 push_information_set
 *
 * @author ChenYou
 * @date 2021-10-29
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = "发布资讯 ")
@Accessors(chain = true)
public class PushInformationSetVO extends BaseVO {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    private Long informationSetId;
    /**
     * 轻应用Id
     */
    @ApiModelProperty(value = "轻应用Id")
    private Long lightAppId;
    /**
     * 消息id
     */
    private Long messageId;
    /**
     * 是否推送到消息中心：0否 1是
     */
    private Integer pushMessage;
    /**
     * 应用服务类型代码
     */
    @ApiModelProperty(value = "应用服务类型代码")
    private String appMarketTypeCode;
    /**
     * 关联Id
     */
    @ApiModelProperty(value = "关联Id")
    private Long relevancyId;
    /**
     * 发布渠道 发布渠道  key  value 微信小程序（物业运营） OPERATOR_MANAGE APP  APP
     */
    @ApiModelProperty(value = "发布渠道 发布渠道  key  value 微信小程序（物业运营） OPERATOR_MANAGE APP  APP")
    private String releaseChannel;


    @ApiModelProperty(value = "发布位置 发布位置 多选时List<String>数组 目前只需要单选")
    private List<String> releaseLocations;
    /**
     * 发布范围--
     */
    @ApiModelProperty(value = "发布范围--")
    private List<String> projectCodes;
    /**
     * 资讯封面
     */
    @ApiModelProperty(value = "资讯封面")
    private List<String> coverUrls;

    /**
     * 是否长期 是否长期  0否 1是
     */
    @ApiModelProperty(value = "是否长期 是否长期  0否 1是")
    private Integer longTerm;
    /**
     * 发布时间
     */
    @ApiModelProperty(value = "发布时间")
    private Date releaseTime;
    /**
     * 到期时间
     */
    @ApiModelProperty(value = "到期时间")
    private Date endTime;
    /**
     * 资讯标题
     */
    @ApiModelProperty(value = "资讯标题")
    private String infoTitle;
    /**
     * 资讯来源
     */
    @ApiModelProperty(value = "资讯来源")
    private String infoResouse;
    /**
     * 分享导语
     */
    @ApiModelProperty(value = "分享导语")
    private String sharingLead;
    /**
     * 资讯形式 资讯形式 0:文章 1:链接
     */
    @ApiModelProperty(value = "资讯形式 资讯形式 0:文章 1:链接")
    private Integer infoForm;
    /**
     * 上架状态 0上架 1下架 2待上架
     */
    @ApiModelProperty(value = "上架状态 0上架 1下架 2待上架")
    private Integer shelfStatus;
    /**
     * 展示样式 （0无图模式,1小图模式,2大图模式,3三图模式）
     */
    @ApiModelProperty(value = "展示样式 （0无图模式,1小图模式,2大图模式,3三图模式）")
    private Integer showType;
    /**
     * 资讯标签--
     */
    @ApiModelProperty(value = "资讯标签--")
    private String infoTag;

    /**
     * 发布内容/链接路径 资讯内容/链接路径 根据资讯形式来存储
     */
    @ApiModelProperty(value = "发布内容/链接路径 资讯内容/链接路径 根据资讯形式来存储")
    private String infoContent;
    /**
     * 附件url
     */
    @ApiModelProperty(value = "附件url")
    private String attachmentUrls;
    /**
     * 排序 排序字段
     */
    @ApiModelProperty(value = "排序 排序字段")
    private Integer orderNum;
    /**
     * 是否禁用 0禁用，1启用；默认1
     */
    @ApiModelProperty(value = "是否禁用 0禁用，1启用；默认1")
    private Boolean status;
    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String remark;

    /**
     * Vo转Entity
     *
     * @return Entity对象
     * @date 2021-10-29
     */
    public PushInformationSet toEntity() {
        PushInformationSet pushInformationSet = DozerBeanUtil
                .transitionType(this, PushInformationSet.class);
        pushInformationSet.setProjectCodeList(ListUtil.listToString(this.getProjectCodes()));
        pushInformationSet.setCoverUrlList(ListUtil.listToString(this.getCoverUrls()));
        pushInformationSet
                .setReleaseLocationList(ListUtil.listToString(this.getReleaseLocations()));
        return pushInformationSet;
    }

    /**
     * Entity转Vo
     *
     * @return Vo对象
     * @date 2021-10-29
     */
    public InfoManageVO toMessageVo() {
        InfoManageVO infoManageVO = DozerBeanUtil
                .transitionType(this, InfoManageVO.class);
        infoManageVO.setProjectCodes(this.getProjectCodes());
        infoManageVO.setCoverUrls(this.getCoverUrls());
        infoManageVO
                .setReleaseLocations(this.getReleaseLocations());
        return infoManageVO;
    }

    /**
     * List-Vo转List-Entity
     *
     * @return List-Entity对象
     * @date 2021-10-29
     */
    public List<PushInformationSet> toListEntity(List<PushInformationSetVO> pushInformationSetVo) {
        List<PushInformationSet> list = new ArrayList<>();
        pushInformationSetVo.forEach(t -> list.add(t.toEntity()));
        return list;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("informationSetId", getInformationSetId())
                .append("lightAppId", getLightAppId())
                .append("appMarketTypeCode", getAppMarketTypeCode())
                .append("relevancyId", getRelevancyId())
                .append("releaseChannel", getReleaseChannel())
                .append("releaseLocations", getReleaseLocations())
                .append("projectCodes", getProjectCodes())
                .append("longTerm", getLongTerm())
                .append("releaseTime", getReleaseTime())
                .append("endTime", getEndTime())
                .append("infoTitle", getInfoTitle())
                .append("infoResouse", getInfoResouse())
                .append("sharingLead", getSharingLead())
                .append("infoForm", getInfoForm())
                .append("shelfStatus", getShelfStatus())
                .append("showType", getShowType())
                .append("tag", getInfoTag())
                .append("coverUrls", getCoverUrls())
                .append("infoContent", getInfoContent())
                .append("attachmentUrls", getAttachmentUrls())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("companyCode", getCompanyCode())
                .append("remark", getRemark())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .toString();
    }

}

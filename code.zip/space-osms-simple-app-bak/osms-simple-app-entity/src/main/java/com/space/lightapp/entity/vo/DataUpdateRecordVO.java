package com.space.lightapp.entity.vo;

import com.alibaba.fastjson.JSONObject;
import com.space.lightapp.base.BaseVO;
import com.space.lightapp.entity.DataUpdateRecord;
import com.space.osms.common.core.utils.DozerBeanUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * 数据修改记录
 *
 * @Author ChenYou
 * @date 2021-12-29 14:19
 * @Version 1.0
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(description = "修改记录")
public class DataUpdateRecordVO extends BaseVO {

    public DataUpdateRecordVO() {
    }

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    private Long dataUpdateId;
    /**
     * 应用Id
     */
    @ApiModelProperty(value = "应用Id")
    private Long lightAppId;
    /**
     * 修改目标表名称
     */
    @ApiModelProperty(value = "修改目标表名称")
    private String tableName;
    /**
     * 修改表主键
     */
    @ApiModelProperty(value = "修改表主键")
    private Long tablePrimaryKey;
    /**
     * 修改理由
     */
    @ApiModelProperty(value = "修改理由")
    private String updateReason;
    /**
     * 原数据
     */
    @ApiModelProperty(value = "原数据")
    private JSONObject originalData;
    /**
     * 修改后的数据
     */
    @ApiModelProperty(value = "修改后的数据")
    private JSONObject changeData;
    /**
     * 状态 0-false-禁用，1-true-启用；默认1-true
     */
    @ApiModelProperty(value = "状态 0-false-禁用，1-true-启用；默认1-true")
    private Boolean status;
    /**
     * 是否删除  0-false-未删除，1-true-删除；默认0-false
     */
    @ApiModelProperty(value = "是否删除  0-false-未删除，1-true-删除；默认0-false")
    private Boolean delFlag;

    /**
     * Vo转Entity
     *
     * @return Entity对象
     * @date 2021-09-27
     */
    public DataUpdateRecord toEntity() {
        DataUpdateRecord record = DozerBeanUtil.transitionType(this, DataUpdateRecord.class);
        return record;
    }

    /**
     * List-Vo转List-Entity
     *
     * @return List-Entity对象
     * @date 2021-09-27
     */
    public List<DataUpdateRecord> toListEntity(List<DataUpdateRecordVO> recordVOS) {
        List<DataUpdateRecord> list = new ArrayList<>();
        recordVOS.forEach(t -> list.add(t.toEntity()));
        return list;
    }
}

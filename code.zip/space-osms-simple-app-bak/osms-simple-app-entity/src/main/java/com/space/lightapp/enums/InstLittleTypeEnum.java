package com.space.lightapp.enums;

/**
 * base数据表子类型
 *
 * @Author Els
 * @date 2021-11-16 20:41
 * @Version 1.0
 */
public enum InstLittleTypeEnum {
    // 子类流程类别
    RE_FUND("reFund", "退款"),

    COMPANY_PAY("companyPay", "周期结算"),

    PLACE_ORDER("placeOrder", "订单服务"),

    PAY_SERVER_SERVER_OFFLINE_FORM("serverOffLineForm", "服务发布线下交易表单数据"),

    ;
    private String code;
    private String info;

    InstLittleTypeEnum(String code, String info) {
        this.code = code;
        this.info = info;
    }

    public String getCode() {
        return code;
    }

    public String getInfo() {
        return info;
    }

    public static InstLittleTypeEnum getEnumByCode(String code) {
        InstLittleTypeEnum[] values = InstLittleTypeEnum.values();
        for (InstLittleTypeEnum value : values) {
            if (value.getCode().equalsIgnoreCase(code)) {
                return value;
            }
        }
        return null;
    }
}

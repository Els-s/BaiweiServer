package com.space.lightapp.entity.vo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.space.lightapp.base.HandleTypeVO;
import com.space.lightapp.entity.LightAppServerData;
import com.space.lightapp.entity.LightAppServerDataDelivery;
import com.space.osms.common.core.utils.DozerBeanUtil;
import com.space.osms.common.file.annotation.Excel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 填答服务数据 Vo对象 light_app_server_data
 *
 * @author ChenYou
 * @date 2021-11-04
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = "填答服务数据 ")
public class LightAppServerDataVO extends HandleTypeVO {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键", required = true)
    private Long serverDataId;
    /**
     * 轻应用Id
     */
    @ApiModelProperty(value = "轻应用Id")
    private Long lightAppId;
    /**
     * 轻应用模块Id
     */
    @ApiModelProperty(value = "轻应用模块Id")
    private Long lightAppModuleId;
    /**
     * 轻应用类型
     */
    @ApiModelProperty(value = "轻应用类型")
    private String appMarketTypeCode;
    /**
     * 外部的订单接口
     */
    @Excel(name = "内部订单号", sort = 2)
    @ApiModelProperty(value = "外部的订单接口")
    private String extOrderCode;
    /**
     * 轻应用小分类
     */
    @ApiModelProperty(value = "轻应用小分类", required = true)
    private String appLittleType;
    /**
     * 服务Id
     */
    @ApiModelProperty(value = "服务Id")
    private Long serverId;
    /**
     * openId
     */
    @ApiModelProperty(value = "openId")
    private String openId;
    /**
     * 是否订阅:未订阅 已订阅
     */
    @ApiModelProperty(value = "是否订阅:未订阅 已订阅")
    private String subscribe;
    /**
     * 客户姓名
     */
    @Excel(name = "客户姓名", sort = 3)
    @ApiModelProperty(value = "客户姓名", required = true)
    private String customerName;
    /**
     * 手机号码
     */
    @Excel(name = "手机号码", sort = 4)
    @ApiModelProperty(value = "手机号码", required = true)
    private String customerPhone;
    /**
     * 企业地址
     */
    @ApiModelProperty(value = "企业地址", required = true)
    private String customerAddress;
    /**
     * 收货地址详情JSON
     */
    @ApiModelProperty(value = "收货地址详情JSON")
    private String receiveDetail;
    /**
     * 订单总价
     */
    @ApiModelProperty(value = "订单总价")
    private String orderMoney;
    /**
     * 结算方式
     */
    @ApiModelProperty(value = "结算方式：cashPay 现结，companyPay 企业周期结算", required = true)
    private String payWay;
    @Excel(name = "结算方式", sort = 7)
    @ApiModelProperty(value = "结算方式：cashPay 现结，companyPay 企业周期结算", required = true)
    private String payWayVo;
    /**
     * 支付方式(1线上支付，2线下支付)
     */
    @ApiModelProperty(value = "支付方式：1线上支付，2线下支付")
    private String paymentWay;
    /**
     * 支付企业
     */
    @ApiModelProperty(value = "支付企业")
    private String payCompany;
    /**
     * 购买数量
     */
    @Excel(name = "购买数量", sort = 8)
    @ApiModelProperty(value = "购买数量")
    private Long buyNum;
    /**
     * 退款数量（包含完成和进行中）
     */
    @Excel(name = "退款数量", sort = 9)
    @ApiModelProperty(value = "退款数量（包含完成和进行中）")
    private Long refundNum;

    public Long getDeliveryNum() {
        if (null == deliveryNum) {
            return 0L;
        } else {
            return deliveryNum;
        }
    }

    public Long getRefundNum() {
        if (null == refundNum) {
            return 0L;
        } else {
            return refundNum;
        }
    }

    /**
     * 服务/配送数量（包含完成和进行中）
     */
    @Excel(name = "服务数量", sort = 10)
    @ApiModelProperty(value = "服务/配送数量（包含完成和进行中）")
    private Long deliveryNum;
    /**
     * 服务/未配送数量
     */
    @ApiModelProperty(value = "服务/未配送数量")
    @TableField(exist = false)
    private Long unDeliveryNum;
    /**
     * 服务时长
     */
    @ApiModelProperty(value = "服务时长:非服务类的传1", required = true)
    private Integer duration;
    /**
     * 规格
     */
    @ApiModelProperty(value = "规格")
    private String specification;
    /**
     * 计算公式
     */
    @ApiModelProperty(value = "计算公式")
    private String formula;
    /**
     * 应付金额
     */
    @Excel(name = "应付金额", sort = 11)
    @ApiModelProperty(value = "应付金额")
    private String buyMoney;
    /**
     * 单据编码
     */
    @ApiModelProperty(value = "单据编码")
    private String orderCode;
    /**
     * 表单设置Id
     */
    @ApiModelProperty(value = "表单设置Id")
    private String formSetId;
    /**
     * 表单Id
     */
    @ApiModelProperty(value = "表单Id")
    private String formId;
    /**
     * 单据来源 1内部单，2客户下单，3代客下单
     */
    @ApiModelProperty(value = "单据来源 1内部单，2客户下单，3代客下单", required = true)
    private Integer source;

    @Excel(name = "单据来源", sort = 1)
    @ApiModelProperty(value = "单据来源 1内部单，2客户下单，3代客下单", required = true)
    private String sourceVo;
    /**
     * 工单内容
     */
    @ApiModelProperty(value = "工单内容")
    private String content;
    /**
     * 流程Id
     */
    @ApiModelProperty(value = "流程Id")
    private String processId;
    /**
     * 流程实例ID
     */
    @ApiModelProperty(value = "流程实例ID")
    private String processInsId;
    /**
     * 当前节点处理人
     */
    @Excel(name = "当前跟进人", sort = 13)
    @ApiModelProperty(value = "当前节点处理人")
    private String processNodeUser;
    /**
     * 对应数据Id 关联实际填答数据
     */
    @ApiModelProperty(value = "对应数据Id 关联实际填答数据")
    private String dataId;
    /**
     * 应用编码
     */
    @ApiModelProperty(value = "应用编码")
    private String appCode;
    /**
     * 业务状态 1待审核，2待支付，3不通过，4待支付,5退款中,6已完成
     */

    @ApiModelProperty(value = "业务状态")
    private String businessState;
    @Excel(name = "订单状态", sort = 12)
    @ApiModelProperty(value = "业务状态Vo")
    private String businessStateVo;

    /**
     * 工单状态 工单状态（1待受理，2处理中，3已完成，4已关闭，5待回访，6已取消）
     */
    @ApiModelProperty(value = "工单状态 工单状态（1待受理，2处理中，3已完成，4已关闭，5待回访，6已取消）")
    private Integer processState;
    /**
     * 流程启动结果 流程启动结果，1-启动成功，-1-启动失败，0-未启动流程
     */
    @ApiModelProperty(value = "流程启动结果 流程启动结果，1-启动成功，-1-启动失败，0-未启动流程")
    private Integer processStartStatus;
    /**
     * 任务Id
     */
    @ApiModelProperty(value = "任务Id")
    private String taskId;
    /**
     * 空间地址信息
     */
    @ApiModelProperty(value = "空间地址信息")
    private String spaceInfo;
    /**
     * 空间地址信息编码
     */
    @ApiModelProperty(value = "空间地址信息编码")
    private String spaceCode;
    /**
     * 排序 排序字段
     */
    @ApiModelProperty(value = "排序 排序字段")
    private Integer orderNum;
    /**
     * 是否禁用 0禁用，1启用；默认1
     */
    @ApiModelProperty(value = "是否禁用 0禁用，1启用；默认1")
    private Boolean status;
    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty(value = "服务分类ID")
    private String serverTypeId;
    /**
     * 服务代码
     */
//  @Excel(name = "商品编码", sort = 7)
    @ApiModelProperty(value = "服务代码", required = true)
    private String serverCode;
    /**
     * 服务名称
     */
    @Excel(name = "商品名称", sort = 6)
    @ApiModelProperty(value = "服务名称", required = true)
    private String serverName;

    /**
     * 结算状态
     */
    @ApiModelProperty(value = "结算状态")
    private Integer taxStatus;
    /**
     * 订单信息
     */
    @ApiModelProperty(value = "订单信息")
    private LightAppServerDataDetailVO orderDetail;
    /**
     * 支付信息
     */
    @ApiModelProperty(value = "支付信息")
    private LightAppServerDataDetailVO payDetail;
    /**
     * 退款信息
     */
    @ApiModelProperty(value = "退款信息")
    private LightAppServerDataDetailVO reFundDetail;
    /**
     * 推送结算信息
     */
    @ApiModelProperty(value = "推送结算信息")
    private LightAppServerDataDetailVO taxDetail;
    /**
     * 配送时间
     */
    private String sendTime;

    @ApiModelProperty(value = "服务类型名称")
    private String serverTypeName;

    @ApiModelProperty(value = "表单数据")
    private String formJson;
    @ApiModelProperty(value = "咨询电话")
    private String hotline;

    @Excel(name = "创建时间", sort = 14)
    private String createDate;

    private String alias;

    @ApiModelProperty(value = "C端用户展示流程")
    private String userProcessInstId;

    /**
     * 搜索开始时间
     */
    @ApiModelProperty(value = "搜索开始时间")
    private String startTime;
    /**
     * 搜索结束时间
     */
    @ApiModelProperty(value = "搜索结束时间")
    private String endTime;

    @Excel(name = "所属企业", sort = 5)
    @ApiModelProperty(value = "企业名称")
    private String companyName;

    /**
     * 订单中心创建订单结果 1-创建成功，-1-创建失败，0-未创建
     */
    private Integer createOrderStatus;

    /**
     * 增值服务状态
     */
    //支付中  待支付、支付中、支付失败、企业支付申请中
    //待派送  受理中
    //退款中  退款审批完成、退款中、退款审核中、待退款、退款审批不通过、
    //已取消  下单审批不通过、支付超时、已关闭、已退款
    //已完成  订单完成
    @ApiModelProperty(value = "增值服务状态：1支付中，2待派送，3退款中，4已取消，5已完成")
    private String businessStateType;

    private List<String> businessStateTypeList;

    private String payRemark;

    @ApiModelProperty(value = "是否显示配送记录按钮")
    @TableField(exist = false)
    private Boolean allowDeliverySign = false;

    @ApiModelProperty(value = "是否显示申请配送按钮")
    @TableField(exist = false)
    private Boolean allowApplyDelivery = false;

    @ApiModelProperty(value = "是否显示申请配送按钮")
    private LightAppServerDataDelivery deliverVo;

    /**
     * Vo转Entity
     *
     * @return Entity对象
     * @date 2021-11-04
     */
    public LightAppServerData toEntity() {
        return DozerBeanUtil.transitionType(this, LightAppServerData.class);
    }


    /**
     * List-Vo转List-Entity
     *
     * @return List-Entity对象
     * @date 2021-11-04
     */
    public List<LightAppServerData> toListEntity(List<LightAppServerDataVO> lightAppServerDataVo) {
        List<LightAppServerData> list = new ArrayList<>();
        lightAppServerDataVo.forEach(t -> list.add(t.toEntity()));
        return list;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("serverDataId", getServerDataId())
                .append("lightAppId", getLightAppId())
                .append("appMarketTypeCode", getAppMarketTypeCode())
                .append("appLittleType", getAppLittleType())
                .append("serverId", getServerId())
                .append("customerName", getCustomerName())
                .append("customerPhone", getCustomerPhone())
                .append("buyNum", getBuyNum())
                .append("buyMoney", getBuyMoney())
                .append("orderCode", getOrderCode())
                .append("formSetId", getFormSetId())
                .append("formId", getFormId())
                .append("source", getSource())
                .append("content", getContent())
                .append("processId", getProcessId())
                .append("processNodeUser", getProcessNodeUser())
                .append("dataId", getDataId())
                .append("appCode", getAppCode())
                .append("businessState", getBusinessState())
                .append("processState", getProcessState())
                .append("processStartStatus", getProcessStartStatus())
                .append("taskId", getTaskId())
                .append("spaceInfo", getSpaceInfo())
                .append("spaceCode", getSpaceCode())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("companyCode", getCompanyCode())
                .append("remark", getRemark())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .toString();
    }
}

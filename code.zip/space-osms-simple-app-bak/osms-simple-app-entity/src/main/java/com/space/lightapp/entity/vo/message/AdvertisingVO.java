package com.space.lightapp.entity.vo.message;

import cn.hutool.core.date.DatePattern;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;
import lombok.Data;
import lombok.experimental.Accessors;
import org.springframework.format.annotation.DateTimeFormat;


/**
 * @author JiangHao
 * @version 1.0
 * @date 2021/11/22 0018 17:32
 * @description 广告表
 */
@Data
@Accessors(chain = true)
public class AdvertisingVO implements Serializable {

    /**
     * {"advertisingChannel":"YYL-02",
     * "advertisingName":"测试1",
     * "newsType":0,
     * "jumpType":4,
     * "showOrder":1,
     * "jumpUrl":294,
     * "imgUrl":"https://spacebusiness.oss-cn-beijing.aliyuncs.com/infoMessageClient//20211111113937438.jpg",
     * "projectCodeList":["ZH_00001_XM_00000001"],
     * "effectDate":"2021-11-11 00:00:00",
     * "endDate":"2021-11-12 00:00:00",
     * "remark":"222",
     * "channelRelBusinessEntities":[{"showOrder":1,"statusType":"YYL-02"}]}
     * @param pushAdvertisingSetVo 广告数据
     * @param authorization
     */

    /**
     * {
     *     "id": 142,
     *     "channelId": null,
     *     "advertisingChannel": "YYL-02",
     *     "advertisingChannelStr": "微信小程序（运营类-02）",
     *     "projectReleaseType": null,
     *     "projectCode": null,
     *     "projectCodeList": [
     *         "ZH_00001_XM_00000001"
     *     ],
     *     "projectNameStr": "科兴科学园",
     *     "projectNameList": null,
     *     "newsType": 0,
     *     "newsTypeStr": "首页banner",
     *     "effectDate": "2021-11-11 16:20:45",
     *     "effectDateStr": "2021-11-11 16:20:45",
     *     "endDate": "2021-11-22 00:00:00",
     *     "endDateStr": "2021-11-19 00:00:00",
     *     "longTerm": "0",
     *     "advertisingName": "测试2233",
     *     "imgUrl": "https://spacebusiness.oss-cn-beijing.aliyuncs.com/infoMessageClient//20211111152740452.jpg",
     *     "jumpType": 4,
     *     "jumpTypeStr": "园区咨讯详情",
     *     "jumpUrl": 294,
     *     "jumpUrlProjectName": null,
     *     "appId": null,
     *     "remark": "222",
     *     "shelfStatus": 1,
     *     "shelfStatusStr": "已下架",
     *     "createPersonCode": "730e843edb544d31945ad20a4381574b",
     *     "updatePersonCode": "6df7eb4bbf574eacac055c9c52a33ffa",
     *     "updatePersonName": null,
     *     "createTime": 1636615670000,
     *     "updateTime": 1636709303000,
     *     "updateTimeStr": "2021-11-12 17:28:23",
     *     "showOrder": 1,
     *     "editFlag": null,
     *     "channelRelBusinessEntities": [
     *         {
     *             "showOrder": 1,
     *             "statusType": "YYL-02"
     *         }
     *     ]
     * }
     */

    /**
     * 主键
     */
    private Long id;

    /**
     * 租户编码
     */
    private String tenementCode;

    /**
     * 发布渠道 : 1全民 2中介 4运营
     */
    @ApiModelProperty(value = "发布渠道", required = true)
    private String advertisingChannel;

    /**
     * 广告名称
     */
    @ApiModelProperty(value = "广告名称", required = true)
    private String advertisingName;

    /**
     * 广告类型 0 banner、1 首页、2 详情页
     */
    @ApiModelProperty(value = "发布位置", required = true)
    private Integer newsType;

    /**
     * 广告跳转类型；0 项目详情、1 H5页面、2 外部小程序、3 无、4 园区咨讯详情、5 园区公告详情
     */
    @ApiModelProperty(value = "跳转链接类型；0 项目详情、1 H5页面、2 外部小程序、3 无、4 园区咨询详情、5 园区公告详情", required = true)
    private Integer jumpType;


    /**
     * 广告跳转地址 (项目类型：传项目code,H5类型传小程序链接,外部小程序传外部小程序的链接和appid) （园区咨询详情、园区公告详情 直接传资讯id）
     */
    @ApiModelProperty(value = "跳转地址信息，根据 jumpType 区分", required = false)
    private String jumpUrl;

    /**
     * 广告图片地址
     */
    @ApiModelProperty(value = "广告图片", required = true)
    private String imgUrl;

    /**
     * 生效时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "开始时间", required = true)
    private Timestamp effectDate;

    /**
     * 结束时间
     */
    @JsonFormat(locale = "zh", timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm")
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @ApiModelProperty(value = "结束时间", required = false)
    private Timestamp endDate;

    /**
     * 部分项目的code
     */
    @ApiModelProperty(value = "发布范围", required = false)
    private List<String> projectCodeList;


    /**
     * 备注说明
     */
    @ApiModelProperty(value = "备注说明", required = false)
    private String remark;


    /**
     * 发布渠道上下架
     */
    private String channelRelBusiness;
    private List<ChannelRelBusinessVO> channelRelBusinessEntities;


    /*              以上是添加字段                                 */


    /**
     * 【运营类】发布渠道列表，需要进行项目隔离
     */
    private List<String> operatorReleaseChannelList;

    /**
     * 【招商类】发布渠道列表
     */
    private List<String> merchantReleaseChannelList;

    /**
     * 小程序的类型：0招商类，运营类1
     */
    @ApiModelProperty(value = "发布渠道类型；", required = true)
    private Integer style;


    /**
     * 是否长期  0否 1是
     */
    @ApiModelProperty(value = "是否长期；0否，1是", required = false)
    private Integer longTerm;


    /**
     * 广告跳转的appId
     */
    @ApiModelProperty(value = "jumpType=2时", required = false)
    private String appId;

    /**
     * 广告排序
     */
    @ApiModelProperty(value = "广告排序", required = true)
    private Integer sortIndex;


    /**
     * 1更新时间 3生效时间 4客户端顺序
     */
    private Integer fieldType;

    /**
     * 倒序：0 正序：1
     */
    private String sortOrder;

    /**
     * 排序字段
     */
    private String sortField;

    private String projectCode;

    /**
     * 上架状态 上架为0、已下架1  待上架2
     */
    private Integer shelfStatus;

    /**
     * 排序
     */
    private Integer showOrder;

}

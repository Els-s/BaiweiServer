package com.space.lightapp.entity.vo.query;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

/**
 * 活动详情按钮展示
 *
 * @Author Jianghao
 * @date 2021-12-16 17:22
 * @Version 1.0
 */
@Data
@AllArgsConstructor
@Builder
public class ActivityButtonVO {

    @ApiModelProperty(value = "是否报名人数已达上线")
    private Boolean allowApplyOver;
    @ApiModelProperty(value = "是否报名已结束")
    private Boolean applyEnd;
    @ApiModelProperty(value = "不可报名")
    private Boolean allowNoApply;
    @ApiModelProperty(value = "可以报名")
    private Boolean allowApply;
    @ApiModelProperty(value = "查看提交报名记录")
    private Boolean allowCommitApplyRecord;
    /*@ApiModelProperty(value = "需要支付")
    private Boolean allowPay;*/
    @ApiModelProperty(value = "扫描签到")
    private Boolean scanSign;
    @ApiModelProperty(value = "已签到")
    private Boolean alreadySign;

    public ActivityButtonVO() {
        this.allowApplyOver = false;
        this.applyEnd = false;
        this.allowNoApply = false;
        this.allowApply = false;
        this.allowCommitApplyRecord = false;
        this.scanSign = false;
        this.alreadySign = false;
    }
}

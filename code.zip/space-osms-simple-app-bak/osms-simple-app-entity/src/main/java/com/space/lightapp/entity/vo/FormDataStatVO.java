package com.space.lightapp.entity.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 表单统计结果数据
 *
 * @Author ChenYou
 * @date 2021-10-22 10:24
 * @Version 1.0
 */
@Data
@ApiModel(description = "统计返回对象")
public class FormDataStatVO {

    /**
     * 全部
     */
    @ApiModelProperty(value = "全部")
    private Long allNum;
    /**
     * 待受理
     */
    @ApiModelProperty(value = "待受理")
    private Long waitingNum;
    /**
     * 处理中
     */
    @ApiModelProperty(value = "处理中")
    private Long hangDingNum;
    /**
     * 已回访
     */
    @ApiModelProperty(value = "已回访")
    private Long visitNum;
    /**
     * 已办结
     */
    @ApiModelProperty(value = "已办结")
    private Long closedNum;
    /**
     * 已取消
     */
    @ApiModelProperty(value = "已取消")
    private Long cancelNum;


}

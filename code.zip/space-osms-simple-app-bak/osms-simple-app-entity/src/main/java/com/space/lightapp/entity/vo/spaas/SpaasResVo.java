package com.space.lightapp.entity.vo.spaas;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * spaas回包格式
 */
@Getter
@Setter
public class SpaasResVo implements Serializable {

    private Boolean success;// spaas 返回
    private String code;
    private String msg;
    private String message; // spaas 返回
    private Object data;

}

package com.space.lightapp.entity.vo.order;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * 商品信息
 *
 * @Author Els
 * @date 2021-11-17 15:31
 * @Version 1.0
 */
@Data
@Accessors(chain = true)
public class OrderDetailVO {

    @ApiModelProperty(value = "商品编码", required = true)
    private String goodsCode;
    @ApiModelProperty(value = "商品名称", required = true)
    private String goodsName;
    @ApiModelProperty(value = "商品规格")
    private List<JSONObject> specifications;
    @ApiModelProperty(value = "商品规格编码")
    private String specificationCode;
    @ApiModelProperty(value = "商品规格名称")
    private String specificationName;
    @ApiModelProperty(value = "费项编码")
    private String feeInternalCode;
    @ApiModelProperty(value = "数量")
    private String count;
    @ApiModelProperty(value = "单价", required = true)
    private String unitPrice;
    @ApiModelProperty(value = "时长")
    private String duration;
    @ApiModelProperty(value = "公式字段值")
    private List<FormulaFieldVO> formulaFieldVOList;
    private String personChannelCode;
    /**
     * 商品图片信息
     */
    private JSONArray photoList;
}

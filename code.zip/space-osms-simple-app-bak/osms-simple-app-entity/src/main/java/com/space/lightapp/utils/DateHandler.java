package com.space.lightapp.utils;

import com.space.osms.common.core.utils.DateUtil;

/**
 * 时间工具(时间工具类适配handler)
 *
 * @date 2022-02-10
 * @Version 1.0
 */
public class DateHandler {

    /**
     * 获取过去天数。
     *
     * @param dataType 0：无，1：本日，2：近三天，3：近七天，4：近三十天，5：近3月，6：近期一年
     */
    public static String getPastDateByIntType(int dataType) {
        String startDate = "";
        if (dataType > 0) {
            switch (dataType) {
                case 1:
                    //1:本日
                    startDate = DateUtil.getPastDate(0);
                    break;
                case 2:
                    //近3日
                    startDate = DateUtil.getPastDate(3);
                    break;
                case 3:
                    //近7天
                    startDate = DateUtil.getPastDate(7);
                    break;
                case 4:
                    //近30日
                    startDate = DateUtil.getPastDate(30);
                    break;
                case 5:
                    //近3月
                    startDate = DateUtil.stepDay(-3, 0);
                    break;
                case 6:
                    //今年
                    startDate = DateUtil.getPastDate(365);
                    break;
                default:
                    break;
            }
        }
        return startDate;
    }
}

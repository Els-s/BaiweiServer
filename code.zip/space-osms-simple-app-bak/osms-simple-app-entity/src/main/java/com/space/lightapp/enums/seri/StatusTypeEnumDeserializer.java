package com.space.lightapp.enums.seri;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.space.lightapp.enums.ActivityEnum;

import java.io.IOException;

public class StatusTypeEnumDeserializer extends StdDeserializer<ActivityEnum.StatusType> {

    public StatusTypeEnumDeserializer() {
        super(ActivityEnum.ActivityStatus.class);
    }

    @Override
    public ActivityEnum.StatusType deserialize(JsonParser jp, DeserializationContext dc)
            throws IOException, JsonProcessingException {
        final JsonNode jsonNode = jp.readValueAsTree();
        String code = jsonNode.get("code").asText();
        String name = jsonNode.get("name").asText();

        for (ActivityEnum.StatusType e : ActivityEnum.StatusType.values()) {
            if (e.getCode().equals(code) && e.getName().equals(name)) {
                return e;
            }
        }
        throw dc.mappingException("Cannot deserialize MyEnum from key " + code + " and value " + name);
    }
}

package com.space.lightapp.enums;

/**
 * 配送方式枚举
 *
 * @Author ChenYou
 * @date 2022-02-08
 * @Version 1.0
 */
public enum DeliveryWayEnum {
    //配送方式
    ONCE("once", "一次配送"),
    MULTIPLE("multiple", "多次配送");

    private String code;
    private String info;

    DeliveryWayEnum(String code, String info) {
        this.code = code;
        this.info = info;
    }

    public String getCode() {
        return code;
    }

    public String getInfo() {
        return info;
    }

    public static DeliveryWayEnum getEnumByCode(String code) {
        DeliveryWayEnum[] values = DeliveryWayEnum.values();
        for (DeliveryWayEnum value : values) {
            if (value.getCode().equalsIgnoreCase(code)) {
                return value;
            }
        }
        return null;
    }

    public static String getInfoByCode(String code) {
        DeliveryWayEnum[] values = DeliveryWayEnum.values();
        for (DeliveryWayEnum value : values) {
            if (value.getCode().equalsIgnoreCase(code)) {
                return value.info;
            }
        }
        return null;
    }
}

package com.space.lightapp.entity.dto.order;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;
import lombok.experimental.Accessors;


/**
 * 订单中心-附件
 *
 * @Author JiangHao
 * @date 2021-11-16 19:31
 * @Version 1.0
 */
@Data
@Accessors(chain = true)
@ApiModel(description = "附件")
public class OrderFileDTO implements Serializable {


    @ApiModelProperty(value = "退款单单号")
    private String refundNo;
    @ApiModelProperty(value = "附件地址")
    private String fileUrl;
    @ApiModelProperty(value = "附件名称")
    private String fileName;
    @ApiModelProperty(value = "oss对应名称（删除用）")
    private String ossName;
    @ApiModelProperty(value = "序号")
    private Integer orderNum;
    @ApiModelProperty(value = "创建时间")
    private Date createTime;

}

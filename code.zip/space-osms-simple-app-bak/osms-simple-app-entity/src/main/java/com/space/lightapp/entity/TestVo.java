package com.space.lightapp.entity;

import lombok.Data;

/**
 * TODO
 *
 * @Author Els
 * @date 2022-02-21 15:33
 * @Version 1.0
 */
@Data
public class TestVo {
    private String name;
}
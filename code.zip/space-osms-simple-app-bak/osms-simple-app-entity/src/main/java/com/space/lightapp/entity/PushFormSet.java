package com.space.lightapp.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.space.lightapp.base.BaseEntity;
import com.space.lightapp.entity.vo.PushFormSetVO;
import com.space.osms.common.core.utils.DozerBeanUtil;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 表单设置对象 push_from_set
 *
 * @author ChenYou
 * @date 2021-10-14
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("push_form_set")
public class PushFormSet extends BaseEntity {

    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long formSetId;
    /**
     * 轻应用Id
     */
    private Long lightAppId;
    /**
     * 轻应用模块Id
     */
    private Long lightAppModuleId;
    /**
     * 表单Id 对接表单系统
     */
    private String formId;
    /**
     * 表单别名
     */
    private String alias;
    /**
     * 存储表名称
     */
    private String sqlTableName;
    /**
     * 排序 排序字段
     */
    private Integer orderNum;
    /**
     * 状态 0禁用，1启用；默认1
     */
    private Boolean status;

    /**
     * 逻辑删除 0有效，1被删除；默认0
     */
    private Boolean delFlag;

    /**
     * Entity转Vo
     *
     * @return Vo对象
     * @date 2021-10-14
     */
    public PushFormSetVO toVo() {
        return DozerBeanUtil.transitionType(this, PushFormSetVO.class);
    }

    /**
     * List-Entity转List-Vo
     *
     * @return List-Vo对象
     * @date 2021-10-14
     */
    public List<PushFormSetVO> toListVo(List<PushFormSet> pushFromSet) {
        List<PushFormSetVO> list = new ArrayList<>();
        pushFromSet.forEach(t -> list.add(t.toVo()));
        return list;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("fromSetId", getFormSetId())
                .append("lightAppId", getLightAppId())
                .append("lightAppModuleId", getLightAppModuleId())
                .append("fromId", getFormId())
                .append("sqlTableName", getSqlTableName())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

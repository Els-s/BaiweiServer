package com.space.lightapp.entity.dto.order;

import com.space.lightapp.entity.vo.order.OrderDetailVO;
import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * 订单中心新增订单DTO
 *
 * @Author Els
 * @date 2021-11-15 19:31
 * @Version 1.0
 */
@Data
@Accessors(chain = true)
public class OrderDTO {

    /**
     * 订单类型
     */
    @ApiModelProperty(value = "订单类型")
    private String appType;
    /**
     * 订单类型
     */
    @ApiModelProperty(value = "订单类型名称")
    private String appName;
    /**
     * 订单状态 PENDING_PAYMENT_NOW(0,"待付款"), SUB_CONTRACT(1,"转签约"), PAID(2,"已付款"), REFUNDING(3,"退款中"), REFUNDED(4,"已退款"),
     * CANCELED(5,"已取消"), PART_PAID(6,"部分付款"),
     */
    private Integer orderState;
    @ApiModelProperty(value = "结算方式 1 周期结算、2 现结")
    private String paymentMethod;
    @ApiModelProperty(value = "订单总价", required = true)
    private String priceTotal;
    @ApiModelProperty(value = "租户编码", required = true)
    private String tenementCode;
    @ApiModelProperty(value = "项目编码", required = true)
    private String projectCode;
    @ApiModelProperty(value = "项目名称", required = true)
    private String projectName;
    @ApiModelProperty(value = "下单用户编码", required = true)
    private String orderUserPersonCode;
    @ApiModelProperty(value = "下单用户手机号", required = true)
    private String orderUserPhone;
    @ApiModelProperty(value = "下单用户名", required = true)
    private String orderUserName;
    @ApiModelProperty(value = "下单用户企业编码", required = true)
    private String orderUserCustomerCode;
    @ApiModelProperty(value = "下单用户企业名称", required = true)
    private String orderUserCustomerName;
    @ApiModelProperty(value = "下单用户企业地址", required = true)
    private String orderUserCustomerAddress;
    @ApiModelProperty(value = "订单来源：0:微信小程序,1:钉钉,2:员工APP,3:园区管理台,4:企业管理台", required = true)
    private Integer orderSource;
    @ApiModelProperty(value = "代客下单支付状态，1=非代客下单，2=代客下单不支付，3=代客下单并支付")
    private Integer valetPayStatus = 1;
    @ApiModelProperty(value = "业务回调地址")
    private String serviceCallbackUrl;
    /**
     * 商品列表-传给订单中心对接
     */
    @ApiModelProperty(value = "商品列表")
    private List<OrderDetailDTO> orderDetailList;
    /**
     * 商品列表-增值服务前后台对接使用
     */
    @ApiModelProperty(value = "商品列表-轻应用")
    private List<OrderDetailVO> orderDetailVos;
    @ApiModelProperty(value = "用户支付通道码", required = true)
    private String personChannelCode;
    @ApiModelProperty(value = "支付方式", required = true)
    private Integer payChannelType = 0;
}

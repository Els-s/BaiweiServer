package com.space.lightapp.entity.vo.message;

import lombok.Data;

/**
 * @description: 资讯管理附件
 * @author: JiangHao
 * @date: 2021/11/11 20:13
 */
@Data
public class DigitalMediaVO {

    /**
     * 图片说明
     */
    private String imageDesc;

    /**
     * 图片url
     */
    private String imageUrl;

    /**
     * 类型
     */
    private String type;

    /**
     * 大小
     */
    private Integer size;
}

package com.space.lightapp.entity.vo.order;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * 查询下单权限
 *
 * @Author ChenYou
 * @date 2021-12-16 13:39
 * @Version 1.0
 */
@Data
@Accessors(chain = true)
@ApiModel(description = "查询下单权限返回")
public class HasAuthPlaceOrderReposeVO {

    /**
     * 是否有下单权限：true：有，false：没有
     */
    private Boolean hasAuthPlace;
    /**
     * C端用户发起最低等级 tourist游客   commonUser普通用户   companyEmployee企业员工   companyManager企业管理员,多种类型英文逗号隔开
     */
    private String serverLaunchUser;
}

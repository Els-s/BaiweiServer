package com.space.lightapp.entity.vo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.space.lightapp.base.BaseVO;
import com.space.lightapp.entity.LightAppActivity;
import com.space.lightapp.entity.PushApplyData;
import com.space.osms.common.core.utils.DozerBeanUtil;
import com.space.osms.common.file.annotation.Excel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 活动 Vo对象 light_app_activity
 *
 * @author ChenYou
 * @date 2021-10-18
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "活动 ")
public class LightAppActivityVO extends BaseVO {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    private Long activityId;
    /**
     * 轻应用Id 关联轻应用Id
     */
    @ApiModelProperty(value = "轻应用Id 关联轻应用Id")
    private Long lightAppId;
    /**
     * 应用服务类型代码
     */
    @ApiModelProperty(value = "应用服务类型代码")
    private String appMarketTypeCode;
    /**
     * 任务中心唯一标识码
     */

    @ApiModelProperty(value = "任务中心唯一标识码")
    private String taskTypeCode;
    /**
     * 关联表单Id 关联表单Id
     */
    @ApiModelProperty(value = "关联表单Id 关联表单Id")
    private String formId;
    /**
     * 关联流程Id
     */
    @ApiModelProperty(value = "关联表单Id 关联表单Id")
    private String processId;
    /**
     * 活动编号
     */
    @Excel(name = "活动编号", sort = 1)
    @ApiModelProperty(value = "活动编号")
    private String activityCode;
    /**
     * 活动名称
     */
    @Excel(name = "活动标题", sort = 2)
    @ApiModelProperty(value = "活动名称")
    private String activityName;
    /**
     * log图片地址
     */
    @ApiModelProperty(value = "log图片地址")
    private String iconUrl;
    /**
     * 活动地址
     */
    @ApiModelProperty(value = "活动地址")
    private String activityAddress;
    /**
     * 活动内容
     */
    @ApiModelProperty(value = "活动内容")
    private String activityContent;
    /**
     * 是否需要签到 0不需要，1需要
     */
    @ApiModelProperty(value = "是否需要签到 0不需要，1需要")
    private Integer needSign;
    /**
     * 签到开始时间
     */
    @ApiModelProperty(value = "签到开始时间")
    @TableField(exist = false)
    private Date signStartTime;
    /**
     * 签到结束时间
     */
    @ApiModelProperty(value = "签到结束时间")
    @TableField(exist = false)
    private Date signEndTime;
    /**
     * 开始时间
     */
    @ApiModelProperty(value = "开始时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date startTime;
    /**
     * 结束时间
     */
    @ApiModelProperty(value = "结束时间")
    private Date endTime;


    @Excel(name = "活动起止时间", sort = 4)
    private String startTimeVo;
    /**
     * 参与条件 tourist游客   commonUser普通用户   companyEmployee企业员工   companyManager企业管理员,多种类型英文逗号隔开
     */
    @ApiModelProperty(value = "参与条件 tourist游客   commonUser普通用户   companyEmployee企业员工   companyManager企业管理员,多种类型英文逗号隔开")
    private String serverLaunchUser;
    /**
     * 参与条件描述
     */
    @ApiModelProperty(value = "参与条件描述")
    private String description;
    /**
     * 活动状态 draft草稿，notStart未开始，underWay进行中，suspend暂停中，finish已结束
     */
    @ApiModelProperty(value = "活动状态 draft草稿，notStart未开始，underWay进行中，suspend暂停中，finish已结束")
    private String activityType;
    /**
     * 活动状态 draft草稿，notStart未开始，underWay进行中，suspend暂停中，finish已结束
     */
    @Excel(name = "活动状态", sort = 8)
    @ApiModelProperty(value = "活动状态 draft草稿，notStart未开始，underWay进行中，suspend暂停中，finish已结束")
    private String activityTypeVo;
    /**
     * 排序 排序字段
     */
    @ApiModelProperty(value = "排序 排序字段")
    private Integer orderNum;
    /**
     * 是否禁用 0禁用，1启用；默认1
     */
    @ApiModelProperty(value = "是否禁用 0禁用，1启用；默认1")
    private Boolean status;
    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String remark;
    /**
     * 逻辑删除 0有效，1被删除；默认0
     */
    @ApiModelProperty(value = "逻辑删除 0有效，1被删除；默认0")
    private Boolean delFlag;

    /**
     * 在线状态：online 上线中，offline 下线中， null 无在线状态
     */
    @ApiModelProperty(value = "在线状态：online 上线中，offline 下线中， null 无在线状态")
    private String onlineStatus;
    /**
     * 在线状态：online 上线中，offline 下线中， null 无在线状态
     */
    @Excel(name = "状态", sort = 9)
    @ApiModelProperty(value = "在线状态：online 上线中，offline 下线中， null 无在线状态")
    private String onlineStatusVo;

    /**
     * 报名开始时间
     */
    private Date applyStartTime;

    /**
     * 报名结束时间
     */
    private Date applyEndTime;

    @Excel(name = "报名时间", sort = 3)
    private String applyTimeVo;

    /**
     * 报名人数
     */
    @Excel(name = "报名人数", sort = 6)
    @TableField(exist = false)
    @ApiModelProperty(value = "报名人数")
    private Integer applyNum;

    /**
     * 实际参与人数
     */
    @Excel(name = "实际参与人数", sort = 7)
    @TableField(exist = false)
    @ApiModelProperty(value = "实际参与人数")
    private Integer actorNum;


    /**
     * 是否需要报名 0不需要，1需要
     */
    @TableField(exist = false)
    @ApiModelProperty(value = "是否需要报名 0不需要，1需要")
    private Integer needApply;
    /**
     * 发布功能设置Vo
     */
    @ApiModelProperty(value = "发布功能设置Vo")
    private PushFunctionSetVO functionSet;
    /**
     * 发布广告Vo
     */
    @ApiModelProperty(value = "发布广告Vo")
    private PushAdvertisingSetVO pushAdvertisingSet;
    /**
     * 发布资讯Vo
     */
    @ApiModelProperty(value = "发布资讯Vo")
    private PushInformationSetVO pushInformationSet;
    /**
     * 活动报名设置Vo
     */
    @ApiModelProperty(value = "活动报名设置Vo")
    private PushApplySetVO pushApplySet;

    private Boolean existTaskCentreCode;
    /**
     * 活动报名内容Vo
     */
    @ApiModelProperty(value = "活动报名内容集合")
    @TableField(exist = false)
    private List<PushApplyData> pushApplyDataList;

    /**
     * 报名费用
     */
    @Excel(name = "活动费用(元)", sort = 5)
    @TableField(exist = false)
    private BigDecimal money;

    /**
     * 暂存类型
     */
    @ApiModelProperty(value = "暂存类型 true:暂存;false:发布")
    @TableField(exist = false)
    private Boolean stagType;

    /**
     * Vo转Entity
     *
     * @return Entity对象
     * @date 2021-10-18
     */
    public LightAppActivity toEntity() {
        return DozerBeanUtil.transitionType(this, LightAppActivity.class);
    }

    /**
     * List-Vo转List-Entity
     *
     * @return List-Entity对象
     * @date 2021-10-18
     */
    public List<LightAppActivity> toListEntity(List<LightAppActivityVO> lightAppActivityVo) {
        List<LightAppActivity> list = new ArrayList<>();
        lightAppActivityVo.forEach(t -> list.add(t.toEntity()));
        return list;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("activityId", getActivityId())
                .append("lightAppId", getLightAppId())
                .append("appMarketTypeCode", getAppMarketTypeCode())
                .append("formId", getFormId())
                .append("activityCode", getActivityCode())
                .append("activityName", getActivityName())
                .append("activityAddress", getActivityAddress())
                .append("activityContent", getActivityContent())
                .append("needSign", getNeedSign())
                .append("signStartTime", getSignStartTime())
                .append("signEndTime", getSignEndTime())
                .append("startTime", getStartTime())
                .append("endTime", getEndTime())
                .append("serverLaunchUser", getServerLaunchUser())
                .append("description", getDescription())
                .append("activityType", getActivityType())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("companyCode", getCompanyCode())
                .append("remark", getRemark())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

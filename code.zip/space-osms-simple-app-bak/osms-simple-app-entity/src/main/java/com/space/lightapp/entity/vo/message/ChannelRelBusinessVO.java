package com.space.lightapp.entity.vo.message;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import lombok.Data;
import lombok.experimental.Accessors;


/**
 * @author JiangHao
 * @version 1.0
 * @date 2021/11/22 0018 17:32
 * @description 上下架状态表
 */
@Data
@Accessors(chain = true)
public class ChannelRelBusinessVO implements Serializable {


    /**
     * id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 比如资源里面：1全民上架 2中介上架、4运营管理  5PC端 ==> 消息中心三期，已经修改为从发布授权动态获取发布渠道
     */
    private String statusType;

    /**
     * 用于各前端进行排序用
     */
    private Integer showOrder;

}

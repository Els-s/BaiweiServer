package com.space.lightapp.enums;

import cn.hutool.core.collection.ListUtil;
import java.util.List;

/**
 * 用户参与条件枚举
 *
 * @Author jiangHao
 * @date 2021-11-08 14:42
 * @Version 1.0
 */
public enum LaunchUserEnum {
    // 参与条件
    TOURIST("tourist", "游客"),
    COMMON_USER("commonUser", "普通用户"),
    COMPANY_EMPLOYEE("companyEmployee", "企业员工"),
    COMPANY_MANAGER("companyManager", "企业管理员");
    private String code;
    private String info;

    LaunchUserEnum(String code, String info) {
        this.code = code;
        this.info = info;
    }

    public String getCode() {
        return code;
    }

    public String getInfo() {
        return info;
    }

    public static List<String> getTouristList() {
        return ListUtil.toList(TOURIST.code);
    }

    public static List<String> getCommonList() {
        return ListUtil.toList(
                TOURIST.code,
                COMMON_USER.code
        );
    }

    public static List<String> getEmployeeList() {
        return ListUtil.toList(
                TOURIST.code,
                COMMON_USER.code,
                COMPANY_EMPLOYEE.code
        );
    }

    public static List<String> getAllList() {
        return ListUtil.toList(
                TOURIST.code,
                COMMON_USER.code,
                COMPANY_EMPLOYEE.code,
                COMPANY_MANAGER.code
        );
    }
}

package com.space.lightapp.enums;

import lombok.Getter;

/**
 * 代客下单分类枚举
 *
 * @Author Els
 * @date 2021-12-14 19:48
 * @Version 1.0
 */
@Getter
public enum ValetPayStatusEnum {
    // 下单返回状态码
    ORDER_BY_USER(1, "非代客下单"),
    VALET_ORDER_WITHOUT_PAY(2, "代客下单不支付"),
    VALET_ORDER_WITH_PAY(3, "代客下单并支付"),
    ;
    private Integer code;
    private String info;

    ValetPayStatusEnum(Integer code, String info) {
        this.code = code;
        this.info = info;
    }

    public static ValetPayStatusEnum getEnumByCode(Integer code) {
        ValetPayStatusEnum[] values = ValetPayStatusEnum.values();
        for (ValetPayStatusEnum value : values) {
            if (value.getCode().equals(code)) {
                return value;
            }
        }
        return null;
    }
}

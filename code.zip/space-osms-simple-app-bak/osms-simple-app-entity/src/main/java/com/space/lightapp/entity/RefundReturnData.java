package com.space.lightapp.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * 退款申请返回数据
 *
 * @author Jianghao
 * @date 2021-11-25
 */
@Data
@Accessors(chain = true)
@ApiModel(description = "退款申请返回数据 ")
public class RefundReturnData {

    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long serverDataId;
    /**
     * 轻应用小分类
     */
    private String appLittleType;
    /**
     * 轻应用类型
     */
    private String appMarketTypeCode;
    /**
     * 服务Id
     */
    private Long serverId;
    /**
     * 订单中心订单编号
     */
    private String extOrderCode;


}

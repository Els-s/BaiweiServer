package com.space.lightapp.entity.vo.spaas;

import com.alibaba.fastjson.JSONObject;
import com.space.lightapp.base.BaseVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 保存表单VO
 *
 * @Author kangmj
 * @date 2021-10-30 14:50
 * @Version 1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = "保存表单VO")
public class SaveFormDataVO extends BaseVO {

    private JSONObject setting;
    private String alias;
    @ApiModelProperty(value = "表单数据")
    private JSONObject data;
    @ApiModelProperty(value = "扩展字段")
    private JSONObject expand;

}

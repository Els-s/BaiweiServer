package com.space.lightapp.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.space.lightapp.base.FormBaseEntity;
import com.space.lightapp.entity.vo.PushApplyDataVO;
import com.space.lightapp.enums.ActivityBusinessStateEnum;
import com.space.osms.common.core.utils.DozerBeanUtil;
import com.space.osms.common.file.annotation.Excel;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 报名数据 对象 push_apply_data
 *
 * @author ChenYou
 * @date 2021-10-20
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("push_apply_data")
public class PushApplyData extends FormBaseEntity {

    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long applyDataId;
    /**
     * 活动Id
     */
    private Long activityId;
    /**
     * 报名人名称
     */
    @Excel(name = "用户姓名", sort = 1)
    private String userName;
    /**
     * 报名人编码
     */
    private String userCode;
    /**
     * 提单人详情（name,id等等信息）
     */
    private String billUserDetail;
    /**
     * 报名人电话
     */
    @Excel(name = "用户电话", sort = 2)
    private String userPhone;
    /**
     * 报名头像
     */
    private String avatarUrl;
    /**
     * 活动报名机器
     */
    @Excel(name = "参与机器码", sort = 3)
    private String activityMachine;

    /**
     * 报名人企业名称
     */
    @Excel(name = "企业", sort = 4)
    private String companyName;
    /**
     * 是否需要付费 0不需要，1需要
     */
    @Excel(name = "是否需要收费", sort = 5, readConverterExp = "0=否,1=是")
    private Integer needMoney;
    /**
     * 付费状态 待支出，支付失败，支付完成
     */
    private String payType;
    /**
     * 关联付费Id
     */
    private String payId;
    /**
     * 报名状态 1报名成功，0报名失败
     */
    @Excel(name = "报名状态", sort = 6, readConverterExp = "0=未报名,1=成功,2报名审核中")
    private Integer applyType;
    /**
     * 报名时间
     */
    @Excel(name = "报名时间", sort = 7, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date applyTime;
    /**
     * 签到状态 1签到成功，0签到失败
     */
    @Excel(name = "签到状态", sort = 8, readConverterExp = "0=失败,1=成功")
    private Integer signType;
    /**
     * 签到时间
     */
    @Excel(name = "签到时间", sort = 9, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date signTime;
    /**
     * 排序 排序字段
     */
    private Integer orderNum;
    /**
     * 是否禁用 0禁用，1启用；默认1
     */
    private Boolean status;
    /**
     * 备注信息
     */
    private String remark;
    /**
     * 逻辑删除 0有效，1被删除；默认0
     */
    private Boolean delFlag;
    /**
     * 企业编码
     */
    private String companyCode;
    /**
     * 搜索开始时间
     */
    @TableField(exist = false)
    private String applyStartTime;
    /**
     * 搜索结束时间
     */
    @TableField(exist = false)
    private String applyEndTime;
    /**
     * 表单配置
     */
    @TableField(exist = false)
    private PushFormSet pushFormSet;

    /**
     * 流程配置
     */
    @TableField(exist = false)
    private PushProcessSet processSet;

    /**
     * 服务名称
     */
    @TableField(exist = false)
    private String serverName;

    /**
     * Entity转Vo
     *
     * @return Vo对象
     * @date 2021-10-20
     */
    public PushApplyDataVO toVo() {
        PushApplyDataVO pushApplyDataVO = DozerBeanUtil.transitionType(this, PushApplyDataVO.class);
        pushApplyDataVO.setBusinessStateName(ActivityBusinessStateEnum.getInfoValue(this.getBusinessState()));
        return pushApplyDataVO;
    }

    /**
     * List-Entity转List-Vo
     *
     * @return List-Vo对象
     * @date 2021-10-20
     */
    public List<PushApplyDataVO> toListVo(List<PushApplyData> pushApplyData) {
        List<PushApplyDataVO> list = new ArrayList<>();
        pushApplyData.forEach(t -> list.add(t.toVo()));
        return list;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("applyDataId", getApplyDataId())
                .append("lightAppId", getLightAppId())
                .append("lightAppModuleId", getLightAppModuleId())
                .append("appMarketTypeCode", getAppMarketTypeCode())
                .append("activityId", getActivityId())
                .append("userName", getUserName())
                .append("userCode", getUserCode())
                .append("companyName", getCompanyName())
                .append("needMoney", getNeedMoney())
                .append("payType", getPayType())
                .append("payId", getPayId())
                .append("applyType", getApplyType())
                .append("applyTime", getApplyTime())
                .append("signType", getSignType())
                .append("signTime", getSignTime())
                .append("orderCode", getOrderCode())
                .append("formSetId", getFormSetId())
                .append("formId", getFormId())
                .append("content", getContent())
                .append("processId", getProcessId())
                .append("processNodeUser", getProcessNodeUser())
                .append("dataId", getDataId())
                .append("appCode", getAppCode())
                .append("businessState", getBusinessState())
                .append("processState", getProcessState())
                .append("processStartStatus", getProcessStartStatus())
                .append("taskId", getTaskId())
                .append("spaceInfo", getSpaceInfo())
                .append("spaceCode", getSpaceCode())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("companyCode", getCompanyCode())
                .append("remark", getRemark())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

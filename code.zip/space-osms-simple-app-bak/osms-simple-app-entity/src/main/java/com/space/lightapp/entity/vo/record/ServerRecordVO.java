package com.space.lightapp.entity.vo.record;

import com.space.lightapp.base.BaseVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 服务记录VO
 *
 * @Author ChenYou
 * @date 2021-11-25 14:50
 * @Version 1.0
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "服务记录数据VO")
public class ServerRecordVO extends BaseVO {

    /**
     * 应用类型
     */
    @ApiModelProperty(value = "应用类型")
    private String appMarketTypeCode;
    /**
     * 轻应用Id
     */
    @ApiModelProperty(value = "轻应用Id")
    private Long lightAppId;
    /**
     * 单据状态
     */
    @ApiModelProperty(value = "单据状态")
    private String businessState;
    /**
     * 流程状态
     */
    @ApiModelProperty(value = "流程状态。处理中=0，已办结=1")
    private Integer processStatus;

    @ApiModelProperty(value = "搜索时间数组")
    private List<String> searchTime;

    public ServerRecordVO(BaseVO baseVO, String appMarketTypeCode, Long lightAppId) {
        this.appMarketTypeCode = appMarketTypeCode;
        this.lightAppId = lightAppId;
        if (null != baseVO) {
            this.setUserInfo(baseVO.getUserInfo());
            this.setTenementCode(baseVO.getTenementCode());
            this.setProjectCode(baseVO.getProjectCode());
            this.setCompanyCode(baseVO.getCompanyCode());
        }
    }
}

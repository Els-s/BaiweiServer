package com.space.lightapp.base;

import com.baomidou.mybatisplus.annotation.TableField;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 表单数据公共实体
 *
 * @Author ChenYou
 * @date 2021-10-20 16:16
 * @Version 1.0
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class FormBaseEntity extends BaseEntity {

    /**
     * 单据来源 1内部单，2客户下单，3代客下单
     */
    @ApiModelProperty(value = "单据来源 1内部单，2客户下单，3代客下单")
    private Integer source;

    /**
     * 单据编码：工单号，问卷号，活动号
     */
    @ApiModelProperty(value = "单据编码")
    private String orderCode;
    /**
     * 轻应用类型
     */
    @ApiModelProperty(value = "轻应用类型")
    private String appMarketTypeCode;
    /**
     * 轻应用Id
     */
    @ApiModelProperty(value = "轻应用Id")
    private Long lightAppId;
    /**
     * 轻应用模块Id
     */
    @ApiModelProperty(value = "轻应用模块Id")
    private Long lightAppModuleId;
    /**
     * 表单设置Id
     */
    @ApiModelProperty(value = "表单设置Id")
    private Long formSetId;
    /**
     * 对应表单Id（Spass的）
     */
    @ApiModelProperty(value = "对应表单Id（Spass的）")
    private String formId;
    /**
     * 关联数据Id（Spass的）
     */
    @ApiModelProperty(value = "关联数据Id（Spass的）")
    private String dataId;
    /**
     * 流程设置Id
     */
    @ApiModelProperty(value = "流程设置Id")
    private Long processSetId;
    /**
     * 流程Id:Spass的流程key
     */
    @ApiModelProperty(value = "流程Id:Spass的流程key")
    private String processId;
    /**
     * 流程实例ID
     */
    @ApiModelProperty(value = "流程实例ID")
    private String processInsId;
    /**
     * 当前节点处理人
     */
    @ApiModelProperty(value = "当前节点处理人")
    private String processNodeUser;
    /**
     * 当前节点处理人详情
     */
    @ApiModelProperty(value = "当前节点处理人详情")
    private String processNodeUserDetail;
    /**
     * 任务Id
     */
    @ApiModelProperty(value = "任务Id")
    private String taskId;
    /**
     * 空间地址信息
     */
    @ApiModelProperty(value = "空间地址信息")
    private String spaceInfo;
    /**
     * 空间地址信息编码
     */
    @ApiModelProperty(value = "空间地址信息编码")
    private String spaceCode;
    /**
     * 单据内容
     */
    @ApiModelProperty(value = "单据内容")
    private String content;
    /**
     * 业务状态
     */
    @ApiModelProperty(value = "业务状态 BusinessStateEnum")
    private String businessState;
    /**
     * 工单状态（1待受理，2处理中，3已完成，4已关闭，5待回访，6已取消）
     */
    @ApiModelProperty(value = "工单状态（1待受理，2处理中，3已完成，4已关闭，5待回访，6已取消）")
    private Integer processState;
    /**
     * 工单状态名称（1待受理，2处理中，3已完成，4已关闭，5待回访，6已取消）
     */
    @ApiModelProperty(value = "工单状态（1待受理，2处理中，3已完成，4已关闭，5待回访，6已取消）")
    @TableField(exist = false)
    private String processStateName;
    /**
     * 流程启动结果 流程启动结果，1-启动成功，-1-启动失败，0-未启动流程
     */
    @ApiModelProperty(value = "流程启动结果 流程启动结果，1-启动成功，-1-启动失败，0-未启动流程")
    private Integer processStartStatus;
    /**
     * 应用编码
     */
    @ApiModelProperty(value = "应用编码")
    private String appCode;

    @TableField(exist = false)
    private String alias;
}

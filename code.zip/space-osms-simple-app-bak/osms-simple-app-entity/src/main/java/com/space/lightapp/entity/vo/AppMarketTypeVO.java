package com.space.lightapp.entity.vo;

import com.space.lightapp.base.BaseVO;
import com.space.lightapp.entity.AppMarketType;
import com.space.osms.common.core.utils.DozerBeanUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 应用服务类型 Vo对象 app_market_type
 *
 * @author ChenYou
 * @date 2021-09-27
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "应用服务类型VO")
public class AppMarketTypeVO extends BaseVO {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    private Long appMarketTypeId;
    /**
     * 应用服务类型代码
     */
    @ApiModelProperty(value = "应用服务类型代码", allowableValues = "workOrder,baseServer,survey,activity,payServer")
    private String appMarketTypeCode;
    /**
     * 应用服务类型名称
     */
    @ApiModelProperty(value = "应用服务类型名称")
    private String appMarketTypeName;
    /**
     * 排序 排序字段
     */
    @ApiModelProperty(value = "排序 排序字段")
    private Long orderNum;
    /**
     * 状态 0-false-禁用，1-true-启用；默认1-true
     */
    @ApiModelProperty(value = "状态 0-false-禁用，1-true-启用；默认1-true")
    private Boolean status;

    /**
     * 是否删除  0-false-未删除，1-true-删除；默认0-false
     */
    @ApiModelProperty(value = "是否删除  0-false-未删除，1-true-删除；默认0-false")
    private Boolean delFlag;

    /**
     * Vo转Entity
     *
     * @return Entity对象
     * @date 2021-09-27
     */
    public AppMarketType toEntity() {
        AppMarketType appMarketType = DozerBeanUtil.transitionType(this, AppMarketType.class);
        return appMarketType;
    }

    /**
     * List-Vo转List-Entity
     *
     * @return List-Entity对象
     * @date 2021-09-27
     */
    public List<AppMarketType> toListEntity(List<AppMarketTypeVO> appMarketTypeVo) {
        List<AppMarketType> list = new ArrayList<>();
        appMarketTypeVo.forEach(t -> list.add(t.toEntity()));
        return list;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("appMarketTypeId", getAppMarketTypeId())
                .append("appMarketTypeCode", getAppMarketTypeCode())
                .append("appMarketTypeName", getAppMarketTypeName())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

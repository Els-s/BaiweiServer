package com.space.lightapp.entity.dto.order;

import com.space.lightapp.enums.PayWayEnum;
import lombok.Data;

/**
 * 返回支付方式
 *
 * @Author ChenYou
 * @date 2021-11-30 20:22
 * @Version 1.0
 */
@Data
public class PayWayVO {

    /**
     * 编码
     */
    private String payWayCode;
    /**
     * 名称
     */
    private String payWayName;

    public PayWayVO(PayWayEnum payWayEnum) {
        this.payWayCode = payWayEnum.getCode();
        this.payWayName = payWayEnum.getInfo();
    }

    public PayWayVO() {
    }
}

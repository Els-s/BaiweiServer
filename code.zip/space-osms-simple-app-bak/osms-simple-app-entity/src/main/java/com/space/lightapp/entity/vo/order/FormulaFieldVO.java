package com.space.lightapp.entity.vo.order;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * TODO
 *
 * @Author Els
 * @date 2021-11-17 19:55
 * @Version 1.0
 */
@Data
public class FormulaFieldVO {

    private String fieldCode;
    private String displayName;
    private String unitName;
    private String value;
    @ApiModelProperty(value = "下拉数据名称")
    private String itemName;
    /**
     * 单位类型（0数量，1时长）
     */
    private Integer unitType;
}

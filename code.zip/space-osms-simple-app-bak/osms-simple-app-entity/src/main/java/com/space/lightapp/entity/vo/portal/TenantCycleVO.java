package com.space.lightapp.entity.vo.portal;

import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 租客周期结算VO（推送企业结算配置）
 *
 * @Author ChenYou
 * @date 2021-11-18 8:55
 * @Version 1.0
 */
@Data
public class TenantCycleVO {

    /**
     * 企业编码
     */
    private String projectCode;
    /**
     * 应用代码
     */
    private String businessCode;
    /**
     * 应用名称
     */
    private String businessName;
    /**
     * 结算方式:0 不允许周期结算，1和周期结算一致
     */
    private Integer settlementMethod;

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("projectCode", getProjectCode())
                .append("businessName", getBusinessName())
                .append("businessCode", getBusinessCode())
                .append("settlementMethod", getSettlementMethod())
                .toString();
    }
}

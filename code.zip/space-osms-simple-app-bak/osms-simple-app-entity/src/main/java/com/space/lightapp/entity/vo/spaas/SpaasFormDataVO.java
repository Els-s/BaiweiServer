package com.space.lightapp.entity.vo.spaas;

import com.alibaba.fastjson.JSONObject;
import lombok.Data;

/**
 * Spass表单数据请求VO
 *
 * @Author ChenYou
 * @date 2021-10-23 9:24
 * @Version 1.0
 */
@Data
public class SpaasFormDataVO {

    /**
     * 当前页
     */
    private Integer pageNo;
    /**
     * 每页行数
     */
    private Integer pageSize;
    /**
     * 排序字段
     */
    private String sortField;
    /**
     * 排序类型：asc升序，desc降序
     */
    private String sortOrder;
    /**
     * 其他请求参数
     */
    private JSONObject params;
}

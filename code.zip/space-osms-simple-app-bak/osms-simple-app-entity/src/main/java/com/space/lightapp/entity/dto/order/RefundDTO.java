package com.space.lightapp.entity.dto.order;

import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * 订单中心新增退款DTO
 *
 * @Author JiangHao
 * @date 2021-11-16 19:31
 * @Version 1.0
 */
@Data
@Accessors(chain = true)
public class RefundDTO {


    @ApiModelProperty(value = "订单编号")
    private String orderNo;
    //默认用户发起
    @ApiModelProperty(value = "退款类型（0:用户发起、1:后台发起）")
    private int refundType;
    @ApiModelProperty(value = "联系人手机号")
    private String callphone;
    //默认微信
    @ApiModelProperty(value = "原订单收款方式(0：微信，1：支付宝)")
    private int oldOrderPayType;
    @ApiModelProperty(value = "退款总金额")
    private String refundAmountTotal;
    @ApiModelProperty(value = "项目编码")
    private String projectCode;
    @ApiModelProperty(value = "收款人")
    private String receiveName;
    //默认原路返回
    @ApiModelProperty(value = "退款方式(0:原路返回,1:银行转账,2:现金)")
    private int refundPattern;
    @ApiModelProperty(value = "退款明细")
    private List<OrderRefundDetailDTO> orderDetailList;
    @ApiModelProperty(value = "退款附件")
    private List<OrderFileDTO> fileList;
    @ApiModelProperty(value = "租户编码")
    private String tenementCode;
    @ApiModelProperty(value = "回调地址")
    private String serviceCallbackUrl;


}

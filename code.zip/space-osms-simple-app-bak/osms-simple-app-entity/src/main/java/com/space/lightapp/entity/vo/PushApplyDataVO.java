package com.space.lightapp.entity.vo;

import com.space.lightapp.base.HandleTypeVO;
import com.space.lightapp.entity.PushApplyData;
import com.space.lightapp.entity.PushFormSet;
import com.space.lightapp.entity.PushProcessSet;
import com.space.osms.common.core.utils.DozerBeanUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 报名数据 Vo对象 push_apply_data
 *
 * @author ChenYou
 * @date 2021-10-20
 */
@Data
@ApiModel(description = "报名数据 ")
public class PushApplyDataVO extends HandleTypeVO {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    private Long applyDataId;
    /**
     * 轻应用Id
     */
    @ApiModelProperty(value = "轻应用Id")
    private Long lightAppId;
    /**
     * 轻应用模块Id
     */
    @ApiModelProperty(value = "轻应用模块Id")
    private Long lightModuleId;
    /**
     * 轻应用类型
     */
    @ApiModelProperty(value = "轻应用类型")
    private String appMarketTypeCode;
    /**
     * 活动Id
     */
    @ApiModelProperty(value = "活动Id")
    private Long activityId;
    /**
     * 报名头像url
     */
    @ApiModelProperty(value = "报名头像url")
    private String avatarUrl;
    /**
     * 报名人名称
     */
    @ApiModelProperty(value = "报名人名称")
    private String userName;
    /**
     * 报名人编码
     */
    @ApiModelProperty(value = "报名人编码")
    private String userCode;
    /**
     * 提单人详情（name,id等等信息）
     */
    @ApiModelProperty(value = "报名人详情")
    private String billUserDetail;
    /**
     * 报名人电话号码
     */
    @ApiModelProperty(value = "报名人电话号码")
    private String userPhone;
    /**
     * 活动报名机器
     */
    @ApiModelProperty(value = "活动报名机器")
    private String activityMachine;
    /**
     * 报名人企业名称
     */
    @ApiModelProperty(value = "报名人企业名称")
    private String companyName;
    /**
     * 是否需要付费 0不需要，1需要
     */
    @ApiModelProperty(value = "是否需要付费 0不需要，1需要")
    private Integer needMoney;
    /**
     * 付费状态 待支出，支付失败，支付完成
     */
    @ApiModelProperty(value = "付费状态 待支出，支付失败，支付完成")
    private String payType;
    /**
     * 关联付费Id
     */
    @ApiModelProperty(value = "关联付费Id")
    private String payId;
    /**
     * 报名状态 1报名成功，0报名失败
     */
    @ApiModelProperty(value = "报名状态 1报名成功，0报名失败")
    private Integer applyType;
    /**
     * 报名时间
     */
    @ApiModelProperty(value = "报名时间")
    private Date applyTime;
    /**
     * 签到状态 1签到成功，0签到失败
     */
    @ApiModelProperty(value = "签到状态 1签到成功，0签到失败")
    private Integer signType;
    /**
     * 签到时间
     */
    @ApiModelProperty(value = "签到时间")
    private Date signTime;
    /**
     * 单据编码
     */
    @ApiModelProperty(value = "单据编码")
    private String orderCode;
    /**
     * 表单设置Id
     */
    @ApiModelProperty(value = "表单设置Id")
    private String formSetId;
    /**
     * 表单Id
     */
    @ApiModelProperty(value = "表单Id")
    private String fromId;
    /**
     * 工单内容
     */
    @ApiModelProperty(value = "工单内容")
    private String content;
    /**
     * 流程Id
     */
    @ApiModelProperty(value = "流程Id")
    private String processId;
    /**
     * 当前节点处理人
     */
    @ApiModelProperty(value = "当前节点处理人")
    private String processNodeUser;
    /**
     * 对应数据Id
     */
    @ApiModelProperty(value = "对应数据Id")
    private String dataId;
    /**
     * 应用编码
     */
    @ApiModelProperty(value = "应用编码")
    private String appCode;
    /**
     * 业务状态
     */
    @ApiModelProperty(value = "业务状态")
    private String businessState;
    /**
     * 业务状态名称
     */
    @ApiModelProperty(value = "业务状态 ActivityBusinessStateEnum")
    private String businessStateName;

    /**
     * 工单状态 工单状态（1待受理，2处理中，3已完成，4已关闭，5待回访，6已取消）
     */
    @ApiModelProperty(value = "工单状态 工单状态（1待受理，2处理中，3已完成，4已关闭，5待回访，6已取消）")
    private Integer processState;
    /**
     * 流程启动结果 流程启动结果，1-启动成功，-1-启动失败，0-未启动流程
     */
    @ApiModelProperty(value = "流程启动结果 流程启动结果，1-启动成功，-1-启动失败，0-未启动流程")
    private Integer processStartStatus;
    /**
     * 任务Id
     */
    @ApiModelProperty(value = "任务Id")
    private String taskId;
    /**
     * 空间地址信息
     */
    @ApiModelProperty(value = "空间地址信息")
    private String spaceInfo;
    /**
     * 空间地址信息编码
     */
    @ApiModelProperty(value = "空间地址信息编码")
    private String spaceCode;
    /**
     * 排序 排序字段
     */
    @ApiModelProperty(value = "排序 排序字段")
    private Integer orderNum;
    /**
     * 是否禁用 0禁用，1启用；默认1
     */
    @ApiModelProperty(value = "是否禁用 0禁用，1启用；默认1")
    private Boolean status;
    /**
     * 备注信息
     */
    @ApiModelProperty(value = "备注信息")
    private String remark;
    /**
     * 逻辑删除 0有效，1被删除；默认0
     */
    @ApiModelProperty(value = "逻辑删除 0有效，1被删除；默认0")
    private Boolean delFlag;
    /**
     * 表单配置
     */
    @ApiModelProperty(value = "表单配置")
    private PushFormSet pushFormSet;

    /**
     * 流程配置
     */
    @ApiModelProperty(value = "流程配置")
    private PushProcessSet processSet;

    /**
     * 流程设置Id
     */
    @ApiModelProperty(value = "流程设置Id")
    private Long processSetId;
    /**
     * 流程实例ID
     */
    @ApiModelProperty(value = "流程实例ID")
    private String processInsId;

    /**
     * Vo转Entity
     *
     * @return Entity对象
     * @date 2021-10-20
     */
    public PushApplyData toEntity() {
        return DozerBeanUtil.transitionType(this, PushApplyData.class);
    }

    /**
     * List-Vo转List-Entity
     *
     * @return List-Entity对象
     * @date 2021-10-20
     */
    public List<PushApplyData> toListEntity(List<PushApplyDataVO> pushApplyDataVo) {
        List<PushApplyData> list = new ArrayList<>();
        pushApplyDataVo.forEach(t -> list.add(t.toEntity()));
        return list;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("applyDataId", getApplyDataId())
                .append("lightAppId", getLightAppId())
                .append("lightModuleId", getLightModuleId())
                .append("appMarketTypeCode", getAppMarketTypeCode())
                .append("activityId", getActivityId())
                .append("userName", getUserName())
                .append("userCode", getUserCode())
                .append("companyName", getCompanyName())
                .append("needMoney", getNeedMoney())
                .append("payType", getPayType())
                .append("payId", getPayId())
                .append("applyType", getApplyType())
                .append("applyTime", getApplyTime())
                .append("signType", getSignType())
                .append("signTime", getSignTime())
                .append("orderCode", getOrderCode())
                .append("formSetId", getFormSetId())
                .append("fromId", getFromId())
                .append("content", getContent())
                .append("processId", getProcessId())
                .append("processNodeUser", getProcessNodeUser())
                .append("dataId", getDataId())
                .append("appCode", getAppCode())
                .append("businessState", getBusinessState())
                .append("processState", getProcessState())
                .append("processStartStatus", getProcessStartStatus())
                .append("taskId", getTaskId())
                .append("spaceInfo", getSpaceInfo())
                .append("spaceCode", getSpaceCode())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("companyCode", getCompanyCode())
                .append("remark", getRemark())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

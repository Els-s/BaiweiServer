package com.space.lightapp.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.util.Date;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * 数据处理记录
 *
 * @Author Els
 * @date 2022-03-03 11:32
 * @Version 1.0
 */
@Data
@Accessors(chain = true)
@TableName("handle_data_his")
public class HandleDataHis {
    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Integer id;

    private String type;
    private String name;
    private String version;
    private String project;
    private String tenant;
    @TableField(fill = FieldFill.INSERT)
    private Date createTime;
}
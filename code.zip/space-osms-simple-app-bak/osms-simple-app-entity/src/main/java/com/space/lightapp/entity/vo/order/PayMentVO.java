package com.space.lightapp.entity.vo.order;

import com.space.lightapp.base.BaseVO;

/**
 * 支付VO
 *
 * @Author ChenYou
 * @date 2021-11-13 11:12
 * @Version 1.0
 */
public class PayMentVO extends BaseVO {

    /**
     * 订单编码（订单中心的订单编码）
     */
    private String orderCode;

}

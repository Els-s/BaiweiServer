package com.space.lightapp.entity.vo.query;

import com.space.lightapp.base.BaseVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 文件下载VO
 *
 * @Author ChenYou
 * @date 2021-11-03 15:55
 * @Version 1.0
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "二维码图片下载配置")
public class QRImageDownLoadVO extends BaseVO {

    /**
     * 应用类型
     */
    @ApiModelProperty("应用类型")
    private String appMarketTypeCode;
    /**
     * 轻应用Id
     */
    @ApiModelProperty("轻应用Id")
    private String lightAppId;
    /**
     * 关联业务Id（工单和基础服务，此字段为null；问卷关联问卷Id，活动关联活动Id）
     */
    @ApiModelProperty(value = "关联业务Id")
    private Long relevancyId;
    /**
     * 放入二维码的地址
     */
    @ApiModelProperty("放入二维码的地址")
    private String url;

    /**
     * 放入二维码的信息
     */
    @ApiModelProperty("放入二维码的信息")
    private String info;
    /**
     * 放进二维码的LOG图片名称
     */
    @ApiModelProperty("放进二维码的LOG图片名称")
    private String logFileName;
    /**
     * 放进二维码的LOG图片名称
     */
    @ApiModelProperty("放进二维码的LOG图片地址")
    private String logFilePath;
}

package com.space.lightapp.entity.vo;

import com.space.lightapp.base.BaseVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 测试人员Vo对象 push_tester_set
 *
 * @author ChenYou
 * @date 2021-10-09
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "添加测试人员")
public class TesterSetAddVO extends BaseVO {


    /**
     * 应用模块Id
     */
    @ApiModelProperty(value = "应用模块Id")
    private Long lightAppModuleId;
    /**
     * 轻应用id
     */
    @ApiModelProperty(value = "轻应用id")
    private Long lightAppId;

    /**
     * 测试人员列表
     */
    @ApiModelProperty(value = "测试人员列表")
    private List<PushTesterSetVO> pushTesterSetVOList;
}

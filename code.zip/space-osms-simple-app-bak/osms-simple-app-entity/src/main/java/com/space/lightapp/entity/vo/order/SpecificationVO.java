package com.space.lightapp.entity.vo.order;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * 商品规格信息
 *
 * @Author ChenYou
 * @date 2021-11-17 15:16
 * @Version 1.0
 */
@Data
@Accessors(chain = true)
@ApiModel(description = "服务规格")
public class SpecificationVO {

    /**
     * 服务规格编码
     */
    @ApiModelProperty(value = "服务规格编码", required = true)
    private String specificationCode;
    /**
     * 服务规格名称
     */
    @ApiModelProperty(value = "服务规格名称", required = true)
    private String specificationName;
}

package com.space.lightapp.entity.vo;

import com.space.lightapp.base.BaseVO;
import com.space.lightapp.entity.LightAppAuth;
import com.space.osms.common.core.utils.DozerBeanUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 轻应用权限Vo对象 light_app_auth
 *
 * @author ChenYou
 * @date 2021-09-27
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "轻应用权限")
public class LightAppAuthVO extends BaseVO {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    private Long lightAppAuthId;
    /**
     * 轻应用Id
     */
    @ApiModelProperty(value = "轻应用Id")
    private Long lightAppId;
    /**
     * 用户类型 个人用户，企业，用户组等等
     */
    @ApiModelProperty(value = "用户类型 个人用户，企业，用户组等等")
    private String userType;
    /**
     * 用户Id
     */
    @ApiModelProperty(value = "用户Id")
    private String userId;
    /**
     * 用户名称
     */
    @ApiModelProperty(value = "用户名称")
    private String userName;
    /**
     * 配置类型 1发起人，2管理人
     */
    @ApiModelProperty(value = "配置类型 1发起人，2管理人")
    private Long configType;
    /**
     * 排序 排序字段
     */
    @ApiModelProperty(value = "排序 排序字段")
    private Long orderNum;
    /**
     * 状态 0-false-禁用，1-true-启用；默认1-true
     */
    @ApiModelProperty(value = "状态 0-false-禁用，1-true-启用；默认1-true")
    private Boolean status;

    /**
     * 是否删除  0-false-未删除，1-true-删除；默认0-false
     */
    @ApiModelProperty(value = "是否删除  0-false-未删除，1-true-删除；默认0-false")
    private Boolean delFlag;

    /**
     * Vo转Entity
     *
     * @return Entity对象
     * @date 2021-09-27
     */
    public LightAppAuth toEntity() {
        LightAppAuth lightAppAuth = DozerBeanUtil.transitionType(this, LightAppAuth.class);
        return lightAppAuth;
    }

    /**
     * List-Vo转List-Entity
     *
     * @return List-Entity对象
     * @date 2021-09-27
     */
    public List<LightAppAuth> toListEntity(List<LightAppAuthVO> lightAppAuthVo) {
        List<LightAppAuth> list = new ArrayList<>();
        lightAppAuthVo.forEach(t -> list.add(t.toEntity()));
        return list;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("lightAppAuthId", getLightAppAuthId())
                .append("lightAppId", getLightAppId())
                .append("userType", getUserType())
                .append("userId", getUserId())
                .append("configType", getConfigType())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

package com.space.lightapp.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.space.lightapp.base.BaseEntity;
import com.space.lightapp.entity.vo.LightAppServerDataDeliveryVO;
import com.space.lightapp.entity.vo.LightAppServerDataVO;
import com.space.osms.common.core.utils.DozerBeanUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 增值下单配送对象 light_app_server_data_delivery
 *
 * @author ChenYou
 * @date 2022-01-07
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("light_app_server_data_delivery")
@ApiModel(description = "增值下单配送")
public class LightAppServerDataDelivery extends BaseEntity {

    private static final long serialVersionUID = -2675255122134744850L;
    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long serverDataDeliveryId;
    /**
     * 轻应用Id
     */
    private Long lightAppId;
    /**
     * 服务数据Id
     */
    private Long serverDataId;
    /**
     * 轻应用小分类
     */
    @TableField(exist = false)
    private String appLittleType;
    /**
     * 服务Id
     */
    private Long serverId;
    /**
     * 服务分类Id
     */
    private Long serverTypeId;
    /**
     * 配送服务编码 配送编码
     */
    private String orderCode;
    /**
     * 配送数量
     */
    private Integer deliveryNum;
    /**
     * 流程key
     */
    private String processKey;
    /**
     * 流程节点状态
     */
    private String processState;
    /**
     * 流程实例Id
     */
    private String processInsId;
    /**
     * 当前节点处理人
     */
    private String processNodeUser;
    /**
     * 处理人详情
     */
    private String processNodeUserDetail;
    /**
     * 对应数据Id
     */
    private String dataId;
    /**
     * 任务Id
     */
    private String taskId;
    /**
     * 配送状态 delivery_ing进行中，delivery_success成功配送,delivery_cancel配送取消
     */
    private String businessState;
    /**
     * 配送状态 deliveryIng进行中，deliverySuccess成功配送,deliveryCancel配送取消
     */
    @TableField(exist = false)
    private String businessStateType;
    /**
     * 流程启动结果 流程启动结果 流程启动结果，1-启动成功，-1-启动失败，0-未启动流程
     */
    private Integer processStartStatus;
    /**
     * 第一个节点处理人
     */
    private String firstHandleName;
    /**
     * 最后节点处理人
     */
    private String lastHandleName;
    /**
     * 表单Id
     */
    private String formId;
    /**
     *  "单据来源 1 发起方，2 园区代申请"
     */
    private Integer source;
    /**
     * 排序 排序字段
     */
    private Integer orderNum;
    /**
     * 是否禁用 0禁用，1启用；默认1
     */
    private Boolean status;
    /**
     * 逻辑删除 0有效，1被删除；默认0
     */
    private Boolean delFlag;
    /**
     * 备注信息
     */
    private String remark;


    private String untitled;

    /**
     * 商品名称
     */
    @TableField(exist = false)
    private String goodsName;

    /**
     * 商品编码
     */
    @TableField(exist = false)
    private String goodsCode;

    /**
     * 规格
     */
    @TableField(exist = false)
    private String specification;

    /**
     * 分类名称
     */
    @TableField(exist = false)
    private String serverTypeName;

    /**
     * 内部订单号
     */
    @TableField(exist = false)
    private String extOrderCode;

    /**
     * 客户姓名
     */
    @TableField(exist = false)
    private String customerName;

    /**
     * 手机号码
     */
    @TableField(exist = false)
    private String customerPhone;


    @TableField(exist = false)
    private List<String> businessStateTypeList;

    /**
     * 搜索开始时间
     */
    @TableField(exist = false)
    private String startTime;
    /**
     * 搜索结束时间
     */
    @TableField(exist = false)
    private String endTime;

    /**
     * Entity转Vo
     *
     * @return Vo对象
     * @date 2022-01-07
     */
    public LightAppServerDataDeliveryVO toVo() {
        return DozerBeanUtil.transitionType(this, LightAppServerDataDeliveryVO.class);
    }

    /**
     * List-Entity转List-Vo
     *
     * @return List-Vo对象
     * @date 2022-01-07
     */
    public List<LightAppServerDataDeliveryVO> toListVo(
            List<LightAppServerDataDelivery> lightAppServerDataDelivery) {
        List<LightAppServerDataDeliveryVO> list = new ArrayList<>();
        lightAppServerDataDelivery.forEach(t -> list.add(t.toVo()));
        return list;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("serverDataDeliveryId", getServerDataDeliveryId())
                .append("lightAppId", getLightAppId())
                .append("serverDataId", getServerDataId())
                .append("orderCode", getOrderCode())
                .append("deliveryNum", getDeliveryNum())
                .append("processKey", getProcessKey())
                .append("processInsId", getProcessInsId())
                .append("processNodeUser", getProcessNodeUser())
                .append("processNodeUserDetail", getProcessNodeUserDetail())
                .append("dataId", getDataId())
                .append("taskId", getTaskId())
                .append("businessState", getBusinessState())
                .append("processStartStatus", getProcessStartStatus())
                .append("firstHandleName", getFirstHandleName())
                .append("lastHandleName", getLastHandleName())
                .append("formId", getFormId())
                .append("source", getSource())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("companyCode", getCompanyCode())
                .append("remark", getRemark())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

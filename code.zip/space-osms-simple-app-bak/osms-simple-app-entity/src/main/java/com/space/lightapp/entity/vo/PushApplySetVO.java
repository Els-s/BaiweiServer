package com.space.lightapp.entity.vo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.space.lightapp.base.BaseVO;
import com.space.lightapp.entity.PushApplySet;
import com.space.osms.common.core.utils.DozerBeanUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 报名设置Vo对象 push_apply_set
 *
 * @author ChenYou
 * @date 2021-10-18
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "报名设置")
public class PushApplySetVO extends BaseVO {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    private Long applySetId;
    /**
     * 轻应用Id
     */
    @ApiModelProperty(value = "轻应用Id")
    private Long lightAppId;
    /**
     * 轻应用类型
     */
    @ApiModelProperty(value = "轻应用类型")
    private String appMarketTypeCode;
    /**
     * 活动Id
     */
    @ApiModelProperty(value = "活动Id")
    private Long activityId;
    /**
     * 是否需要签到 0不需要，1需要
     */
    @ApiModelProperty(value = "活动Id")
    @TableField(exist = false)
    private Integer needSign;
    /**
     * 表单Id
     */
    @ApiModelProperty(value = "表单Id")
    private String fromId;
    /**
     * 报名人数上限
     */
    @ApiModelProperty(value = "报名人数上限")
    private Integer limitNumber;
    /**
     * 报名开始时间
     */
    @ApiModelProperty(value = "报名开始时间")
    private Date startTime;
    /**
     * 报名结束时间
     */
    @ApiModelProperty(value = "报名结束时间")
    private Date endTime;
    /**
     * 是否需要报名 0:不需要；1：需要
     */
    @ApiModelProperty(value = "是否需要报名 0:不需要；1：需要")
    private String needApply;
    /**
     * 是否需要报名费用 0不需要，1需要
     */
    @ApiModelProperty(value = "是否需要报名费用 0不需要，1需要")
    private Integer needMoney;
    /**
     * 费用金额
     */
    @ApiModelProperty(value = "费用金额")
    private BigDecimal money;
    /**
     * 流程Id
     */
    @ApiModelProperty(value = "流程Id")
    private String processId;
    /**
     * 是否需要填写信息 0需要，1不需要
     */
    @ApiModelProperty(value = "是否需要填写信息 0需要，1不需要")
    private Integer needInfo;
    /**
     * 排序 排序字段
     */
    @ApiModelProperty(value = "排序 排序字段")
    private Integer orderNum;
    /**
     * 是否禁用 0禁用，1启用；默认1
     */
    @ApiModelProperty(value = "是否禁用 0禁用，1启用；默认1")
    private Boolean status;
    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String remark;
    /**
     * 逻辑删除 0有效，1被删除；默认0
     */
    @ApiModelProperty(value = "逻辑删除 0有效，1被删除；默认0")
    private Boolean delFlag;

    /**
     * Vo转Entity
     *
     * @return Entity对象
     * @date 2021-10-18
     */
    public PushApplySet toEntity() {
        return DozerBeanUtil.transitionType(this, PushApplySet.class);
    }

    /**
     * List-Vo转List-Entity
     *
     * @return List-Entity对象
     * @date 2021-10-18
     */
    public List<PushApplySet> toListEntity(List<PushApplySetVO> pushApplySetVo) {
        List<PushApplySet> list = new ArrayList<>();
        pushApplySetVo.forEach(t -> list.add(t.toEntity()));
        return list;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("applySetId", getApplySetId())
                .append("lightAppId", getLightAppId())
                .append("appMarketTypeCode", getAppMarketTypeCode())
                .append("activityId", getActivityId())
                .append("fromId", getFromId())
                .append("limitNumber", getLimitNumber())
                .append("startTime", getStartTime())
                .append("endTime", getEndTime())
                .append("needMoney", getNeedMoney())
                .append("money", getMoney())
                .append("processId", getProcessId())
                .append("needInfo", getNeedInfo())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("companyCode", getCompanyCode())
                .append("remark", getRemark())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

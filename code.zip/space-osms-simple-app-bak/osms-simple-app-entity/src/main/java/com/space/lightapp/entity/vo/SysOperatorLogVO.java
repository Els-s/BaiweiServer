package com.space.lightapp.entity.vo;

import com.space.lightapp.base.BaseVO;
import com.space.lightapp.entity.SysOperatorLog;
import com.space.osms.common.core.utils.DozerBeanUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 操作日志Vo对象 sys_operator_log
 *
 * @author ChenYou
 * @date 2021-11-22
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "操作日志")
public class SysOperatorLogVO extends BaseVO {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    private Long operatorId;
    /**
     * 应用代码
     */
    @ApiModelProperty(value = "应用代码")
    private String moduleCode;
    /**
     * 模块标题
     */
    @ApiModelProperty(value = "模块标题")
    private String title;
    /**
     * 操作类型 add，delete，update，import，export，other
     */
    @ApiModelProperty(value = "操作类型 add，delete，update，import，export，other")
    private String operatorType;
    /**
     * 方法名称
     */
    @ApiModelProperty(value = "方法名称")
    private String method;
    /**
     * 请求方式
     */
    @ApiModelProperty(value = "请求方式")
    private String requestMethod;
    /**
     * 请求URL
     */
    @ApiModelProperty(value = "请求URL")
    private String operatorUrl;
    /**
     * 主机地址
     */
    @ApiModelProperty(value = "主机地址")
    private String operatorIp;
    /**
     * 操作地点
     */
    @ApiModelProperty(value = "操作地点")
    private String operatorLocation;
    /**
     * 请求参数
     */
    @ApiModelProperty(value = "请求参数")
    private String operatorParam;
    /**
     * 返回参数
     */
    @ApiModelProperty(value = "返回参数")
    private String jsonResult;
    /**
     * 操作状态 normal-正常，exception-异常
     */
    @ApiModelProperty(value = "操作状态 normal-正常，exception-异常")
    private String operatorState;
    /**
     * 错误消息
     */
    @ApiModelProperty(value = "错误消息")
    private String errorMsg;
    /**
     * 起始时间
     */
    @ApiModelProperty(value = "开始时间")
    private String startTime;
    /**
     * 结束时间
     */
    @ApiModelProperty(value = "结束时间")
    private String endTime;

    /**
     * Vo转Entity
     *
     * @return Entity对象
     * @date 2021-11-22
     */
    public SysOperatorLog toEntity() {
        return DozerBeanUtil.transitionType(this, SysOperatorLog.class);
    }

    /**
     * List-Vo转List-Entity
     *
     * @return List-Entity对象
     * @date 2021-11-22
     */
    public List<SysOperatorLog> toListEntity(List<SysOperatorLogVO> sysOperatorLogVo) {
        List<SysOperatorLog> list = new ArrayList<>();
        sysOperatorLogVo.forEach(t -> list.add(t.toEntity()));
        return list;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("operatorId", getOperatorId())
                .append("moduleCode", getModuleCode())
                .append("title", getTitle())
                .append("operatorType", getOperatorType())
                .append("method", getMethod())
                .append("requestMethod", getRequestMethod())
                .append("operatorUrl", getOperatorUrl())
                .append("operatorIp", getOperatorIp())
                .append("operatorLocation", getOperatorLocation())
                .append("operatorParam", getOperatorParam())
                .append("jsonResult", getJsonResult())
                .append("operatorState", getOperatorState())
                .append("errorMsg", getErrorMsg())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("companyCode", getCompanyCode())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .toString();
    }

}

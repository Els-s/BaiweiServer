package com.space.lightapp.enums;

import cn.hutool.core.collection.ListUtil;
import java.util.List;

/**
 * 订单业务状态
 *
 * @Author Els
 * @date 2021-11-16 15:04
 * @Version 1.0
 */
public enum BusinessStateEnum {
    //订单业务状态
    ORDER_ACCEPT_ING("order_accept_ing", "受理中", "受理中"),
    ORDER_ACCEPT("order_accept", "已受理", "已受理"),
    ORDER_APPLY_NO_PASS("order_apply_no_pass", "不通过", "下单审批不通过"),

    //支付业务状态
    PAY_AWAIT("pay_await", "待支付", "待支付"),
    PAY_TIME_OUT("pay_time_out", "已失效", "支付超时"),
    // 支付中
    PAY_ING("paying", "待支付", "待支付"),
    PAY_FAIL("pay_fail", "支付失败", "支付失败"),
    COMPANY_PAY_FAIL_BY_PROCESS("company_pay_fail_by_process", "支付失败", "月结审核后支付异常"),
    PAY_SUCCESS("pay_success", "已支付", "已支付"),
    //企业周期结算审批
    COMPANY_PAY_APPLY_ING("company_pay_apply_ing", "待审核", "企业支付申请中"),
    COMPANY_PAY_APPLY_NO_PASS("company_pay_apply_no_pass", "企业审核不通过", "企业支付申请未通过"),
    COMPANY_PAY_APPLY_ACCEPT("company_pay_apply_accept", "已通过", "企业支付申请完成"),
    //退款业务状态
    REFUND_APPLY_ING("refund_apply_ing", "退款中", "退款审批中"),
    REFUND_APPLY_NO_PASS("refund_apply_no_pass", "退款审核不通过", "退款审批不通过"),
    REFUND_APPLY_ACCEPT("refund_apply_accept", "退款中", "退款审批完成"),

    REFUND_AWAIT("refund_await", "退款中", "待退款"),

    REFUND_ING("refund_ing", "退款中", "退款中"),
    REFUND_FAIL("refund_fail", "退款失败", "退款失败"),
    REFUND_SUCCESS("refund_success", "已退款", "已退款"),

    //服务线下下单审批完成之后就是订单完成状态
    //订单结算状态
    ORDER_COMMIT("order_commit", "已完成", "订单完成"),
    ORDER_CLOSE("order_close", "已完成", "已关闭"),
    //订单取消
    ORDER_CANCEL("order_cancel", "已取消", "订单取消"),

    // 初始状态
    ORDER_INIT("order_init", "暂无", "订单初始状态"),
    ;

    private String code;
    private String info;
    private String msg;

    BusinessStateEnum(String code, String info, String msg) {
        this.code = code;
        this.info = info;
        this.msg = msg;
    }

    /**
     * 根据启动流程的类型，添加对应业务状态
     */
    public static String getBusinessState(StartProcessTypeEnum startProcessType) {
        switch (startProcessType) {
            case SERVER_TYPE:
                return ORDER_ACCEPT_ING.code;
            case COMPANY_PAY:
                return COMPANY_PAY_APPLY_ING.code;
            case REFUND:
                return REFUND_ING.code;
            default:
                break;
        }
        return ORDER_INIT.code;
    }

    public String getCode() {
        return code;
    }

    public String getInfo() {
        return info;
    }

    public String getMsg() {
        return msg;
    }

    /**
     * 获取已完结的所有状态
     *
     * @param
     * @return
     */
    public static String getFinishedCodes() {
        return ORDER_COMMIT.code + "," + ORDER_CLOSE.code + "," + ORDER_CANCEL.code + ","
                + PAY_TIME_OUT.code;
    }

    /**
     * 获取已完结的所有状态数组
     *
     * @param
     * @return
     */
    public static List<String> getFinishedCodeList() {
        return ListUtil
                .toList(ORDER_COMMIT.code,
                        ORDER_CLOSE.code,

                        ORDER_APPLY_NO_PASS.code,
                        COMPANY_PAY_APPLY_NO_PASS.code,
                        REFUND_APPLY_NO_PASS.code,

                        ORDER_CANCEL.code,
                        PAY_SUCCESS.code,
                        PAY_TIME_OUT.code,
                        COMPANY_PAY_APPLY_ACCEPT.code,
                        REFUND_FAIL.code,
                        REFUND_SUCCESS.code);
    }

    public static String getInfoValue(String code) {
        BusinessStateEnum[] values = BusinessStateEnum.values();
        for (BusinessStateEnum value : values) {
            if (value.getCode().equals(code)) {
                return value.getInfo();
            }
        }
        return "暂无";
    }

    public static String getMsgValue(String code) {
        BusinessStateEnum[] values = BusinessStateEnum.values();
        for (BusinessStateEnum value : values) {
            if (value.getCode().equals(code)) {
                return value.getMsg();
            }
        }
        return "暂无";
    }
}

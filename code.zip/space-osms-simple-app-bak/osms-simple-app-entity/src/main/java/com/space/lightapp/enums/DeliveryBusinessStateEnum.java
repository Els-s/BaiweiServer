package com.space.lightapp.enums;

import cn.hutool.core.collection.ListUtil;
import java.util.List;

/**
 * 配送状态枚举
 *
 * @Author ChenYou
 * @date 2022-01-07 17:32
 * @Version 1.0
 */
public enum DeliveryBusinessStateEnum {
    //配送状态
    DELIVERY_START_ING("delivery_start_ing", "待受理"),
    DELIVERY_ING("delivery_ing", "处理中"),
    DELIVERY_SUCCESS("delivery_success", "已完成"),
    DELIVERY_CANCEL("delivery_cancel", "已取消"),
    DELIVERY_REJECT("delivery_reject", "已关闭");

    private String code;
    private String info;

    DeliveryBusinessStateEnum(String code, String info) {
        this.code = code;
        this.info = info;
    }

    public String getCode() {
        return code;
    }

    public String getInfo() {
        return info;
    }

    public static DeliveryBusinessStateEnum getEnumByCode(String code) {
        DeliveryBusinessStateEnum[] values = DeliveryBusinessStateEnum.values();
        for (DeliveryBusinessStateEnum value : values) {
            if (value.getCode().equalsIgnoreCase(code)) {
                return value;
            }
        }
        return null;
    }

    public static List<String> getEndStatusList() {
        return ListUtil.toList(
                DELIVERY_SUCCESS.code,
                DELIVERY_CANCEL.code,
                DELIVERY_REJECT.code);
    }
}

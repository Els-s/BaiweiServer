package com.space.lightapp.entity.vo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.space.lightapp.base.BaseVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * 表单数据查询VO
 *
 * @Author ChenYou
 * @date 2021-10-22 9:13
 * @Version 1.0
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(description = "表单数据查询VO")
public class FormDataSelectVO extends BaseVO {

    /**
     * 轻应用Id
     */
    @ApiModelProperty(value = "轻应用Id")
    private Long lightAppId;
    /**
     * 轻应用类型
     */
    @ApiModelProperty(value = "轻应用类型")
    private String appMarketTypeCode;
    /**
     * 应用小分类编码
     */
    @ApiModelProperty(value = "应用小分类编码")
    private String appLittleType;
    /**
     * 关联业务Id（工单和基础服务，此字段为null；问卷关联问卷Id，活动关联活动Id）
     */
    @ApiModelProperty(value = "关联业务Id")
    private Long relevancyId;
    /**
     * 工单状态（1待受理，2处理中，3已完成，4已关闭，5待回访，6已取消）
     */
    @ApiModelProperty(value = "工单状态（1待受理，2处理中，3已完成，4已关闭，5待回访，6已取消）")
    private Integer processState;
    /**
     * 工单状态（1待受理，2处理中，3已完成，4已关闭，5待回访，6已取消）
     */
    @ApiModelProperty(value = "工单状态（1待受理，2处理中，3已完成，4已关闭，5待回访，6已取消）")
    @TableField(exist = false)
    private List<Integer> processStateList;
    /**
     * 时间状态（1:本日，2:近3日，3:近7天，4:近30日，5:近3月，6:今年）
     */
    @ApiModelProperty(value = "时间状态（1:本日，2:近3日，3:近7天，4:近30日，5:近3月，6:今年）")
    private Integer dataType;
    /**
     * 查询起始时间
     */
    @ApiModelProperty(value = "查询起始时间")
    private String startTime;
    /**
     * 查询结束时间
     */
    @ApiModelProperty(value = "查询结束时间")
    private String endTime;


}

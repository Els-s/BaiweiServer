package com.space.lightapp.entity.dto.resp;

import com.space.lightapp.base.BaseFieldDTO;
import com.space.lightapp.enums.ActivityEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.Date;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 活动信息返回
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "活动信息 ")
public class AppActivityDTO extends BaseFieldDTO {

    /**
     * 应用ID
     */
    private Long lightAppId;
    /**
     * 服务类型代码
     */
    @ApiModelProperty(value = "服务类型代码")
    private String appMarketTypeCode;
    /**
     * 活动id
     */
    @ApiModelProperty(value = "活动id")
    private Long activityId;
    /**
     * 活动地址
     */
    @ApiModelProperty(value = "活动地址")
    private String activityAddress;
    /**
     * 活动内容
     */
    @ApiModelProperty(value = "活动内容")
    private String activityContent;
    /**
     * 流程ID
     */
    @ApiModelProperty(value = "流程ID")
    private String processId;
    /**
     * 活动代码
     */
    @ApiModelProperty(value = "活动代码")
    private String activityCode;
    /**
     * 活动名称
     */
    @ApiModelProperty(value = "活动名称")
    private String activityName;
    /**
     * 表单ID
     */
    @ApiModelProperty(value = "表单ID")
    private String formId;
    /**
     * log图片地址
     */
    @ApiModelProperty(value = "log图片地址")
    private String iconUrl;
    /**
     * 是否需要签到
     */
    @ApiModelProperty(value = "是否需要签到 0不需要，1需要")
    private String needSign;

    /**
     * 签到开始时间
     */
    @ApiModelProperty(value = "签到开始时间")
    private Date signStartTime;
    /**
     * 签到结束时间
     */
    @ApiModelProperty(value = "签到结束时间")
    private Date signEndTime;

    @ApiModelProperty(value = "参与条件 tourist:游客   commonUser:普通用户   companyEmployee:企业员工   companyManager:企业管理员,多种类型英文逗号隔开")
    private String serverLaunchUser;

    /**
     * 是否需要报名 0:不需要；1：需要
     */
    @ApiModelProperty(value = "是否需要报名 0:不需要；1：需要")
    private String needApply;
    /**
     * 参与条件描述
     */
    @ApiModelProperty(value = "参与条件描述")
    private String description;
    /**
     * 报名上限
     */
    @ApiModelProperty(value = "报名上限")
    private Integer limitNumber;
    /**
     * 报名开始时间
     */
    @ApiModelProperty(value = "报名开始时间")
    private Date applyStartTime;
    /**
     * 报名结束时间
     */
    @ApiModelProperty(value = "报名结束时间")
    private Date applyEndTime;
    /**
     * 签到开始时间
     */
    @ApiModelProperty(value = "活动开始生效时间")
    private Date startTime;
    /**
     * 签到结束时间
     */
    @ApiModelProperty(value = "活动结束时间")
    private Date endTime;
    /**
     * 报名开始时间
     */
    @ApiModelProperty(value = "是否需要报名费用 0不需要，1需要")
    private Integer needMoney;
    /**
     * 报名费用金额
     */
    @ApiModelProperty(value = "报名费用金额")
    private String money;
    /**
     * 活动状态 draft草稿，notStart未开始，underWay进行中，suspend暂停中，finish已结束
     */
    @ApiModelProperty(value = "活动状态 draft草稿，notStart未开始，underWay进行中，suspend暂停中，finish已结束")
    private String activityType;
    /**
     * 在线状态：online 上线中，offline 下线中， null 无在线状态
     */
    @ApiModelProperty(value = "在线状态：online 上线中，offline 下线中， null 无在线状态")
    private String onlineStatus;
    /**
     * 是否需要填写报名信息
     */
    @ApiModelProperty(value = "是否需要填写报名信息 0不需要，1需要")
    private Integer needInfo;
    /**
     * 子查询: 活动参与人数
     */
    @ApiModelProperty(value = "活动参与人数")
    private Integer joinNum;
    /**
     * 是否存在我的参与记录
     */
    @ApiModelProperty(value = "是否存在我的参与记录")
    private Integer hasMyJoinNum;

    /**
     * 是否存在我的参与审核记录
     */
    @ApiModelProperty(value = "是否存在我的参与审核记录")
    private Integer hasMyJoinCheckNum;

    /**
     * 点击量查看数
     */
    @ApiModelProperty(value = "点击量查看数")
    private Integer readCount;

    /**
     * 活动签到状态
     */
    @ApiModelProperty(value = "活动签到状态")
    private ActivityEnum.ActivitySignStatus signStatus;

    /**
     * 我的签到记录数
     */
    @ApiModelProperty(value = "是否存在我的签到记录数")
    private Integer hasMySignNum;

    private ActivityEnum.ActivityStatus activityStatusEnum;
    private ActivityEnum.ActivityApply canApplyEnum;
    private List<String> mobileList;
    private List<String> avatarList;
}



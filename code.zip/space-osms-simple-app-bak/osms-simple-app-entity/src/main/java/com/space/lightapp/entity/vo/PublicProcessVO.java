package com.space.lightapp.entity.vo;

import com.space.lightapp.base.BaseVO;
import com.space.lightapp.entity.PublicProcess;
import com.space.osms.common.core.utils.DozerBeanUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 公共流程 Vo对象 public_process
 *
 * @author ChenYou
 * @date 2021-11-12
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "公共流程 ")
public class PublicProcessVO extends BaseVO {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    private Long publicProcessId;
    /**
     * 流程分类 settle-企业结算流程，refund-退款流程
     */
    @ApiModelProperty(value = "流程分类 settle-企业结算流程，refund-退款流程")
    private String processType;
    /**
     * 表单 默认表单的Id
     */
    @ApiModelProperty(value = "表单 默认表单的Id")
    private String formId;
    /**
     * 表单别名 表单别名
     */
    @ApiModelProperty(value = "表单别名 表单别名")
    private String alias;
    /**
     * 流程key 对应Spaas的流程key，暂时手动维护
     */
    @ApiModelProperty(value = "流程key 对应Spaas的流程key，暂时手动维护")
    private String processKey;
    /**
     * 排序 排序字段
     */
    @ApiModelProperty(value = "排序 排序字段")
    private Integer orderNum;
    /**
     * 是否禁用 0禁用，1启用；默认1
     */
    @ApiModelProperty(value = "是否禁用 0禁用，1启用；默认1")
    private Boolean status;
    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String remark;
    /**
     * 逻辑删除 0有效，1被删除；默认0
     */
    @ApiModelProperty(value = "逻辑删除 0有效，1被删除；默认0")
    private Boolean delFlag;

    /**
     * Vo转Entity
     *
     * @return Entity对象
     * @date 2021-11-12
     */
    public PublicProcess toEntity() {
        return DozerBeanUtil.transitionType(this, PublicProcess.class);
    }

    /**
     * List-Vo转List-Entity
     *
     * @return List-Entity对象
     * @date 2021-11-12
     */
    public List<PublicProcess> toListEntity(List<PublicProcessVO> publicProcessVo) {
        List<PublicProcess> list = new ArrayList<>();
        publicProcessVo.forEach(t -> list.add(t.toEntity()));
        return list;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("publicProcessId", getPublicProcessId())
                .append("processType", getProcessType())
                .append("formId", getFormId())
                .append("alias", getAlias())
                .append("processKey", getProcessKey())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("companyCode", getCompanyCode())
                .append("remark", getRemark())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

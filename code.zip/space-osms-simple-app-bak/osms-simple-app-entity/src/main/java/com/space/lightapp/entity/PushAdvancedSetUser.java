package com.space.lightapp.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.space.lightapp.base.BaseEntity;
import com.space.lightapp.entity.vo.PushAdvancedSetUserVO;
import com.space.osms.common.core.utils.DozerBeanUtil;
import io.swagger.annotations.ApiModel;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 高级设置-发起角色对象 push_advanced_set_user
 *
 * @author ChenYou
 * @date 2021-11-04
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("push_advanced_set_user")
@ApiModel(description = "高级设置-发起角色")
public class PushAdvancedSetUser extends BaseEntity {

    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long setUserId;
    /**
     * 轻应用Id
     */
    private Long lightAppId;
    /**
     * 高级设置Id
     */
    private Long pushAdvancedSetId;
    /**
     * 设置类型 1发起角色，其他待定
     */
    private Integer setType;
    /**
     * 用户数据类型 user用户，role角色，company企业，group用户组
     */
    private String userType;
    /**
     * 对应类型代码
     */
    private String userCode;
    /**
     * 对应名称
     */
    private String userName;
    /**
     * 排序 排序字段
     */
    private Integer orderNum;
    /**
     * 状态 0禁用，1启用；默认1
     */
    private Boolean status;
    /**
     * 逻辑删除 0有效，1被删除；默认0
     */
    private Boolean delFlag;

    /**
     * Entity转Vo
     *
     * @return Vo对象
     * @date 2021-11-04
     */
    public PushAdvancedSetUserVO toVo() {
        return DozerBeanUtil.transitionType(this, PushAdvancedSetUserVO.class);
    }

    /**
     * List-Entity转List-Vo
     *
     * @return List-Vo对象
     * @date 2021-11-04
     */
    public List<PushAdvancedSetUserVO> toListVo(List<PushAdvancedSetUser> pushAdvancedSetUser) {
        List<PushAdvancedSetUserVO> list = new ArrayList<>();
        pushAdvancedSetUser.forEach(t -> list.add(t.toVo()));
        return list;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("setUserId", getSetUserId())
                .append("lightAppId", getLightAppId())
                .append("pushAdvancedSetId", getPushAdvancedSetId())
                .append("setType", getSetType())
                .append("userType", getUserType())
                .append("userCode", getUserCode())
                .append("userName", getUserName())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("companyCode", getCompanyCode())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

package com.space.lightapp.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.space.lightapp.entity.vo.FormInstRelationVO;
import com.space.osms.common.core.utils.DozerBeanUtil;
import io.swagger.annotations.ApiModel;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import lombok.Data;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 单流程数据关联信息对象 form_inst_relation
 *
 * @author ChenYou
 * @date 2021-11-08
 */
@Data
@Accessors(chain = true)
@TableName("form_inst_relation")
@ApiModel(description = "单流程数据关联信息")
public class FormInstRelation {

    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long relId;
    /**
     * 主键
     */
    private String instId;
    /**
     * 表单别名
     */
    private String alisa;
    /**
     * 数据ID
     */
    private String dataId;
    /**
     * 轻应用Id
     */
    private Long lightAppId;
    /**
     * 报单人-手机号
     */
    private String userPhone;
    /**
     * 报单人-用户编码
     */
    private String userCode;
    /**
     * 应用类型
     */
    private String appMarkTypeCode;
    /**
     * 子类流程类别
     */
    private String instLittleTypeCode;
    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    private Date createTime;
    /**
     * 创建人
     */
    @TableField(fill = FieldFill.INSERT)
    private String createBy;

    /**
     * 更新时间
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date updateTime;

    /**
     * Entity转Vo
     *
     * @return Vo对象
     * @date 2021-11-08
     */
    public FormInstRelationVO toVo() {
        return DozerBeanUtil.transitionType(this, FormInstRelationVO.class);
    }

    /**
     * List-Entity转List-Vo
     *
     * @return List-Vo对象
     * @date 2021-11-08
     */
    public List<FormInstRelationVO> toListVo(List<FormInstRelation> formInstRelation) {
        List<FormInstRelationVO> list = new ArrayList<>();
        formInstRelation.forEach(t -> list.add(t.toVo()));
        return list;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("instId", getInstId())
                .append("alisa", getAlisa())
                .append("dataId", getDataId())
                .append("lightAppId", getLightAppId())
                .append("userPhone", getUserPhone())
                .append("userCode", getUserCode())
                .append("appMarkTypeCode", getAppMarkTypeCode())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateTime", getUpdateTime())
                .toString();
    }
}

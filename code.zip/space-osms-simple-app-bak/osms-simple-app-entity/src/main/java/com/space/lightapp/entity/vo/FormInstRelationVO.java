package com.space.lightapp.entity.vo;

import com.space.lightapp.base.BaseVO;
import com.space.lightapp.entity.FormInstRelation;
import com.space.osms.common.core.utils.DozerBeanUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 单流程数据关联信息Vo对象 form_inst_relation
 *
 * @author ChenYou
 * @date 2021-11-08
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "单流程数据关联信息")
public class FormInstRelationVO extends BaseVO {

    /**
     * 主键
     */
    private Long relId;
    /**
     * 流程ID
     */
    @ApiModelProperty(value = "流程ID")
    private String instId;
    /**
     * 表单别名
     */
    @ApiModelProperty(value = "表单别名")
    private String alisa;
    /**
     * 数据ID
     */
    @ApiModelProperty(value = "数据ID")
    private String dataId;
    /**
     * 轻应用Id
     */
    private Long lightAppId;
    /**
     * 报单人-手机号
     */
    @ApiModelProperty(value = "报单人-手机号")
    private String userPhone;
    /**
     * 报单人-用户编码
     */
    @ApiModelProperty(value = "报单人-用户编码")
    private String userCode;
    /**
     * 应用类型
     */
    @ApiModelProperty(value = "应用类型")
    private String appMarkTypeCode;
    /**
     * 子类流程类别
     */
    @ApiModelProperty(value = "子类流程类别")
    private String instLittleTypeCode;

    /**
     * Vo转Entity
     *
     * @return Entity对象
     * @date 2021-11-08
     */
    public FormInstRelation toEntity() {
        return DozerBeanUtil.transitionType(this, FormInstRelation.class);
    }

    /**
     * List-Vo转List-Entity
     *
     * @return List-Entity对象
     * @date 2021-11-08
     */
    public List<FormInstRelation> toListEntity(List<FormInstRelationVO> formInstRelationVo) {
        List<FormInstRelation> list = new ArrayList<>();
        formInstRelationVo.forEach(t -> list.add(t.toEntity()));
        return list;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("instId", getInstId())
                .append("alisa", getAlisa())
                .append("dataId", getDataId())
                .append("lightAppId", getLightAppId())
                .append("userPhone", getUserPhone())
                .append("userCode", getUserCode())
                .append("appMarkTypeCode", getAppMarkTypeCode())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateTime", getUpdateTime())
                .toString();
    }
}

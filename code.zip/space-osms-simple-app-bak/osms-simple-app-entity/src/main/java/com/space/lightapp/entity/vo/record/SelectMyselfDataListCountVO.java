package com.space.lightapp.entity.vo.record;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 我的应用数据数量VO
 *
 * @Author Els
 * @date 2021-12-30 19:53
 * @Version 1.0
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SelectMyselfDataListCountVO {

    private long total;
    private long processIng;
    private long finished;
}

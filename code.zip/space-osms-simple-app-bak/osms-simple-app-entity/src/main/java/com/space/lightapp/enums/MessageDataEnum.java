package com.space.lightapp.enums;

/**
 * @author JiangHao
 * @version 1.0
 * @date 2021/12/1 0001 20:08
 * @description
 */
public enum MessageDataEnum {
    // 订阅消息
    ORDER_SUCCESS("order_success", "下单成功。"),
    ORDER_APPLY_NO_PASS("order_apply_no_pass", "下单审批不通过。"),
    PAY_SUCCESS("pay_success", "支付成功。"),
    REFUND_FAIL("refund_fail", "退款失败."),
    REFUND_APPLY_NO_PASS("refund_apply_no_pass", "退款审批不通过."),
    REFUND_SUCCESS("refund_success", "退款成功。"),
    ORDER_COMPLETE_SUCCESS("order_complete_success", "订单已完成。"),
    ;

    private String code;
    private String info;

    MessageDataEnum(String code, String info) {
        this.code = code;
        this.info = info;
    }

    public String getCode() {
        return code;
    }

    public String getInfo() {
        return info;
    }
}

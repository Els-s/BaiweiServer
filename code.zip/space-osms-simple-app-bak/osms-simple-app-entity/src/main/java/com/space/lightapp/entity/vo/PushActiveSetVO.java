package com.space.lightapp.entity.vo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.space.lightapp.base.BaseVO;
import com.space.lightapp.entity.PushActiveSet;
import com.space.osms.common.core.utils.DozerBeanUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 启用设置Vo对象 push_active_set
 *
 * @author ChenYou
 * @date 2021-09-27
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "启用设置")
public class PushActiveSetVO extends BaseVO {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    private Long pushActiveSetId;
    /**
     * 应用模块Id
     */
    @ApiModelProperty(value = "应用模块Id")
    private Long lightAppModuleId;
    /**
     * 轻应用id
     */
    @ApiModelProperty(value = "轻应用id")
    private Long lightAppId;
    /**
     * 启用项目代码
     */
    @ApiModelProperty(value = "启用项目代码")
    private String activeProjectCode;
    /**
     * 启用项目名称
     */
    @ApiModelProperty(value = "启用项目名称")
    private String activeProjectName;
    /**
     * 排序 排序字段
     */
    @ApiModelProperty(value = "排序 排序字段")
    private Long orderNum;
    /**
     * 状态 0-false-禁用，1-true-启用；默认1-true
     */
    @ApiModelProperty(value = "状态 0-false-禁用，1-true-启用；默认1-true")
    private Boolean status;

    /**
     * 是否删除  0-false-未删除，1-true-删除；默认0-false
     */
    @ApiModelProperty(value = "是否删除  0-false-未删除，1-true-删除；默认0-false")
    private Boolean delFlag;

    /**
     * 应用类型代码
     */
    @ApiModelProperty(value = "应用类型代码")
    @TableField(exist = false)
    private String appMarketTypeCode;

    /**
     * Vo转Entity
     *
     * @return Entity对象
     * @date 2021-09-27
     */
    public PushActiveSet toEntity() {
        PushActiveSet pushActiveSet = DozerBeanUtil.transitionType(this, PushActiveSet.class);
        return pushActiveSet;
    }

    /**
     * List-Vo转List-Entity
     *
     * @return List-Entity对象
     * @date 2021-09-27
     */
    public List<PushActiveSet> toListEntity(List<PushActiveSetVO> pushActiveSetVo) {
        List<PushActiveSet> list = new ArrayList<>();
        pushActiveSetVo.forEach(t -> list.add(t.toEntity()));
        return list;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("pushActiveSetId", getPushActiveSetId())
                .append("lightAppModuleId", getLightAppModuleId())
                .append("activeProjectCode", getActiveProjectCode())
                .append("activeProjectName", getActiveProjectName())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

package com.space.lightapp.entity.vo.order;

import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;

/**
 * 订单详情按钮展示
 *
 * @Author Els
 * @date 2021-12-10 17:22
 * @Version 1.0
 */
@Data
@Builder
public class CancelButtonVO {

    @ApiModelProperty(value = "是否显示配送记录按钮")
    private Boolean allowDeliverySign;
    @ApiModelProperty(value = "是否可以申请配送")
    private Boolean allowApplyDelivery;
    @ApiModelProperty(value = "是否可以取消")
    private Boolean allowCancel;
    @ApiModelProperty(value = "是否可以发起支付")
    private Boolean allowPay;
    @ApiModelProperty(value = "是否可以发起撤销退款=取消退款")
    private Boolean allowCancelRefund;
    @ApiModelProperty(value = "是否需要填写退款原因")
    private Boolean needRefundReason;
}

package com.space.lightapp.entity.vo;

import com.space.lightapp.base.BaseVO;
import com.space.lightapp.entity.PushFunctionSet;
import com.space.osms.common.core.utils.DozerBeanUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 功能设置Vo对象 push_function_set
 *
 * @author ChenYou
 * @date 2021-10-14
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "功能设置")
public class PushFunctionSetVO extends BaseVO {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    private Long functionSetId;
    /**
     * 轻应用Id
     */
    @ApiModelProperty(value = "轻应用Id")
    private Long lightAppId;
    /**
     * 应用服务类型代码 survey问卷，active活动
     */
    @ApiModelProperty(value = "应用服务类型代码 survey问卷，active活动")
    private String appMarketTypeCode;
    /**
     * 关联Id
     */
    @ApiModelProperty(value = "关联Id")
    private Long relevancyId;
    /**
     * 填写渠道
     */
    @ApiModelProperty(value = "填写渠道")
    private String pushDitch;
    /**
     * 限制用户填写次数
     */
    @ApiModelProperty(value = "限制用户填写次数类型：仅限 once；每天 day;每周 week；每月 month")
    private String writeTime;
    /**
     * 限制用户填写次数值
     */
    @ApiModelProperty(value = "限制用户填写次数值")
    private Integer writeTimeCount;
    /**
     * 是否允许分享到朋友圈
     */
    @ApiModelProperty(value = "是否允许分享到朋友圈")
    private Boolean shareFriends;
    /**
     * 是否允许发送给朋友
     */
    @ApiModelProperty(value = "是否允许发送给朋友")
    private Boolean shareFriend;
    /**
     * 排序 排序字段
     */
    @ApiModelProperty(value = "排序 排序字段")
    private Integer orderNum;
    /**
     * 是否禁用 0禁用，1启用；默认1
     */
    @ApiModelProperty(value = "是否禁用 0禁用，1启用；默认1")
    private Boolean status;
    /**
     * 备注信息
     */
    @ApiModelProperty(value = "备注")
    private String remark;

    /**
     * 逻辑删除 0有效，1被删除；默认0
     */
    @ApiModelProperty(value = "逻辑删除 0有效，1被删除；默认0")
    private Boolean delFlag;

    /**
     * Vo转Entity
     *
     * @return Entity对象
     * @date 2021-10-14
     */
    public PushFunctionSet toEntity() {
        return DozerBeanUtil.transitionType(this, PushFunctionSet.class);
    }

    /**
     * List-Vo转List-Entity
     *
     * @return List-Entity对象
     * @date 2021-10-14
     */
    public List<PushFunctionSet> toListEntity(List<PushFunctionSetVO> pushFunctionSetVo) {
        List<PushFunctionSet> list = new ArrayList<>();
        pushFunctionSetVo.forEach(t -> list.add(t.toEntity()));
        return list;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("functionSetId", getFunctionSetId())
                .append("lightAppId", getLightAppId())
                .append("appMarketTypeCode", getAppMarketTypeCode())
                .append("relevancyId", getRelevancyId())
                .append("pushDitch", getPushDitch())
                .append("writeTime", getWriteTime())
                .append("shareFriends", getShareFriends())
                .append("shareFriend", getShareFriend())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("remark", getRemark())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

package com.space.lightapp.entity.vo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.space.lightapp.base.BaseVO;
import com.space.lightapp.entity.PushAdvertisingSet;
import com.space.lightapp.entity.vo.message.AdvertisingVO;
import com.space.lightapp.entity.vo.message.ChannelRelBusinessVO;
import com.space.osms.common.core.utils.DozerBeanUtil;
import com.space.osms.common.core.utils.ListUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 发布广告 Vo对象 push_advertising_set
 *
 * @author ChenYou
 * @date 2021-10-29
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "发布广告 ")
public class PushAdvertisingSetVO extends BaseVO {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    private Long advertisingSetId;
    /**
     * 轻应用Id
     */
    @ApiModelProperty(value = "轻应用Id")
    private Long lightAppId;
    /**
     * 消息id
     */
    private Long messageId;
    /**
     * 是否推送到消息中心：0否 1是
     */
    private Integer pushMessage;
    /**
     * 应用服务类型代码
     */
    @ApiModelProperty(value = "应用服务类型代码")
    private String appMarketTypeCode;
    /**
     * 关联Id
     */
    @ApiModelProperty(value = "关联Id")
    private Long relevancyId;
    /**
     * 发布渠道 上架渠道以及排序，statusType全民:ORANGE_MANILA，中介报备:REPORT，运营:OPERATOR_MANAGE；排序showOrder
     */
    @ApiModelProperty(value = "发布渠道 上架渠道以及排序，statusType全民:ORANGE_MANILA，中介报备:REPORT，运营:OPERATOR_MANAGE；排序showOrder")
    private String advertisingChannel;

    @TableField(exist = false)
    private List<ChannelRelBusinessVO> channelRelBusinessEntities;
    /**
     * 广告名称
     */
    @ApiModelProperty(value = "广告名称")
    private String advertisingName;
    /**
     * 发布位置 发布位置：0 Banner图
     */
    @ApiModelProperty(value = "发布位置 发布位置：0 Banner图")
    private String newsType;
    /**
     * 广告跳转类型 0 项目详情、1 H5页面
     */
    @ApiModelProperty(value = "广告跳转类型 0 项目详情、1 H5页面")
    private String jumpType;
    /**
     * 跳转链接 广告跳转地址，项目详情传ProjectCode
     */
    @ApiModelProperty(value = "跳转链接 广告跳转地址，项目详情传ProjectCode")
    private String jumpUrl;
    /**
     * 发布范围
     */
    @ApiModelProperty(value = "发布范围")
    @TableField(exist = false)
    private List<String> projectCodeList;
    private String projectCodes;
    /**
     * 是否长期  0否 1是
     */
    @ApiModelProperty(value = "是否长期  0否 1是")
    private Integer longTerm;
    /**
     * 开始时间
     */
    @ApiModelProperty(value = "开始时间")
    private Date startTime;
    /**
     * 到期时间
     */
    @ApiModelProperty(value = "到期时间")
    private Date endTime;
    /**
     * 到期时间
     */
    @ApiModelProperty(value = "到期时间")
    private Date endDate;
    /**
     * 生效时间
     */
    @ApiModelProperty(value = "生效时间")
    private Date effectDate;
    /**
     * 广告图片
     */
    @ApiModelProperty(value = "广告图片")
    private String imgUrl;
    /**
     * 排序 排序字段 showOrder
     */
    @ApiModelProperty(value = "排序 排序字段")
    private Integer showOrder;
    /**
     * 是否禁用 0禁用，1启用；默认1
     */
    @ApiModelProperty(value = "是否禁用 0禁用，1启用；默认1")
    private Boolean status;
    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String remark;

    /**
     * Vo转Entity
     *
     * @return Entity对象
     * @date 2021-10-29
     */
    public PushAdvertisingSet toEntity() {
        PushAdvertisingSet pushAdvertisingSet = DozerBeanUtil
                .transitionType(this, PushAdvertisingSet.class);
        pushAdvertisingSet.setProjectCodes(ListUtil.listToString(this.getProjectCodeList()));
        return pushAdvertisingSet;
    }

    /**
     * Entity转消息Vo
     *
     * @return Vo对象
     * @date 2021-10-29
     */
    public AdvertisingVO toMessageVo() {
        AdvertisingVO advertisingVO = DozerBeanUtil
                .transitionType(this, AdvertisingVO.class);
        advertisingVO.setProjectCodeList(this.getProjectCodeList());
        //advertisingVO.setEndDate(new Timestamp(this.getEndTime().getTime()));
        return advertisingVO;
    }

    /**
     * List-Vo转List-Entity
     *
     * @return List-Entity对象
     * @date 2021-10-29
     */
    public List<PushAdvertisingSet> toListEntity(List<PushAdvertisingSetVO> pushAdvertisingSetVo) {
        List<PushAdvertisingSet> list = new ArrayList<>();
        pushAdvertisingSetVo.forEach(t -> list.add(t.toEntity()));
        return list;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("advertisingSetId", getAdvertisingSetId())
                .append("lightAppId", getLightAppId())
                .append("appMarketTypeCode", getAppMarketTypeCode())
                .append("relevancyId", getRelevancyId())
                .append("advertisingChannel", getAdvertisingChannel())
                .append("advertisingName", getAdvertisingName())
                .append("newsType", getNewsType())
                .append("jumpType", getJumpType())
                .append("jumpUrl", getJumpUrl())
                .append("longTerm", getLongTerm())
                .append("startTime", getStartTime())
                .append("endTime", getEndTime())
                .append("effectDate", getEffectDate())
                .append("imgUrl", getImgUrl())
                .append("showOrder", getShowOrder())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("companyCode", getCompanyCode())
                .append("remark", getRemark())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .toString();
    }

}

package com.space.lightapp.entity.dto;

import com.space.lightapp.base.BaseVO;
import com.space.lightapp.entity.DictType;
import com.space.osms.common.core.utils.DozerBeanUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 字典类型Dto对象 dict_type
 *
 * @author ChenYou
 * @date 2021-09-27
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "字典类型")
public class DictTypeDTO extends BaseVO {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    private Long dictTypeId;
    /**
     * 字典分类：默认public公共分类，
     */
    @ApiModelProperty(value = "字典分类：填写appCode值。", required = true)
    private String dictClassCode;
    /**
     * 类型代码
     */
    @ApiModelProperty(value = "类型代码")
    private String dictTypeCode;
    /**
     * 轻应用Id
     */
    @ApiModelProperty(value = "轻应用Id")
    private Long lightAppId;
    /**
     * 状态 0-false-禁用，1-true-启用；默认1-true
     */
    @ApiModelProperty(value = "状态 0-false-禁用，1-true-启用；默认1-true")
    private Boolean status;

    /**
     * 是否删除  0-false-未删除，1-true-删除；默认0-false
     */
    @ApiModelProperty(value = "是否删除  0-false-未删除，1-true-删除；默认0-false")
    private Boolean delFlag;
    /**
     * 类型名称
     */
    @ApiModelProperty(value = "类型名称")
    private String dictTypeName;
    /**
     * 排序 排序字段
     */
    @ApiModelProperty(value = "排序 排序字段")
    private Long orderNum;

    /**
     * Dto转Entity
     *
     * @return Entity对象
     * @date 2021-09-27
     */
    public DictType toEntity() {
        DictType dictType = DozerBeanUtil.transitionType(this, DictType.class);
        return dictType;
    }

    /**
     * List-Dto转List-Entity
     *
     * @return List-Entity对象
     * @date 2021-09-27
     */
    public List<DictType> toListEntity(List<DictTypeDTO> dictTypeDto) {
        List<DictType> list = new ArrayList<>();
        dictTypeDto.forEach(t -> list.add(t.toEntity()));
        return list;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("dictTypeId", getDictTypeId())
                .append("lightAppTemplateId", getLightAppId())
                .append("dictTypeCode", getDictTypeCode())
                .append("dictTypeName", getDictTypeName())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("delFlag", getDelFlag())
                .toString();
    }

}



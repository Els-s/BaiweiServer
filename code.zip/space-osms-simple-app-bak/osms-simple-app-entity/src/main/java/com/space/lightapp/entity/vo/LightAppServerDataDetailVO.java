package com.space.lightapp.entity.vo;

import com.alibaba.fastjson.JSONObject;
import com.space.lightapp.base.BaseVO;
import com.space.lightapp.entity.LightAppServerDataDetail;
import com.space.osms.common.core.utils.DozerBeanUtil;
import com.space.osms.common.core.utils.ListUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 服务下单详情 Vo对象 light_app_server_data_detail
 *
 * @author ChenYou
 * @date 2021-11-12
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = "服务下单详情 ")
public class LightAppServerDataDetailVO extends BaseVO {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    private Long serverDataDetailId;
    /**
     * 轻应用Id
     */
    @ApiModelProperty(value = "轻应用Id")
    private Long lightAppId;
    /**
     * 轻应用类型
     */
    @ApiModelProperty(value = "轻应用类型")
    private String appMarketTypeCode;
    /**
     * 轻应用小分类
     */
    @ApiModelProperty(value = "轻应用小分类")
    private String appLittleType;
    /**
     * 服务Id
     */
    @ApiModelProperty(value = "服务Id")
    private Long serverId;
    /**
     * 下单数据Id
     */
    @ApiModelProperty(value = "下单数据Id")
    private Long serverDataId;
    /**
     * 附件
     */
    @ApiModelProperty(value = "附件")
    private List<String> fileUrlList;

    private String fileUrls;
    /**
     * 单据类型 支付，退款，周期结算
     */
    @ApiModelProperty(value = "单据类型 支付，退款，周期结算")
    private String orderType;
    /**
     * 单据编码（对外） 对应类型不同的单据
     */
    @ApiModelProperty(value = "单据编码（对外） 对应类型不同的单据")
    private String orderCode;
    /**
     * 详情
     */
    private String orderDetail;
    /**
     * 详情展示
     */
    @ApiModelProperty(value = "详情展示数据")
    private JSONObject dataVo;
    /**
     * 对应金额
     */
    @ApiModelProperty(value = "对应金额")
    private String money;
    /**
     * 数据状态 0失败，1成功，2进行中
     */
    @ApiModelProperty(value = "数据状态 0失败，1成功，2进行中")
    private String dataType;
    /**
     * 流程key
     */
    @ApiModelProperty(value = "流程key")
    private String processKey;
    /**
     * 流程定义Id
     */
    @ApiModelProperty(value = "流程定义Id")
    private String processInsId;
    /**
     * 表单Id
     */
    @ApiModelProperty(value = "表单Id")
    private String formId;
    /**
     * 排序 排序字段
     */
    @ApiModelProperty(value = "排序 排序字段")
    private Integer orderNum;
    /**
     * 是否禁用 0禁用，1启用；默认1
     */
    @ApiModelProperty(value = "是否禁用 0禁用，1启用；默认1")
    private Boolean status;
    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String remark;
    /**
     * 支付状态
     */
    @ApiModelProperty(value = "支付状态")
    private String payStatus;

    /**
     * Vo转Entity
     *
     * @return Entity对象
     * @date 2021-11-12
     */
    public LightAppServerDataDetail toEntity() {
        LightAppServerDataDetail lightAppServerDataDetail = DozerBeanUtil
                .transitionType(this, LightAppServerDataDetail.class);
        lightAppServerDataDetail.setFileUrl(ListUtil.listToString(this.fileUrlList));
        return lightAppServerDataDetail;
    }

    /**
     * List-Vo转List-Entity
     *
     * @return List-Entity对象
     * @date 2021-11-12
     */
    public List<LightAppServerDataDetail> toListEntity(
            List<LightAppServerDataDetailVO> lightAppServerDataDetailVo) {
        List<LightAppServerDataDetail> list = new ArrayList<>();
        lightAppServerDataDetailVo.forEach(t -> list.add(t.toEntity()));
        return list;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("serverDataDetailId", getServerDataDetailId())
                .append("lightAppId", getLightAppId())
                .append("appMarketTypeCode", getAppMarketTypeCode())
                .append("appLittleType", getAppLittleType())
                .append("serverId", getServerId())
                .append("serverDataId", getServerDataId())
                .append("orderType", getOrderType())
                .append("orderCode", getOrderCode())
                .append("dataVo", getDataVo())
                .append("money", getMoney())
                .append("dataType", getDataType())
                .append("processKey", getProcessKey())
                .append("processInsId", getProcessInsId())
                .append("formId", getFormId())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("companyCode", getCompanyCode())
                .append("remark", getRemark())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .toString();
    }

}

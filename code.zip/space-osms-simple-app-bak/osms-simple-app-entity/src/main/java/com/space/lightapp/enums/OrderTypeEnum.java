package com.space.lightapp.enums;

/**
 * 单据详情类型
 *
 * @Author ChenYou
 * @date 2021-11-13 15:45
 * @Version 1.0
 */
public enum OrderTypeEnum {
    // 单据详情类型
    PLACE_ORDER("placeOrder", "下单"),
    PAY("pay", "支付"),
    RE_FUND("reFund", "退款"),
    COMPANY_PAY("companyPay", "周期结算"),
    TAX("tax", "推送结算信息"),

    ;

    private String code;
    private String info;

    OrderTypeEnum(String code, String info) {
        this.code = code;
        this.info = info;
    }

    public String getCode() {
        return code;
    }

    public String getInfo() {
        return info;
    }
}

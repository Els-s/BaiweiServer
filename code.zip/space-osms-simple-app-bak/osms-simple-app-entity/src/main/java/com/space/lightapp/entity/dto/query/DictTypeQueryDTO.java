package com.space.lightapp.entity.dto.query;

import com.space.lightapp.base.BaseVO;
import com.space.lightapp.entity.DictType;
import com.space.osms.common.core.utils.DozerBeanUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 字典类型Dto对象 dict_type
 *
 * @author ChenYou
 * @date 2021-09-27
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "字典类型")
public class DictTypeQueryDTO extends BaseVO {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    private Long dictTypeId;
    /**
     * 轻应用Id
     */
    @ApiModelProperty(value = "轻应用Id")
    private Long lightAppId;
    /**
     * 字典分类：默认public公共分类，
     */
    @ApiModelProperty(value = "字典分类：填写appCode值。")
    private String dictClassCode;
    /**
     * 类型代码
     */
    @ApiModelProperty(value = "类型代码")
    private String dictTypeCode;
    /**
     * 类型名称
     */
    @ApiModelProperty(value = "类型名称")
    private String dictTypeName;
    /**
     * pageNo
     */
    @ApiModelProperty(value = "当前页")
    private Integer pageNo;
    /**
     * pageSize
     */
    @ApiModelProperty(value = "每页数量")
    private Integer pageSize;

    /**
     * Dto转Entity
     *
     * @return Entity对象
     * @date 2021-09-27
     */
    public DictType toEntity() {
        DictType dictType = DozerBeanUtil.transitionType(this, DictType.class);
        return dictType;
    }

    /**
     * List-Dto转List-Entity
     *
     * @return List-Entity对象
     * @date 2021-09-27
     */
    public List<DictType> toListEntity(List<DictTypeQueryDTO> dictTypeDto) {
        List<DictType> list = new ArrayList<>();
        dictTypeDto.forEach(t -> list.add(t.toEntity()));
        return list;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("dictTypeCode", getDictTypeCode())
                .append("dictTypeName", getDictTypeName())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .toString();
    }

}



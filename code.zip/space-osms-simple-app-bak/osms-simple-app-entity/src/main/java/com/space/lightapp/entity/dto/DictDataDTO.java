package com.space.lightapp.entity.dto;

import com.space.lightapp.base.BaseVO;
import com.space.lightapp.entity.DictData;
import com.space.osms.common.core.utils.DozerBeanUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 字典数据Dto对象 dict_data
 *
 * @author ChenYou
 * @date 2021-09-27
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "字典数据")
public class DictDataDTO extends BaseVO {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    private Long dictDataId;
    /**
     * 字典分类：默认public公共分类，
     */
    @ApiModelProperty(value = "字典分类：填写appCode值。", required = true)
    private String dictClassCode;
    /**
     * 字典类型
     */
    @ApiModelProperty(value = "字典类型")
    private Long dictTypeId;
    /**
     * 字典内容代码
     */
    @ApiModelProperty(value = "字典内容代码")
    private String dictDataCode;
    /**
     * 字典名称
     */
    @ApiModelProperty(value = "字典名称")
    private String dictDataName;
    /**
     * 父级Id
     */
    @ApiModelProperty(value = "父级Id")
    private Long parentId;
    /**
     * 排序 排序字段
     */
    @ApiModelProperty(value = "排序 排序字段")
    private Long ordernum;
    /**
     * 状态 0-false-禁用，1-true-启用；默认1-true
     */
    @ApiModelProperty(value = "状态 0-false-禁用，1-true-启用；默认1-true")
    private Boolean status;

    /**
     * 是否删除  0-false-未删除，1-true-删除；默认0-false
     */
    @ApiModelProperty(value = "是否删除  0-false-未删除，1-true-删除；默认0-false")
    private Boolean delFlag;

    /**
     * Dto转Entity
     *
     * @return Entity对象
     * @date 2021-09-27
     */
    public DictData toEntity() {
        DictData dictData = DozerBeanUtil.transitionType(this, DictData.class);
        return dictData;
    }

    /**
     * List-Dto转List-Entity
     *
     * @return List-Entity对象
     * @date 2021-09-27
     */
    public List<DictData> toListEntity(List<DictDataDTO> dictDataDto) {
        List<DictData> list = new ArrayList<>();
        dictDataDto.forEach(t -> list.add(t.toEntity()));
        return list;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("dictDataId", getDictDataId())
                .append("dictTypeId", getDictTypeId())
                .append("dictDataName", getDictDataName())
                .append("parentId", getParentId())
                .append("ordernum", getOrdernum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("delFlag", getDelFlag())
                .toString();
    }


}



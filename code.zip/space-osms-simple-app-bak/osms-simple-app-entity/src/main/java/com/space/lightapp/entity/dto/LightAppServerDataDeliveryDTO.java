package com.space.lightapp.entity.dto;

import com.space.lightapp.base.BaseVO;
import com.space.lightapp.entity.LightAppServerDataDelivery;
import com.space.osms.common.core.utils.DozerBeanUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 增值下单配送Dto对象 light_app_server_data_delivery
 *
 * @author ChenYou
 * @date 2022-01-07
 */
@Data
@ApiModel(description = "增值下单配送")
public class LightAppServerDataDeliveryDTO extends BaseVO {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    private Long serverDataDeliveryId;
    /**
     * 轻应用Id
     */
    @ApiModelProperty(value = "轻应用Id")
    private Long lightAppId;
    /**
     * 服务数据Id
     */
    @ApiModelProperty(value = "服务数据Id")
    private Long serverDataId;
    /**
     * 配送服务编码 配送编码
     */
    @ApiModelProperty(value = "配送服务编码 配送编码")
    private String orderCode;
    /**
     * 配送数量
     */
    @ApiModelProperty(value = "配送数量")
    private Integer deliveryNum;
    /**
     * 流程key
     */
    @ApiModelProperty(value = "流程key")
    private String processKey;
    /**
     * 流程定义Id
     */
    @ApiModelProperty(value = "流程定义Id")
    private String processInsId;
    /**
     * 当前节点处理人
     */
    @ApiModelProperty(value = "当前节点处理人")
    private String processNodeUser;
    /**
     * 处理人详情
     */
    @ApiModelProperty(value = "处理人详情")
    private String processNodeUserDetail;
    /**
     * 对应数据Id
     */
    @ApiModelProperty(value = "对应数据Id")
    private String dataId;
    /**
     * 任务Id
     */
    @ApiModelProperty(value = "任务Id")
    private String taskId;
    /**
     * 配送状态 delivery_ing进行中，delivery_success成功配送，delivery_fail配送失败
     */
    @ApiModelProperty(value = "配送状态 delivery_ing进行中，delivery_success成功配送，delivery_fail配送失败")
    private String businessState;
    /**
     * 流程启动结果 流程启动结果 流程启动结果，1-启动成功，-1-启动失败，0-未启动流程
     */
    @ApiModelProperty(value = "流程启动结果 流程启动结果 流程启动结果，1-启动成功，-1-启动失败，0-未启动流程")
    private Integer processStartStatus;
    /**
     * 第一个节点处理人
     */
    @ApiModelProperty(value = "第一个节点处理人")
    private String firstHandleName;
    /**
     * 最后节点处理人
     */
    @ApiModelProperty(value = "最后节点处理人")
    private String lastHandleName;
    /**
     * 表单Id
     */
    @ApiModelProperty(value = "表单Id")
    private String formId;
    /**
     * 单据来源 1内部单，2客户下单，3代客下单
     */
    @ApiModelProperty(value = "单据来源 1内部单，2客户下单，3代客下单")
    private Integer source;
    /**
     * 排序 排序字段
     */
    @ApiModelProperty(value = "排序 排序字段")
    private Integer orderNum;
    /**
     * 是否禁用 0禁用，1启用；默认1
     */
    @ApiModelProperty(value = "是否禁用 0禁用，1启用；默认1")
    private Boolean status;
    /**
     * 逻辑删除 0有效，1被删除；默认0
     */
    @ApiModelProperty(value = "逻辑删除 0有效，1被删除；默认0")
    private Boolean delFlag;
    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String remark;

    /**
     * Dto转Entity
     *
     * @return Entity对象
     * @date 2022-01-07
     */
    public LightAppServerDataDelivery toEntity() {
        return DozerBeanUtil.transitionType(this, LightAppServerDataDelivery.class);
    }

    /**
     * List-Dto转List-Entity
     *
     * @return List-Entity对象
     * @date 2022-01-07
     */
    public List<LightAppServerDataDelivery> toListEntity(
            List<LightAppServerDataDeliveryDTO> lightAppServerDataDeliveryDto) {
        List<LightAppServerDataDelivery> list = new ArrayList<>();
        lightAppServerDataDeliveryDto.forEach(t -> list.add(t.toEntity()));
        return list;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("serverDataDeliveryId", getServerDataDeliveryId())
                .append("lightAppId", getLightAppId())
                .append("serverDataId", getServerDataId())
                .append("orderCode", getOrderCode())
                .append("deliveryNum", getDeliveryNum())
                .append("processKey", getProcessKey())
                .append("processInsId", getProcessInsId())
                .append("processNodeUser", getProcessNodeUser())
                .append("processNodeUserDetail", getProcessNodeUserDetail())
                .append("dataId", getDataId())
                .append("taskId", getTaskId())
                .append("businessState", getBusinessState())
                .append("processStartStatus", getProcessStartStatus())
                .append("firstHandleName", getFirstHandleName())
                .append("lastHandleName", getLastHandleName())
                .append("formId", getFormId())
                .append("source", getSource())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("companyCode", getCompanyCode())
                .append("remark", getRemark())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("delFlag", getDelFlag())
                .toString();
    }

}



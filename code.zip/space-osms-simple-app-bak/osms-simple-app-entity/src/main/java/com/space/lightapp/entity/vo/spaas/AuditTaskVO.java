package com.space.lightapp.entity.vo.spaas;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.space.lightapp.base.BaseVO;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 审核REQ Vo
 *
 * @Author kangmj
 * @date 2021-11-02 11:07
 * @Version 1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class AuditTaskVO extends BaseVO {

    private String formJson;
    private String opinion;
    private String instId;
    //操作类型，通过：AGREE；驳回：BACK；暂停：PAUSE；允许暂停：PASS_PAUSE；取消暂停：CANCEL_PAUSE；拒绝：REFUSE；允许拒绝：PASS_REFUSE；撤销：REVOKE；重新提交：RESUBMIT；转办：TRANSFER；同意转办：APPLY_TRANSFER；取消转办：CANCEL_TRANSFER
    private String checkType;
    private String taskId;
    private JSONObject nodeExecutors;
    private String uid;
    private String buttonFormJson;
    private String opFiles;
    private String agentToUserId;
    private String vars;
    private String workOrderType;

}

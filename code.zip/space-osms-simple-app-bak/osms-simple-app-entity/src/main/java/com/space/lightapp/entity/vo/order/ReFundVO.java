package com.space.lightapp.entity.vo.order;

import com.space.lightapp.base.BaseVO;
import com.space.lightapp.entity.dto.order.RefundDTO;
import com.space.lightapp.entity.vo.LightAppServerDataVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 退款VO
 *
 * @Author ChenYou
 * @date 2021-11-13 11:15
 * @Version 1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = "退款VO")
public class ReFundVO extends BaseVO {


    @ApiModelProperty(value = "下单服务数据", required = true)
    private LightAppServerDataVO serverData;

    @ApiModelProperty(value = "退款详情", required = true)
    private RefundDTO refundDTO;
}

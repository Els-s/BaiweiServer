package com.space.lightapp.entity.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * 配送服务状态统计数量Vo
 *
 * @Author JiangHao
 * @date 2021-12-22 17:03
 * @Version 1.0
 */
@Data
@Accessors(chain = true)
@ApiModel(value = "配送服务状态统计数量Vo")
public class DeliveryNumRspVO {

    @ApiModelProperty(value = "全部")
    private Integer all;
    @ApiModelProperty(value = "已配送数量")
    private Integer deliverySuccess;
    @ApiModelProperty(value = "配送中数量")
    private Integer deliveryIng;
    @ApiModelProperty(value = "取消配送数量")
    private Integer deliveryCancel;

}

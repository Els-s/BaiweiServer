package com.space.lightapp.entity;

import cn.hutool.core.date.DateUtil;
import cn.space.base.utils.ToolUtil;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.space.lightapp.base.BaseEntity;
import com.space.lightapp.entity.vo.LightAppActivityVO;
import com.space.lightapp.enums.ActivityAndSurveyStatusEnum;
import com.space.lightapp.enums.OnlineStatusEnum;
import com.space.osms.common.core.utils.DozerBeanUtil;
import com.space.osms.common.file.annotation.Excel;
import io.swagger.annotations.ApiModelProperty;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 活动 对象 light_app_activity
 *
 * @author ChenYou
 * @date 2021-10-18
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("light_app_activity")
public class LightAppActivity extends BaseEntity {

    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long activityId;
    /**
     * 轻应用Id 关联轻应用Id
     */
    private Long lightAppId;
    /**
     * 应用服务类型代码
     */
    private String appMarketTypeCode;
    /**
     * 任务中心唯一标识码
     */
    private String taskTypeCode;
    /**
     * 关联表单Id 关联表单Id
     */
    private String formId;
    /**
     * 关联流程Id
     */
    private String processId;
    /**
     * 活动编号
     */
    private String activityCode;
    /**
     * 活动名称
     */
    @Excel(name = "活动名称", sort = 1)
    private String activityName;
    /**
     * log图片地址
     */
    private String iconUrl;
    /**
     * 活动地址
     */
    @Excel(name = "活动地址", sort = 2)
    private String activityAddress;
    /**
     * 活动内容
     */
    @Excel(name = "活动内容", sort = 3)
    private String activityContent;
    /**
     * 是否需要签到 0不需要，1需要
     */
    @Excel(name = "是否需要签到", sort = 7, readConverterExp = "0=否,1=是")
    private Integer needSign;

    /**
     * 签到开始时间
     */
    @Excel(name = "签到开始时间", sort = 8, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date signStartTime;
    /**
     * 签到结束时间
     */
    @Excel(name = "签到结束", sort = 9, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date signEndTime;
    /**
     * 开始时间
     */
    @Excel(name = "活动开始时间", sort = 10, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date startTime;
    /**
     * 结束时间
     */
    @Excel(name = "活动结束时间", sort = 11, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date endTime;
    /**
     * 参与条件 tourist游客   commonUser普通用户   companyEmployee企业员工   companyManager企业管理员,多种类型英文逗号隔开
     */
    @Excel(name = "参与用户等级", sort = 12, readConverterExp = "tourist=游客, commonUser=普通用户,ompanyEmployee=企业员工,companyManager=企业管理员")
    private String serverLaunchUser;
    /**
     * 参与条件描述
     */
    private String description;

    private Boolean existTaskCentreCode;


    /**
     * 报名开始时间
     */
    @TableField(exist = false)
    @Excel(name = "报名开始时间", sort = 5, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date applyStartTime;

    /**
     * 报名结束时间
     */
    @TableField(exist = false)
    @Excel(name = "报名结束时间", sort = 6, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date applyEndTime;

    /**
     * 活动状态 draft草稿，notStart未开始，underWay进行中，suspend暂停中，finish已结束
     */
    @Excel(name = "活动状态", sort = 13, readConverterExp = "draft=草稿,notStart未=开始,underWay=进行中,suspend=暂停中,finish=已结束")
    private String activityType;

    /**
     * 在线状态：online 上线中，offline 下线中， null 无在线状态
     */
    @Excel(name = "上线状态", sort = 14, readConverterExp = "online=上线中,offline=下线中")
    private String onlineStatus;
    /**
     * 排序 排序字段
     */
    private Integer orderNum;
    /**
     * 是否禁用 0禁用，1启用；默认1
     */
    private Boolean status;
    /**
     * 备注
     */
    private String remark;
    /**
     * 逻辑删除 0有效，1被删除；默认0
     */
    private Boolean delFlag;

    /**
     * 报名人数
     */
    @TableField(exist = false)
    @Excel(name = "报名人数")
    private Integer applyNum;

    /**
     * 实际参与人数
     */
    @TableField(exist = false)
    @Excel(name = "实际参与人数")
    private Integer actorNum;
    /**
     * 是否需要报名 0不需要，1需要
     */
    @TableField(exist = false)
    @Excel(name = "是否需要报名", sort = 4, readConverterExp = "0=否,1=是")
    private Integer needApply;

    /**
     * 点击量查看数
     */
    private Integer readCount;

    /**
     * 报名费用
     */
    @TableField(exist = false)
    private BigDecimal money;


    /**
     * 暂存类型 true:暂存;false:发布
     */
    @ApiModelProperty(value = "暂存类型 true:暂存;false:发布")
    @TableField(exist = false)
    private Boolean stagType;

    /**
     * Entity转Vo
     *
     * @return Vo对象
     * @date 2021-10-18
     */
    public LightAppActivityVO toVo() {
        LightAppActivityVO activityVO = DozerBeanUtil.transitionType(this, LightAppActivityVO.class);
        if (ToolUtil.isNotEmpty(applyStartTime)) {
            activityVO.setApplyTimeVo(
                    DateUtil.format(applyStartTime, "yyyy-MM-dd HH:mm:ss") + "至" + DateUtil
                            .format(applyEndTime, "yyyy-MM-dd HH:mm:ss"));
        }
        activityVO.setActivityTypeVo(ActivityAndSurveyStatusEnum.getInfoValue(activityType));
        activityVO.setOnlineStatusVo(OnlineStatusEnum.getInfoValue(onlineStatus));
        activityVO.setOnlineStatusVo(OnlineStatusEnum.getInfoValue(onlineStatus));
        activityVO.setStartTimeVo(DateUtil.format(startTime, "yyyy-MM-dd HH:mm:ss"));
        return activityVO;
    }

    /**
     * List-Entity转List-Vo
     *
     * @return List-Vo对象
     * @date 2021-10-18
     */
    public List<LightAppActivityVO> toListVo(List<LightAppActivity> lightAppActivity) {
        List<LightAppActivityVO> list = new ArrayList<>();
        lightAppActivity.forEach(t -> list.add(t.toVo()));
        return list;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("activityId", getActivityId())
                .append("lightAppId", getLightAppId())
                .append("appMarketTypeCode", getAppMarketTypeCode())
                .append("formId", getFormId())
                .append("activityCode", getActivityCode())
                .append("activityName", getActivityName())
                .append("activityAddress", getActivityAddress())
                .append("activityContent", getActivityContent())
                .append("needSign", getNeedSign())
                .append("signStartTime", getSignStartTime())
                .append("signEndTime", getSignEndTime())
                .append("startTime", getStartTime())
                .append("endTime", getEndTime())
                .append("serverLaunchUser", getServerLaunchUser())
                .append("description", getDescription())
                /*     .append("applyStartTime", getApplyStartTime())
                     .append("applyEndTime", getApplyEndTime())*/
                .append("activityType", getActivityType())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("companyCode", getCompanyCode())
                .append("readCount", getReadCount())
                .append("remark", getRemark())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("delFlag", getDelFlag())
                .append("applyNum", getApplyNum())
                .append("actorNum", getActorNum())
                .toString();
    }

}

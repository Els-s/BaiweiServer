package com.space.lightapp.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.space.lightapp.base.BaseEntity;
import com.space.lightapp.entity.vo.PushActiveSetVO;
import com.space.osms.common.core.utils.DozerBeanUtil;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 启用设置对象 push_active_set
 *
 * @author ChenYou
 * @date 2021-09-27
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("push_active_set")
public class PushActiveSet extends BaseEntity {

    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long pushActiveSetId;
    /**
     * 应用模块Id
     */
    private Long lightAppModuleId;

    /**
     * 轻应用id
     */
    private Long lightAppId;
    /**
     * 启用项目代码
     */
    private String activeProjectCode;
    /**
     * 启用项目名称
     */
    private String activeProjectName;
    /**
     * 排序 排序字段
     */
    private Long orderNum;
    /**
     * 状态 0-false-禁用，1-true-启用；默认1-true
     */
    private Boolean status;

    /**
     * 是否删除  0-false-未删除，1-true-删除；默认0-false
     */
    private Boolean delFlag;

    /**
     * 应用类型代码
     */
    @TableField(exist = false)
    private String appMarketTypeCode;

    /**
     * Entity转Vo
     *
     * @return Vo对象
     * @date 2021-09-27
     */
    public PushActiveSetVO toVo() {
        PushActiveSetVO pushActiveSetVo = DozerBeanUtil.transitionType(this, PushActiveSetVO.class);
        return pushActiveSetVo;
    }

    /**
     * List-Entity转List-Vo
     *
     * @return List-Vo对象
     * @date 2021-09-27
     */
    public List<PushActiveSetVO> toListVo(List<PushActiveSet> pushActiveSet) {
        List<PushActiveSetVO> list = new ArrayList<>();
        pushActiveSet.forEach(t -> list.add(t.toVo()));
        return list;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("pushActiveSetId", getPushActiveSetId())
                .append("lightAppModuleId", getLightAppModuleId())
                .append("activeProjectCode", getActiveProjectCode())
                .append("activeProjectName", getActiveProjectName())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

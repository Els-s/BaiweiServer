package com.space.lightapp.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.space.lightapp.base.BaseEntity;
import com.space.lightapp.entity.vo.LightAppCategoryVO;
import com.space.osms.common.core.utils.DozerBeanUtil;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Spaas分类信息存储对象 light_app_category
 *
 * @author ChenYou
 * @date 2021-10-26
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("light_app_category")
public class LightAppCategory extends BaseEntity {

    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long id;
    /**
     * spaas分类Id
     */
    private String categoryId;
    /**
     * 别名
     */
    private String alias;
    /**
     * 排序 排序字段
     */
    private Integer orderNum;
    /**
     * 是否禁用 0禁用，1启用；默认1
     */
    private Boolean status;
    /**
     * 逻辑删除 0有效，1被删除；默认0
     */
    private Boolean delFlag;

    /**
     * Entity转Vo
     *
     * @return Vo对象
     * @date 2021-10-26
     */
    public LightAppCategoryVO toVo() {
        return DozerBeanUtil.transitionType(this, LightAppCategoryVO.class);
    }

    /**
     * List-Entity转List-Vo
     *
     * @return List-Vo对象
     * @date 2021-10-26
     */
    public List<LightAppCategoryVO> toListVo(List<LightAppCategory> lightAppCategory) {
        List<LightAppCategoryVO> list = new ArrayList<>();
        lightAppCategory.forEach(t -> list.add(t.toVo()));
        return list;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("id", getId())
                .append("categoryId", getCategoryId())
                .append("alias", getAlias())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("companyCode", getCompanyCode())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

package com.space.lightapp.entity.vo.order;

import java.math.BigDecimal;
import java.util.Date;
import lombok.Data;

/**
 * 支付记录
 *
 * @Author ChenYou
 * @date 2021-11-25 17:20
 * @Version 1.0
 */
@Data
public class PayLogVO {

    /**
     * 应用名称
     */
    private String lightAppName;
    /**
     * 应用Id（）
     */
    private Long lightAppId;
    /**
     * 支付时间
     */
    private Date payDate;
    /**
     * 数据主键Id
     */
    private Long dataId;
    /**
     * 所属项目
     */
    private String projectCode;
    /**
     * 支付金额
     */
    private BigDecimal payMoney;
}

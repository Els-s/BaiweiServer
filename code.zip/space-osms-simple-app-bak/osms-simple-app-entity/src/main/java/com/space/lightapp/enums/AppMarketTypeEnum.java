package com.space.lightapp.enums;

/**
 * 服务类型枚举类
 *
 * @Author ChenYou
 * @date 2021-09-27 15:57
 * @Version 1.0
 */
public enum AppMarketTypeEnum {
    /**
     * 工单类
     */
    WORK_ORDER("workOrder", "工单类"),
    /**
     * 基础服务类
     */
    BASE_SERVER("baseServer", "基础服务"),
    /**
     * 问卷类
     */
    SURVEY("survey", "问卷"),
    /**
     * 活动类
     */
    ACTIVITY("activity", "活动"),
    /**
     * 有偿服务类
     */
    PAY_SERVER("payServer", "有偿服务");

    private String code;
    private String info;

    AppMarketTypeEnum(String code, String info) {
        this.code = code;
        this.info = info;
    }

    public String getCode() {
        return code;
    }

    public String getInfo() {
        return info;
    }

    public static AppMarketTypeEnum getEnumByCode(String code) {
        AppMarketTypeEnum[] values = AppMarketTypeEnum.values();
        for (AppMarketTypeEnum value : values) {
            if (value.getCode().equalsIgnoreCase(code)) {
                return value;
            }
        }
        return null;
    }

}

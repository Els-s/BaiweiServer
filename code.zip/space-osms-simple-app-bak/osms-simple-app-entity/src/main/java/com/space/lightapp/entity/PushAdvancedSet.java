package com.space.lightapp.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.space.lightapp.base.BaseEntity;
import com.space.lightapp.entity.vo.PushAdvancedSetVO;
import com.space.lightapp.enums.DeliveryWayEnum;
import com.space.osms.common.core.utils.DozerBeanUtil;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 高级设置对象 push_advanced_set
 *
 * @author ChenYou
 * @date 2021-10-09
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("push_advanced_set")
public class PushAdvancedSet extends BaseEntity {

    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long pushAdvancedSetId;
    /**
     * 应用模块Id
     */
    private Long lightAppModuleId;
    /**
     * 轻应用id
     */
    private Long lightAppId;
    /**
     * 服务发起角色 client客户使用，inside内部使用,多个用英文逗号隔开
     */
    private String serverLaunchRole;
    /**
     * C端用户发起最低等级 tourist游客   commonUser普通用户   companyEmployee企业员工   companyManager企业管理员,多种类型英文逗号隔开
     */
    private String serverLaunchUser;
    /**
     * 企业管理员可见员工数据 0否，1是
     */
    private Boolean seeEmployeeData;
    /**
     * 是否允许代客录单 0否，1是
     */
    private Boolean repGuestOrder;
    /**
     * 是否允许需要打印模板 0否，1是
     */
    private Boolean needPrintTemplate;
    /**
     * 打印模板编号
     */
    private String printTemplateCode;
    /**
     * 运营方 单选（1自营，2第三方）
     */
    private Integer operator;
    /**
     * 结算方式 1现结，2企业周期结算，多选英文逗号隔开
     */
    private String payWay;
    /**
     * 现结限时支付时间 (限时数值（正整数）)
     */
    private Integer pastTimeNum;
    /**
     * 现结限时支付时间单位（月month，天day，小时hour，分钟minute，秒second）
     */
    private String pastTimeUnit;
    /**
     * 企业管理员审核 是否需要审核（0 不需要，1需要）
     */
    private Boolean needCheck;
    /**
     * 是否开启配送时间显示
     */
    private Boolean openSendTime;
    /**
     * 配送方式 once 一次配送，multiple多次配送
     */
    private String sendWay;
    /**
     * 多次配送最低数量：设置了多次配送，且数量大于等于此（默认2）
     */
    private Long multipleMinNum;
    /**
     * 配送时间输入框
     */
    private String sendTime;
    /**
     * 配送起始时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date sendStartTime;
    /**
     * 配送终止时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date sendEndTime;
    /**
     * 排序 排序字段
     */
    private Integer orderNum;
    /**
     * 是否禁用 0禁用，1启用；默认1
     */
    private Boolean status;

    /**
     * 备注
     */
    private String remark;
    /**
     * 逻辑删除 0有效，1被删除；默认0
     */
    private Boolean delFlag;

    /**
     * 应用类型代码
     */
    @TableField(exist = false)
    private String appMarketTypeCode;

    /**
     * Entity转Vo
     *
     * @return Vo对象
     * @date 2021-10-09
     */
    public PushAdvancedSetVO toVo() {
        PushAdvancedSetVO vo = DozerBeanUtil.transitionType(this, PushAdvancedSetVO.class);
        if (StringUtils.isNotBlank(sendWay)) {
            vo.setSendWayName(DeliveryWayEnum.getInfoByCode(sendWay));
        }
        return vo;
    }

    /**
     * List-Entity转List-Vo
     *
     * @return List-Vo对象
     * @date 2021-10-09
     */
    public List<PushAdvancedSetVO> toListVo(List<PushAdvancedSet> pushAdvancedSet) {
        List<PushAdvancedSetVO> list = new ArrayList<>();
        pushAdvancedSet.forEach(t -> list.add(t.toVo()));
        return list;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("pushAdvancedSetId", getPushAdvancedSetId())
                .append("lightAppModuleId", getLightAppModuleId())
                .append("serverLaunchRole", getServerLaunchRole())
                .append("serverLaunchUser", getServerLaunchUser())
                .append("seeEmployeeData", getSeeEmployeeData())
                .append("repGuestOrder", getRepGuestOrder())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("remark", getRemark())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

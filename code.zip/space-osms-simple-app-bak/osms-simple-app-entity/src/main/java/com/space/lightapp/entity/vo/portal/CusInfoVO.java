package com.space.lightapp.entity.vo.portal;

import lombok.Data;
import lombok.experimental.Accessors;

/**
 * 公司信息
 *
 * @Author Els
 * @date 2021-12-23 9:50
 * @Version 1.0
 */
@Data
@Accessors(chain = true)
public class CusInfoVO {

    private String name;
    private String type;
    private String corpId;
//  "id": "1636",
//      "name": "深圳市思倍云科技有限公司",
//      "firstCharKey": "S",
//      "corp": "深圳市思倍云科技有限公司",
//      "linkman": "王萍",
//      "phone": "156****6466",
//      "type": "1",
//      "typeName": "个人",
//      "izEnter": "true",
//      "izEnterName": "是",
//      "enterTime": "1631635200000",
//      "corpId": "MIS2021012600002",
//      "projectId": null,
//      "tenantCode": "ZH_00001",
//      "addressList": null
}

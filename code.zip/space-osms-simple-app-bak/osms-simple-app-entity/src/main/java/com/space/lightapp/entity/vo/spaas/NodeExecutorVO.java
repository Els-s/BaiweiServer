package com.space.lightapp.entity.vo.spaas;

import lombok.Data;

/**
 * NodeExectorVO
 *
 * @Author kangmj
 * @date 2021-11-02 11:10
 * @Version 1.0
 */
@Data
public class NodeExecutorVO {

    private String type;
    private String name;
    private String id;
}

package com.space.lightapp.entity.dto;

import com.space.lightapp.base.BaseVO;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Spass新增表单内容数据
 *
 * @Author ChenYou
 * @date 2021-10-20 13:44
 * @Version 1.0
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class SpaasFormDataSynDTO extends BaseVO {

    /**
     * 表单ID
     */
    private String formId;

    /**
     * 表名称
     */
    private String formName;
    /**
     * 表单数据ID
     */
    private String dataId;

    /**
     * 前端提交的表单数据
     */
    private String data;

    /**
     * 扩展字段
     */
    private String expand;

    // ##############其他冗余字段
    /**
     *
     */
    private String account;
}

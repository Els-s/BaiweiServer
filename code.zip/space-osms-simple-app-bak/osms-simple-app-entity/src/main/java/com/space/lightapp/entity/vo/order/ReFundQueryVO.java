package com.space.lightapp.entity.vo.order;

import com.space.lightapp.base.BaseVO;
import com.space.lightapp.entity.vo.LightAppServerDataDetailVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * @author JiangHao
 * @version 1.0
 * @date 2021/11/18 0018 17:32
 * @description
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(description = "退款查询")
public class ReFundQueryVO extends BaseVO {

    /**
     * 外部的订单接口
     */
    @ApiModelProperty(value = "外部的订单接口")
    private String extOrderCode;

    /**
     * 服务详情
     */
    @ApiModelProperty(value = "服务详情")
    private LightAppServerDataDetailVO serverDataDetailVO;
}

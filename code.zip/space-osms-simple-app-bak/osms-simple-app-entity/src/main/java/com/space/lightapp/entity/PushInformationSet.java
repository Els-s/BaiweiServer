package com.space.lightapp.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.space.lightapp.base.BaseEntity;
import com.space.lightapp.entity.vo.PushInformationSetVO;
import com.space.osms.common.core.utils.DozerBeanUtil;
import com.space.osms.common.core.utils.StringUtil;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 发布资讯 对象 push_information_set
 *
 * @author ChenYou
 * @date 2021-10-29
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("push_information_set")
public class PushInformationSet extends BaseEntity {

    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long informationSetId;
    /**
     * 轻应用Id
     */
    private Long lightAppId;
    /**
     * 应用服务类型代码
     */
    private String appMarketTypeCode;
    /**
     * 关联Id
     */
    private Long relevancyId;
    /**
     * 消息id
     */
    private Long messageId;
    /**
     * 是否推送到消息中心：0否 1是
     */
    private Integer pushMessage;
    /**
     * 发布渠道 发布渠道  key  value 微信小程序（物业运营） OPERATOR_MANAGE APP  APP
     */
    private String releaseChannel;
    /**
     * 发布位置 发布位置 多选时List<String>数组 目前只需要单选
     */
    private String releaseLocationList;
    /**
     * 发布范围--
     */
    private String projectCodeList;
    /**
     * 资讯封面
     */
    private String coverUrlList;

    /**
     * 是否长期 是否长期  0否 1是
     */
    private Integer longTerm;
    /**
     * 发布时间
     */
    private Date releaseTime;
    /**
     * 到期时间
     */
    private Date endTime;
    /**
     * 资讯标题
     */
    private String infoTitle;
    /**
     * 资讯来源（任务中心的名称写错了，这边不改，对应他们）
     */
    private String infoResouse;
    /**
     * 分享导语
     */
    private String sharingLead;
    /**
     * 资讯形式 资讯形式 0:文章 1:链接
     */
    private Integer infoForm;
    /**
     * 上架状态 0上架 1下架 2待上架
     */
    private Integer shelfStatus;
    /**
     * 展示样式 （0无图模式,1小图模式,2大图模式,3三图模式）
     */
    private Integer showType;
    /**
     * 资讯标签--
     */
    private String infoTag;

    /**
     * 发布内容/链接路径 资讯内容/链接路径 根据资讯形式来存储
     */
    private String infoContent;
    /**
     * 附件url
     */
    private String attachmentUrls;
    /**
     * 排序 排序字段
     */
    private Integer orderNum;
    /**
     * 是否禁用 0禁用，1启用；默认1
     */
    private Boolean status;
    /**
     * 备注
     */
    private String remark;
    /**
     * 逻辑删除 0有效，1被删除；默认0
     */
    private Boolean delFlag;

    /**
     * Entity转Vo
     *
     * @return Vo对象
     * @date 2021-10-29
     */
    public PushInformationSetVO toVo() {
        PushInformationSetVO pushInformationSetVO = DozerBeanUtil
                .transitionType(this, PushInformationSetVO.class);
        pushInformationSetVO.setProjectCodes(StringUtil.stringToList(this.getProjectCodeList()));
        pushInformationSetVO.setCoverUrls(StringUtil.stringToList(this.getCoverUrlList()));
        pushInformationSetVO
                .setReleaseLocations(
                        StringUtil.stringToList(this.getReleaseLocationList()));
        return pushInformationSetVO;
    }

    /**
     * Entity转Vo
     *
     * @return Vo对象
     * @date 2021-10-29
     */
/*  public InfoManageVO toMessageVo() {
    InfoManageVO infoManageVO = DozerBeanUtil
        .transitionType(this, InfoManageVO.class);
 *//*   infoManageVO.setProjectCodes(DozerBeanUtil.stringToList(infoManageVO.getProjectCodesVo()));
    infoManageVO.setCoverUrls(DozerBeanUtil.stringToList(infoManageVO.getCoverUrlsVo()));
    infoManageVO
        .setReleaseLocations(DozerBeanUtil.stringToList(infoManageVO.getReleaseLocationsVo()));*//*
    return infoManageVO;
  }*/

    /**
     * List-Entity转List-Vo
     *
     * @return List-Vo对象
     * @date 2021-10-29
     */
    public List<PushInformationSetVO> toListVo(List<PushInformationSet> pushInformationSet) {
        List<PushInformationSetVO> list = new ArrayList<>();
        pushInformationSet.forEach(t -> list.add(t.toVo()));
        return list;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("informationSetId", getInformationSetId())
                .append("lightAppId", getLightAppId())
                .append("appMarketTypeCode", getAppMarketTypeCode())
                .append("relevancyId", getRelevancyId())
                .append("releaseChannel", getReleaseChannel())
                .append("releaseLocationList", getReleaseLocationList())
                .append("projectCodeList", getProjectCodeList())
                .append("longTerm", getLongTerm())
                .append("releaseTime", getReleaseTime())
                .append("endTime", getEndTime())
                .append("infoTitle", getInfoTitle())
                .append("infoResouse", getInfoResouse())
                .append("sharingLead", getSharingLead())
                .append("infoForm", getInfoForm())
                .append("shelfStatus", getShelfStatus())
                .append("showType", getShowType())
                .append("tag", getInfoTag())
                .append("coverUrlList", getCoverUrlList())
                .append("infoContent", getInfoContent())
                .append("attachmentUrls", getAttachmentUrls())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("companyCode", getCompanyCode())
                .append("remark", getRemark())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

package com.space.lightapp.entity.vo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * 状态统计数量Vo
 *
 * @Author kangmj
 * @date 2021-10-18 17:03
 * @Version 1.0
 */
@Data
@Accessors(chain = true)
@ApiModel(value = "状态统计数量Vo")
public class SurveyTypeNumRspVO {

    @ApiModelProperty(value = "全部")
    private Integer all;
    @ApiModelProperty(value = "草稿")
    private Integer draft;
    @ApiModelProperty(value = "未开始")
    private Integer notStart;
    @ApiModelProperty(value = "进行中")
    private Integer underWay;
    @ApiModelProperty(value = "暂停中")
    @JsonIgnore
    private Integer suspend;
    @ApiModelProperty(value = "已结束")
    private Integer finish;

}

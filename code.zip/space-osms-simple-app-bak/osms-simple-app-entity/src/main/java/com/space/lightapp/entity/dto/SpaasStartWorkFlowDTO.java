package com.space.lightapp.entity.dto;

import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @author lanhai
 * @descript 流程启动接口参数 jpaas接口文档见：http://doc.redxun.cn/docs/jpaas/bpmApi
 * @since 2021/5/14 11:55
 */
@Data
@Accessors(chain = true)
public class SpaasStartWorkFlowDTO {

    public SpaasStartWorkFlowDTO() {
        this.checkType = "AGREE";
    }

    /**
     * 审批类型
     **/
    private String checkType;

    /**
     * 表单数据
     **/
    private String formJson;

    private String workOrderData;

    /**
     * 流程定义KEY
     **/
    private String defKey;

    /**
     * 用户账号，用于当发起人用户
     **/
    private String userAccount;

    /**
     * bo表单别名
     **/
    private String boAlias;

    private String formAlias;

    private String dataId;
}

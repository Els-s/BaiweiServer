package com.space.lightapp.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.space.lightapp.base.BaseEntity;
import com.space.lightapp.entity.vo.AppMarketTypeVO;
import com.space.osms.common.core.utils.DozerBeanUtil;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 应用服务类型 对象 app_market_type
 *
 * @author ChenYou
 * @date 2021-09-27
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("app_market_type")
public class AppMarketType extends BaseEntity {

    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long appMarketTypeId;
    /**
     * 应用服务类型代码
     */
    private String appMarketTypeCode;
    /**
     * 应用服务类型名称
     */
    private String appMarketTypeName;
    /**
     * 排序 排序字段
     */
    private Long orderNum;
    /**
     * 状态 0-false-禁用，1-true-启用；默认1-true
     */
    private Boolean status;

    /**
     * 是否删除  0-false-未删除，1-true-删除；默认0-false
     */
    private Boolean delFlag;

    /**
     * Entity转Vo
     *
     * @return Vo对象
     * @date 2021-09-27
     */
    public AppMarketTypeVO toVo() {
        AppMarketTypeVO appMarketTypeVo = DozerBeanUtil.transitionType(this, AppMarketTypeVO.class);
        return appMarketTypeVo;
    }

    /**
     * List-Entity转List-Vo
     *
     * @return List-Vo对象
     * @date 2021-09-27
     */
    public List<AppMarketTypeVO> toListVo(List<AppMarketType> appMarketType) {
        List<AppMarketTypeVO> list = new ArrayList<>();
        appMarketType.forEach(t -> list.add(t.toVo()));
        return list;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("appMarketTypeId", getAppMarketTypeId())
                .append("appMarketTypeCode", getAppMarketTypeCode())
                .append("appMarketTypeName", getAppMarketTypeName())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

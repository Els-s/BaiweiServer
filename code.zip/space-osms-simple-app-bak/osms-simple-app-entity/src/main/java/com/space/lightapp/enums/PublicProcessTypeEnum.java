package com.space.lightapp.enums;

/**
 * 公共流程状态
 *
 * @Author ChenYou
 * @date 2021-11-13 15:40
 * @Version 1.0
 */
public enum PublicProcessTypeEnum {
    //公共流程
    COMPANY_PAY("companyPay", "企业结算流程"),
    RE_FUND("reFund", "退款流程");

    private String code;
    private String info;

    PublicProcessTypeEnum(String code, String info) {
        this.code = code;
        this.info = info;
    }

    public String getCode() {
        return code;
    }

    public String getInfo() {
        return info;
    }
}

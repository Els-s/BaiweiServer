package com.space.lightapp.entity.vo.query;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.space.lightapp.base.BaseVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.Date;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 问卷列表查询参数
 *
 * @Author kangmj
 * @date 2021-10-25 10:59
 * @Version 1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = "问卷列表查询参数")
public class AppSurveyListReqVO extends BaseVO {

    /**
     * 轻应用Id 关联轻应用Id
     */
    @ApiModelProperty(value = "必填：轻应用Id 关联轻应用Id")
    private Long lightAppId;
    /**
     * 问卷名称
     */
    @ApiModelProperty(value = "问卷名称")
    private String surveyName;
    /**
     * 搜索开始时间
     */
    @ApiModelProperty(value = "搜索开始时间")
    private String startTime;
    /**
     * 搜索结束时间
     */
    @ApiModelProperty(value = "搜索结束时间")
    private String endTime;
    /**
     * 问卷状态
     */
    @ApiModelProperty(value = "问卷状态：draft草稿，notStart未开始，underWay进行中，suspend暂停中，finish已结束")
    private String surveyType;
    /**
     * 时间状态（1:本日，2:近3日，3:近7天，4:近30日，5:近3月，6:今年）
     */
    @ApiModelProperty(value = "时间状态（1:本日，2:近3日，3:近7天，4:近30日，5:近3月，6:今年）")
    private Integer dataType;
}

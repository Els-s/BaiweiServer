package com.space.lightapp.entity.vo;

import com.space.lightapp.base.BaseVO;
import com.space.lightapp.entity.PushAdvancedSetUser;
import com.space.osms.common.core.utils.DozerBeanUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 高级设置-发起角色Vo对象 push_advanced_set_user
 *
 * @author ChenYou
 * @date 2021-11-04
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "高级设置-发起角色")
public class PushAdvancedSetUserVO extends BaseVO {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    private Long setUserId;
    /**
     * 轻应用Id
     */
    @ApiModelProperty(value = "轻应用Id")
    private Long lightAppId;
    /**
     * 高级设置Id
     */
    @ApiModelProperty(value = "高级设置Id")
    private Long pushAdvancedSetId;
    /**
     * 设置类型 1发起角色，其他待定
     */
    @ApiModelProperty(value = "设置类型 1发起角色，其他待定")
    private Integer setType;
    /**
     * 用户数据类型 user用户，role角色，company企业，group用户组
     */
    @ApiModelProperty(value = "用户数据类型 user用户，role角色，company企业，group用户组")
    private String userType;
    /**
     * 对应类型代码
     */
    @ApiModelProperty(value = "对应类型代码")
    private String userCode;
    /**
     * 对应名称
     */
    @ApiModelProperty(value = "对应名称")
    private String userName;
    /**
     * 排序 排序字段
     */
    @ApiModelProperty(value = "排序 排序字段")
    private Integer orderNum;
    /**
     * 状态 0禁用，1启用；默认1
     */
    @ApiModelProperty(value = "状态 0禁用，1启用；默认1")
    private Boolean status;
    /**
     * 逻辑删除 0有效，1被删除；默认0
     */
    @ApiModelProperty(value = "逻辑删除 0有效，1被删除；默认0")
    private Boolean delFlag;

    /**
     * Vo转Entity
     *
     * @return Entity对象
     * @date 2021-11-04
     */
    public PushAdvancedSetUser toEntity() {
        return DozerBeanUtil.transitionType(this, PushAdvancedSetUser.class);
    }

    /**
     * List-Vo转List-Entity
     *
     * @return List-Entity对象
     * @date 2021-11-04
     */
    public List<PushAdvancedSetUser> toListEntity(List<PushAdvancedSetUserVO> pushAdvancedSetUserVo) {
        List<PushAdvancedSetUser> list = new ArrayList<>();
        pushAdvancedSetUserVo.forEach(t -> list.add(t.toEntity()));
        return list;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("setUserId", getSetUserId())
                .append("lightAppId", getLightAppId())
                .append("pushAdvancedSetId", getPushAdvancedSetId())
                .append("setType", getSetType())
                .append("userType", getUserType())
                .append("userCode", getUserCode())
                .append("userName", getUserName())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("companyCode", getCompanyCode())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

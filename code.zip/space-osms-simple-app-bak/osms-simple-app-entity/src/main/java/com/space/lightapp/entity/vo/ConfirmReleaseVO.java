package com.space.lightapp.entity.vo;

import com.space.lightapp.base.BaseVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * 轻应用 对象 确认发布
 *
 * @author Jianghao
 * @date 2021-10-18
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(description = "工单管理 确认发布")
public class ConfirmReleaseVO extends BaseVO {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    private Long lightAppId;

    /**
     * 【发布测试】是否开启状态
     */
    @ApiModelProperty(value = "【发布测试】是否开启状态")
    private Boolean releaseOpenState;


    /**
     * 测试数据处理类型
     */
    @ApiModelProperty(value = "测试数据处理类型 1:删除测试数据 2：保留测试数据")
    private Integer type;


    /**
     * 暂存类型
     */
    @ApiModelProperty(value = "暂存类型 true:暂存;false:发布")
    private Boolean stagType;


}

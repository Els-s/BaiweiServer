package com.space.lightapp.entity.vo.query;

import com.space.lightapp.base.BaseFieldDTO;
import io.swagger.annotations.ApiModel;
import lombok.Getter;
import lombok.Setter;

/**
 * 允许代客录单服务查询参数
 */
@Getter
@Setter
@ApiModel(description = "允许代客录单服务查询参数")
public class AppValetVO extends BaseFieldDTO {

}

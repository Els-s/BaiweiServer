package com.space.lightapp.enums;

/**
 * 服务类型枚举类 基础服务baseServer->没有流程noNeedBpm,有流程needBpm，增值服务payServer->商品线上goodOnLine，服务线上serverOnline，服务线下serverOffLine
 *
 * @Author ChenYou
 * @date 2021-09-27 15:57
 * @Version 1.0
 */
public enum AppLittleTypeEnum {
    /**
     * 基础服务类：纯表单
     */
    BASE_SERVER_NO_NEED_BPM("noNeedBpm", "表单服务"),
    /**
     * 基础服务类：表单服务+流程服务
     */
    BASE_SERVER_NEED_BPM("needBpm", "表单服务+流程服务"),
    /**
     * 有偿服务类:商品定价在线交易
     */
    PAY_SERVER_GOOD_ONLINE("goodOnLine", "商品定价在线交易"),
    /**
     * 有偿服务类:服务定价在线交易
     */
    PAY_SERVER_SERVER_ONLINE("serverOnline", "服务定价在线交易"),
    /**
     * 有偿服务类:服务发布线下交易
     */
    PAY_SERVER_SERVER_OFFLINE("serverOffLine", "服务发布线下交易");

    private String code;
    private String info;

    AppLittleTypeEnum(String code, String info) {
        this.code = code;
        this.info = info;
    }

    public String getCode() {
        return code;
    }

    public String getInfo() {
        return info;
    }

    public static AppLittleTypeEnum getEnumByCode(String code) {
        AppLittleTypeEnum[] values = AppLittleTypeEnum.values();
        for (AppLittleTypeEnum value : values) {
            if (value.getCode().equalsIgnoreCase(code)) {
                return value;
            }
        }
        return null;
    }
}

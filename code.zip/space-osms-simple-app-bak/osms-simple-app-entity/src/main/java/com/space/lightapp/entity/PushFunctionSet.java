package com.space.lightapp.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.space.lightapp.base.BaseEntity;
import com.space.lightapp.entity.vo.PushFunctionSetVO;
import com.space.osms.common.core.utils.DozerBeanUtil;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 功能设置对象 push_function_set
 *
 * @author ChenYou
 * @date 2021-10-14
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("push_function_set")
public class PushFunctionSet extends BaseEntity {

    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long functionSetId;
    /**
     * 轻应用Id
     */
    private Long lightAppId;
    /**
     * 应用服务类型代码 survey问卷，active活动
     */
    private String appMarketTypeCode;
    /**
     * 关联Id
     */
    private Long relevancyId;
    /**
     * 填写渠道
     */
    private String pushDitch;
    /**
     * 限制用户填写次数类型 PushSetEnum WRITE_TIME
     */
    private String writeTime;
    /**
     * 限制用户填写次数值
     */
    private Integer writeTimeCount;
    /**
     * 是否允许分享到朋友圈
     */
    private Boolean shareFriends;
    /**
     * 是否允许发送给朋友
     */
    private Boolean shareFriend;
    /**
     * 排序 排序字段
     */
    private Integer orderNum;
    /**
     * 是否禁用 0禁用，1启用；默认1
     */
    private Boolean status;
    /**
     * 备注信息
     */
    private String remark;

    /**
     * 逻辑删除 0有效，1被删除；默认0
     */
    private Boolean delFlag;

    /**
     * Entity转Vo
     *
     * @return Vo对象
     * @date 2021-10-14
     */
    public PushFunctionSetVO toVo() {
        return DozerBeanUtil.transitionType(this, PushFunctionSetVO.class);
    }

    /**
     * List-Entity转List-Vo
     *
     * @return List-Vo对象
     * @date 2021-10-14
     */
    public List<PushFunctionSetVO> toListVo(List<PushFunctionSet> pushFunctionSet) {
        List<PushFunctionSetVO> list = new ArrayList<>();
        pushFunctionSet.forEach(t -> list.add(t.toVo()));
        return list;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("functionSetId", getFunctionSetId())
                .append("lightAppId", getLightAppId())
                .append("appMarketTypeCode", getAppMarketTypeCode())
                .append("relevancyId", getRelevancyId())
                .append("pushDitch", getPushDitch())
                .append("writeTime", getWriteTime())
                .append("shareFriends", getShareFriends())
                .append("shareFriend", getShareFriend())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("remark", getRemark())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

package com.space.lightapp.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.space.lightapp.base.BaseEntity;
import com.space.lightapp.entity.vo.PushProcessSetVO;
import com.space.osms.common.core.utils.DozerBeanUtil;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 流程设置对象 push_process_set
 *
 * @author ChenYou
 * @date 2021-10-14
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("push_process_set")
public class PushProcessSet extends BaseEntity {

    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long processSetId;
    /**
     * 轻应用Id
     */
    private Long lightAppId;
    /**
     * 轻应用模块Id
     */
    private Long lightAppModuleId;
    /**
     * 任务中心唯一标识码
     */
    private String taskTypeCode;
    /**
     * 流程Id
     */
    private String processId;
    /**
     * 流程定义Id
     */
    private String definitionId;
    /**
     * 流程名称
     */
    private String processName;
    /**
     * 排序 排序字段
     */
    private Integer orderNum;
    /**
     * 状态 0禁用，1启用；默认1
     */
    private Boolean status;

    /**
     * 逻辑删除 0有效，1被删除；默认0
     */
    private Boolean delFlag;

    /**
     * Entity转Vo
     *
     * @return Vo对象
     * @date 2021-10-14
     */
    public PushProcessSetVO toVo() {
        return DozerBeanUtil.transitionType(this, PushProcessSetVO.class);
    }

    /**
     * List-Entity转List-Vo
     *
     * @return List-Vo对象
     * @date 2021-10-14
     */
    public List<PushProcessSetVO> toListVo(List<PushProcessSet> pushProcessSet) {
        List<PushProcessSetVO> list = new ArrayList<>();
        pushProcessSet.forEach(t -> list.add(t.toVo()));
        return list;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("processSetId", getProcessSetId())
                .append("lightAppId", getLightAppId())
                .append("lightAppModuleId", getLightAppModuleId())
                .append("processId", getProcessId())
                .append("processName", getProcessName())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

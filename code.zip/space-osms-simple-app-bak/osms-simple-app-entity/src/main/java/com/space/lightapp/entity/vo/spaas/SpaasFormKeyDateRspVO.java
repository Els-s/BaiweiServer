package com.space.lightapp.entity.vo.spaas;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 表单Key信息
 *
 * @Author kangmj
 * @date 2021-10-27 11:44
 * @Version 1.0
 */
@Data
public class SpaasFormKeyDateRspVO {

    @ApiModelProperty(value = "关联流程 def_key")
    private String processKey;

    @ApiModelProperty(value = "关联表单别名")
    private String alias;

    /**
     * 流程定义Id
     **/
    @ApiModelProperty(value = "流程定义Id, defId")
    private String definitionId;
    /**
     * 表单ID
     **/
    private String formId;
}

package com.space.lightapp.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.space.lightapp.base.BaseEntity;
import com.space.lightapp.entity.vo.SysOperatorLogVO;
import com.space.lightapp.enums.log.OperatorStateEnum;
import com.space.lightapp.enums.log.OperatorTypeEnum;
import com.space.osms.common.core.utils.DozerBeanUtil;
import io.swagger.annotations.ApiModel;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 操作日志对象 sys_operator_log
 *
 * @author ChenYou
 * @date 2021-11-22
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("sys_operator_log")
@ApiModel(description = "操作日志")
public class SysOperatorLog extends BaseEntity {

    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long operatorId;
    /**
     * 应用代码
     */
    private String moduleCode;
    /**
     * 模块标题
     */
    private String title;
    /**
     * 操作类型 add，delete，update，import，export，other
     */
    private String operatorType;
    /**
     * 方法名称
     */
    private String method;
    /**
     * 请求方式
     */
    private String requestMethod;
    /**
     * 请求URL
     */
    private String operatorUrl;
    /**
     * 主机地址
     */
    private String operatorIp;
    /**
     * 操作地点
     */
    private String operatorLocation;
    /**
     * 请求参数
     */
    private String operatorParam;
    /**
     * 返回参数
     */
    private String jsonResult;
    /**
     * 操作状态 normal-正常，exception-异常
     */
    private String operatorState;
    /**
     * 错误消息
     */
    private String errorMsg;
    /**
     * 起始时间
     */
    @TableField(exist = false)
    private String startTime;
    /**
     * 结束时间
     */
    @TableField(exist = false)
    private String endTime;

    /**
     * Entity转Vo
     *
     * @return Vo对象
     * @date 2021-11-22
     */
    public SysOperatorLogVO toVo() {
        SysOperatorLogVO sysOperatorLogVO = DozerBeanUtil.transitionType(this, SysOperatorLogVO.class);
        sysOperatorLogVO
                .setOperatorState(OperatorStateEnum.getInfoValue(sysOperatorLogVO.getOperatorState()));
        sysOperatorLogVO
                .setOperatorType(OperatorTypeEnum.getInfoValue(sysOperatorLogVO.getOperatorType()));
        return sysOperatorLogVO;
    }

    /**
     * List-Entity转List-Vo
     *
     * @return List-Vo对象
     * @date 2021-11-22
     */
    public List<SysOperatorLogVO> toListVo(List<SysOperatorLog> sysOperatorLog) {
        List<SysOperatorLogVO> list = new ArrayList<>();
        sysOperatorLog.forEach(t -> list.add(t.toVo()));
        return list;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("operatorId", getOperatorId())
                .append("moduleCode", getModuleCode())
                .append("title", getTitle())
                .append("operatorType", getOperatorType())
                .append("method", getMethod())
                .append("requestMethod", getRequestMethod())
                .append("operatorUrl", getOperatorUrl())
                .append("operatorIp", getOperatorIp())
                .append("operatorLocation", getOperatorLocation())
                .append("operatorParam", getOperatorParam())
                .append("jsonResult", getJsonResult())
                .append("operatorState", getOperatorState())
                .append("errorMsg", getErrorMsg())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("companyCode", getCompanyCode())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .toString();
    }

}

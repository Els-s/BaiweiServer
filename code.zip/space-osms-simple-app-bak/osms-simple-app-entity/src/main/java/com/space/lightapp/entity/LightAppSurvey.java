package com.space.lightapp.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.space.lightapp.base.BaseEntity;
import com.space.lightapp.entity.vo.LightAppSurveyVO;
import com.space.osms.common.core.utils.DozerBeanUtil;
import io.swagger.annotations.ApiModelProperty;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 问卷对象 light_app_survey
 *
 * @author ChenYou
 * @date 2021-10-14
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("light_app_survey")
public class LightAppSurvey extends BaseEntity {

    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long surveyId;
    /**
     * 轻应用Id 关联轻应用Id
     */
    private Long lightAppId;
    /**
     * 应用服务类型代码
     */
    private String appMarketTypeCode;
    /**
     * 任务中心唯一标识码
     */
    private String taskTypeCode;
    /**
     * 关联表单Id 关联表单Id
     */
    private String formId;
    /**
     * 关联流程Id
     */
    private String processId;
    /**
     * 问卷编号
     */
    private String surveyCode;
    /**
     * 问卷名称
     */
    private String surveyName;
    /**
     * 问卷目的
     */
    private String surveyAim;
    /**
     * 开始时间
     */
    private Date startTime;
    /**
     * 结束时间
     */
    private Date endTime;
    /**
     * 参与条件 tourist游客   commonUser普通用户   companyEmployee企业员工   companyManager企业管理员,多种类型英文逗号隔开
     */
    private String serverLaunchUser;
    /**
     * 前言
     */
    private String foreword;
    /**
     * 结束语
     */
    private String tag;
    /**
     * 展示方式 1一页显示，2每题一页
     */
    private String displayMode;
    /**
     * 填写问卷的总时长
     */
    private BigDecimal surveyTime;
    /**
     * 是否显示题号 0不显示，1显示
     */
    private Boolean showNumber;
    /**
     * 是否显示题型 0不显示，1显示
     */
    private Boolean showItemType;
    /**
     * 排序 排序字段
     */
    private Integer orderNum;
    /**
     * 是否禁用 0禁用，1启用；默认1
     */
    private Boolean status;
    /**
     * 问卷状态
     */
    private String surveyType;
    /**
     * 在线状态：online 上线中，offline 下线中， null 无在线状态
     */
    private String onlineStatus;
    /**
     * 备注信息
     */
    private String remark;

    /**
     * 逻辑删除 0有效，1被删除；默认0
     */
    private Boolean delFlag;

    private Boolean existTaskCentreCode;
    /**
     * 答卷数量
     */
    @TableField(exist = false)
    private Integer answerNum;

    /**
     * 暂存类型
     */
    @ApiModelProperty(value = "暂存类型 true:暂存;false:发布")
    @TableField(exist = false)
    private Boolean stagType;


    /**
     * Entity转Vo
     *
     * @return Vo对象
     * @date 2021-10-14
     */
    public LightAppSurveyVO toVo() {
        return DozerBeanUtil.transitionType(this, LightAppSurveyVO.class);
    }

    /**
     * List-Entity转List-Vo
     *
     * @return List-Vo对象
     * @date 2021-10-14
     */
    public List<LightAppSurveyVO> toListVo(List<LightAppSurvey> lightAppSurvey) {
        List<LightAppSurveyVO> list = new ArrayList<>();
        lightAppSurvey.forEach(t -> list.add(t.toVo()));
        return list;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("surveyId", getSurveyId())
                .append("lightAppId", getLightAppId())
                .append("appMarketTypeCode", getAppMarketTypeCode())
                .append("formId", getFormId())
                .append("surveyCode", getSurveyCode())
                .append("surveyName", getSurveyName())
                .append("surveyAim", getSurveyAim())
                .append("startTime", getStartTime())
                .append("endTime", getEndTime())
                .append("serverLaunchUser", getServerLaunchUser())
                .append("foreword", getForeword())
                .append("tag", getTag())
                .append("displayMode", getDisplayMode())
                .append("surveyTime", getSurveyTime())
                .append("showNumber", getShowNumber())
                .append("showItemType", getShowItemType())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("remark", getRemark())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

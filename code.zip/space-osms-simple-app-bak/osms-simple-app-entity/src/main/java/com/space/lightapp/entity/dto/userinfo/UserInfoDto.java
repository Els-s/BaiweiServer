package com.space.lightapp.entity.dto.userinfo;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * { "userInfo": { "user": { "label": "Mao", "value": "d188adf7bb334503be7be5f2b1fe6084" }, "phone": 18682236617,
 * "company": { "label": "深圳市卓越同兴互联科技有限公司", "value": "CSR2021091500948" }, "companyAddress": { "label":
 * "科兴科学园-G层商业D栋G层G33", "value": "2610" }* 	} }
 */
//public class UserInfoCombDto {
//    private UserInfoDto userInfo ;
//}

@Data
@Accessors(chain = true)
public class UserInfoDto {

    private UserDto user = new UserDto();
    private String phone;
    private UserDto company = new UserDto();
    private UserDto companyAddress = new UserDto();
}

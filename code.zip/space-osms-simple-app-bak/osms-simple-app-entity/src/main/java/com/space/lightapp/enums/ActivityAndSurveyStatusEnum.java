package com.space.lightapp.enums;

/**
 * 活动枚举
 *
 * @Author JiangHao
 * @date 2021-10-20 11:35
 * @Version 1.0
 */
public enum ActivityAndSurveyStatusEnum {
    // 活动状态
    STATUS_DRAFT("draft", "草稿"),
    STATUS_NOT_START("notStart", "未开始"),
    STATUS_UNDERWAY("underWay", "进行中"),
    STATUS_FINISH("finish", "已结束"),
    STATUS_SUSPEND("suspend", "暂停中"),
    ;
    private String code;
    private String info;

    ActivityAndSurveyStatusEnum(String code, String info) {
        this.code = code;
        this.info = info;
    }

    public String getCode() {
        return code;
    }

    public String getInfo() {
        return info;
    }

    public static String getInfoValue(String code) {
        ActivityAndSurveyStatusEnum[] values = ActivityAndSurveyStatusEnum.values();
        for (ActivityAndSurveyStatusEnum value : values) {
            if (value.getCode().equals(code)) {
                return value.getInfo();
            }
        }
        return "暂无";
    }
}

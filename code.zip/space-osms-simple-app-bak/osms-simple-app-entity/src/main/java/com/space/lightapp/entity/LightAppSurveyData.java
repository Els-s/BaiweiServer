package com.space.lightapp.entity;

import cn.hutool.core.date.BetweenFormatter.Level;
import cn.hutool.core.date.DateUnit;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.ObjectUtil;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.space.lightapp.base.FormBaseEntity;
import com.space.lightapp.entity.vo.LightAppSurveyDataVO;
import com.space.osms.common.core.utils.DozerBeanUtil;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 填答问卷数据 对象 light_app_survey_data
 *
 * @author ChenYou
 * @date 2021-10-20
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("light_app_survey_data")
public class LightAppSurveyData extends FormBaseEntity {

    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long surveyDataId;
    /**
     * 问卷模型Id
     */
    private Long surveyId;
    /**
     * 答卷人
     */
    private String answerName;
    /**
     * 答卷人Code
     */
    private String answerCode;
    /**
     * 答卷人企业
     */
    private String answerCompany;
    /**
     * 答卷机器
     */
    private String answerMachine;
    /**
     * 开始填答时间
     */
    private Date startTime;
    /**
     * 结束时间
     */
    private Date endTime;
    /**
     * 排序 排序字段
     */
    private Integer orderNum;
    /**
     * 是否禁用 0禁用，1启用；默认1
     */
    private Boolean status;
    /**
     * 备注信息
     */
    private String remark;
    /**
     * 逻辑删除 0有效，1被删除；默认0
     */
    private Boolean delFlag;

    /**
     * 搜索开始时间
     */
    @TableField(exist = false)
    private String answerStartTime;
    /**
     * 搜索结束时间
     */
    @TableField(exist = false)
    private String answerEndTime;

    /**
     * 表单配置
     */
    @TableField(exist = false)
    private PushFormSet pushFormSet;

    /**
     * 流程配置
     */
    @TableField(exist = false)
    private PushProcessSet processSet;

    /**
     * Entity转Vo
     *
     * @return Vo对象
     * @date 2021-10-20
     */
    public LightAppSurveyDataVO toVo() {
        LightAppSurveyDataVO surveyDataVo = DozerBeanUtil.transitionType(this,
                LightAppSurveyDataVO.class);
        if (ObjectUtil.isEmpty(surveyDataVo.getStartTime()) || ObjectUtil.isEmpty(
                surveyDataVo.getEndTime())) {
            return surveyDataVo;
        } else {
            surveyDataVo.setTakeTime(DateUtil.formatBetween(
                    DateUtil.between(surveyDataVo.getStartTime(), surveyDataVo.getEndTime(), DateUnit.MS,
                            true), Level.MILLISECOND));
            return surveyDataVo;
        }
    }

    /**
     * List-Entity转List-Vo
     *
     * @return List-Vo对象
     * @date 2021-10-20
     */
    public List<LightAppSurveyDataVO> toListVo(List<LightAppSurveyData> lightAppSurveyData) {
        List<LightAppSurveyDataVO> list = new ArrayList<>();
        lightAppSurveyData.forEach(t -> list.add(t.toVo()));
        return list;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("surveyDataId", getSurveyDataId())
                .append("lightAppId", getLightAppId())
                .append("lightAppModuleId", getLightAppModuleId())
                .append("appMarketTypeCode", getAppMarketTypeCode())
                .append("surveyId", getSurveyId())
                .append("answerName", getAnswerName())
                .append("answerCompany", getAnswerCompany())
                .append("answerMachine", getAnswerMachine())
                .append("startTime", getStartTime())
                .append("endTime", getEndTime())
                .append("orderCode", getOrderCode())
                .append("formSetId", getFormSetId())
                .append("formId", getFormId())
                .append("content", getContent())
                .append("processId", getProcessId())
                .append("processNodeUser", getProcessNodeUser())
                .append("dataId", getDataId())
                .append("appCode", getAppCode())
                .append("businessState", getBusinessState())
                .append("processState", getProcessState())
                .append("processStartStatus", getProcessStartStatus())
                .append("taskId", getTaskId())
                .append("spaceInfo", getSpaceInfo())
                .append("spaceCode", getSpaceCode())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("companyCode", getCompanyCode())
                .append("remark", getRemark())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

package com.space.lightapp.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.space.lightapp.base.BaseEntity;
import com.space.lightapp.entity.vo.PushApplySetVO;
import com.space.osms.common.core.utils.DozerBeanUtil;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 报名设置对象 push_apply_set
 *
 * @author ChenYou
 * @date 2021-10-18
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("push_apply_set")
public class PushApplySet extends BaseEntity {

    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long applySetId;
    /**
     * 轻应用Id
     */
    private Long lightAppId;
    /**
     * 轻应用类型
     */
    private String appMarketTypeCode;
    /**
     * 活动Id
     */
    private Long activityId;
    /**
     * 表单Id
     */
    private String formId;
    /**
     * 是否需要报名 0:不需要；1：需要
     */
    private String needApply;
    /**
     * 报名人数上限
     */
    private Integer limitNumber;
    /**
     * 报名开始时间
     */
    private Date startTime;
    /**
     * 报名结束时间
     */
    private Date endTime;
    /**
     * 是否需要报名费用 0不需要，1需要
     */
    private Integer needMoney;
    /**
     * 费用金额
     */
    private BigDecimal money;
    /**
     * 流程Id
     */
    private String processId;
    /**
     * 是否需要填写信息 0需要，1不需要
     */
    private Integer needInfo;
    /**
     * 排序 排序字段
     */
    private Integer orderNum;
    /**
     * 是否禁用 0禁用，1启用；默认1
     */
    private Boolean status;
    /**
     * 备注
     */
    private String remark;
    /**
     * 逻辑删除 0有效，1被删除；默认0
     */
    private Boolean delFlag;

    /**
     * Entity转Vo
     *
     * @return Vo对象
     * @date 2021-10-18
     */
    public PushApplySetVO toVo() {
        return DozerBeanUtil.transitionType(this, PushApplySetVO.class);
    }

    /**
     * List-Entity转List-Vo
     *
     * @return List-Vo对象
     * @date 2021-10-18
     */
    public List<PushApplySetVO> toListVo(List<PushApplySet> pushApplySet) {
        List<PushApplySetVO> list = new ArrayList<>();
        pushApplySet.forEach(t -> list.add(t.toVo()));
        return list;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("applySetId", getApplySetId())
                .append("lightAppId", getLightAppId())
                .append("appMarketTypeCode", getAppMarketTypeCode())
                .append("activityId", getActivityId())
                .append("formId", getFormId())
                .append("limitNumber", getLimitNumber())
                .append("startTime", getStartTime())
                .append("endTime", getEndTime())
                .append("needMoney", getNeedMoney())
                .append("money", getMoney())
                .append("processId", getProcessId())
                .append("needInfo", getNeedInfo())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("companyCode", getCompanyCode())
                .append("remark", getRemark())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

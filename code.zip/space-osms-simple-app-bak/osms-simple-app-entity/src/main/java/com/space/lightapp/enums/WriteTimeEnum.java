package com.space.lightapp.enums;

/**
 * 用户填写次数类型枚举
 *
 * @Author jiangHao
 * @date 2021-11-08 14:42
 * @Version 1.0
 */
public enum WriteTimeEnum {
    // PushFunctionSet 用户填写次数类型枚举
    WRITE_TIME_ONCE("once", "仅限"),
    WRITE_TIME_DAY("day", "每天"),
    WRITE_TIME_WEEK("week", "每周"),
    WRITE_TIME_MONTH("month", "每月");
    private String code;
    private String info;

    WriteTimeEnum(String code, String info) {
        this.code = code;
        this.info = info;
    }

    public String getCode() {
        return code;
    }

    public String getInfo() {
        return info;
    }
}

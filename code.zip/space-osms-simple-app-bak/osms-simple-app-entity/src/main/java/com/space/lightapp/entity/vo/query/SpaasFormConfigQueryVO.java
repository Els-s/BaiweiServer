package com.space.lightapp.entity.vo.query;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * spaas表单配置查询对象
 *
 * @Author ChenYou
 * @date 2021-10-28 21:10
 * @Version 1.0
 */
@Data
@ApiModel(description = "spaas表单配置查询对象")
public class SpaasFormConfigQueryVO {

    /**
     * 轻应用Id
     */
    @ApiModelProperty(value = "轻应用Id")
    private Long lightAppId;
    /**
     * 应用类型代码
     */
    @ApiModelProperty(value = "应用类型代码")
    private String appMarketTypeCode;
    /**
     * 关联业务Id（工单和基础服务，此字段为null；问卷关联问卷Id，活动关联活动Id）
     */
    @ApiModelProperty(value = "关联业务Id")
    private Long relevancyId;
}

package com.space.lightapp.entity.vo.spaas;

import lombok.Data;

/**
 * 返回表单配置信息
 *
 * @Author ChenYou
 * @date 2021-10-23 11:32
 * @Version 1.0
 */
@Data
public class SpaasFormConfigVO {

    /**
     * 数据库别名：配置在Spass的数据库名称，一般dsAlias和dsName一样，例如：osms_light_app
     */
    private String dsAlias;
    /**
     * 数据库名称：配置在Spass的数据库名称,一般dsAlias和dsName一样，例如：osms_light_app
     */
    private String dsName;
    /**
     * 分类：默认分类选择：默认工单
     */
    private String categoryId;
    /**
     * 动态表中文名称
     */
    private String name;
    /**
     * 标识键：数据表标识：唯一，t_alias就是动态表名称
     */
    private String alias;
    /**
     * 应用分类（Spaas分类用，不可修改）
     */
    private String appIdKey;
}

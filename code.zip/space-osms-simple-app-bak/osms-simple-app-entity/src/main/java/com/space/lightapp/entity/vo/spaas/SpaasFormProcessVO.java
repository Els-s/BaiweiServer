package com.space.lightapp.entity.vo.spaas;

import com.space.lightapp.base.BaseFieldDTO;
import com.space.lightapp.base.BaseVO;
import com.space.lightapp.entity.PushAdvancedSet;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * 轻应用 关联表单流程 信息
 */
@Getter
@Setter
@ApiModel(description = "轻应用")
public class SpaasFormProcessVO extends BaseFieldDTO {

    @ApiModelProperty(value = "关联流程 def_key")
    private String processId;

    @ApiModelProperty(value = "关联表单别名")
    private String alias;

    @ApiModelProperty(value = "应用服务类型标识")
    private String appFlagType;

    @ApiModelProperty(value = "应用服务代码")
    private String appMarketCode;

    @ApiModelProperty(value = "应用服务ID")
    private String lightAppId;

    @ApiModelProperty(value = "应用服务图标")
    private String iconUrl;

    @ApiModelProperty(value = "应用服务编码:如 workOrder")
    private String lightAppCode;

    @ApiModelProperty(value = "应用服务名称")
    private String lightAppName;

    @ApiModelProperty(value = "应用服务模块类型编码：表单=fromSet, 流程=processSet")
    private String lightAppModuleTypeCode;

    @ApiModelProperty(value = "应用服务模块ID")
    private String lightAppModuleId;

    @ApiModelProperty(value = "应用服务模块编码：表单=fromSet, 流程=processSet")
    private String lightAppModuleCode;

    @ApiModelProperty(value = "应用服务模块名称")
    private String lightAppModuleName;

    @ApiModelProperty(value = "高级设置发布信息")
    private PushAdvancedSet pushAdvancedSet;

}

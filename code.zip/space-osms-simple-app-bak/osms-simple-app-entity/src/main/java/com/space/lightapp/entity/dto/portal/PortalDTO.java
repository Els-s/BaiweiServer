package com.space.lightapp.entity.dto.portal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 门户接口DTO，可扩展
 *
 * @Author Els
 * @date 2021-12-02 20:14
 * @Version 1.0
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PortalDTO {

    private String tenementCode;
    private String projectCode;
    private String phone;
    private String personCode;
    private String customerCode;
}

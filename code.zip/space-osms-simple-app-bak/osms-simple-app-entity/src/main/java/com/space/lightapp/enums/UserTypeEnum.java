package com.space.lightapp.enums;

/**
 * 用户类型枚举
 *
 * @Author ChenYou
 * @date 2021-09-27 16:12
 * @Version 1.0
 */
public enum UserTypeEnum {
    /**
     * 个人账户
     */
    USER("user", "个人账户"),
    /**
     * 用户组
     */
    GROUP("group", "用户组"),
    /**
     * 角色
     */
    ROLE("role", "角色"),
    /**
     * 企业
     */
    COMPANY("company", "企业"),
    /**
     * 岗位
     */
    POSITION("position", "岗位"),
    /**
     * 岗位
     */
    ORG_CODE("orgCode", "组");

    UserTypeEnum(String code, String info) {
        this.code = code;
        this.info = info;
    }

    private String code;
    private String info;

    public String getCode() {
        return code;
    }

    public String getInfo() {
        return info;
    }

    public static UserTypeEnum getEnumByCode(String code) {
        UserTypeEnum[] values = UserTypeEnum.values();
        for (UserTypeEnum value : values) {
            if (value.getCode().equals(code)) {
                return value;
            }
        }
        return null;
    }

    public static String getInfoByCode(String code) {
        UserTypeEnum[] values = UserTypeEnum.values();
        for (UserTypeEnum value : values) {
            if (value.getCode().equals(code)) {
                return value.getInfo();
            }
        }
        return code;
    }
}

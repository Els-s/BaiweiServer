package com.space.lightapp.entity.vo.message;


import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;
import lombok.Data;
import lombok.experimental.Accessors;
import org.springframework.format.annotation.DateTimeFormat;


/**
 * @description: 资讯管理表
 * @author: JiangHao
 * @date: 2021/11/11 20:13
 */
@Data
@Accessors(chain = true)
public class InfoManageVO implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 发布渠道
     */
    @ApiModelProperty(value = "发布渠道", required = true)
    private String releaseChannel;

    /**
     * 发布位置支持多选
     */
    @ApiModelProperty(value = "发布位置", required = true)
    private List<String> releaseLocations;

    /**
     * 发布位置支持多选
     */
  /*  @ApiModelProperty(value = "发布位置", required = true)
    private String releaseLocationsVo;*/

    /**
     * 项目code集合
     */
    @ApiModelProperty(value = "发布范围", required = true)
    private List<String> projectCodes;
    /**
     * 项目code集合
     */
 /*   @ApiModelProperty(value = "发布范围", required = true)
    private String projectCodesVo;*/

    /**
     * 封面路径
     */
    @ApiModelProperty(value = "咨询封面", required = true)
    private List<String> coverUrls;
    /**
     * 封面路径
     */
 /*   @ApiModelProperty(value = "咨询封面", required = true)
    private String coverUrlsVo;*/

    /**
     * 发布时间（如即时就存当前时间）
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "开始时间", required = true)
    private Timestamp releaseTime;

    /**
     * 结束时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "结束时间", required = false)
    private Timestamp endTime;

    /**
     * 是否长期  0否 1是
     */
    @ApiModelProperty(value = "是否长期；0否，1是", required = false)
    private Integer longTerm;

    /**
     * 资讯标题
     */
    @ApiModelProperty(value = "标题", required = true)
    private String infoTitle;

    /**
     * 资讯来源
     */
    @ApiModelProperty(value = "咨询来源")
    private String infoResouse;

    /**
     * 分享导语
     */
    @ApiModelProperty(value = "分享导语")
    private String sharingLead;


    /**
     * 资讯正文/链接路径
     */
    @ApiModelProperty(value = "发布内容", required = true)
    private String infoContent;


    /**
     * 发布渠道key
     */
    private String releaseChannelName;

    /**
     * 发布位置
     */
    private String releaseLocationName;

    /**
     * 租户编码
     */
    private String tenementCode;

    /**
     * 删除标记 数据的逻辑删除标记；默认为0；0是有效   1被删除
     */
    private Integer delFlag;

    /**
     * 展示样式（0无图模式,1小图模式,2大图模式,3三图模式）
     */
    private Integer showType;

    /**
     * 资讯形式 0:文章 1:链接
     */
    private Integer infoForm;

    /**
     * 创建人编码
     */
    private String createPersonCode;

    /**
     * 更新人编码
     */
    private String updatePersonCode;

    /**
     * 更新人名称
     */
    private String updatePersonName;

    /**
     * 更新时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Timestamp createTime;

    /**
     * 修改时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Timestamp updateTime;

    /**
     * 上下架状态 0上架 1下架 2待上架
     */
    private Integer shelfStatus;

    /**
     * 上下架汉语
     */
    private String shelfStatusName;

    /**
     * 项目code集合
     */
    private String projectCode;

    /**
     * 查询名称
     */
    private String projectName;

    /**
     * 结束时间过滤  1为查询当前时间大于结束时间的记录
     */
    private Integer hasEnded;

    /**
     * 背景照片url
     */
    private List<String> backGroupUrls;

    /**
     * 背景文件类型
     */
    private Integer fileType;
    /**
     * 背景文件类型描述
     */
    private String backGroupTypeName;

    /**
     * 多个附件
     */
    private List<DigitalMediaVO> attachmentList;

    /**
     * 0创建时间 1更新时间 2发布时间
     */
    private Integer fieldType;

    /**
     * 倒序：0 正序：1
     */
    private String sortOrder;

    /**
     * 排序字段
     */
    private String sortField;

    /**
     * 当创建人与当前用户不同则无法编辑 0：前端可编辑，1：前端无法编辑
     */
    private Integer editFlag;

    /**
     * 资讯标签id
     */
    private String infoTag;

    /**
     * 发布渠道列表
     */
    private List<String> releaseChannelList;

}

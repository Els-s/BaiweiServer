package com.space.lightapp.entity.vo;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.space.lightapp.base.HandleTypeVO;
import com.space.lightapp.entity.PushFormData;
import com.space.lightapp.entity.PushFormSet;
import com.space.lightapp.entity.PushProcessSet;
import com.space.osms.common.core.utils.DozerBeanUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 单数据 Vo对象 push_form_data
 *
 * @author ChenYou
 * @date 2021-10-20
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = "单数据 ")
public class PushFormDataVO extends HandleTypeVO {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    private Long formDataId;
    /**
     * 轻应用Id
     */
    @ApiModelProperty(value = "轻应用Id")
    private Long lightAppId;
    /**
     * 轻应用模块Id
     */
    @ApiModelProperty(value = "轻应用模块Id")
    private Long lightAppModuleId;
    /**
     * 轻应用类型
     */
    @ApiModelProperty(value = "轻应用类型")
    private String appMarketTypeCode;
    /**
     * 工单标签 测
     */
    @ApiModelProperty(value = "工单标签 测")
    private String dataTag;
    /**
     * 单据编码 工单编码
     */
    @ApiModelProperty(value = "单据编码 工单编码")
    private String orderCode;
    /**
     * 表单设置Id
     */
    @ApiModelProperty(value = "表单设置Id")
    private Long formSetId;
    /**
     * 表单Id 对接表单系统
     */
    @ApiModelProperty(value = "表单Id 对接表单系统")
    private String formId;
    /**
     * 工单内容
     */
    @ApiModelProperty(value = "工单内容")
    private String content;
    /**
     * 流程Id
     */
    @ApiModelProperty(value = "流程Id")
    private String processId;
    /**
     * 流程实例ID
     */
    @ApiModelProperty(value = "流程实例ID")
    private String processInsId;
    /**
     * 当前节点处理人
     */
    @ApiModelProperty(value = "当前节点处理人")
    private String processNodeUser;
    /**
     * 当前节点处理人详情
     */
    @ApiModelProperty(value = "当前节点处理人详情")
    private JSONArray assigneeIdNameMap;
    /**
     * 提单人
     */
    @ApiModelProperty(value = "提单人")
    private String billUser;
    /**
     * 提单人详情（name,id等等信息）
     */
    @ApiModelProperty(value = "提单人详情")
    private String billUserDetail;
    /**
     * 提单人详情（name,id等等信息）
     */
    @ApiModelProperty(value = "提单人详情")
    private JSONObject createByIdNameMap;
    /**
     * 对应数据Id 对应存储表单数据
     */
    @ApiModelProperty(value = "对应数据Id 对应存储表单数据")
    private String dataId;
    /**
     * 应用编码
     */
    @ApiModelProperty(value = "应用编码")
    private String appCode;
    /**
     * 业务状态
     */
    @ApiModelProperty(value = "业务状态")
    private String businessState;
    /**
     * 业务状态
     */
    @ApiModelProperty(value = "工单状态Vo")
    private String businessStateVo;
    /**
     * 工单状态 工单状态（1待受理，2处理中，3已完成，4已关闭，5待回访，6已取消）
     */
    @ApiModelProperty(value = "工单状态 工单状态（1待受理，2处理中，3已完成，4已关闭，5待回访，6已取消）")
    private Integer processState;
    /**
     * 工单状态名称（1待受理，2处理中，3已完成，4已关闭，5待回访，6已取消）
     */
    @ApiModelProperty(value = "工单状态（1待受理，2处理中，3已完成，4已关闭，5待回访，6已取消）")
    private String processStateName;
    /**
     * 流程启动结果 流程启动结果，1-启动成功，-1-启动失败，0-未启动流程
     */
    @ApiModelProperty(value = "流程启动结果 流程启动结果，1-启动成功，-1-启动失败，0-未启动流程")
    private Integer processStartStatus;
    /**
     * 任务Id
     */
    @ApiModelProperty(value = "任务Id")
    private String taskId;
    /**
     * 空间地址信息
     */
    @ApiModelProperty(value = "空间地址信息")
    private String spaceInfo;
    /**
     * 空间地址信息编码
     */
    @ApiModelProperty(value = "空间地址信息编码")
    private String spaceCode;
    /**
     * 排序 排序字段
     */
    @ApiModelProperty(value = "排序 排序字段")
    private Integer orderNum;
    /**
     * 状态 0禁用，1启用；默认1
     */
    @ApiModelProperty(value = "状态 0禁用，1启用；默认1")
    private Boolean status;
    /**
     * 逻辑删除 0有效，1被删除；默认0
     */
    @ApiModelProperty(value = "逻辑删除 0有效，1被删除；默认0")
    private Boolean delFlag;
    /**
     * 表单配置
     */
    @ApiModelProperty(value = "表单配置")
    private PushFormSet pushFormSet;

    /**
     * 流程配置
     */
    @ApiModelProperty(value = "流程配置")
    private PushProcessSet processSet;
    /**
     * 公司名称
     */
    @ApiModelProperty(value = "公司名称")
    private String companyName;

    /**
     * Vo转Entity
     *
     * @return Entity对象
     * @date 2021-10-20
     */
    public PushFormData toEntity() {
        return DozerBeanUtil.transitionType(this, PushFormData.class);
    }

    /**
     * List-Vo转List-Entity
     *
     * @return List-Entity对象
     * @date 2021-10-20
     */
    public List<PushFormData> toListEntity(List<PushFormDataVO> pushFormDataVo) {
        List<PushFormData> list = new ArrayList<>();
        pushFormDataVo.forEach(t -> list.add(t.toEntity()));
        return list;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("formDataId", getFormDataId())
                .append("lightAppId", getLightAppId())
                .append("lightAppModuleId", getLightAppModuleId())
                .append("appMarketTypeCode", getAppMarketTypeCode())
                .append("dataTag", getDataTag())
                .append("orderCode", getOrderCode())
                .append("formSetId", getFormSetId())
                .append("formId", getFormId())
                .append("content", getContent())
                .append("processId", getProcessId())
                .append("processNodeUser", getProcessNodeUser())
                .append("dataId", getDataId())
                .append("appCode", getAppCode())
                .append("businessState", getBusinessState())
                .append("processState", getProcessState())
                .append("processStartStatus", getProcessStartStatus())
                .append("taskId", getTaskId())
                .append("spaceInfo", getSpaceInfo())
                .append("spaceCode", getSpaceCode())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("companyCode", getCompanyCode())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

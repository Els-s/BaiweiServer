package com.space.lightapp.entity.vo;

import com.space.lightapp.base.BaseVO;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * TODO
 *
 * @Author Els
 * @date 2021-12-20 14:12
 * @Version 1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class SurveyAppListVo extends BaseVO {

    private String statusType;
    private Integer pageNo;
    private Integer pageSize;
}

package com.space.lightapp.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.space.lightapp.base.BaseEntity;
import com.space.lightapp.base.BaseVO;
import com.space.lightapp.entity.vo.LightAppModuleVO;
import com.space.lightapp.enums.AppMarketTypeEnum;
import com.space.lightapp.enums.LightAppModuleTypeCodeEnum;
import com.space.osms.common.core.utils.DozerBeanUtil;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 轻应用模块对象 light_app_module
 *
 * @author ChenYou
 * @date 2021-09-27
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("light_app_module")
public class LightAppModule extends BaseEntity {

    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long lightAppModuleId;
    /**
     * 轻应用Id
     */
    private Long lightAppId;
    /**
     * 应用类型代码
     */
    private String appMarketTypeCode;
    /**
     * 关联业务Id（工单和基础服务，此字段为null；问卷关联问卷Id，活动关联活动Id）
     */
    private Long relevancyId;
    /**
     * 轻应用模块代码
     */
    private String lightAppModuleCode;
    /**
     * 模块名称
     */
    private String lightAppModuleName;
    /**
     * 模块类型
     */
    private String lightAppModuleTypeCode;
    /**
     * 排序 排序字段
     */
    private Long orderNum;
    /**
     * 状态 0-false-禁用，1-true-启用；默认1-true
     */
    private Boolean status;

    /**
     * 是否删除  0-false-未删除，1-true-删除；默认0-false
     */
    private Boolean delFlag;

    /**
     * 高级设置
     */
    @TableField(exist = false)
    private PushAdvancedSet pushAdvancedSet;


    /**
     * 使用项目
     */
    @TableField(exist = false)
    private List<PushActiveSet> pushActiveSetList;

    /**
     * 测试人员
     */
    @TableField(exist = false)
    private List<PushTesterSet> pushTesterSetList;

    /**
     * 表单设置
     */
    @TableField(exist = false)
    private PushFormSet pushFormSet;

    /**
     * 流程设置
     */
    @TableField(exist = false)
    private PushProcessSet pushProcessSet;

    /**
     * Entity转Vo
     *
     * @return Vo对象
     * @date 2021-09-27
     */
    public LightAppModuleVO toVo() {
        LightAppModuleVO lightAppModuleVo = DozerBeanUtil.transitionType(this, LightAppModuleVO.class);
        return lightAppModuleVo;
    }

    /**
     * List-Entity转List-Vo
     *
     * @return List-Vo对象
     * @date 2021-09-27
     */
    public List<LightAppModuleVO> toListVo(List<LightAppModule> lightAppModule) {
        List<LightAppModuleVO> list = new ArrayList<>();
        lightAppModule.forEach(t -> list.add(t.toVo()));
        return list;
    }

    /**
     * 无参构造
     **/
    public LightAppModule() {
    }

    /**
     * module构造函数
     **/
    public LightAppModule(Long lightAppId, Long relevancyId, AppMarketTypeEnum appMarketTypeEnum,
            LightAppModuleTypeCodeEnum moduleTypeCodeEnum, BaseVO baseVO) {
        this.lightAppModuleName = moduleTypeCodeEnum.getInfo();
        this.lightAppModuleCode = moduleTypeCodeEnum.getCode();
        this.lightAppModuleTypeCode = moduleTypeCodeEnum.getCode();
        this.lightAppId = lightAppId;
        this.relevancyId = relevancyId;
        this.appMarketTypeCode = appMarketTypeEnum.getCode();
        this.setTenementCode(baseVO.getTenementCode());
        this.setProjectCode(baseVO.getProjectCode());
        this.setCompanyCode(baseVO.getCompanyCode());
    }

    /**
     * moduleType造函数
     **/
    public LightAppModule(LightAppModuleType moduleType) {
        this.lightAppModuleName = moduleType.getLightAppModuleTypeName();
        this.lightAppModuleCode = moduleType.getLightAppModuleTypeCode();
        this.lightAppModuleTypeCode = moduleType.getLightAppModuleTypeCode();
        this.setTenementCode(moduleType.getTenementCode());
        this.setProjectCode(moduleType.getProjectCode());
        this.setCompanyCode(moduleType.getCompanyCode());
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("lightAppModuleId", getLightAppModuleId())
                .append("lightAppId", getLightAppId())
                .append("lightAppModuleCode", getLightAppModuleCode())
                .append("lightAppModuleName", getLightAppModuleName())
                .append("lightAppModuleType", getLightAppModuleTypeCode())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

package com.space.lightapp.entity.vo;

import com.space.lightapp.base.BaseVO;
import com.space.lightapp.entity.PushTesterSet;
import com.space.osms.common.core.utils.DozerBeanUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 测试人员Vo对象 push_tester_set
 *
 * @author ChenYou
 * @date 2021-10-09
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "测试人员")
public class PushTesterSetVO extends BaseVO {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    private Long pushTesterSetId;
    /**
     * 应用模块Id
     */
    @ApiModelProperty(value = "应用模块Id")
    private Long lightAppModuleId;
    /**
     * 轻应用id
     */
    @ApiModelProperty(value = "轻应用id")
    private Long lightAppId;
    /**
     * 数据类型 user用户，role角色，company企业，group用户组
     */
    @ApiModelProperty(value = "数据类型 user用户，role角色，company企业，group用户组")
    private String userType;
    /**
     * 对应类型代码
     */
    @ApiModelProperty(value = "对应类型代码")
    private String userCode;
    /**
     * 对应类型代码
     */
    @ApiModelProperty(value = "对应类型名称")
    private String userName;
    /**
     * 排序 排序字段
     */
    @ApiModelProperty(value = "排序 排序字段")
    private Integer orderNum;
    /**
     * 状态 0禁用，1启用；默认1
     */
    @ApiModelProperty(value = "状态 0禁用，1启用；默认1")
    private Boolean status;

    /**
     * 逻辑删除 0有效，1被删除；默认0
     */
    @ApiModelProperty(value = "逻辑删除 0有效，1被删除；默认0")
    private Boolean delFlag;

    /**
     * Vo转Entity
     *
     * @return Entity对象
     * @date 2021-10-09
     */
    public PushTesterSet toEntity() {
        return DozerBeanUtil.transitionType(this, PushTesterSet.class);
    }

    /**
     * List-Vo转List-Entity
     *
     * @return List-Entity对象
     * @date 2021-10-09
     */
    public List<PushTesterSet> toListEntity(List<PushTesterSetVO> pushTesterSetVo) {
        List<PushTesterSet> list = new ArrayList<>();
        pushTesterSetVo.forEach(t -> list.add(t.toEntity()));
        return list;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("pushTesterSetId", getPushTesterSetId())
                .append("lightAppModuleId", getLightAppModuleId())
                .append("userType", getUserType())
                .append("userCode", getUserCode())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

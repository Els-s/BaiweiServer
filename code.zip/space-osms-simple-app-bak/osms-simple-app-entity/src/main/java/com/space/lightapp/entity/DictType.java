package com.space.lightapp.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.space.lightapp.base.BaseEntity;
import com.space.lightapp.entity.vo.DictTypeVO;
import com.space.osms.common.core.utils.DozerBeanUtil;
import com.space.osms.common.file.annotation.Excel;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 字典类型对象 dict_type
 *
 * @author ChenYou
 * @date 2021-09-27
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("dict_type")
public class DictType extends BaseEntity {

    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long dictTypeId;
    /**
     * 字典分类：默认public公共分类
     */
    private String dictClassCode;
    /**
     * 轻应用Id
     */
    private Long lightAppId;
    /**
     * 类型代码
     */
    private String dictTypeCode;
    /**
     * 类型名称
     */
    @Excel(name = "类型名称")
    private String dictTypeName;
    /**
     * 排序 排序字段
     */
    private Long orderNum;
    /**
     * 状态 0-false-禁用，1-true-启用；默认1-true
     */
    private Boolean status;

    /**
     * 是否删除  0-false-未删除，1-true-删除；默认0-false
     */
    private Boolean delFlag;
    /**
     * 数据字典关联的数据
     */
    @TableField(exist = false)
    List<DictData> dictDataList;

    /**
     * Entity转Vo
     *
     * @return Vo对象
     * @date 2021-09-27
     */
    public DictTypeVO toVo() {
        DictTypeVO dictTypeVo = DozerBeanUtil.transitionType(this, DictTypeVO.class);
        return dictTypeVo;
    }

    /**
     * List-Entity转List-Vo
     *
     * @return List-Vo对象
     * @date 2021-09-27
     */
    public List<DictTypeVO> toListVo(List<DictType> dictType) {
        List<DictTypeVO> list = new ArrayList<>();
        dictType.forEach(t -> list.add(t.toVo()));
        return list;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("dictTypeId", getDictTypeId())
                .append("lightAppTemplateId", getLightAppId())
                .append("dictTypeCode", getDictTypeCode())
                .append("dictTypeName", getDictTypeName())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

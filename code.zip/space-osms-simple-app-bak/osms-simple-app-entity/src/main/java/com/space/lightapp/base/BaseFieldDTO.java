package com.space.lightapp.base;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * 基础属性数据转换对象
 */
@Data
@Accessors(chain = true)
public class BaseFieldDTO implements Serializable {

    @JsonIgnore
    private Long pageIndex;
    @JsonIgnore
    private Long pageSize;

    /**
     * 租户编码
     */
    @ApiModelProperty(value = "租户编码", hidden = true)
    private String tenementCode;

    /**
     * 园区编码
     */
    @ApiModelProperty(value = "园区编码", hidden = true)
    private String projectCode;

    /**
     * 企业编码
     */
    @ApiModelProperty(value = "企业编码", hidden = true)
    private String companyCode;

    /**
     * 当前用户 手机号
     */
    @ApiModelProperty(value = "当前用户 手机号")
    private String mobile;

    /**
     * 当前用户 编码
     */
    @ApiModelProperty(value = "当前用户 编码")
    private String personCode;

}

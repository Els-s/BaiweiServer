package com.space.lightapp.enums;

import lombok.Getter;

/**
 * TODO
 *
 * @Author Els
 * @date 2021-12-07 18:05
 * @Version 1.0
 */
@Getter
public enum TaxStatusEnum {
    // 结算推送状态
    NOT_START(0, "未开始"),
    SUCCESS(1, "成功"),
    FAILED(2, "失败"),
    ;
    private Integer code;
    private String desc;

    TaxStatusEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }
}

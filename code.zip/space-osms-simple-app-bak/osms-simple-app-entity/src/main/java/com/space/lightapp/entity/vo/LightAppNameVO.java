package com.space.lightapp.entity.vo;

import com.space.lightapp.base.BaseVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * 轻应用 对象 light_app
 *
 * @author ChenYou
 * @date 2021-09-27
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(description = "校验轻应用名称唯一")
public class LightAppNameVO extends BaseVO {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    private Long lightAppId;

    /**
     * 轻应用名称
     */
    @ApiModelProperty(value = "轻应用名称")
    private String lightAppName;
}

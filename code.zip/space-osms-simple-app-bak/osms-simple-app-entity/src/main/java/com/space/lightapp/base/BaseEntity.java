package com.space.lightapp.base;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @author ChenYou
 * @since 2021/9/24 14:00
 */
@Data
@Accessors(chain = true)
public class BaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    private Date createTime;
    /**
     * 创建人
     */
    @TableField(fill = FieldFill.INSERT)
    private String createBy;

    /**
     * 更新时间
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date updateTime;

    /**
     * 更新人
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private String updateBy;

    /**
     * 租户编码
     */
    @TableField(fill = FieldFill.INSERT)
    private String tenementCode;
    /**
     * 园区编码
     */
    private String projectCode;
    /**
     * 企业编码
     */
    private String companyCode;

    /**
     * 搜索字段
     */
    @TableField(exist = false)
    private String searchInfo;
}

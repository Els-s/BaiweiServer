package com.space.lightapp.entity.vo.order;

import com.space.lightapp.base.BaseVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * 查询下单权限
 *
 * @Author ChenYou
 * @date 2021-12-16 13:39
 * @Version 1.0
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@ApiModel(description = "查询下单权限")
public class HasAuthPlaceOrderVO extends BaseVO {

    /**
     * 轻应用Id
     */
    @ApiModelProperty(value = "轻应用Id")
    private Long lightAppId;
}

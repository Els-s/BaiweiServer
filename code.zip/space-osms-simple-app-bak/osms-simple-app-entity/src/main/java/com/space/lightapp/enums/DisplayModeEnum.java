package com.space.lightapp.enums;

/**
 * 展示方式枚举
 *
 * @Author jiangHao
 * @date 2021-11-08 14:42
 * @Version 1.0
 */
public enum DisplayModeEnum {


    // 展示方式
    DISPLAY_MODE_ONE_PAGE("1", "一页显示"),
    DISPLAY_MODE_EACH_PAGE("2", "每题一页"),

    ;
    private String code;
    private String info;

    DisplayModeEnum(String code, String info) {
        this.code = code;
        this.info = info;
    }

    public String getCode() {
        return code;
    }

    public String getInfo() {
        return info;
    }
}

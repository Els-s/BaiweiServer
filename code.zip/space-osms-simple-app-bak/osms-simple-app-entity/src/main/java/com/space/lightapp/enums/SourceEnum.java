package com.space.lightapp.enums;

/**
 * @author JiangHao
 * @version 1.0
 * @date 2021/12/6 0006 15:27
 * @description
 */
public enum SourceEnum {
    //数据来源
    INSIDE_UNIT(1, "内部单"),
    CUSTOMER_ORDER(2, "客户下单"),
    REPLACE_CUSTOMER_ORDER(3, "代客下单"),
    ;

    private Integer code;
    private String info;

    SourceEnum(Integer code, String info) {
        this.code = code;
        this.info = info;
    }


    public Integer getCode() {
        return code;
    }

    public String getInfo() {
        return info;
    }

    public static String getInfoValue(Integer code) {
        SourceEnum[] values = SourceEnum.values();
        for (SourceEnum value : values) {
            if (value.getCode().equals(code)) {
                return value.getInfo();
            }
        }
        return "暂无";
    }
}

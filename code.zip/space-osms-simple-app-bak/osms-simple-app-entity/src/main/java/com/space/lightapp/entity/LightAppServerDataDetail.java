package com.space.lightapp.entity;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.space.lightapp.base.BaseEntity;
import com.space.lightapp.entity.vo.LightAppServerDataDetailVO;
import com.space.osms.common.core.utils.DozerBeanUtil;
import com.space.osms.common.core.utils.StringUtil;
import io.swagger.annotations.ApiModel;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 服务下单详情 对象 light_app_server_data_detail
 *
 * @author ChenYou
 * @date 2021-11-12
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("light_app_server_data_detail")
@ApiModel(description = "服务下单详情 ")
public class LightAppServerDataDetail extends BaseEntity {

    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long serverDataDetailId;
    /**
     * 轻应用Id
     */
    private Long lightAppId;
    /**
     * 轻应用类型
     */
    private String appMarketTypeCode;
    /**
     * 轻应用小分类
     */
    private String appLittleType;
    /**
     * 服务Id
     */
    private Long serverId;
    /**
     * 下单数据Id
     */
    private Long serverDataId;
    /**
     * 单据类型 支付，退款，周期结算
     */
    private String orderType;
    /**
     * 单据编码（对外） 对应类型不同的单据
     */
    private String orderCode;
    /**
     * 附件
     */
    @TableField(exist = false)
    private List<String> fileUrlList;

    private String fileUrl;
    /**
     * 详情
     */
    private String orderDetail;
    /**
     * 对应金额
     */
    private BigDecimal money;
    /**
     * 数据状态 0 失败，1成功，2进行中
     */
    private String dataType;
    /**
     * 流程key
     */
    private String processKey;
    /**
     * 流程定义Id
     */
    private String processInsId;
    /**
     * 表单Id
     */
    private String formId;
    /**
     * 排序 排序字段
     */
    private Integer orderNum;
    /**
     * 是否禁用 0禁用，1启用；默认1
     */
    private Boolean status;
    /**
     * 备注
     */
    private String remark;


    /**
     * Entity转Vo
     *
     * @return Vo对象
     * @date 2021-11-12
     */
    public LightAppServerDataDetailVO toVo() {
        LightAppServerDataDetailVO lightAppServerDataDetailVO = DozerBeanUtil
                .transitionType(this, LightAppServerDataDetailVO.class);
        lightAppServerDataDetailVO.setFileUrlList(StringUtil.stringToList(this.fileUrl));
        lightAppServerDataDetailVO.setDataVo(JSONObject.parseObject(this.orderDetail));
        return lightAppServerDataDetailVO;
    }

    /**
     * List-Entity转List-Vo
     *
     * @return List-Vo对象
     * @date 2021-11-12
     */
    public List<LightAppServerDataDetailVO> toListVo(
            List<LightAppServerDataDetail> lightAppServerDataDetail) {
        List<LightAppServerDataDetailVO> list = new ArrayList<>();
        lightAppServerDataDetail.forEach(t -> list.add(t.toVo()));
        return list;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("serverDataDetailId", getServerDataDetailId())
                .append("lightAppId", getLightAppId())
                .append("appMarketTypeCode", getAppMarketTypeCode())
                .append("appLittleType", getAppLittleType())
                .append("serverId", getServerId())
                .append("serverDataId", getServerDataId())
                .append("orderType", getOrderType())
                .append("orderCode", getOrderCode())
                .append("money", getMoney())
                .append("dataType", getDataType())
                .append("processKey", getProcessKey())
                .append("processInsId", getProcessInsId())
                .append("formId", getFormId())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("companyCode", getCompanyCode())
                .append("remark", getRemark())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .toString();
    }

}

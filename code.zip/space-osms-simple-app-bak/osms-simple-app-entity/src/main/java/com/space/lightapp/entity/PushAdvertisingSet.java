package com.space.lightapp.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.space.lightapp.base.BaseEntity;
import com.space.lightapp.entity.vo.PushAdvertisingSetVO;
import com.space.lightapp.entity.vo.message.ChannelRelBusinessVO;
import com.space.osms.common.core.utils.DozerBeanUtil;
import com.space.osms.common.core.utils.StringUtil;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 发布广告 对象 push_advertising_set
 *
 * @author ChenYou
 * @date 2021-10-29
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("push_advertising_set")
public class PushAdvertisingSet extends BaseEntity {

    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long advertisingSetId;
    /**
     * 轻应用Id
     */
    private Long lightAppId;
    /**
     * 应用服务类型代码
     */
    private String appMarketTypeCode;
    /**
     * 关联Id
     */
    private Long relevancyId;
    /**
     * 消息id
     */
    private Long messageId;
    /**
     * 是否推送到消息中心：0否 1是
     */
    private Integer pushMessage;
    /**
     * 发布渠道 上架渠道以及排序，statusType全民:ORANGE_MANILA，中介报备:REPORT，运营:OPERATOR_MANAGE；排序showOrder
     */
    private String advertisingChannel;

    @TableField(exist = false)
    private List<ChannelRelBusinessVO> channelRelBusinessEntities;
    /**
     * 广告名称
     */
    private String advertisingName;
    /**
     * 发布位置 发布位置：0 Banner图
     */
    private String newsType;
    /**
     * 广告跳转类型 0 项目详情、1 H5页面
     */
    private String jumpType;
    /**
     * 跳转链接 广告跳转地址，项目详情传ProjectCode
     */
    private String jumpUrl;
    /**
     * 发布范围
     */
    private String projectCodes;
    /**
     * 发布范围 集合
     */
    @TableField(exist = false)
    private List<String> projectCodeList;
    /**
     * 是否长期  0否 1是
     */
    private Integer longTerm;
    /**
     * 开始时间
     */
    private Date startTime;
    /**
     * 到期时间
     */
    private Date endTime;
    /**
     * 到期时间
     */
    @ApiModelProperty(value = "到期时间")
    private Date endDate;
    /**
     * 生效时间
     */
    private Date effectDate;
    /**
     * 广告图片
     */
    private String imgUrl;
    /**
     * 排序 排序字段
     */
    private Integer showOrder;
    /**
     * 是否禁用 0禁用，1启用；默认1
     */
    private Boolean status;
    /**
     * 备注
     */
    private String remark;
    /**
     * 逻辑删除 0有效，1被删除；默认0
     */
    private Boolean delFlag;

    /**
     * Entity转Vo
     *
     * @return Vo对象
     * @date 2021-10-29
     */
    public PushAdvertisingSetVO toVo() {
        PushAdvertisingSetVO pushAdvertisingSetVO = DozerBeanUtil
                .transitionType(this, PushAdvertisingSetVO.class);
        pushAdvertisingSetVO.setProjectCodeList(StringUtil.stringToList(this.getProjectCodes()));
        return pushAdvertisingSetVO;
    }

    /**
     * Entity转消息Vo
     *
     * @return Vo对象
     * @date 2021-10-29
     */
/*  public AdvertisingVO toMessageVo() {
    AdvertisingVO advertisingVO = DozerBeanUtil
        .transitionType(this, AdvertisingVO.class);
    advertisingVO.setProjectCodeList(DozerBeanUtil.stringToList(this.getProjectCodes()));
    return advertisingVO;
  }*/

    /**
     * List-Entity转List-Vo
     *
     * @return List-Vo对象
     * @date 2021-10-29
     */
    public List<PushAdvertisingSetVO> toListVo(List<PushAdvertisingSet> pushAdvertisingSet) {
        List<PushAdvertisingSetVO> list = new ArrayList<>();
        pushAdvertisingSet.forEach(t -> list.add(t.toVo()));
        return list;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("advertisingSetId", getAdvertisingSetId())
                .append("lightAppId", getLightAppId())
                .append("appMarketTypeCode", getAppMarketTypeCode())
                .append("relevancyId", getRelevancyId())
                .append("advertisingChannel", getAdvertisingChannel())
                .append("advertisingName", getAdvertisingName())
                .append("newsType", getNewsType())
                .append("jumpType", getJumpType())
                .append("jumpUrl", getJumpUrl())
                .append("projectCodes", getProjectCodes())
                .append("longTerm", getLongTerm())
                .append("startTime", getStartTime())
                .append("endTime", getEndTime())
                .append("effectDate", getEffectDate())
                .append("imgUrl", getImgUrl())
                // .append("showOrder", getShowOrder())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("companyCode", getCompanyCode())
                .append("remark", getRemark())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

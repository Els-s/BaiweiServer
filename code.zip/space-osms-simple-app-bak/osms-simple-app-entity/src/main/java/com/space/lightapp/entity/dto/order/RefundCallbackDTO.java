package com.space.lightapp.entity.dto.order;

import lombok.Data;

/**
 * 退款回调DTO
 *
 * @Author JiangHao
 * @date 2021-11-26 11:34
 * @Version 1.0
 */
@Data
public class RefundCallbackDTO {

    private String orderNo;
    private String refundNo;
    private String refundAmount;
    private String refundStatus;

}

package com.space.lightapp.entity.vo.delivery;

import com.space.lightapp.entity.LightAppServerData;
import com.space.lightapp.entity.LightAppServerDataDelivery;
import lombok.Builder;
import lombok.Data;

/**
 * TODO
 *
 * @Author Els
 * @date 2022-03-04 15:28
 * @Version 1.0
 */
@Data
@Builder
public class ServerDataByInstIdVO {

    private LightAppServerData serverData;
    private Boolean delivery;
    private LightAppServerDataDelivery serverDataDelivery;
}

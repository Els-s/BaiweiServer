package com.space.lightapp.entity.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * 增值服务状态统计数量Vo
 *
 * @Author JiangHao
 * @date 2021-12-22 17:03
 * @Version 1.0
 */
@Data
@Accessors(chain = true)
@ApiModel(value = "增值服务服务发布状态统计数量Vo")
public class PayServerOffLineNumRspVO {

    @ApiModelProperty(value = "全部")
    private Integer all;
    @ApiModelProperty(value = "受理中")
    private Integer accepting;
    @ApiModelProperty(value = "已受理")
    private Integer accepted;
    @ApiModelProperty(value = "已关闭")
    private Integer closed;

}

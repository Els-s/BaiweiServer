package com.space.lightapp.entity.vo.record;

import com.space.lightapp.base.BaseVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 服务列表VO
 *
 * @Author ChenYou
 * @date 2021-11-29 17:39
 * @Version 1.0
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "服务列表VO")
public class ServerListVO extends BaseVO {

    /**
     * 应用分类，可以传多个，英文逗号隔开:payServer,workOrder,baseServer,survey,activity
     */
    @ApiModelProperty(required = true, value = "应用分类，可以传多个，英文逗号隔开:payServer,workOrder,baseServer,survey,activity")
    private String appMarketTypeCodes;
    /**
     * 起始时间
     */
    @ApiModelProperty(value = "起始时间")
    private String startTime;
    /**
     * 结束时间
     */
    @ApiModelProperty(value = "结束时间")
    private String endTime;

    @ApiModelProperty(value = "查询应用类型：noNeedBpm = 表单服务")
    private String appLittleType;
}

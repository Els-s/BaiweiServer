package com.space.lightapp.entity.vo;

import com.space.lightapp.base.BaseVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 移动顺序VO
 *
 * @Author ChenYou
 * @date 2021-11-10 10:34
 * @Version 1.0
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "轻应用")
public class MoveOrderVO extends BaseVO {

    /**
     * 需要移动的目标主键
     */
    @ApiModelProperty(value = "移动目标主键：需要移动的目标主键")
    private Long targetPrimaryId;
    /**
     * 需要移动的目标：移动后的排序值
     */
    @ApiModelProperty(value = "移动目标主键：需要移动的目标主键")
    private Integer targetOrderNum;
    /**
     * 被动移动目标主键：移动到某位置的主键
     */
    @ApiModelProperty(value = "被动移动目标主键：移动到某位置的主键")
    private Long movePrimaryId;
    /**
     * 被动移动目标主键：移动到某位置的主键
     */
    @ApiModelProperty(value = "被动移动目标：移动到某位置的主键")
    private Integer moveOrderNum;
}

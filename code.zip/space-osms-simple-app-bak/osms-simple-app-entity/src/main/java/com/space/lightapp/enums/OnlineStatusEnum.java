package com.space.lightapp.enums;

/**
 * 问卷枚举
 *
 * @Author kangmj
 * @date 2021-10-16 11:35
 * @Version 1.0
 */
public enum OnlineStatusEnum {
    // 在线状态 onlineStatus,
    NOT_START_STATUS("start", "未上线"),
    ONLINE_STATUS("online", "上线中"),
    OFFLINE_STATUS("offline", "下线中"),
    END_STATUS("end", "结束"),
    ;
    private String code;
    private String info;

    OnlineStatusEnum(String code, String info) {
        this.code = code;
        this.info = info;
    }

    public String getCode() {
        return code;
    }

    public String getInfo() {
        return info;
    }

    public static String getInfoValue(String code) {
        OnlineStatusEnum[] values = OnlineStatusEnum.values();
        for (OnlineStatusEnum value : values) {
            if (value.getCode().equals(code)) {
                return value.getInfo();
            }
        }
        return "暂无";
    }
}

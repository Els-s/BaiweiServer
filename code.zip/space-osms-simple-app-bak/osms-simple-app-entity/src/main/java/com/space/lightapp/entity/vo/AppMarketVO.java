package com.space.lightapp.entity.vo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.space.lightapp.base.BaseVO;
import com.space.lightapp.entity.AppMarket;
import com.space.osms.common.core.utils.DozerBeanUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 应用服务 Vo对象 app_market
 *
 * @author ChenYou
 * @date 2021-09-27
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "应用服务")
public class AppMarketVO extends BaseVO {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键", example = "1")
    private Long appMarketId;
    /**
     * 服务代码
     */
    @ApiModelProperty(value = "服务代码")
    private String appMarketCode;
    /**
     * 服务名称
     */
    @ApiModelProperty(value = "服务名称")
    private String appMarketName;
    /**
     * 服务类型代码
     */
    @ApiModelProperty(value = "服务类型代码")
    private String appMarketTypeCode;
    /**
     * 排序
     */
    @ApiModelProperty(value = "排序", example = "1")
    private Long orderNum;
    /**
     * 状态 0-false-禁用，1-true-启用；默认1-true
     */
    @ApiModelProperty(value = "状态 0-false-禁用，1-true-启用；默认1-true")
    private Boolean status;
    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String remark;
    /**
     * 是否删除  0-false-未删除，1-true-删除；默认0-false
     */
    @ApiModelProperty(value = "是否删除  0-false-未删除，1-true-删除；默认0-false")
    private Boolean delFlag;

    /**
     * 轻应用
     */
    @TableField(exist = false)
    private List<LightAppVO> lightAppVoList;

    /**
     * 应用管理人员
     */
    @ApiModelProperty(value = "应用管理人员")
    @TableField(exist = false)
    private List<LightAppAuthVO> lightAppAuthVOList;

    /**
     * 轻应用id
     */
    @TableField(exist = false)
    private Long lightAppId;

    /**
     * 状态 0-false-禁用，1-true-启用；默认1-true
     */
    @ApiModelProperty(value = "状态 0-false-下架，1-true-上架；默认1-true")
    private Boolean lightStatus;


    /**
     * 服务代码
     */
    @ApiModelProperty(value = "存在可复制按钮 false-不存在，true-存在")
    @TableField(exist = false)
    private Boolean copyStatus;


    /**
     * Vo转Entity
     *
     * @return Entity对象
     * @date 2021-09-27
     */
    public AppMarket toEntity() {
        AppMarket appMarket = DozerBeanUtil.transitionType(this, AppMarket.class);
        return appMarket;
    }

    /**
     * List-Vo转List-Entity
     *
     * @return List-Entity对象
     * @date 2021-09-27
     */
    public List<AppMarket> toListEntity(List<AppMarketVO> appMarketVo) {
        List<AppMarket> list = new ArrayList<>();
        appMarketVo.forEach(t -> list.add(t.toEntity()));
        return list;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("appMarketId", getAppMarketId())
                .append("appMarketCode", getAppMarketCode())
                .append("appMarketName", getAppMarketName())
                .append("appMarketTypeCode", getAppMarketTypeCode())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

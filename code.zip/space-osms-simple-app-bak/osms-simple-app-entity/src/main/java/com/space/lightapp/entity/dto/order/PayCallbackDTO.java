package com.space.lightapp.entity.dto.order;

import lombok.Data;

/**
 * 支付回调DTO
 *
 * @Author Els
 * @date 2021-11-16 11:34
 * @Version 1.0
 */
@Data
public class PayCallbackDTO {

    private String orderNo;
    /**
     * 支付金额
     */
    private String payAmount;
    private String payedTime;
    private String payCode;
    /**
     * 渠道交易流水号
     */
    private String transactionId;
}

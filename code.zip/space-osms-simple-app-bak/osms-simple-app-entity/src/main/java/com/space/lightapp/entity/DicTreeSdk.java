package com.space.lightapp.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @author JiangHao
 * @version 1.0
 * @date 2021/12/3 0003 14:51
 * @description
 */
@Data
@Accessors(chain = true)
@TableName("字典详情")
public class DicTreeSdk {

    private String treeId;
    private String name;
    private String alias;
    private String dataShowType;

}

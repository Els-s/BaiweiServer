package com.space.lightapp.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.space.lightapp.base.BaseEntity;
import com.space.lightapp.entity.vo.DictDataVO;
import com.space.osms.common.core.utils.DozerBeanUtil;
import com.space.osms.common.file.annotation.Excel;
import com.space.osms.common.file.annotation.Excel.Type;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 字典数据对象 dict_data
 *
 * @author ChenYou
 * @date 2021-09-27
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("dict_data")
public class DictData extends BaseEntity {

    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long dictDataId;
    /**
     * 字典类型
     */
    private Long dictTypeId;
    /**
     * 字典内容代码
     */
    @Excel(name = "字典内容代码")
    private String dictDataCode;
    /**
     * 字典名称
     */
    @Excel(name = "字典名称")
    private String dictDataName;
    /**
     * 父级Id
     */
    private Long parentId;
    /**
     * 父级名称
     */
    @Excel(name = "上级名称", type = Type.IMPORT)
    @TableField(exist = false)
    private String parentName;
    /**
     * 排序 排序字段
     */
    @Excel(name = "排序")
    private Long orderNum;
    /**
     * 状态 0-false-禁用，1-true-启用；默认1-true
     */
    @Excel(name = "状态", readConverterExp = "true=启用,false=禁用")
    private Boolean status;

    /**
     * 是否删除  0-false-未删除，1-true-删除；默认0-false
     */
    private Boolean delFlag;
    /**
     * 所属类型对象
     */
    @Excel(name = "所属数据项", targetAttr = "dictTypeName", type = Type.EXPORT)
    @TableField(exist = false)
    private DictType dictType;
    /**
     * 所属类型名称
     */
    @Excel(name = "所属数据项", type = Type.IMPORT)
    @TableField(exist = false)
    private String dictTypeName;

    /**
     * Entity转Vo
     *
     * @return Vo对象
     * @date 2021-09-27
     */
    public DictDataVO toVo() {
        DictDataVO dictDataVo = DozerBeanUtil.transitionType(this, DictDataVO.class);
        return dictDataVo;
    }

    /**
     * List-Entity转List-Vo
     *
     * @return List-Vo对象
     * @date 2021-09-27
     */
    public List<DictDataVO> toListVo(List<DictData> dictData) {
        List<DictDataVO> list = new ArrayList<>();
        dictData.forEach(t -> list.add(t.toVo()));
        return list;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("dictDataId", getDictDataId())
                .append("dictTypeId", getDictTypeId())
                .append("dictDataName", getDictDataName())
                .append("parentId", getParentId())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("delFlag", getDelFlag())
                .toString();
    }
}

package com.space.lightapp.enums;

import cn.space.base.enums.exception.AbstractBaseExceptionEnum;

/**
 * 公共异常定义
 *
 * @author ChenYou
 */
public enum ResultEnum implements AbstractBaseExceptionEnum {
    // 异常枚举
    USER_ERROR(1000, "用户信息错误"),
    LIGHT_APP_ID_ERROR(1001, "应用id不能为空."),
    PROJECT_CODE_ERROR(1002, "园区编码不能为空。"),
    TENEMENT_CODE_ERROR(1003, "租户编码不能为空。"),
    LIGHT_APP_NAME_ERROR(1004, "应用名称不能为空。"),
    LIGHT_APP_MODULE_ID_ERROR(1005, "模块id不能为空。"),
    LIGHT_APP_EMPTY(1006, "该轻应用不存在。"),
    LIGHT_APP_TYPE_EMPTY(1007, "轻应用状态不能为空。"),
    LIGHT_APP_MODULE_EMPTY(1008, "模块数据为空。"),
    APP_MARKET_TYPE_CODE_EMPTY(1009, "应用类型代码为空。"),
    ACTIVITY_ID_EMPTY(1010, "活动id为空。"),
    ACTIVITY_NOT_EXIST(1011, "活动不存在。"),
    ADVANCED_SET_EMPTY(1012, "高级设置为空。"),
    LIGHT_APP_TYPE_NOT_TEST(1013, "轻应用状态不是测试，请确认。"),
    TESTER_EMPTY(1014, "添加的测试人员为空。"),
    APPLY_DATA_EMPTY(1015, "报名列表为空。"),
    ADVANCED_SET_EXIST(1016, "高级设置已存在。"),
    TESTDATA_NOT_EXIST(1017, "无测试数据。"),
    DICT_TYPE_ID_EMPTY(1018, "字典项id不能为空."),
    DICT_TYPE_NAME_EMPTY(1019, "字典项名称不能为空."),
    FROM_ID_NULL(90010, "表单Id不能为空。"),
    PROCESS_ID_NULL(90011, "流程Id不能为空。"),
    PUSH_ACTIVE_SET_ID_NULL(90012, "启用设置Id不能为空。"),
    FROM_PARAM_LESS(90013, "表单回调缺少关键参数"),
    FROM_DATA_KEY_NULL(90014, "表单数据为空"),
    FROM_DATA_ERROR(90015, "查询表单数据异常。"),
    ERROR_SURVEY_ID_NULL(3105, "问卷ID为空。"),
    ERROR_SURVEY_NULL(3102, "问卷不存在。"),
    ERROR_SURVEY_ONLINE(3103, "问卷不可上线或者状态异常，请确认。"),
    ERROR_SURVEY_OFFLINE(3104, "问卷不可下线或者状态异常，请确认。"),

    ERROR_ACTIVITY_NUM_EXIST(4101, "活动编号已存在。"),
    ERROR_ACTIVITY_NULL(4102, "活动不存在。"),
    ERROR_ACTIVITY_ONLINE(4103, "活动不可上线或者状态异常，请确认。"),
    ERROR_ACTIVITY_OFFLINE(4104, "活动不可下线或者状态异常，请确认。"),
    ERROR_ACTIVITY_ONLINE_OR_FINISH(4105, "活动上线状态和活动结束后不可编辑，请确认。"),
    ERROR_ACTIVITY_NOT_EXIST(4106, "活动编号不存在。"),
    ERROR_SIGN_NOT_START(4107, "签到还未开始。"),
    ERROR_SIGN_END(4107, "签到已结束。"),

    CREAT_ORDER_ERROR(5101, "新建订单异常！"),
    PAY_START_ERROR(5102, "调用支付异常！"),
    REFUND_ADD_ERROR(5103, "退款新增异常！"),
    QUERY_ORDER_INFO_ERROR(5104, "查询订单详情失败！"),
    NO_ORDER_NUM(5105, "新建订单未返回订单编号！"),
    PAY_TIME_OUT(5106, "订单支付已超时。"),
    ORDER_NO_OPENID(5107, "缺少openId"),
    ;

    /**
     * 状态码
     */
    private Integer code;
    /**
     * 状态信息
     */
    private String msg;

    ResultEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    @Override
    public Integer getCode() {
        return code;
    }

    @Override
    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}

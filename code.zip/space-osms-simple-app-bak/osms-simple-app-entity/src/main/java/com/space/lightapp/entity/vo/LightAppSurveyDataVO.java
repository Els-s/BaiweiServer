package com.space.lightapp.entity.vo;

import com.space.lightapp.base.BaseVO;
import com.space.lightapp.entity.LightAppSurveyData;
import com.space.lightapp.entity.PushFormSet;
import com.space.lightapp.entity.PushProcessSet;
import com.space.osms.common.core.utils.DozerBeanUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 填答问卷数据 Vo对象 light_app_survey_data
 *
 * @author ChenYou
 * @date 2021-10-20
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "填答问卷数据 ")
public class LightAppSurveyDataVO extends BaseVO {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    private Long surveyDataId;
    /**
     * 轻应用Id
     */
    @ApiModelProperty(value = "轻应用Id")
    private Long lightAppId;
    /**
     * 轻应用模块Id
     */
    @ApiModelProperty(value = "轻应用模块Id")
    private Long lightModuleId;
    /**
     * 轻应用类型
     */
    @ApiModelProperty(value = "轻应用类型")
    private String appMarketTypeCode;
    /**
     * 问卷Id
     */
    @ApiModelProperty(value = "问卷Id")
    private Long surveyId;
    /**
     * 答卷人
     */
    @ApiModelProperty(value = "答卷人")
    private String answerName;
    /**
     * 答卷人企业
     */
    @ApiModelProperty(value = "答卷人企业")
    private String answerCompany;
    /**
     * 答卷机器
     */
    @ApiModelProperty(value = "答卷机器")
    private String answerMachine;
    /**
     * 开始填答时间
     */
    @ApiModelProperty(value = "开始填答时间")
    private Date startTime;
    /**
     * 结束时间
     */
    @ApiModelProperty(value = "结束时间")
    private Date endTime;
    /**
     * 单据编码
     */
    @ApiModelProperty(value = "单据编码")
    private String orderCode;
    /**
     * 表单设置Id
     */
    @ApiModelProperty(value = "表单设置Id")
    private String formSetId;
    /**
     * 表单Id
     */
    @ApiModelProperty(value = "表单Id")
    private String formId;
    /**
     * 工单内容
     */
    @ApiModelProperty(value = "工单内容")
    private String content;
    /**
     * 流程Id
     */
    @ApiModelProperty(value = "流程Id")
    private String processId;
    /**
     * 花费时长
     */
    @ApiModelProperty(value = "花费时长")
    private String takeTime;
    /**
     * 当前节点处理人
     */
    @ApiModelProperty(value = "当前节点处理人")
    private String processNodeUser;
    /**
     * 对应数据Id 关联实际填答数据
     */
    @ApiModelProperty(value = "对应数据Id 关联实际填答数据")
    private String dataId;
    /**
     * 应用编码
     */
    @ApiModelProperty(value = "应用编码")
    private String appCode;
    /**
     * 业务状态
     */
    @ApiModelProperty(value = "业务状态")
    private String businessState;
    /**
     * 工单状态 工单状态（1待受理，2处理中，3已完成，4已关闭，5待回访，6已取消）
     */
    @ApiModelProperty(value = "工单状态 工单状态（1待受理，2处理中，3已完成，4已关闭，5待回访，6已取消）")
    private Integer processState;
    /**
     * 流程启动结果 流程启动结果，1-启动成功，-1-启动失败，0-未启动流程
     */
    @ApiModelProperty(value = "流程启动结果 流程启动结果，1-启动成功，-1-启动失败，0-未启动流程")
    private Integer processStartStatus;
    /**
     * 任务Id
     */
    @ApiModelProperty(value = "任务Id")
    private String taskId;
    /**
     * 空间地址信息
     */
    @ApiModelProperty(value = "空间地址信息")
    private String spaceInfo;
    /**
     * 空间地址信息编码
     */
    @ApiModelProperty(value = "空间地址信息编码")
    private String spaceCode;
    /**
     * 排序 排序字段
     */
    @ApiModelProperty(value = "排序 排序字段")
    private Integer orderNum;
    /**
     * 是否禁用 0禁用，1启用；默认1
     */
    @ApiModelProperty(value = "是否禁用 0禁用，1启用；默认1")
    private Boolean status;
    /**
     * 备注信息
     */
    @ApiModelProperty(value = "备注信息")
    private String remark;
    /**
     * 逻辑删除 0有效，1被删除；默认0
     */
    @ApiModelProperty(value = "逻辑删除 0有效，1被删除；默认0")
    private Boolean delFlag;
    /**
     * 表单配置
     */
    @ApiModelProperty(value = "表单配置")
    private PushFormSet pushFormSet;

    /**
     * 流程配置
     */
    @ApiModelProperty(value = "流程配置")
    private PushProcessSet processSet;

    /**
     * Vo转Entity
     *
     * @return Entity对象
     * @date 2021-10-20
     */
    public LightAppSurveyData toEntity() {
        return DozerBeanUtil.transitionType(this, LightAppSurveyData.class);
    }

    /**
     * List-Vo转List-Entity
     *
     * @return List-Entity对象
     * @date 2021-10-20
     */
    public List<LightAppSurveyData> toListEntity(List<LightAppSurveyDataVO> lightAppSurveyDataVo) {
        List<LightAppSurveyData> list = new ArrayList<>();
        lightAppSurveyDataVo.forEach(t -> list.add(t.toEntity()));
        return list;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("surveyDataId", getSurveyDataId())
                .append("lightAppId", getLightAppId())
                .append("lightModuleId", getLightModuleId())
                .append("appMarketTypeCode", getAppMarketTypeCode())
                .append("surveyId", getSurveyId())
                .append("answerName", getAnswerName())
                .append("answerCompany", getAnswerCompany())
                .append("answerMachine", getAnswerMachine())
                .append("startTime", getStartTime())
                .append("endTime", getEndTime())
                .append("orderCode", getOrderCode())
                .append("formSetId", getFormSetId())
                .append("formId", getFormId())
                .append("content", getContent())
                .append("processId", getProcessId())
                .append("processNodeUser", getProcessNodeUser())
                .append("dataId", getDataId())
                .append("appCode", getAppCode())
                .append("businessState", getBusinessState())
                .append("processState", getProcessState())
                .append("processStartStatus", getProcessStartStatus())
                .append("taskId", getTaskId())
                .append("spaceInfo", getSpaceInfo())
                .append("spaceCode", getSpaceCode())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("companyCode", getCompanyCode())
                .append("remark", getRemark())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

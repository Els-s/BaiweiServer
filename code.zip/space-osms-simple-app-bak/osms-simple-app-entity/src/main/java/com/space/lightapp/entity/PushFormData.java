package com.space.lightapp.entity;

import cn.hutool.core.date.DateTime;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.space.lightapp.base.FormBaseEntity;
import com.space.lightapp.entity.vo.PushFormDataVO;
import com.space.lightapp.entity.vo.excel.PushFormDataExcelVO;
import com.space.lightapp.enums.ProcessStateEnum;
import com.space.osms.common.core.utils.DozerBeanUtil;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 单数据 对象 push_form_data
 *
 * @author ChenYou
 * @date 2021-10-20
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("push_form_data")
public class PushFormData extends FormBaseEntity {

    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long formDataId;
    /**
     * 工单标签 测
     */
    private String dataTag;
    /**
     * 排序 排序字段
     */
    private Integer orderNum;
    /**
     * 状态 0禁用，1启用；默认1
     */
    private Boolean status;
    /**
     * 逻辑删除 0有效，1被删除；默认0
     */
    private Boolean delFlag;
    /**
     * 提单人
     */
    private String billUser;
    /**
     * 提单人详情（name,id等等信息）
     */
    private String billUserDetail;
    /**
     * 表单配置
     */
    @TableField(exist = false)
    private PushFormSet pushFormSet;

    /**
     * 流程配置
     */
    @TableField(exist = false)
    private PushProcessSet processSet;

    /**
     * 服务名称
     */
    @TableField(exist = false)
    private String serverName;

    /**
     * Entity转Vo
     *
     * @return Vo对象
     * @date 2021-10-20
     */
    public PushFormDataVO toVo() {
        PushFormDataVO pushFormDataVO = DozerBeanUtil.transitionType(this, PushFormDataVO.class);
        pushFormDataVO.setAssigneeIdNameMap(JSONArray.parseArray(getProcessNodeUserDetail()));
        pushFormDataVO.setCreateByIdNameMap(JSONObject.parseObject(getBillUserDetail()));
        pushFormDataVO.setProcessStateName(ProcessStateEnum.getInfoValue(this.getProcessState()));
        pushFormDataVO.setBusinessStateVo(pushFormDataVO.getProcessStateName());
        return pushFormDataVO;
    }

    /**
     * Entity转 ExcelVo
     *
     * @return ExcelVo对象
     * @date 2021-10-20
     */
    public PushFormDataExcelVO toExcelVo() {
        PushFormDataExcelVO pushFormDataExcelVO = DozerBeanUtil.transitionType(this,
                PushFormDataExcelVO.class);
        pushFormDataExcelVO.setCreateTimeStr(new DateTime(this.getCreateTime()).toString());
        return pushFormDataExcelVO;
    }

    /**
     * List-Entity转List-Vo
     *
     * @return List-Vo对象
     * @date 2021-10-20
     */
    public List<PushFormDataVO> toListVo(List<PushFormData> pushFormData) {
        List<PushFormDataVO> list = new ArrayList<>();
        pushFormData.forEach(t -> list.add(t.toVo()));
        return list;
    }

    /**
     * List-Entity转List-Vo
     *
     * @return List-Vo对象
     * @date 2021-10-20
     */
    public List<PushFormDataExcelVO> toExcelListVo(List<PushFormData> pushFormData) {
        List<PushFormDataExcelVO> list = new ArrayList<>();
        pushFormData.forEach(t -> list.add(t.toExcelVo()));
        return list;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("formDataId", getFormDataId())
                .append("lightAppId", getLightAppId())
                .append("lightAppModuleId", getLightAppModuleId())
                .append("appMarketTypeCode", getAppMarketTypeCode())
                .append("dataTag", getDataTag())
                .append("orderCode", getOrderCode())
                .append("formSetId", getFormSetId())
                .append("formId", getFormId())
                .append("content", getContent())
                .append("processId", getProcessId())
                .append("processNodeUser", getProcessNodeUser())
                .append("dataId", getDataId())
                .append("appCode", getAppCode())
                .append("businessState", getBusinessState())
                .append("processState", getProcessState())
                .append("processStartStatus", getProcessStartStatus())
                .append("taskId", getTaskId())
                .append("spaceInfo", getSpaceInfo())
                .append("spaceCode", getSpaceCode())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("companyCode", getCompanyCode())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

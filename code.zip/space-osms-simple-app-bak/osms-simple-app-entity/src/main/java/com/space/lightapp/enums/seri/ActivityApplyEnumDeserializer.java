package com.space.lightapp.enums.seri;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.space.lightapp.enums.ActivityEnum;

import java.io.IOException;

public class ActivityApplyEnumDeserializer extends StdDeserializer<ActivityEnum.ActivityApply> {

    public ActivityApplyEnumDeserializer() {
        super(ActivityEnum.ActivityStatus.class);
    }

    @Override
    public ActivityEnum.ActivityApply deserialize(JsonParser jp, DeserializationContext dc)
            throws IOException, JsonProcessingException {
        final JsonNode jsonNode = jp.readValueAsTree();
        String code = jsonNode.get("code").asText();
        String name = jsonNode.get("name").asText();

        for (ActivityEnum.ActivityApply e : ActivityEnum.ActivityApply.values()) {
            if (e.getCode().equals(code) && e.getName().equals(name)) {
                return e;
            }
        }
        throw dc.mappingException("Cannot deserialize MyEnum from key " + code + " and value " + name);
    }
}

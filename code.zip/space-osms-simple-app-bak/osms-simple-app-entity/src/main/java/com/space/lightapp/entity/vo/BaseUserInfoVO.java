package com.space.lightapp.entity.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 用户信息类
 *
 * @Author Els
 * @date 2021-12-06 21:44
 * @Version 1.0
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BaseUserInfoVO {

    @ApiModelProperty(value = "用户ID")
    private String userId;
    @ApiModelProperty(value = "用户名称")
    private String userName;
    @ApiModelProperty(value = "用户手机号")
    private String userPhone;
    @ApiModelProperty(value = "用户公司编码")
    private String userCustomerCode;
    @ApiModelProperty(value = "用户公司名称")
    private String userCustomerName;
    @ApiModelProperty(value = "用户公司地址")
    private String userCustomerAddress;
}

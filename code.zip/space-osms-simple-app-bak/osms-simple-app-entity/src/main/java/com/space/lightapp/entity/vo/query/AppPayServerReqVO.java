package com.space.lightapp.entity.vo.query;

import com.space.lightapp.base.BaseVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * 活动列表查询参数
 *
 * @Author jianghao
 * @date 2021-10-29
 * @Version 1.0
 */

@EqualsAndHashCode(callSuper = true)
@Data
@Accessors(chain = true)
@ApiModel(description = "增值服务列表查询参数")
public class AppPayServerReqVO extends BaseVO {

    /**
     * 轻应用Id 关联轻应用Id
     */
    @ApiModelProperty(value = "必填：轻应用Id 关联轻应用Id")
    private Long lightAppId;
    /**
     * 轻应用小分类
     */
    @ApiModelProperty(value = "轻应用小分类", required = true)
    private String appLittleType;
    /**
     * 搜索开始时间
     */
    @ApiModelProperty(value = "搜索开始时间")
    private String startTime;
    /**
     * 搜索结束时间
     */
    @ApiModelProperty(value = "搜索结束时间")
    private String endTime;
    /**
     * 增值服务状态
     */
    //支付中  待支付、支付中、支付失败、企业支付申请中
    //待派送  受理中
    //退款中  退款审批完成、退款中、退款审核中、待退款、退款审批不通过、
    //已取消  下单审批不通过、支付超时、已关闭、已退款
    //已完成  订单完成
    @ApiModelProperty(value = "增值服务状态：1支付中，2待派送，3退款中，4已取消，5已完成")
    private Integer businessStateType;
    /**
     * 时间状态（1:本日，2:近3日，3:近7天，4:近30日，5:近3月，6:今年）
     */
    @ApiModelProperty(value = "时间状态（1:本日，2:近3日，3:近7天，4:近30日，5:近3月，6:今年）")
    private Integer dataType;
}

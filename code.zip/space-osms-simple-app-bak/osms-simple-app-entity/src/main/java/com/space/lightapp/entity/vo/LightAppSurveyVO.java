package com.space.lightapp.entity.vo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.space.lightapp.base.BaseVO;
import com.space.lightapp.entity.LightAppSurvey;
import com.space.osms.common.core.utils.DozerBeanUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 问卷Vo对象 light_app_survey
 *
 * @author ChenYou
 * @date 2021-10-14
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = "问卷")
public class LightAppSurveyVO extends BaseVO {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    private Long surveyId;
    /**
     * 轻应用Id 关联轻应用Id
     */
    @ApiModelProperty(value = "轻应用Id 关联轻应用Id")
    private Long lightAppId;
    /**
     * 应用服务类型代码
     */
    @ApiModelProperty(value = "应用服务类型代码")
    private String appMarketTypeCode;
    /**
     * 任务中心唯一标识码
     */
    @ApiModelProperty(value = "任务中心唯一标识码")
    private String taskTypeCode;
    /**
     * 关联表单Id 关联表单Id
     */
    @ApiModelProperty(value = "关联表单Id 关联表单Id")
    private String formId;
    /**
     * 关联流程Id
     */
    @ApiModelProperty(value = "关联表单Id 关联表单Id")
    private String processId;
    /**
     * 问卷编号
     */
    @ApiModelProperty(value = "问卷编号")
    private String surveyCode;
    /**
     * 问卷名称
     */
    @ApiModelProperty(value = "问卷名称")
    private String surveyName;
    /**
     * 问卷目的
     */
    @ApiModelProperty(value = "问卷目的")
    private String surveyAim;
    /**
     * 开始时间
     */
    @ApiModelProperty(value = "开始时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date startTime;
    /**
     * 结束时间
     */
    @ApiModelProperty(value = "结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date endTime;
    /**
     * 参与条件 tourist游客   commonUser普通用户   companyEmployee企业员工   companyManager企业管理员,多种类型英文逗号隔开
     */
    @ApiModelProperty(value = "参与条件 tourist游客   commonUser普通用户   companyEmployee企业员工   companyManager企业管理员,多种类型英文逗号隔开")
    private String serverLaunchUser;
    /**
     * 前言
     */
    @ApiModelProperty(value = "前言")
    private String foreword;
    /**
     * 结束语
     */
    @ApiModelProperty(value = "结束语")
    private String tag;
    /**
     * 展示方式 1一页显示，2每题一页
     */
    @ApiModelProperty(value = "展示方式 1一页显示，2每题一页")
    private String displayMode;
    /**
     * 填写问卷的总时长
     */
    @ApiModelProperty(value = "填写问卷的总时长")
    private BigDecimal surveyTime;
    /**
     * 是否显示题号 0不显示，1显示
     */
    @ApiModelProperty(value = "是否显示问题数及问题类型 false不显示，true显示")
    private Boolean showNumber;
    /**
     * 是否显示题型 0不显示，1显示
     */
    @ApiModelProperty(value = "是否显示题型 false不显示，true显示")
    private Boolean showItemType;
    /**
     * 排序 排序字段
     */
    @ApiModelProperty(value = "排序 排序字段")
    private Integer orderNum;
    /**
     * 是否禁用 0禁用，1启用；默认1
     */
    @ApiModelProperty(value = "是否禁用 0禁用，1启用；默认1")
    private Boolean status;
    /**
     * 问卷状态
     */
    @ApiModelProperty(value = "问卷状态：draft草稿，notStart未开始，underWay进行中，suspend暂停中，finish已结束")
    private String surveyType;
    /**
     * 在线状态：online 上线中，offline 下线中， null 无在线状态
     */
    @ApiModelProperty(value = "在线状态：online 上线中，offline 下线中， null 无在线状态")
    private String onlineStatus;
    /**
     * 备注信息
     */
    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty(value = "答卷数量")
    private Integer answerNum;

    private Boolean existTaskCentreCode;

    /**
     * 暂存类型
     */
    @ApiModelProperty(value = "暂存类型 true:暂存;false:发布")
    @TableField(exist = false)
    private Boolean stagType;

    /**
     * 发布功能设置Vo
     */
    @ApiModelProperty(value = "发布功能设置Vo")
    private PushFunctionSetVO functionSet;
    /**
     * 发布广告Vo
     */
    @ApiModelProperty(value = "发布广告Vo")
    private PushAdvertisingSetVO pushAdvertisingSet;
    /**
     * 发布资讯Vo
     */
    @ApiModelProperty(value = "发布资讯Vo")
    private PushInformationSetVO pushInformationSet;

    /**
     * Vo转Entity
     *
     * @return Entity对象
     * @date 2021-10-14
     */
    public LightAppSurvey toEntity() {
        return DozerBeanUtil.transitionType(this, LightAppSurvey.class);
    }

    /**
     * List-Vo转List-Entity
     *
     * @return List-Entity对象
     * @date 2021-10-14
     */
    public List<LightAppSurvey> toListEntity(List<LightAppSurveyVO> lightAppSurveyVo) {
        List<LightAppSurvey> list = new ArrayList<>();
        lightAppSurveyVo.forEach(t -> list.add(t.toEntity()));
        return list;
    }

    @Override
    public String toString() {
        return "LightAppSurveyVO{" +
                "surveyId=" + surveyId +
                ", lightAppId=" + lightAppId +
                ", appMarketTypeCode='" + appMarketTypeCode + '\'' +
                ", formId='" + formId + '\'' +
                ", surveyCode='" + surveyCode + '\'' +
                ", surveyName='" + surveyName + '\'' +
                ", surveyAim='" + surveyAim + '\'' +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                ", serverLaunchUser='" + serverLaunchUser + '\'' +
                ", foreword='" + foreword + '\'' +
                ", tag='" + tag + '\'' +
                ", displayMode='" + displayMode + '\'' +
                ", surveyTime=" + surveyTime +
                ", showNumber=" + showNumber +
                ", showItemType=" + showItemType +
                ", orderNum=" + orderNum +
                ", status=" + status +
                ", surveyType='" + surveyType + '\'' +
                ", remark='" + remark + '\'' +
                ", answerNum=" + answerNum +
                ", functionSet=" + functionSet +
                ", pushAdvertisingSet=" + pushAdvertisingSet +
                ", pushInformationSet=" + pushInformationSet +
                "} " + super.toString();
    }
}

package com.space.lightapp.enums;

/**
 * @author JiangHao
 * @version 1.0
 * @date 2021/12/1 0001 15:17
 * @description 消息订阅
 */
public enum SubscribeEnum {
    //订阅
    NOT_SUBSCRIBE("not_subscribe", "未订阅"),
    SUBSCRIBE("subscribe", "已订阅");

    private String code;
    private String info;

    SubscribeEnum(String code, String info) {
        this.code = code;
        this.info = info;
    }

    public String getCode() {
        return code;
    }

    public String getInfo() {
        return info;
    }
}

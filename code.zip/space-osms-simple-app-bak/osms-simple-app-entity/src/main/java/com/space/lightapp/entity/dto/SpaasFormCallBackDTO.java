package com.space.lightapp.entity.dto;

import com.space.lightapp.base.BaseVO;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * spass表单回调DTO
 *
 * @Author ChenYou
 * @date 2021-10-19 10:49
 * @Version 1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class SpaasFormCallBackDTO extends BaseVO {

    /**
     * 应用类型
     **/
    private String orderTypeCode;
    /**
     * 应用Id
     **/
    private String orderTypeId;
    /**
     * 表单ID
     **/
    private String formId;
    /**
     * 表别名（生成数据库的表t_alias）
     **/
    private String alias;
    /**
     * 流程定义key, 业务processKey
     **/
    private String key;
    /**
     * 流程定义Id
     **/
    private String definitionId;
    /**
     * 业务模型别名
     */
    private String boAlias;
    /**
     * 业务工作流Id
     **/
    private String processId;
    /**
     * 表单版本：test测试版本，formal正式版本
     */
    private String status;
}

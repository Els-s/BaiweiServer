package com.space.lightapp.enums;

/**
 * 活动业务状态枚举类
 *
 * @author JiangHao
 * @date 2021-12-20
 * @Version 1.0
 */
public enum ActivityBusinessStateEnum {


    /**
     * 业务状态(1待支付，2已报名，3待审核，4已签到，5退款中)
     */
    UN_PAY("un_pay", "待支付"),
    APPLY("apply", "已报名"),
    APPLY_ING("apply_ing", "报名审核中"),
    APPLY_FAIL("apply_fail", "报名失败"),
    CHECK("check", "待审核"),
    SIGN("sign", "已签到"),
    REFUND("refund", "退款中");

    private String code;

    private String info;

    ActivityBusinessStateEnum(String code, String info) {
        this.code = code;
        this.info = info;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }


    public static String getInfoValue(String code) {
        ActivityBusinessStateEnum[] values = ActivityBusinessStateEnum.values();
        for (ActivityBusinessStateEnum value : values) {
            if (value.getCode().equals(code)) {
                return value.getInfo();
            }
        }
        return "暂无";
    }
}

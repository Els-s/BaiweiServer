package com.space.lightapp.utils;

import cn.hutool.core.util.StrUtil;
import cn.space.base.result.Response;
import com.alibaba.fastjson.JSONObject;
import com.space.osms.common.core.utils.StringUtil;
import java.io.IOException;
import java.nio.charset.Charset;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.net.ssl.SSLContext;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.MapUtils;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.util.EntityUtils;

/**
 * Http请求工具类
 *
 * @Author ChenYou
 * @date 2021-11-06 9:29
 * @Version 1.0
 */
@Slf4j
public class HttpUtils {

    private static PoolingHttpClientConnectionManager connMgr;
    private static RequestConfig requestConfig;
    private static final int MAX_TIMEOUT = 50000;
    private static final String HTTP_TYPE = "https";
    private static final String EN_CODE = "UTF-8";

    static {
        // 设置连接池
        connMgr = new PoolingHttpClientConnectionManager();
        // 设置连接池大小
        connMgr.setMaxTotal(100);
        connMgr.setDefaultMaxPerRoute(connMgr.getMaxTotal());
        // Validate connections after 1 sec of inactivity
        connMgr.setValidateAfterInactivity(5000);
        RequestConfig.Builder configBuilder = RequestConfig.custom();
        // 设置连接超时
        configBuilder.setConnectTimeout(MAX_TIMEOUT);
        // 设置读取超时
        configBuilder.setSocketTimeout(MAX_TIMEOUT);
        // 设置从连接池获取连接实例的超时
        configBuilder.setConnectionRequestTimeout(MAX_TIMEOUT);
        requestConfig = configBuilder.build();
    }

    /**
     * SDK的http调用适配方法，Json数据（单独分离token参数）
     *
     * @param apiUrl   调用Api全路径
     * @param jsonData json类型的body数据
     * @param token    请求token
     * @return Response
     */
    public static Response handleJsonSdkPost(String apiUrl, String jsonData,
            String token) {
        Map<String, Object> headerMaps = new HashMap<>();
        if (StrUtil.isNotBlank(token)) {
            headerMaps.put("Authorization", token);
        }
        return doPost(apiUrl, jsonData, getHeaders(headerMaps));
    }

    /**
     * SDK的http调用适配方法，Map数据（单独分离token参数）
     *
     * @param apiUrl    调用Api全路径
     * @param paramMaps Map类型的body数据
     * @param token     请求token
     * @return Response
     */
    public static Response handleMapSdkPost(String apiUrl,
            Map<String, Object> paramMaps, String token) {
        Map<String, Object> headerMaps = new HashMap<>();
        if (StrUtil.isNotBlank(token)) {
            headerMaps.put("Authorization", token);
        }
        return doPost(apiUrl, paramMaps, getHeaders(headerMaps));
    }

    /**
     * json格式的Post请求
     *
     * @param apiUrl     调用Api全路径
     * @param jsonData   json类型的body数据
     * @param headerMaps 请求头信息
     * @return Response
     */
    public static Response handleJsonPost(String apiUrl, String jsonData,
            Map<String, Object> headerMaps) {
        return doPost(apiUrl, jsonData, getHeaders(headerMaps));
    }

    /**
     * map格式的Post请求
     *
     * @param apiUrl     调用Api全路径
     * @param paramMaps  Map类型的body数据
     * @param headerMaps 请求Header Map  K-V
     * @return Response
     */
    public static Response handleMapPost(String apiUrl,
            Map<String, Object> paramMaps, Map<String, Object> headerMaps) {
        return doPost(apiUrl, paramMaps, getHeaders(headerMaps));
    }

    /**
     * map格式的Get请求(单独token，无其他header)
     *
     * @param apiUrl    调用Api全路径
     * @param paramMaps Map类型的body数据
     * @param token     请求Header Map  K-V
     * @return Response
     */
    public static Response handleMapTokenGet(String apiUrl,
            Map<String, Object> paramMaps, String token) {
        Map<String, Object> headerMaps = new HashMap<>();
        if (StrUtil.isNotBlank(token)) {
            headerMaps.put("Authorization", token);
        }
        return doGet(apiUrl, paramMaps, getHeaders(headerMaps));
    }

    /**
     * map格式的Get请求
     *
     * @param apiUrl     调用Api全路径
     * @param paramMaps  Map类型的body数据
     * @param headerMaps 请求Header Map  K-V
     * @return Response
     */
    public static Response handleMapGet(String apiUrl,
            Map<String, Object> paramMaps, Map<String, Object> headerMaps) {
        return doGet(apiUrl, paramMaps, getHeaders(headerMaps));
    }

    /**
     * 发送 GET 请求（HTTP），K-V形式
     *
     * @param apiUrl 全路径
     * @param params 请求参数
     * @return
     */
    public static Response doGet(String apiUrl, Map<String, Object> params, Header[] headers) {
        StringBuffer param = new StringBuffer();
        int i = 0;
        if (MapUtils.isNotEmpty(params)) {
            for (Map.Entry<String, Object> entry : params.entrySet()) {
                String key = entry.getKey();
                if (i == 0) {
                    param.append("?");
                } else {
                    param.append("&");
                }
                param.append(key).append("=").append(entry.getValue());
                i++;
            }
        }
        apiUrl += param;
        String result = null;
        HttpClient httpClient;
        if (apiUrl.startsWith(HTTP_TYPE)) {
            httpClient = HttpClients.custom().setSSLSocketFactory(createSslConnSocketFactory())
                    .setConnectionManager(connMgr).setDefaultRequestConfig(requestConfig).build();
        } else {
            httpClient = HttpClients.createDefault();
        }
        try {
            HttpGet httpGet = new HttpGet(apiUrl);
            if (headers != null && headers.length > 0) {
                httpGet.setHeaders(headers);
            }
            HttpResponse response = httpClient.execute(httpGet);
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                result = EntityUtils.toString(entity, EN_CODE);
            }
            int statusCode = response.getStatusLine().getStatusCode();
            if (HttpStatus.SC_OK != statusCode) {
                return Response.error(statusCode, result);
            }
        } catch (IOException e) {
            e.printStackTrace();
            return Response.error("Http请求失败：url->" + apiUrl);
        }
        //调用接口临时适配（等Spaas提供新接口）
        JSONObject jsonObject = JSONObject.parseObject(result);
        if (jsonObject.containsKey("code") && jsonObject.containsKey("data")) {
            return JSONObject.parseObject(result, Response.class);
        } else if (jsonObject.containsKey("returnCode") && jsonObject.containsKey("data")) {
            //兼容消息中心的返回类型
            return Response.success(jsonObject.getJSONArray("data"));
        } else {
            return StringUtil.isEmpty(result) ? Response.error("Http请求获取数据为null：url->" + apiUrl)
                    : Response.success(jsonObject);
        }
    }

    private static List<NameValuePair> getNameValueList(Map<String, Object> params) {
        if (params == null) {
            return new ArrayList<>();
        }
        List<NameValuePair> pairList = new ArrayList<>(params.size());
        for (Map.Entry<String, Object> entry : params.entrySet()) {
            NameValuePair pair = new BasicNameValuePair(entry.getKey(),
                    entry.getValue() != null ? entry.getValue().toString() : "");
            pairList.add(pair);
        }
        return pairList;
    }

    private static Header[] getHeaders(Map<String, Object> params) {
        if (null == params || params.size() == 0) {
            return null;
        }
        Header[] headers = new Header[params.size()];
        int i = 0;
        for (Map.Entry<String, Object> entry : params.entrySet()) {
            String key = entry.getKey();
            BasicHeader header = new BasicHeader(key,
                    StringUtil.isNull(entry.getValue()) ? "" : entry.getValue().toString());
            headers[i++] = header;
        }
        return headers;
    }

    /**
     * 发送 POST 请求，K-V形式
     *
     * @param apiUrl API接口URL
     * @param params 参数map
     * @return
     */
    public static Response doPost(String apiUrl, Map<String, Object> params, Header[] headers) {
        CloseableHttpClient httpClient;
        if (apiUrl.startsWith(HTTP_TYPE)) {
            httpClient = HttpClients.custom().setSSLSocketFactory(createSslConnSocketFactory())
                    .setConnectionManager(connMgr).setDefaultRequestConfig(requestConfig).build();
        } else {
            httpClient = HttpClients.createDefault();
        }
        HttpPost httpPost = new HttpPost(apiUrl);
        CloseableHttpResponse response = null;
        String result = null;
        try {
            if (headers != null) {
                httpPost.setHeaders(headers);
            }
            httpPost.setConfig(requestConfig);
            List<NameValuePair> pairList = getNameValueList(params);
            if (pairList.size() > 0) {
                httpPost.setEntity(new UrlEncodedFormEntity(pairList, Charset.forName(EN_CODE)));
            }
            response = httpClient.execute(httpPost);
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                result = EntityUtils.toString(entity, EN_CODE);
            }
            int statusCode = response.getStatusLine().getStatusCode();
            if (HttpStatus.SC_OK != statusCode) {
                return Response.error(statusCode, result);
            }
        } catch (IOException e) {
            e.printStackTrace();
            return Response.error("Http请求失败：url->" + apiUrl);
        } finally {
            if (response != null) {
                try {
                    EntityUtils.consume(response.getEntity());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return StringUtil.isEmpty(result) ? Response.error("Http请求获取数据为null：url->" + apiUrl)
                : JSONObject.parseObject(result, Response.class);
    }

    /**
     * 发送 POST 请求，JSON形式，接收端需要支持json形式，否则取不到数据
     *
     * @param apiUrl
     * @param json   json对象
     * @return
     */
    public static Response doPost(String apiUrl, String json, Header[] headers) {
        CloseableHttpClient httpClient;
        if (apiUrl.startsWith("https")) {
            httpClient = HttpClients.custom().setSSLSocketFactory(createSslConnSocketFactory())
                    .setConnectionManager(connMgr).setDefaultRequestConfig(requestConfig).build();
        } else {
            httpClient = HttpClients.createDefault();
        }
        String result = null;
        HttpPost httpPost = new HttpPost(apiUrl);
        if (null != headers && headers.length > 0) {
            httpPost.setHeaders(headers);
        }
        CloseableHttpResponse response = null;
        try {
            httpPost.setConfig(requestConfig);
            StringEntity stringEntity = new StringEntity(json, EN_CODE);
            stringEntity.setContentEncoding(EN_CODE);
            stringEntity.setContentType("application/json");
            httpPost.setEntity(stringEntity);
            response = httpClient.execute(httpPost);
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                result = EntityUtils.toString(entity, EN_CODE);
            }
            int statusCode = response.getStatusLine().getStatusCode();
            if (HttpStatus.SC_OK != statusCode) {
                return Response.error(statusCode, result);
            }
        } catch (IOException e) {
            e.printStackTrace();
            return Response.error("Http请求失败：url->" + apiUrl);
        } finally {
            if (response != null) {
                try {
                    EntityUtils.consume(response.getEntity());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        if (!StringUtil.isEmpty(result)) {
            JSONObject object;
            try {
                object = JSONObject.parseObject(result);
            } catch (Exception e) {
                return Response.success(JSONObject.parseObject(result));
            }
            if (object.containsKey("returnCode") && object.getLong("returnCode") == 200) {
                JSONObject data = object.getJSONObject("data");
                return Response.success(data);
            }
            if (!object.containsKey("code")) {
                return Response.success(JSONObject.parseObject(result));
            }

        }
        return StringUtil.isEmpty(result) ? Response.error("Http请求获取数据为null：url->" + apiUrl)
                : JSONObject.parseObject(result, Response.class);
    }

    /**
     * 创建SSL安全连接
     *
     * @return
     */
    private static SSLConnectionSocketFactory createSslConnSocketFactory() {
        SSLConnectionSocketFactory sslSf = null;
        try {
            SSLContext sslContext = new SSLContextBuilder().loadTrustMaterial(null,
                    (TrustStrategy) (chain, authType) -> true).build();
            sslSf = new SSLConnectionSocketFactory(sslContext, (arg0, arg1) -> true);
        } catch (GeneralSecurityException e) {
            e.printStackTrace();
        }
        return sslSf;
    }
}

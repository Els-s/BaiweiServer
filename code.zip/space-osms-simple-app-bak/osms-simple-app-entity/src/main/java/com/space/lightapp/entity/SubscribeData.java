package com.space.lightapp.entity;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @author JiangHao
 * @version 1.0
 * @date 2021/12/2 0002 14:47
 * @description
 */
@Data
@Accessors(chain = true)
@ApiModel(description = "订阅消息参数")
public class SubscribeData {

    private Long serverDataId;
    private String openId;
    private String tmplIds[];
}

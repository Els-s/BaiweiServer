package com.space.lightapp.base;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 数据处理状态
 *
 * @Author ChenYou
 * @date 2021-11-30 20:57
 * @Version 1.0
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class HandleTypeVO extends BaseVO {

    /**
     * 处理状态  0 处理中，1处理完
     */
    private int handleType;
}

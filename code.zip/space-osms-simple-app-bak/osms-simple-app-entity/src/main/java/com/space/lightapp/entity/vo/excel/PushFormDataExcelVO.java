package com.space.lightapp.entity.vo.excel;

import com.space.osms.common.file.annotation.Excel;
import lombok.Data;

/**
 * 表单导出数据VO
 *
 * @Author Els
 * @date 2021-12-21 16:24
 * @Version 1.0
 */
@Data
public class PushFormDataExcelVO {

    @Excel(name = "单据来源")
    private String source;
    @Excel(name = "单据编码")
    private String orderCode;
    @Excel(name = "提单人")
    private String billUser;
    @Excel(name = "当前节点处理人")
    private String processNodeUser;
    @Excel(name = "当前节点处理人详情")
    private String processNodeUserDetail;
    @Excel(name = "工单状态")
    private String processStateName;
    @Excel(name = "创建时间")
    private String createTimeStr;
}

package com.space.lightapp.base;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.space.lightapp.entity.dto.JpaasUserDTO;
import io.swagger.annotations.ApiModelProperty;
import java.util.Date;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * VO对象父类
 *
 * @Author ChenYou
 * @date 2021-10-18 9:01
 * @Version 1.0
 */
@Data
@Accessors(chain = true)
public class BaseVO {

    /**
     * 用户信息
     */
    @ApiModelProperty(value = "用户信息", hidden = true)
    private JpaasUserDTO userInfo;

    /**
     * 操作用户类型
     */
    @ApiModelProperty(value = "操作用户类型")
    private String opeUserType;
    /**
     * 租户编码
     */
    @ApiModelProperty(value = "租户编码", hidden = true)
    private String tenementCode;
    /**
     * 园区编码
     */
    @ApiModelProperty(value = "园区编码", hidden = true)
    private String projectCode;
    /**
     * 企业编码
     */
    @ApiModelProperty(value = "企业编码", hidden = true)
    private String companyCode;

    /**
     * 搜索字段
     */
    @ApiModelProperty(value = "搜索字段")
    private String searchInfo;
    /**
     * 创建人
     */
    @ApiModelProperty(value = "创建人", hidden = true)
    private String createBy;
    /**
     * 更新人
     */
    @ApiModelProperty(value = "更新人")
    private String updateBy;
    /**
     * 创建时间
     */
    @ApiModelProperty(value = "创建时间", hidden = true)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;
    /**
     * 更新时间
     */
    @ApiModelProperty(value = "更新时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date updateTime;
}

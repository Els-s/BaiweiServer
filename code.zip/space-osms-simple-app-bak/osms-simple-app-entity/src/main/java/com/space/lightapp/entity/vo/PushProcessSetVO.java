package com.space.lightapp.entity.vo;

import com.space.lightapp.base.BaseVO;
import com.space.lightapp.entity.PushProcessSet;
import com.space.osms.common.core.utils.DozerBeanUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 流程设置Vo对象 push_process_set
 *
 * @author ChenYou
 * @date 2021-10-14
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "流程设置")
public class PushProcessSetVO extends BaseVO {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    private Long processSetId;
    /**
     * 轻应用Id
     */
    @ApiModelProperty(value = "轻应用Id")
    private Long lightAppId;
    /**
     * 轻应用模块Id
     */
    @ApiModelProperty(value = "轻应用模块Id")
    private Long lightAppModuleId;
    /**
     * 任务中心唯一标识码
     */
    @ApiModelProperty(value = "任务中心唯一标识码")
    private String taskTypeCode;
    /**
     * 流程Id
     */
    @ApiModelProperty(value = "流程Id")
    private String processId;
    /**
     * 流程定义Id
     */
    @ApiModelProperty(value = "流程定义Id")
    private String definitionId;
    /**
     * 流程名称
     */
    @ApiModelProperty(value = "流程名称")
    private String processName;
    /**
     * 排序 排序字段
     */
    @ApiModelProperty(value = "排序 排序字段")
    private Integer orderNum;
    /**
     * 状态 0禁用，1启用；默认1
     */
    @ApiModelProperty(value = "状态 0禁用，1启用；默认1")
    private Boolean status;

    /**
     * 逻辑删除 0有效，1被删除；默认0
     */
    @ApiModelProperty(value = "逻辑删除 0有效，1被删除；默认0")
    private Boolean delFlag;

    /**
     * Vo转Entity
     *
     * @return Entity对象
     * @date 2021-10-14
     */
    public PushProcessSet toEntity() {
        return DozerBeanUtil.transitionType(this, PushProcessSet.class);
    }

    /**
     * List-Vo转List-Entity
     *
     * @return List-Entity对象
     * @date 2021-10-14
     */
    public List<PushProcessSet> toListEntity(List<PushProcessSetVO> pushProcessSetVo) {
        List<PushProcessSet> list = new ArrayList<>();
        pushProcessSetVo.forEach(t -> list.add(t.toEntity()));
        return list;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("processSetId", getProcessSetId())
                .append("lightAppId", getLightAppId())
                .append("lightAppModuleId", getLightAppModuleId())
                .append("processId", getProcessId())
                .append("processName", getProcessName())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

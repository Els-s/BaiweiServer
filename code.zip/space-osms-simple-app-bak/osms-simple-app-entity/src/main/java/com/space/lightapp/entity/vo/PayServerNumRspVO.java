package com.space.lightapp.entity.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * 增值服务状态统计数量Vo
 *
 * @Author JiangHao
 * @date 2021-12-22 17:03
 * @Version 1.0
 */
@Data
@Accessors(chain = true)
@ApiModel(value = "增值服务状态统计数量Vo")
public class PayServerNumRspVO {

    @ApiModelProperty(value = "全部")
    private Integer all;
    @ApiModelProperty(value = "支付中")
    private Integer pay;
    @ApiModelProperty(value = "待派送")
    private Integer delivery;
    @ApiModelProperty(value = "退款中")
    private Integer refund;
    @ApiModelProperty(value = "已取消")
    private Integer cancel;
    @ApiModelProperty(value = "已完成")
    private Integer finish;

}

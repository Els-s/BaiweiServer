package com.space.lightapp.entity.vo.order;

import com.alibaba.fastjson.JSONObject;
import com.space.lightapp.base.BaseVO;
import com.space.lightapp.entity.dto.order.OrderDTO;
import com.space.lightapp.entity.vo.LightAppServerDataVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 下单VO
 *
 * @Author ChenYou
 * @date 2021-11-12 17:11
 * @Version 1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = "下单实体VO")
public class PlaceOrderVO extends BaseVO {

    @ApiModelProperty(value = "业务服务数据", required = true)
    private LightAppServerDataVO serverData;

    @ApiModelProperty(value = "下单数据", required = true)
    private OrderDTO order;

    @ApiModelProperty(value = "线下表单数据，没有时不带")
    private JSONObject spaasData;
}

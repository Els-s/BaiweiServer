package com.space.lightapp.enums;


/**
 * 应用状态枚举类
 *
 * @author jianghao
 * @date 2021-10-13
 * @Version 1.0
 */
public enum LightAppTypeEnum {
    /**
     * 草稿
     */
    DRAFT("draft", "草稿"),
    /**
     * 测试
     */
    TEST("test", "测试"),
    /**
     * 上线
     */
    UPLINE("upLine", "上线"),
    /**
     * 下线
     */
    DOWNLINE("downLine", "下线");

    LightAppTypeEnum(String code, String info) {
        this.code = code;
        this.info = info;
    }

    private String code;
    private String info;

    public String getCode() {
        return code;
    }

    public String getInfo() {
        return info;
    }

    public static String getInfoByCode(String code) {
        LightAppTypeEnum[] values = LightAppTypeEnum.values();
        for (LightAppTypeEnum value : values) {
            if (value.getCode().equalsIgnoreCase(code)) {
                return value.getInfo();
            }
        }
        return "未知";
    }
}

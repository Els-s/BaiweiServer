package com.space.lightapp.enums;

/**
 * 支付方式枚举
 *
 * @Author ChenYou
 * @date 2021-11-13 15:51
 * @Version 1.0
 */
public enum PayWayEnum {
    // 支付方式枚举 orderCode订单中心枚举值
    COMPANY_PAY("companyPay", "0", "企业结算"),
    CASH_PAY("cashPay", "1", "现结");

    private String code;
    private String orderCode;
    private String info;

    PayWayEnum(String code, String orderCode, String info) {
        this.code = code;
        this.orderCode = orderCode;
        this.info = info;
    }

    public String getCode() {
        return code;
    }

    public String getOrderCode() {
        return orderCode;
    }

    public String getInfo() {
        return info;
    }

    public static PayWayEnum getEnumByCode(String code) {
        PayWayEnum[] values = PayWayEnum.values();
        for (PayWayEnum value : values) {
            if (value.getCode().equals(code)) {
                return value;
            }
        }
        return null;
    }

    public static PayWayEnum getEnumByorderCode(String orderCode) {
        PayWayEnum[] values = PayWayEnum.values();
        for (PayWayEnum value : values) {
            if (value.getOrderCode().equals(orderCode)) {
                return value;
            }
        }
        return null;
    }

    public static String getInfoValue(String code) {
        PayWayEnum[] values = PayWayEnum.values();
        for (PayWayEnum value : values) {
            if (value.getCode().equals(code)) {
                return value.getInfo();
            }
        }
        return "暂无";
    }
}

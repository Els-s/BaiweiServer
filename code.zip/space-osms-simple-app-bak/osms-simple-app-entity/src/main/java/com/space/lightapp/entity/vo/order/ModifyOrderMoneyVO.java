package com.space.lightapp.entity.vo.order;

import com.space.lightapp.base.BaseVO;
import io.swagger.annotations.ApiModelProperty;
import java.math.BigDecimal;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 修改订单价格VO
 *
 * @Author Els
 * @date 2021-12-30 9:30
 * @Version 1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class ModifyOrderMoneyVO extends BaseVO {

    private Long serverDataId;
    @ApiModelProperty(value = "轻应用类型")
    private String appMarketTypeCode;
    @ApiModelProperty(value = "外部的订单接口")
    private String extOrderCode;
    @ApiModelProperty(value = "手机号码", required = true)
    private String customerPhone;
    @ApiModelProperty(value = "修改后应付金额")
    private String buyMoney;
    @ApiModelProperty(value = "备注")
    private String remark;
}

package com.space.lightapp.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @author JiangHao
 * @version 1.0
 * @date 2021/12/3 0003 14:35
 * @description
 */
@Data
@Accessors(chain = true)
@TableName("字典内容")
public class DictDataSdk {

    private String treeId;
    private String name;
    private String value;

}

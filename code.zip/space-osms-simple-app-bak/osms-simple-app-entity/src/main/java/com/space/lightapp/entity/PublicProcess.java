package com.space.lightapp.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.space.lightapp.base.BaseEntity;
import com.space.lightapp.entity.vo.PublicProcessVO;
import com.space.osms.common.core.utils.DozerBeanUtil;
import io.swagger.annotations.ApiModel;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 公共流程 对象 public_process
 *
 * @author ChenYou
 * @date 2021-11-12
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("public_process")
@ApiModel(description = "公共流程 ")
public class PublicProcess extends BaseEntity {

    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long publicProcessId;
    /**
     * 流程分类 settle-企业结算流程，refund-退款流程
     */
    private String processType;
    /**
     * 表单 默认表单的Id
     */
    private String formId;
    /**
     * 表单别名 表单别名
     */
    private String alias;
    /**
     * 流程key 对应Spaas的流程key，暂时手动维护
     */
    private String processKey;
    /**
     * 排序 排序字段
     */
    private Integer orderNum;
    /**
     * 是否禁用 0禁用，1启用；默认1
     */
    private Boolean status;
    /**
     * 逻辑删除 0有效，1被删除；默认0
     */
    private Boolean delFlag;
    /**
     * 备注
     */
    private String remark;

    /**
     * Entity转Vo
     *
     * @return Vo对象
     * @date 2021-11-12
     */
    public PublicProcessVO toVo() {
        return DozerBeanUtil.transitionType(this, PublicProcessVO.class);
    }

    /**
     * List-Entity转List-Vo
     *
     * @return List-Vo对象
     * @date 2021-11-12
     */
    public List<PublicProcessVO> toListVo(List<PublicProcess> publicProcess) {
        List<PublicProcessVO> list = new ArrayList<>();
        publicProcess.forEach(t -> list.add(t.toVo()));
        return list;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("publicProcessId", getPublicProcessId())
                .append("processType", getProcessType())
                .append("formId", getFormId())
                .append("alias", getAlias())
                .append("processKey", getProcessKey())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("companyCode", getCompanyCode())
                .append("remark", getRemark())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

package com.space.lightapp.entity.vo;

import com.space.lightapp.base.BaseVO;
import com.space.lightapp.entity.LightAppServerType;
import com.space.osms.common.core.utils.DozerBeanUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 服务分类 Vo对象 light_app_server_type
 *
 * @author ChenYou
 * @date 2021-11-04
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "服务分类 ")
public class LightAppServerTypeVO extends BaseVO {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    private Long serverTypeId;
    /**
     * 轻应用Id
     */
    @ApiModelProperty(value = "轻应用Id")
    private Long lightAppId;
    /**
     * 应用类型
     */
    @ApiModelProperty(value = "应用类型")
    private String appMarketTypeCode;
    /**
     * 服务类型名称
     */
    @ApiModelProperty(value = "服务类型名称")
    private String serverTypeName;
    /**
     * 服务类型编码
     */
    @ApiModelProperty(value = "服务类型编码")
    private String serverTypeCode;

    @ApiModelProperty(value = "关联表单ID")
    private String formId;

    @ApiModelProperty(value = "关联表单别名")
    private String alias;
    /**
     * 流程Key
     */
    @ApiModelProperty(value = "流程Key")
    private String processKey;
    /**
     * 是否存在Spaas流程
     */
    private Boolean existSpaasProcess;

    private String taskTypeCode;

    private Boolean existTaskCentreCode;
    /**
     * 排序 排序字段
     */
    @ApiModelProperty(value = "排序 排序字段")
    private Integer orderNum;
    /**
     * 是否禁用 0禁用，1启用；默认1
     */
    @ApiModelProperty(value = "是否禁用 0禁用，1启用；默认1")
    private Boolean status;
    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String remark;
    /**
     * 轻应用业务代码
     */
    @ApiModelProperty(value = "轻应用业务代码:C019")
    private String appId;

    /**
     * Vo转Entity
     *
     * @return Entity对象
     * @date 2021-11-04
     */
    public LightAppServerType toEntity() {
        return DozerBeanUtil.transitionType(this, LightAppServerType.class);
    }

    /**
     * List-Vo转List-Entity
     *
     * @return List-Entity对象
     * @date 2021-11-04
     */
    public List<LightAppServerType> toListEntity(List<LightAppServerTypeVO> lightAppServerTypeVo) {
        List<LightAppServerType> list = new ArrayList<>();
        lightAppServerTypeVo.forEach(t -> list.add(t.toEntity()));
        return list;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("serverTypeId", getServerTypeId())
                .append("lightAppId", getLightAppId())
                .append("appMarketTypeCode", getAppMarketTypeCode())
                .append("serverTypeName", getServerTypeName())
                .append("serverTypeCode", getServerTypeCode())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("companyCode", getCompanyCode())
                .append("remark", getRemark())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .toString();
    }

}

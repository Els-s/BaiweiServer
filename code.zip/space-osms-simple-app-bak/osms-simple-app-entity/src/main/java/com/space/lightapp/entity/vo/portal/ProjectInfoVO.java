package com.space.lightapp.entity.vo.portal;

import lombok.Data;
import lombok.experimental.Accessors;

/**
 * 项目信息
 *
 * @Author Els
 * @date 2021-12-23 19:49
 * @Version 1.0
 */
@Data
@Accessors(chain = true)
public class ProjectInfoVO {

    private String name;
    private String code;

//"id": "4403051001000000000000000000000000000000",
//    "code": "ZH_00001_XM_00000001",
//    "tenementCode": "ZH_00001",
//    "internalParentCode": "root",
//    "internalCode": "ZH_00001_XM_00000001",
//    "externalCode": "XM0001",
//    "externalParentCode": null,
//    "name": "科兴科学园",
//    "type": {
//    "value": 0,
//        "label": "项目",
//        "clz": "cn.space.space.entity.Project",
//        "index": 0
//  },
//      "createTime": 1626156777000,
//      "createBy": "Genzon",
//      "updateTime": 1638602906000,
//      "category": {
//    "value": 0,
//        "label": "办公室",
//        "index": 0
//  },
//      "labelCode": "603f5d31-e5e3-11eb-bf98-0242ac180006",
//      "projectCode": "ZH_00001_XM_00000001",
//      "fullName": "科兴科学园",
//      "orderNum": 0,
//      "applicationType": null,
//      "rentStatus": 1,
//      "enableStatus": 1,
//      "objectType": null,
//      "oldHouseCode": null,
//      "area": null,
//      "projectFormat": "d1758c9d66594ce49625c85204dc2bc5,c70ebda7c45d4f52ab309641e8205c5a",
//      "updateBy": "730e843edb544d31945ad20a4381574b",
//      "children": [],
//      "details": {
//    "tenementCode": "ZH_00001",
//        "createBy": null,
//        "updateBy": "730e843edb544d31945ad20a4381574b",
//        "createTime": 4076816353000,
//        "updateTime": 1638602906000,
//        "id": "4403051001000000000000000000000000000000",
//        "code": "ZH_00001_XM_00000001",
//        "externalCode": "XM0001",
//        "name": "科兴科学园",
//        "enCode": "XM0001",
//        "cover": "https://spacebusiness.oss-cn-beijing.aliyuncs.com/space/project/20210708112127494.jpg",
//        "area": null,
//        "projectFormat": "d1758c9d66594ce49625c85204dc2bc5,c70ebda7c45d4f52ab309641e8205c5a",
//        "coolingMode": null,
//        "airBillingMethod": null,
//        "airOpeningHours": null,
//        "propertyCompany": null,
//        "completionTime": null,
//        "propertyRight": null,
//        "usageRate": null,
//        "developer": null,
//        "propertyManageFees": null,
//        "parkingFee": null,
//        "elevatorsCount": null,
//        "phone": "0755-88888878",
//        "applicationType": {
//      "value": 2,
//          "label": "其他",
//          "index": 2
//    },
//    "rentStatus": {
//      "value": 1,
//          "label": "待租",
//          "index": 1
//    },
//    "enableStatus": {
//      "value": 1,
//          "label": "已启用",
//          "index": 1
//    },
//    "projectAddress": {
//      "tenementCode": "ZH_00001",
//          "createBy": null,
//          "updateBy": "730e843edb544d31945ad20a4381574b",
//          "createTime": 1615366753000,
//          "updateTime": 1638602906000,
//          "id": "b8fd1b2aaf7194aa72de178c355ecf5c",
//          "code": null,
//          "externalCode": null,
//          "projectCode": "ZH_00001_XM_00000001",
//          "provinceCode": null,
//          "provinceName": "广东省",
//          "cityCode": "156440300",
//          "cityName": "深圳市",
//          "areaCode": "440305",
//          "areaName": "南山区",
//          "address": "广东省深圳市科兴科学园",
//          "longitude": "113.943574899",
//          "latitude": "22.548203799",
//          "businessDistrict": null
//    },
//    "labelCodes": null,
//        "parkSpaceCount": 30,
//        "labelCode": null,
//        "orderNum": null,
//        "externalParentCode": null,
//        "formatCodeList": [
//    "d1758c9d66594ce49625c85204dc2bc5",
//        "c70ebda7c45d4f52ab309641e8205c5a"
//      ],
//    "sync": false
//  },
//      "resourceType": null,
//      "chooseFlag": false,
//      "additionalData": null,
//      "projectName": null,
//      "formatCodeList": null,
//      "hasParent": false
}

package com.space.lightapp.entity.dto.spaas;

import com.alibaba.fastjson.JSONObject;
import com.space.lightapp.entity.vo.spaas.SpaasFormProcessVO;

import java.util.HashMap;
import java.util.TreeMap;

/**
 * 服务关联的表单流程信息
 */
public class SpaasFormProcessDTO extends TreeMap<String, SpaasFormProcessVO> {

    public SpaasFormProcessDTO putIfAbsentData(SpaasFormProcessVO data) {
//        String key = data.getAppFlagType()+"_"+data.getLightAppModuleCode() ;
        String key = data.getAppFlagType();
        this.putIfAbsent(key, data);
        return this;
    }

    public static void main(String[] args) {
        mockData();
    }

    private static void mockData() {
        SpaasFormProcessVO vo = new SpaasFormProcessVO();
        vo.setAppFlagType("flag_complaint");
        vo.setLightAppModuleCode("formSet");
        vo.setAlias("complaint");
        vo.setProcessId("process_complaint1");
        SpaasFormProcessDTO dto = new SpaasFormProcessDTO();
        dto.putIfAbsentData(vo);

        SpaasFormProcessVO vo2 = new SpaasFormProcessVO();
        vo2.setAppFlagType("flag_complaint");
        vo2.setLightAppModuleCode("formSet");
        vo2.setAlias("complaint");
        vo2.setProcessId("process_complaint2");

        dto.putIfAbsentData(vo2);

        SpaasFormProcessVO vo3 = new SpaasFormProcessVO();
        vo3.setAppFlagType("flag_suggest");
        vo3.setLightAppModuleCode("formSet");
        vo3.setAlias("suggest");
        vo3.setProcessId("process_suggest");

        dto.putIfAbsentData(vo3);

        System.out.println(JSONObject.toJSONString(dto));
    }

}

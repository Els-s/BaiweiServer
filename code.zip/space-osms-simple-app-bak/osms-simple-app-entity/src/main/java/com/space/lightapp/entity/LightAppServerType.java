package com.space.lightapp.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.space.lightapp.base.BaseEntity;
import com.space.lightapp.entity.vo.LightAppServerTypeVO;
import com.space.osms.common.core.utils.DozerBeanUtil;
import io.swagger.annotations.ApiModel;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 服务分类 对象 light_app_server_type
 *
 * @author ChenYou
 * @date 2021-11-04
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("light_app_server_type")
@ApiModel(description = "服务分类 ")
public class LightAppServerType extends BaseEntity {

    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long serverTypeId;
    /**
     * 轻应用Id
     */
    private Long lightAppId;
    /**
     * 应用类型
     */
    private String appMarketTypeCode;
    /**
     * 服务类型名称
     */
    private String serverTypeName;
    /**
     * 服务类型编码
     */
    private String serverTypeCode;
    /**
     * 排序 排序字段
     */
    private Integer orderNum;
    /**
     * 是否禁用 0禁用，1启用；默认1
     */
    private Boolean status;
    /**
     * 备注
     */
    private String remark;
    /**
     * 关联表单ID
     */
    private String formId;
    /**
     * 流程Key
     */
    private String processKey;
    /**
     * 是否存在Spaas流程
     */
    private Boolean existSpaasProcess;
    /**
     * 关联表单别名
     */
    private String alias;
    /**
     * 任务中心唯一标识码 task_type_code
     */
    private String taskTypeCode;

    private Boolean existTaskCentreCode;
    /**
     * 逻辑删除 0有效，1被删除；默认0
     */
    private Boolean delFlag;

    /**
     * Entity转Vo
     *
     * @return Vo对象
     * @date 2021-11-04
     */
    public LightAppServerTypeVO toVo() {
        return DozerBeanUtil.transitionType(this, LightAppServerTypeVO.class);
    }

    /**
     * List-Entity转List-Vo
     *
     * @return List-Vo对象
     * @date 2021-11-04
     */
    public List<LightAppServerTypeVO> toListVo(List<LightAppServerType> lightAppServerType) {
        List<LightAppServerTypeVO> list = new ArrayList<>();
        lightAppServerType.forEach(t -> list.add(t.toVo()));
        return list;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("serverTypeId", getServerTypeId())
                .append("lightAppId", getLightAppId())
                .append("appMarketTypeCode", getAppMarketTypeCode())
                .append("serverTypeName", getServerTypeName())
                .append("serverTypeCode", getServerTypeCode())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("companyCode", getCompanyCode())
                .append("remark", getRemark())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

package com.space.lightapp.entity.dto.order;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * 订单商品
 *
 * @Author Els
 * @date 2021-11-15 19:35
 * @Version 1.0
 */
@Data
@Accessors(chain = true)
public class OrderDetailDTO {

    @ApiModelProperty(value = "商品编码", required = true)
    private String goodsCode;
    @ApiModelProperty(value = "商品名称", required = true)
    private String goodsName;
    @ApiModelProperty(value = "商品规格编码")
    private String specificationCode;
    @ApiModelProperty(value = "商品规格名称")
    private String specificationName;
    @ApiModelProperty(value = "费项编码")
    private String feeInternalCode;
    @ApiModelProperty(value = "数量")
    private String count;
    @ApiModelProperty(value = "单价", required = true)
    private String unitPrice;
    @ApiModelProperty(value = "时长")
    private String duration;

    private String personChannelCode;
}

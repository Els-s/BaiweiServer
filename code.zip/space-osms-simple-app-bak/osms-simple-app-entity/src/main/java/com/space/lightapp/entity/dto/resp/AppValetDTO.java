package com.space.lightapp.entity.dto.resp;

import com.space.lightapp.base.BaseFieldDTO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 允许代客录单的app服务
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "允许代客录单的app服务 ")
public class AppValetDTO extends BaseFieldDTO {

    private String advancedSetId;
    private String lightAppModuleId;
    private String repGuestOrder;
    private String appMarketCode;

    /**
     * 应用ID
     */
    private Long lightAppId;
    /**
     * 服务类型代码
     */
    @ApiModelProperty(value = "服务类型代码")
    private String appMarketTypeCode;
    /**
     * 服务类型名称
     */
    @ApiModelProperty(value = "应用服务名称")
    private String lightAppName;

    /**
     * 应用服务编码
     */
    @ApiModelProperty(value = "应用服务编码")
    private String lightAppCode;

    /**
     * 表单别名
     */
    @ApiModelProperty(value = "关联表单别名")
    private String alias;
    /**
     * 流程ID
     */
    @ApiModelProperty(value = "流程ID")
    private String processId;

}



package com.space.lightapp.entity.vo;

import com.space.lightapp.base.BaseVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 表单设置或者流程设置查询VO
 *
 * @Author ChenYou
 * @date 2021-10-19 21:34
 * @Version 1.0
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "表单设置或者流程设置查询VO")
public class FromOrProcessSelectVO extends BaseVO {

    /**
     * 轻应用Id
     */
    @ApiModelProperty(value = "轻应用Id", required = true)
    private Long lightAppId;
    /**
     * 应用类型
     */
    @ApiModelProperty(value = "应用类型：baseServer,workOrder等等", required = true)
    private String appMarketTypeCode;
    /**
     * 关联Id
     */
    @ApiModelProperty(value = "问卷或者活动Id，没有可以为null")
    private Long relevancyId;

}

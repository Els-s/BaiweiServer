package com.space.lightapp.entity.vo.message;

import java.io.Serializable;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @description: 广告上线、下线
 * @author: JiangHao
 * @date: 2021/11/11 20:13
 */
@Data
@Accessors(chain = true)
public class AdvertisingUnLineVO implements Serializable {

    /**
     * POST {"businessId":141,"status":1}
     */
    /**
     * 业务id
     */
    private Long businessId;

    /**
     * 上下架状态 0：上架 1:下架
     */
    private Long status;


}

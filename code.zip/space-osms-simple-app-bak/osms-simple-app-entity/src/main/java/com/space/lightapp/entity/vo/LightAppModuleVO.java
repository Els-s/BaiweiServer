package com.space.lightapp.entity.vo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.space.lightapp.base.BaseVO;
import com.space.lightapp.entity.LightAppModule;
import com.space.lightapp.entity.PushFormSet;
import com.space.lightapp.entity.PushProcessSet;
import com.space.osms.common.core.utils.DozerBeanUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 轻应用模块Vo对象 light_app_module
 *
 * @author ChenYou
 * @date 2021-09-27
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "轻应用模块")
public class LightAppModuleVO extends BaseVO {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    private Long lightAppModuleId;
    /**
     * 轻应用Id
     */
    @ApiModelProperty(value = "轻应用Id")
    private Long lightAppId;
    /**
     * 应用类型代码
     */
    @ApiModelProperty(value = "应用类型代码")
    private String appMarketTypeCode;
    /**
     * 关联业务Id（工单和基础服务，此字段为null；问卷关联问卷Id，活动关联活动Id）
     */
    @ApiModelProperty(value = "关联业务Id")
    private Long relevancyId;
    /**
     * 轻应用模块代码
     */
    @ApiModelProperty(value = "轻应用模块代码")
    private String lightAppModuleCode;
    /**
     * 模块名称
     */
    @ApiModelProperty(value = "模块名称")
    private String lightAppModuleName;
    /**
     * 模块类型
     */
    @ApiModelProperty(value = "模块类型")
    private String lightAppModuleType;
    /**
     * 排序 排序字段
     */
    @ApiModelProperty(value = "排序 排序字段")
    private Long orderNum;
    /**
     * 状态 0-false-禁用，1-true-启用；默认1-true
     */
    @ApiModelProperty(value = "状态 0-false-禁用，1-true-启用；默认1-true")
    private Boolean status;

    /**
     * 是否删除  0-false-未删除，1-true-删除；默认0-false
     */
    @ApiModelProperty(value = "是否删除  0-false-未删除，1-true-删除；默认0-false")
    private Boolean delFlag;

    /**
     * 高级设置
     */
    @TableField(exist = false)
    private PushAdvancedSetVO pushAdvancedSetVO;


    /**
     * 使用项目
     */
    @TableField(exist = false)
    private List<PushActiveSetVO> pushActiveSetVoList;

    /**
     * 测试人员
     */
    @TableField(exist = false)
    private List<PushTesterSetVO> pushTesterSetVoList;

    /**
     * 表单设置
     */
    @TableField(exist = false)
    private PushFormSet pushFormSet;

    /**
     * 流程设置
     */
    @TableField(exist = false)
    private PushProcessSet pushProcessSet;

    /**
     * Vo转Entity
     *
     * @return Entity对象
     * @date 2021-09-27
     */
    public LightAppModule toEntity() {
        LightAppModule lightAppModule = DozerBeanUtil.transitionType(this, LightAppModule.class);
        return lightAppModule;
    }

    /**
     * List-Vo转List-Entity
     *
     * @return List-Entity对象
     * @date 2021-09-27
     */
    public List<LightAppModule> toListEntity(List<LightAppModuleVO> lightAppModuleVo) {
        List<LightAppModule> list = new ArrayList<>();
        lightAppModuleVo.forEach(t -> list.add(t.toEntity()));
        return list;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("lightAppModuleId", getLightAppModuleId())
                .append("lightAppTemplateId", getLightAppId())
                .append("lightAppModuleCode", getLightAppModuleCode())
                .append("lightAppModuleName", getLightAppModuleName())
                .append("lightAppModuleType", getLightAppModuleType())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

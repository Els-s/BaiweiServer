package com.space.lightapp.consts;

public interface ConstPage {

    Long DEFAULT_PAGE_SIZE = 10L;
    Long DEFAULT_PAGE_INDEX = 1L;
}

package com.space.lightapp.entity.vo.delivery;

import com.space.lightapp.base.BaseVO;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 开启配送
 *
 * @Author ChenYou
 * @date 2022-01-07 14:43
 * @Version 1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class StartDeliveryVO extends BaseVO {

    /**
     * 轻应用Id
     */
    private Long lightAppId;
    /**
     * 轻应用类型
     */
    private String appMarketTypeCode;
    /**
     * 应用小分类
     */
    private String appLittleType;
    /**
     * 下单数据Id
     */
    private Long lightAppServerDataId;
    /**
     * 配送数量
     */
    private Integer deliveryNum;

    /**
     * 备注
     */
    private String remark;

    /**
     *  "单据来源 1 下单用户，2 园区代申请"
     */
    private Integer source;
}

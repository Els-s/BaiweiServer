package com.space.lightapp.enums;

import cn.hutool.core.collection.ListUtil;
import java.util.List;

/**
 * 工单状态枚举类
 *
 * @author ChenYou
 * @date 2021-10-20
 * @Version 1.0
 */
public enum ProcessStateEnum {


    /**
     * WAITING:待受理 HANGDING:处理中 FINISH:已完成 CLOSED:已关闭 VISIT:待回访 CANCEL:已取消
     */
    WAITING(1, "待受理"),
    HANGDING(2, "处理中"),
    FINISH(3, "已完成"),
    CLOSED(4, "已关闭"),
    VISIT(5, "待回访"),
    CANCEL(6, "已取消");

    private Integer code;

    private String info;

    ProcessStateEnum(Integer code, String info) {
        this.code = code;
        this.info = info;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    /**
     * 获取已完结的所有状态
     *
     * @param
     * @return
     */
    public static String getFinishedCodes() {
        return FINISH.code + "," + CLOSED.code + "," + CANCEL.code;
    }

    /**
     * 获取已完结的所有状态
     *
     * @param
     * @return
     */
    public static List<Integer> getFinishedCodeList() {
        return ListUtil.toList(FINISH.code, CLOSED.code, CANCEL.code);
    }

    public static String getInfoValue(Integer code) {
        ProcessStateEnum[] values = ProcessStateEnum.values();
        for (ProcessStateEnum value : values) {
            if (value.getCode().equals(code)) {
                return value.getInfo();
            }
        }
        return "暂无";
    }
}

package com.space.lightapp.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.space.lightapp.base.BaseEntity;
import com.space.lightapp.entity.vo.AppMarketVO;
import com.space.osms.common.core.utils.DozerBeanUtil;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 应用服务 对象 app_market
 *
 * @author ChenYou
 * @date 2021-09-27
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("app_market")
public class AppMarket extends BaseEntity {

    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long appMarketId;
    /**
     * 服务代码
     */
    private String appMarketCode;
    /**
     * 服务名称
     */
    private String appMarketName;
    /**
     * 服务类型代码
     */
    private String appMarketTypeCode;
    /**
     * 排序
     */
    private Long orderNum;
    /**
     * 状态 0-false-禁用，1-true-启用；默认1-true
     */
    private Boolean status;

    /**
     * 备注
     */
    private String remark;
    /**
     * 是否删除 0-false-未删除，1-true-删除；默认0-false
     */
    private Boolean delFlag;
    /**
     * 轻应用
     */
    @ApiModelProperty(hidden = true)
    @TableField(exist = false)
    private List<LightApp> lightAppList;

    /**
     * 状态 0-false-禁用，1-true-启用；默认1-true
     */
    @TableField(exist = false)
    private Boolean lightStatus;

    /**
     * 服务代码
     */
    @TableField(exist = false)
    private Boolean copyStatus;

    /**
     * Entity转Vo
     *
     * @return Vo对象
     * @date 2021-09-27
     */
    public AppMarketVO toVo() {
        AppMarketVO appMarketVo = DozerBeanUtil.transitionType(this, AppMarketVO.class);
        if (this.lightAppList != null) {
            appMarketVo.setLightAppVoList(new LightApp().toListVo(this.lightAppList));
        }
        return appMarketVo;
    }

    /**
     * List-Entity转List-Vo
     *
     * @return List-Vo对象
     * @date 2021-09-27
     */
    public List<AppMarketVO> toListVo(List<AppMarket> appMarket) {
        List<AppMarketVO> list = new ArrayList<>();
        appMarket.forEach(t -> list.add(t.toVo()));
        return list;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("appMarketId", getAppMarketId())
                .append("appMarketCode", getAppMarketCode())
                .append("appMarketName", getAppMarketName())
                .append("appMarketTypeCode", getAppMarketTypeCode())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

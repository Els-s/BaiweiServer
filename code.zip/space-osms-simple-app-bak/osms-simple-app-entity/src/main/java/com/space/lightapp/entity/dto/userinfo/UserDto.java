package com.space.lightapp.entity.dto.userinfo;

import lombok.Data;
import lombok.experimental.Accessors;

/**
 * TODO
 *
 * @Author Els
 * @date 2021-12-17 16:02
 * @Version 1.0
 */
@Data
@Accessors(chain = true)
public class UserDto {

    private String label;
    private String value;
}

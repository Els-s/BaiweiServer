package com.space.lightapp.enums;


/**
 * 模板类型枚举类
 *
 * @author jianghao
 * @date 2021-10-19
 * @Version 1.0
 */
public enum LightAppModuleTypeCodeEnum {
    /**
     * 表单设置
     */
    FROM_SET("fromSet", "表单设置"),
    /**
     * 流程设置
     */
    PROCESS_SET("processSet", "流程设置"),
    /**
     * 高级设置
     */
    ADVANCE_SET("advanceSet", "高级设置"),
    /**
     * 启用设置
     */
    START_SET("startSet", "启用设置"),

    /**
     * 发布测试
     */
    PUSH_SET("pushSet", "发布测试"),
    /**
     * 权限设置
     */
    AUTH_SET("authSet", "权限设置");

    LightAppModuleTypeCodeEnum(String code, String info) {
        this.code = code;
        this.info = info;
    }

    private String code;
    private String info;

    public String getCode() {
        return code;
    }

    public String getInfo() {
        return info;
    }
}

package com.space.lightapp.entity.vo;

import com.space.lightapp.base.BaseVO;
import com.space.lightapp.entity.LightAppCategory;
import com.space.osms.common.core.utils.DozerBeanUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Spaas分类信息存储Vo对象 light_app_category
 *
 * @author ChenYou
 * @date 2021-10-26
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "Spaas分类信息存储")
public class LightAppCategoryVO extends BaseVO {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    private Long id;
    /**
     * spaas分类Id
     */
    @ApiModelProperty(value = "spaas分类Id")
    private String categoryId;
    /**
     * 别名
     */
    @ApiModelProperty(value = "别名")
    private String alias;
    /**
     * 排序 排序字段
     */
    @ApiModelProperty(value = "排序 排序字段")
    private Integer orderNum;
    /**
     * 是否禁用 0禁用，1启用；默认1
     */
    @ApiModelProperty(value = "是否禁用 0禁用，1启用；默认1")
    private Boolean status;
    /**
     * 逻辑删除 0有效，1被删除；默认0
     */
    @ApiModelProperty(value = "逻辑删除 0有效，1被删除；默认0")
    private Boolean delFlag;

    /**
     * Vo转Entity
     *
     * @return Entity对象
     * @date 2021-10-26
     */
    public LightAppCategory toEntity() {
        return DozerBeanUtil.transitionType(this, LightAppCategory.class);
    }

    /**
     * List-Vo转List-Entity
     *
     * @return List-Entity对象
     * @date 2021-10-26
     */
    public List<LightAppCategory> toListEntity(List<LightAppCategoryVO> lightAppCategoryVo) {
        List<LightAppCategory> list = new ArrayList<>();
        lightAppCategoryVo.forEach(t -> list.add(t.toEntity()));
        return list;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("id", getId())
                .append("categoryId", getCategoryId())
                .append("alias", getAlias())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("companyCode", getCompanyCode())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

package com.space.lightapp.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.space.lightapp.base.BaseEntity;
import com.space.lightapp.entity.vo.PushFormFieldVO;
import com.space.osms.common.core.utils.DozerBeanUtil;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 表单字段对象 push_from_field
 *
 * @author ChenYou
 * @date 2021-10-15
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Accessors(chain = true)
@TableName("push_form_field")
public class PushFormField extends BaseEntity {

    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long formFieldId;
    /**
     * 轻应用Id
     */
    private String lightAppId;
    /**
     * 轻应用模块Id
     */
    private String lightAppModuleId;
    /**
     * 数据库字段
     */
    private String formFieldCode;
    /**
     * 中文名称
     */
    private String formFieldName;
    /**
     * 字段类型 字段类型 0基础字段，1表单字段
     */
    private String formFieldType;
    /**
     * 列表是否显示 列表是否显示 0不显示 1显示
     */
    private String showState;
    /**
     * 排序 排序字段
     */
    private Integer orderNum;
    /**
     * 是否禁用 0禁用，1启用；默认1
     */
    private Boolean status;
    /**
     * 备注
     */
    private String remark;

    /**
     * 逻辑删除 0有效，1被删除；默认0
     */
    private Boolean delFlag;

    /**
     * Entity转Vo
     *
     * @return Vo对象
     * @date 2021-10-15
     */
    public PushFormFieldVO toVo() {
        return DozerBeanUtil.transitionType(this, PushFormFieldVO.class);
    }

    /**
     * List-Entity转List-Vo
     *
     * @return List-Vo对象
     * @date 2021-10-15
     */
    public List<PushFormFieldVO> toListVo(List<PushFormField> pushFromField) {
        List<PushFormFieldVO> list = new ArrayList<>();
        pushFromField.forEach(t -> list.add(t.toVo()));
        return list;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("formFieldId", getFormFieldId())
                .append("lightAppId", getLightAppId())
                .append("lightAppModuleId", getLightAppModuleId())
                .append("formFieldCode", getFormFieldCode())
                .append("formFieldName", getFormFieldName())
                .append("formFieldType", getFormFieldType())
                .append("showState", getShowState())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("remark", getRemark())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

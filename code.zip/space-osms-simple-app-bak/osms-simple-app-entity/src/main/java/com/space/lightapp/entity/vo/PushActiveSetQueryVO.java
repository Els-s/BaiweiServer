package com.space.lightapp.entity.vo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.github.dozermapper.core.Mapping;
import com.space.lightapp.base.BaseVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 启用设置Vo对象 push_active_set
 *
 * @author ChenYou
 * @date 2021-09-27
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "启用设置编辑保存")
public class PushActiveSetQueryVO extends BaseVO {


    /**
     * 轻应用id
     */
    @ApiModelProperty(value = "轻应用id")
    private Long lightAppId;
    /**
     * 应用类型代码
     */
    @ApiModelProperty(value = "应用类型代码")
    @TableField(exist = false)
    private String appMarketTypeCode;

    @Mapping()
    @ApiModelProperty(value = "启用设置列表")
    private List<PushActiveSetVO> list;
}

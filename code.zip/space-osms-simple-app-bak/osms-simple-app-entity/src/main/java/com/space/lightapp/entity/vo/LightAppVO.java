package com.space.lightapp.entity.vo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.space.lightapp.base.BaseVO;
import com.space.lightapp.entity.LightApp;
import com.space.osms.common.core.utils.DozerBeanUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 轻应用 Vo对象 light_app
 *
 * @author ChenYou
 * @date 2021-09-27
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "轻应用")
@Accessors(chain = true)
public class LightAppVO extends BaseVO {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    private Long lightAppId;
    /**
     * 应用服务代码
     */
    @ApiModelProperty(value = "应用服务代码")
    private String appMarketCode;
    /**
     * 应用小分类（主要是增值服务小分类较多）
     * <p>
     * appLittleType值：基础服务baseServer->没有流程noNeedBpm,有流程needBpm
     * <p>
     * 增值服务payServer->商品线上goodOnLine，服务线上serverOnline，服务线下serverOffLine
     */
    @ApiModelProperty(value = "应用小分类（主要是增值服务小分类较多）"
            + "appLittleType值：基础服务baseServer->没有流程noNeedBpm,有流程needBpm"
            + "增值服务payServer->商品线上goodOnLine，服务线上serverOnline，服务线下serverOffLine")
    private String appLittleType;
    /**
     * 应用服务类型 冗余
     */
    @ApiModelProperty(value = "应用服务类型 冗余")
    private String appMarketTypeCode;
    /**
     * 任务中心唯一标识码
     */
    @ApiModelProperty(value = "任务中心唯一标识码")
    private String taskTypeCode;
    /**
     * 轻应用代码
     */
    @ApiModelProperty(value = "轻应用代码")
    private String lightAppCode;
    /**
     * 轻应用名称
     */
    @ApiModelProperty(value = "轻应用名称")
    private String lightAppName;
    /**
     * 应用标志 flag_complaint flag_suggest flag_question flag_activity
     */
    private String appFlagType;
    /**
     * 轻应用状态
     */
    @ApiModelProperty(value = "轻应用状态 draft草稿，test测试，upline上线，下线downline")
    private String lightAppType;
    /**
     * 图标
     */
    @ApiModelProperty(value = "图标")
    private String iconUrl;

    /**
     * 排序 排序字段
     */
    @ApiModelProperty(value = "排序 排序字段")
    private Long orderNum;
    /**
     * 状态 0-false-禁用，1-true-启用；默认1-true
     */
    @ApiModelProperty(value = "状态 0-false-禁用，1-true-启用；默认1-true")
    private Boolean status;
    /**
     * 【发布测试】状态是否开启 o未开启;1启用 默认1-true
     */
    @ApiModelProperty(value = "【发布测试】状态是否开启 o未开启;1启用 默认1-true")
    private Boolean releaseOpenState;
    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String remark;
    /**
     * 是否删除  0-false-未删除，1-true-删除；默认0-false
     */
    @ApiModelProperty(value = "是否删除  0-false-未删除，1-true-删除；默认0-false")
    private Boolean delFlag;

    private Boolean existTaskCentreCode;

    /**
     * 模块集合
     */
    @TableField(exist = false)
    private List<LightAppModuleVO> lightAppModuleVoList;


    /**
     * 字典数据
     */
    @TableField(exist = false)
    private List<DictDataVO> dictDataVoList;

    /**
     * 字典类型
     */
    @TableField(exist = false)
    private List<DictTypeVO> dictTypeVoList;
    /**
     * 是否允许代客入单：0 全部，1仅仅代客入单，2仅仅非代客入单
     */
    @ApiModelProperty(value = "是否允许代客入单：0 全部，1仅仅代客入单，2仅仅非代客入单")
    private String repGuestOrder;
    /**
     * 启用项目
     */
    @TableField(exist = false)
    private List<PushActiveSetVO> pushActiveSetVoList;
    /**
     * 是否有操作权限
     */
    @ApiModelProperty(value = "是否有操作权限")
    private Boolean hasHandleType;


    /**
     * Vo转Entity
     *
     * @return Entity对象
     * @date 2021-09-27
     */
    public LightApp toEntity() {
        LightApp lightApp = DozerBeanUtil.transitionType(this, LightApp.class);
        return lightApp;
    }

    /**
     * List-Vo转List-Entity
     *
     * @return List-Entity对象
     * @date 2021-09-27
     */
    public List<LightApp> toListEntity(List<LightAppVO> lightAppVo) {
        List<LightApp> list = new ArrayList<>();
        lightAppVo.forEach(t -> list.add(t.toEntity()));
        return list;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("lightAppId", getLightAppId())
                .append("appMarketCode", getAppMarketCode())
                .append("appMarketTypeCode", getAppMarketTypeCode())
                .append("lightAppCode", getLightAppCode())
                .append("lightAppName", getLightAppName())
                .append("lightAppType", getLightAppType())
                .append("iconUrl", getIconUrl())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("releaseOpenState", getReleaseOpenState())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

package com.space.lightapp.entity.vo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.space.lightapp.base.BaseVO;
import com.space.lightapp.entity.PushAdvancedSet;
import com.space.osms.common.core.utils.DozerBeanUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 高级设置Vo对象 push_advanced_set
 *
 * @author ChenYou
 * @date 2021-10-09
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel(description = "高级设置")
public class PushAdvancedSetVO extends BaseVO {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    private Long pushAdvancedSetId;
    /**
     * 应用模块Id
     */
    @ApiModelProperty(value = "应用模块Id")
    private Long lightAppModuleId;
    /**
     * 轻应用id
     */
    @ApiModelProperty(value = "轻应用id")
    private Long lightAppId;
    /**
     * 服务发起角色 client客户使用，inside内部使用,多个用英文逗号隔开
     */
    @ApiModelProperty(value = "服务发起角色 client客户使用，inside内部使用,多个用英文逗号隔开")
    private String serverLaunchRole;
    /**
     * C端用户发起最低等级 tourist游客   commonUser普通用户   companyEmployee企业员工   companyManager企业管理员,多种类型英文逗号隔开
     */
    @ApiModelProperty(value = "C端用户发起最低等级 tourist游客   commonUser普通用户   companyEmployee企业员工   companyManager企业管理员,多种类型英文逗号隔开")
    private String serverLaunchUser;
    /**
     * 企业管理员可见员工数据 0否，1是
     */
    @ApiModelProperty(value = "企业管理员可见员工数据 0否，1是")
    private Boolean seeEmployeeData;
    /**
     * 是否允许代客录单 0否，1是
     */
    @ApiModelProperty(value = "是否允许代客录单 0否，1是")
    private Boolean repGuestOrder;
    /**
     * 是否允许需要打印模板 0否，1是
     */
    @ApiModelProperty(value = "否允许需要打印模板 0否，1是")
    private Boolean needPrintTemplate;
    /**
     * 打印模板编号
     */
    @ApiModelProperty(value = "打印模板编号")
    private String printTemplateCode;
    /**
     * 运营方 单选（1自营，2第三方）
     */
    @ApiModelProperty(value = "运营方 单选（1自营，2第三方）")
    private Integer operator;
    /**
     * 结算方式 1现结，2企业周期结算，多选英文逗号隔开
     */
    @ApiModelProperty(value = "结算方式 1现结，2企业周期结算，多选英文逗号隔开")
    private String payWay;
    /**
     * 现结限时支付时间 (限时数值（正整数）)
     */
    @ApiModelProperty(value = "现结限时支付时间 (限时数值（正整数）)")
    private Integer pastTimeNum;
    /**
     * 现结限时支付时间单位（月month，天day，小时hour，分钟minute，秒second）
     */
    @ApiModelProperty(value = "现结限时支付时间单位（月month，天day，小时hour，分钟minute，秒second）")
    private String pastTimeUnit;
    /**
     * 企业管理员审核 是否需要审核（0 不需要，1需要）
     */
    @ApiModelProperty(value = "企业管理员审核 是否需要审核（0 不需要，1需要）")
    private Boolean needCheck;
    /**
     * 是否开启配送时间显示
     */
    @ApiModelProperty(value = "是否开启配送时间显示")
    private Boolean openSendTime;
    /**
     * 配送方式 once 一次配送，multiple多次配送
     */
    @ApiModelProperty(value = "配送方式 once 一次配送，multiple多次配送")
    private String sendWay;
    /**
     * 配送方式名称
     */
    @ApiModelProperty(value = "配送方式名称")
    private String sendWayName;
    /**
     * 多次配送最低数量：设置了多次配送，且数量大于等于此（默认2）
     */
    @ApiModelProperty(value = "多次配送最低数量：设置了多次配送，且数量大于等于此（默认2）")
    private Long multipleMinNum;
    /**
     * 配送时间输入框
     */
    @ApiModelProperty(value = "配送时间输入框")
    private String sendTime;
    /**
     * 配送起始时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date sendStartTime;
    /**
     * 配送终止时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date sendEndTime;
    /**
     * 排序 排序字段
     */
    @ApiModelProperty(value = "排序 排序字段")
    private Integer orderNum;
    /**
     * 是否禁用 0禁用，1启用；默认1
     */
    @ApiModelProperty(value = "是否禁用 0禁用，1启用；默认1")
    private Boolean status;

    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String remark;
    /**
     * 逻辑删除 0有效，1被删除；默认0
     */
    @ApiModelProperty(value = "逻辑删除 0有效，1被删除；默认0")
    private Boolean delFlag;

    /**
     * 应用类型代码
     */
    @ApiModelProperty(value = "应用类型代码")
    @TableField(exist = false)
    private String appMarketTypeCode;

    /**
     * Vo转Entity
     *
     * @return Entity对象
     * @date 2021-10-09
     */
    public PushAdvancedSet toEntity() {
        return DozerBeanUtil.transitionType(this, PushAdvancedSet.class);
    }

    /**
     * List-Vo转List-Entity
     *
     * @return List-Entity对象
     * @date 2021-10-09
     */
    public List<PushAdvancedSet> toListEntity(List<PushAdvancedSetVO> pushAdvancedSetVo) {
        List<PushAdvancedSet> list = new ArrayList<>();
        pushAdvancedSetVo.forEach(t -> list.add(t.toEntity()));
        return list;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("pushAdvancedSetId", getPushAdvancedSetId())
                .append("lightAppModuleId", getLightAppModuleId())
                .append("serverLaunchRole", getServerLaunchRole())
                .append("serverLaunchUser", getServerLaunchUser())
                .append("seeEmployeeData", getSeeEmployeeData())
                .append("repGuestOrder", getRepGuestOrder())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("remark", getRemark())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

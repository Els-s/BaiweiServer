package com.space.lightapp.entity.vo;

import com.space.lightapp.base.BaseVO;
import com.space.lightapp.entity.LightAppServer;
import com.space.lightapp.enums.AppMarketTypeEnum;
import com.space.osms.common.core.utils.DozerBeanUtil;
import com.space.osms.common.core.utils.ListUtil;
import com.space.osms.common.file.annotation.Excel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 服务设置 Vo对象 light_app_server
 *
 * @author ChenYou
 * @date 2021-11-04
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(description = "服务设置 ")
public class LightAppServerVO extends BaseVO {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    private Long serverId;
    /**
     * 轻应用Id
     */
    @ApiModelProperty(value = "轻应用Id")
    private Long lightAppId;
    /**
     * 服务名称
     */
    @ApiModelProperty(value = "服务名称")
    private String serverName;
    /**
     * 服务代码
     */
    @ApiModelProperty(value = "服务代码")
    private String serverCode;
    /**
     * 任务中心唯一编码
     */
    @ApiModelProperty(value = "任务中心唯一编码")
    private String taskTypeCode;
    /**
     * 服务分类
     */
    @ApiModelProperty(value = "服务分类")
    private String serverTypeId;
    /**
     * 服务分类名称
     */
    @ApiModelProperty(value = "服务分类名称")
    @Excel(name = "分类名称", sort = 2)
    private String serverTypeName;
    /**
     * 服务海报
     */
    @ApiModelProperty(value = "服务海报列表")
    private List<String> serverIconList;
    /**
     * 标签提示 1不显示，2免费，3价格面议
     */
    @ApiModelProperty(value = "标签提示 1不显示，2免费，3价格面议")
    private Integer tagHint;
    /**
     * 商品编号
     */
    @Excel(name = "服务编码", sort = 1)
    @ApiModelProperty(value = "商品编号")
    private String goodsCode;
    /**
     * 商品名称
     */
    @Excel(name = "商品名称", sort = 3)
    @ApiModelProperty(value = "商品名称")
    private String goodsName;
    /**
     * 商品详情(存的JSON)，支持一个商品多个规格，多个计费，多种单位等等
     */
    @ApiModelProperty(value = "商品详情(存的JSON):")
    private String goodsDetail;
    /**
     * 规格
     */
    @ApiModelProperty(value = "规格")
    private String specification;
    /**
     * 单位
     */
    @ApiModelProperty(value = "单位")
    private String unitName;
    /**
     * 是否固定定价 价格类型：1固定定价，2沟通定价
     */
    @ApiModelProperty(value = "是否固定定价 价格类型：1固定定价，2沟通定价")
    private Integer priceType;
    /**
     * 标准单价
     */
    @ApiModelProperty(value = "标准单价")
    private String price;
    /**
     * 咨询电话
     */
    @ApiModelProperty(value = "咨询电话")
    private String hotline;
    /**
     * 计算公式
     */
    @ApiModelProperty(value = "计算公式")
    private String formula;
    /**
     * 图片 多个图片用英文逗号隔开
     */
    @ApiModelProperty(value = "图片 多个图片用英文逗号隔开")
    private List<String> photoLists;
    /**
     * 服务状态 draft草稿，upLine上架，downLine下架
     */
    @ApiModelProperty(value = "服务状态 draft草稿，upLine上架，downLine下架")
    private String serverState;
    /**
     * 服务内容是否开启 0不开启，1开启；默认开启
     */
    @ApiModelProperty(value = "服务内容是否开启 0不开启，1开启；默认开启")
    private Boolean openContent;
    /**
     * 服务内容
     */
    @ApiModelProperty(value = "服务内容")
    private String serverContent;
    /**
     * 常见问题是否开启 0不开启，1开启；默认开启
     */
    @ApiModelProperty(value = "常见问题是否开启 0不开启，1开启；默认开启")
    private Boolean openIssue;
    /**
     * 常见问题
     */
    @ApiModelProperty(value = "常见问题")
    private String issue;
    /**
     * 排序 排序字段
     */
    @ApiModelProperty(value = "排序 排序字段")
    private Integer orderNum;
    /**
     * 是否禁用 0禁用，1启用；默认1
     */
    @ApiModelProperty(value = "是否禁用 0禁用，1启用；默认1")
    private Boolean status;

    @Excel(name = "状态", sort = 4)
    @ApiModelProperty(value = "是否禁用 0禁用，1启用；默认1")
    private String statusVo;
    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String remark;
    /**
     * 逻辑删除 0有效，1被删除；默认0
     */
    @ApiModelProperty(value = "逻辑删除 0有效，1被删除；默认0")
    private Boolean delFlag;

    @Excel(name = "最近更新人", sort = 5)
    private String updateUser;

    @Excel(name = "创建时间", sort = 6)
    private String createDate;

    private String sendTime;
    /**
     * 应用小分类（主要是增值服务小分类较多）
     * <p>
     * appLittleType值：基础服务baseServer->没有流程noNeedBpm,有流程needBpm
     * <p>
     * 增值服务payServer->商品线上goodOnLine，服务线上serverOnline，服务线下serverOffLine
     */
    @ApiModelProperty(value = "应用小分类（主要是增值服务小分类较多）appLittleType值：基础服务baseServer->没有流程noNeedBpm,有流程needBpm  增值服务payServer->商品线上goodOnLine，服务线上serverOnline，服务线下serverOffLine")
    private String appLittleType;
    /**
     * 表单配置详情
     */
    @ApiModelProperty(value = "表单配置详情")
    private PushFormSetVO pushFromSetVO;
    /**
     * 表单配置详情
     */
    private String appMarketTypeCode = AppMarketTypeEnum.PAY_SERVER.getCode();

    /**
     * Vo转Entity
     *
     * @return Entity对象
     * @date 2021-11-04
     */
    public LightAppServer toEntity() {
        LightAppServer lightAppServer = DozerBeanUtil.transitionType(this, LightAppServer.class);
        lightAppServer.setServerIcon(ListUtil.listToString(this.getServerIconList()));
        lightAppServer.setPhotoList(ListUtil.listToString(this.getPhotoLists()));
        return lightAppServer;
    }

    /**
     * List-Vo转List-Entity
     *
     * @return List-Entity对象
     * @date 2021-11-04
     */
    public List<LightAppServer> toListEntity(List<LightAppServerVO> lightAppServerVo) {
        List<LightAppServer> list = new ArrayList<>();
        lightAppServerVo.forEach(t -> list.add(t.toEntity()));
        return list;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("serverId", getServerId())
                .append("serverName", getServerName())
                .append("serverCode", getServerCode())
                .append("taskTypeCode", getTaskTypeCode())
                .append("serverTypeId", getServerTypeId())
                .append("tagHint", getTagHint())
                .append("goodsCode", getGoodsCode())
                .append("goodsName", getGoodsName())
                .append("specification", getSpecification())
                .append("unitName", getUnitName())
                .append("priceType", getPriceType())
                .append("price", getPrice())
                .append("hotline", getHotline())
                .append("formula", getFormula())
                .append("photoLists", getPhotoLists())
                .append("serverState", getServerState())
                .append("openContent", getOpenContent())
                .append("serverContent", getServerContent())
                .append("openIssue", getOpenIssue())
                .append("issue", getIssue())
                .append("orderNum", getOrderNum())
                .append("status", getStatus())
                .append("tenementCode", getTenementCode())
                .append("projectCode", getProjectCode())
                .append("companyCode", getCompanyCode())
                .append("remark", getRemark())
                .append("createBy", getCreateBy())
                .append("createTime", getCreateTime())
                .append("updateBy", getUpdateBy())
                .append("updateTime", getUpdateTime())
                .append("delFlag", getDelFlag())
                .toString();
    }

}

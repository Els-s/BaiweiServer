package com.space.lightapp.enums;

/**
 * 记录数据table
 *
 * @Author ChenYou
 * @date 2021-12-29 16:50
 * @Version 1.0
 */
public enum DataUpdateRecordEnum {
    // 增值服务
    LIGHT_APP_SERVER_DATA("light_app_server_data", "增值服务");
    private String code;
    private String info;

    DataUpdateRecordEnum(String code, String info) {
        this.code = code;
        this.info = info;
    }

    public String getCode() {
        return code;
    }

    public String getInfo() {
        return info;
    }
}

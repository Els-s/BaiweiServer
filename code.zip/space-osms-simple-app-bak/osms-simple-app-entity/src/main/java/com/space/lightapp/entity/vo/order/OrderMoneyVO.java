package com.space.lightapp.entity.vo.order;

import com.space.lightapp.entity.dto.order.OrderDTO;
import com.space.lightapp.entity.vo.LightAppServerDataVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.math.BigDecimal;
import java.util.List;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * 下单价格
 *
 * @Author ChenYou
 * @date 2021-11-17 11:07
 * @Version 1.0
 */
@Data
@Accessors(chain = true)
@ApiModel(description = "价格计算")
public class OrderMoneyVO {

    /**
     * 服务小分类
     */
    @ApiModelProperty(value = "服务小分类:商品线上 goodOnLine，服务线上 serverOnline，服务线下 serverOffLine")
    private String appLittleType;
    /**
     * 服务Id
     */
    @ApiModelProperty(value = "服务Id")
    private Long serverId;
    /**
     * 服务规格信息
     */
    @ApiModelProperty(value = "服务规格信息")
    private List<SpecificationVO> specificationVos;
    /**
     * 单价
     */
    @ApiModelProperty(value = "单价", required = true)
    private BigDecimal price;
    /**
     * 数量
     */
    @ApiModelProperty(value = "购买数量", required = true)
    private Integer buyNum;
    /**
     * 服务时长
     */
    @ApiModelProperty(value = "服务时长:非服务类的传1", required = true)
    private Integer duration;
    /**
     * 订单价格
     */
    @ApiModelProperty(value = "订单价格")
    private BigDecimal orderMoney;
    /**
     * 应付金额
     */
    @ApiModelProperty(value = "应付金额")
    private BigDecimal buyMoney;
    /**
     * 冗余 下单数据
     */
    @ApiModelProperty(value = "业务服务数据")
    private LightAppServerDataVO serverData;
    /**
     * 冗余 下单数据
     */
    @ApiModelProperty(value = "下单数据")
    private OrderDTO order;

}

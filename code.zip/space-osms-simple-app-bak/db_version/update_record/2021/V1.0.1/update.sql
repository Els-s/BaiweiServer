/**---------V1.0.1.0-----------START---*/
ALTER TABLE `osms_light_app`.`push_apply_data`
  CHANGE `sign_type` `sign_type` INT(1) DEFAULT 0  NULL   COMMENT '签到状态 1已签到，0未签到';
/**---------V1.0.1.0-----------END-----*/

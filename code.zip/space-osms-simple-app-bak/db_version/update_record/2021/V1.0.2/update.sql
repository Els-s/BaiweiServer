-- 增加活动提单人详情数据
ALTER TABLE `push_apply_data`
    ADD COLUMN `bill_user_detail`  text NULL COMMENT '提表人详情' AFTER `user_code`;
-- 高级设置
ALTER TABLE `push_advanced_set`
  ADD COLUMN `open_send_time` INT(1) DEFAULT 0  NULL   COMMENT '是否开启配送时间：0不开启，1开启' AFTER `past_time_unit`;
-- 活动填写数据
ALTER TABLE `osms_light_app`.`push_apply_data`
  CHANGE `apply_type` `apply_type` INT(1) DEFAULT 0  NULL   COMMENT '报名状态 1报名成功，0报名失败';
-- 报名设置
ALTER TABLE `osms_light_app`.`push_apply_set`
  CHANGE `need_money` `need_money` INT(0) NULL   COMMENT '是否需要报名费用 0不需要，1需要';


/**---------V1.0.0.3-----------START---*/
/**增加结算状态 */
ALTER TABLE `light_app_server_data`
ADD COLUMN `tax_status`  tinyint(2) NULL DEFAULT 0 COMMENT '结算状态' AFTER `del_flag`;
/**---------V1.0.0.3-----------END-----*/

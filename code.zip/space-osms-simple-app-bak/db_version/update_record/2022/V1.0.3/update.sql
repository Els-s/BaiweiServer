-- 前言和结束语内容限制加长
ALTER TABLE `light_app_survey`
CHANGE `foreword` `foreword` VARCHAR(1000) CHARSET utf8mb4 COLLATE utf8mb4_general_ci NULL   COMMENT '前言',
CHANGE `tag` `tag` VARCHAR(1000) CHARSET utf8mb4 COLLATE utf8mb4_general_ci NULL   COMMENT '结束语';

-- 活动地址和活动内容限制加长
ALTER TABLE `light_app_activity`
  CHANGE `activity_address` `activity_address` VARCHAR(500) CHARSET utf8mb4 COLLATE utf8mb4_general_ci NULL   COMMENT '活动地址',
  CHANGE `activity_content` `activity_content` TEXT CHARSET utf8mb4 COLLATE utf8mb4_general_ci NULL   COMMENT '活动内容';

-- 添加活动业务状态
ALTER TABLE `push_apply_data`
  CHANGE `business_state` `business_state` VARCHAR(64) CHARSET utf8mb4 COLLATE utf8mb4_general_ci NULL   COMMENT '业务状态(1待支付，2已报名，3报名待审核中，4已签到，5退款中，6退款失败，7退款成功，8报名审核不通过)';

--排序字段名修改
ALTER TABLE `osms_light_app`.`push_advertising_set`
  CHANGE `order_num` `show_order` INT(1) NULL   COMMENT '排序 排序字段';

ALTER TABLE `osms_light_app`.`push_advertising_set`
  ADD COLUMN `end_date` DATETIME NULL   COMMENT '到期时间' AFTER `end_time`;

ALTER TABLE `osms_light_app`.`push_information_set`
  CHANGE `release_locations` `release_location_list` VARCHAR(512) CHARSET utf8mb4 COLLATE utf8mb4_general_ci NULL   COMMENT '发布位置 发布位置 多选时List<String>数组 目前只需要单选',
  CHANGE `project_codes` `project_code_list` VARCHAR(512) CHARSET utf8mb4 COLLATE utf8mb4_general_ci NULL   COMMENT '发布范围--',
  CHANGE `cover_urls` `cover_url_list` VARCHAR(1024) CHARSET utf8mb4 COLLATE utf8mb4_general_ci NULL   COMMENT '资讯封面';

ALTER TABLE `osms_light_app`.`push_information_set`
  CHANGE `long_term` `long_term` INT(11) DEFAULT 0  NULL   COMMENT '是否长期 是否长期  0否 1是';
ALTER TABLE `osms_light_app`.`push_advertising_set`
  CHANGE `long_term` `long_term` INT(1) DEFAULT 0  NULL   COMMENT '是否长期 是否长期  0否 1是';


-- 增加修改记录表
CREATE TABLE data_update_record(
    data_update_id BIGINT NOT NULL AUTO_INCREMENT  COMMENT '主键' ,
    light_app_id BIGINT    COMMENT '应用Id' ,
    table_name VARCHAR(64)    COMMENT '对应表数据' ,
    table_primary_key VARCHAR(64)    COMMENT '对应主键' ,
    update_reason VARCHAR(64)    COMMENT '修改原因' ,
    original_data TEXT    COMMENT '原数据 json格式' ,
    change_data TEXT    COMMENT '修改后数据 json格式' ,
    status INT(1)   DEFAULT 1 COMMENT '是否禁用 0禁用，1启用；默认1' ,
    tenement_code VARCHAR(64)    COMMENT '租户编码' ,
    project_code VARCHAR(64)    COMMENT '园区编码' ,
    company_code VARCHAR(64)    COMMENT '企业编码' ,
    remark TEXT    COMMENT '备注' ,
    create_by VARCHAR(64)    COMMENT '创建人' ,
    create_time DATETIME    COMMENT '创建时间' ,
    update_by VARCHAR(64)    COMMENT '更新人' ,
    update_time DATETIME    COMMENT '更新时间' ,
    del_flag INT(1)   DEFAULT 0 COMMENT '逻辑删除 0有效，1被删除；默认0' ,
    PRIMARY KEY (data_update_id)
) COMMENT = '数据修改记录 ';

-- 增加创建订单状态
ALTER TABLE `light_app_server_data`
    ADD COLUMN `create_order_status`  tinyint(1) NULL COMMENT '订单中心创建订单结果 1-创建成功，-1-创建失败，0-未创建' AFTER `space_code`;

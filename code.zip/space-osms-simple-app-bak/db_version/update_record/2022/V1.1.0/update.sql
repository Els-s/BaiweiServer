--  多次配送详情
CREATE TABLE light_app_server_data_delivery
(
    server_data_delivery_id  BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键',
    light_app_id             BIGINT COMMENT '轻应用Id',
    server_data_id           BIGINT COMMENT '服务数据Id',
    server_id                BIGINT COMMENT '服务Id',
    server_type_id           BIGINT COMMENT '服务分类Id',
    order_code               VARCHAR(64) COMMENT '配送服务编码 配送编码',
    delivery_num             INT COMMENT '配送数量',
    process_key              VARCHAR(64) COMMENT '流程key',
    process_ins_id           VARCHAR(64) COMMENT '流程定义Id',
    process_node_user        VARCHAR(1024) COMMENT '当前节点处理人',
    process_node_user_detail TEXT COMMENT '处理人详情',
    data_id                  VARCHAR(64) COMMENT '对应数据Id',
    task_id                  VARCHAR(64) COMMENT '任务Id',
    process_state            VARCHAR(256) COMMENT '流程节点状态',
    business_state           VARCHAR(64) DEFAULT 'delivery_start_ing' COMMENT '配送状态 delivery_start_ing 启动中，delivery_ing进行中，delivery_success成功配送,delivery_cancel配送取消,delivery_reject已拒绝',
    process_start_status     INT(1)      DEFAULT 0 COMMENT '流程启动结果 流程启动结果 流程启动结果，1-启动成功，-1-启动失败，0-未启动流程',
    first_handle_name        VARCHAR(64) COMMENT '第一个节点处理人',
    last_handle_name         VARCHAR(64) COMMENT '最后节点处理人',
    form_id                  VARCHAR(64) COMMENT '表单Id',
    source                   INT(1) COMMENT '单据来源 1内部单，2客户下单，3代客下单',
    order_num                INT(4) COMMENT '排序 排序字段',
    STATUS                   INT(1)      DEFAULT 1 COMMENT '是否禁用 0禁用，1启用；默认1',
    tenement_code            VARCHAR(64) COMMENT '租户编码',
    project_code             VARCHAR(64) COMMENT '园区编码',
    company_code             VARCHAR(64) COMMENT '企业编码',
    remark                   TEXT COMMENT '备注',
    create_by                VARCHAR(64) COMMENT '创建人',
    create_time              DATETIME COMMENT '创建时间',
    update_by                VARCHAR(64) COMMENT '更新人',
    update_time              DATETIME COMMENT '更新时间',
    del_flag                 INT(1)      DEFAULT 0 COMMENT '逻辑删除 0有效，1被删除；默认0',
    untitled                 VARCHAR(64) COMMENT '',
    PRIMARY KEY (server_data_delivery_id)
) COMMENT = '服务下单配送详情';
-- 数据处理记录
CREATE TABLE `handle_data_his`
(
    `id`          int          NOT NULL AUTO_INCREMENT,
    `type`        varchar(200) NULL,
    `name`        varchar(200) NULL,
    `version`     varchar(100) NULL,
    `create_time` datetime     NULL,
    `project`     varchar(100) NULL,
    `tenant`      varchar(100) NULL,
    PRIMARY KEY (`id`)
) COMMENT = '数据处理记录';

-- 添加已经配送数量字段
ALTER TABLE `light_app_server_data`
    ADD COLUMN `delivery_num` INT(10) DEFAULT 0 NULL COMMENT '服务数量（包含完成和进行中）' AFTER `buy_num`,
    ADD COLUMN `refund_num`   INT(10) DEFAULT 0 NULL COMMENT '退款数量（包含完成和进行中）' AFTER `delivery_num`;

-- 添加配送方式设置
ALTER TABLE `push_advanced_set`
    ADD COLUMN `send_way`         VARCHAR(32) DEFAULT 'once' NULL COMMENT 'once（默认） 一次配送，multiple 多次配送' AFTER `open_send_time`,
    ADD COLUMN `multiple_min_num` INT(1)      DEFAULT 2      NULL COMMENT '多次配送最低数量（默认2，商品如果只下单一个）' AFTER `send_way`;

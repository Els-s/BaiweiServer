文件说明：
    初始化数据库结构脚本：init_table.sql
    初始化字典数据脚本：init_data.sql
    数据清理脚本：cleanData.sql

轻应用初始化版本注意事项：
1：提供表单存储数据库配置给Spaas配置。
2：增值服务需要初始化退款，周期结算等流程，把流程key写入数据库表：public_process。
3：初始化基本数据到数据库：init_data.sql。
4：任务中心初始化父类型数据到数据库。
5：Spaas Nacos配置需增加回调轻应用代码配置。MQ消息配置。
6：订单中心初始化开票和费项相关数据。

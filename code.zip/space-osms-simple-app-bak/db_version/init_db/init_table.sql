/*
SQLyog Ultimate v12.08 (64 bit)
MySQL - 5.7.32 : Database - osms_light_app
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `app_market` */

DROP TABLE IF EXISTS `app_market`;

CREATE TABLE `app_market` (
  `app_market_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `app_market_code` varchar(64) DEFAULT NULL COMMENT '服务代码',
  `app_market_name` varchar(64) DEFAULT NULL COMMENT '服务名称',
  `app_market_type_code` varchar(64) DEFAULT NULL COMMENT '服务类型代码',
  `order_num` int(1) DEFAULT NULL COMMENT '排序',
  `status` int(1) DEFAULT '1' COMMENT '状态 0禁用，1启用；默认1',
  `tenement_code` varchar(64) DEFAULT NULL COMMENT '租户编码',
  `project_code` varchar(64) DEFAULT NULL COMMENT '园区编码',
  `company_code` varchar(64) DEFAULT NULL COMMENT '企业编码',
  `remark` text COMMENT '备注',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `del_flag` int(1) DEFAULT '0' COMMENT '逻辑删除 0有效，1被删除；默认0',
  PRIMARY KEY (`app_market_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COMMENT='应用服务';

/*Table structure for table `app_market_type` */

DROP TABLE IF EXISTS `app_market_type`;

CREATE TABLE `app_market_type` (
  `app_market_type_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `app_market_type_code` varchar(64) DEFAULT NULL COMMENT '应用服务类型代码',
  `app_market_type_name` varchar(64) DEFAULT NULL COMMENT '应用服务类型名称',
  `order_num` int(1) DEFAULT NULL COMMENT '排序 排序字段',
  `status` int(1) DEFAULT '1' COMMENT '状态 0禁用，1启用；默认1',
  `tenement_code` varchar(64) DEFAULT NULL COMMENT '租户编码',
  `project_code` varchar(64) DEFAULT NULL COMMENT '园区编码',
  `company_code` varchar(64) DEFAULT NULL COMMENT '企业编码',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `del_flag` int(1) DEFAULT '0' COMMENT '逻辑删除 0有效，1被删除；默认0',
  PRIMARY KEY (`app_market_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COMMENT='应用服务类型-模板数据初始化';

/*Table structure for table `data_update_record` */

DROP TABLE IF EXISTS `data_update_record`;

CREATE TABLE `data_update_record` (
  `data_update_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `light_app_id` bigint(20) DEFAULT NULL COMMENT '应用Id',
  `table_name` varchar(64) DEFAULT NULL COMMENT '对应表数据',
  `table_primary_key` varchar(64) DEFAULT NULL COMMENT '对应主键',
  `update_reason` varchar(64) DEFAULT NULL COMMENT '修改原因',
  `original_data` text COMMENT '原数据 json格式',
  `change_data` text COMMENT '修改后数据 json格式',
  `status` int(1) DEFAULT '1' COMMENT '是否禁用 0禁用，1启用；默认1',
  `tenement_code` varchar(64) DEFAULT NULL COMMENT '租户编码',
  `project_code` varchar(64) DEFAULT NULL COMMENT '园区编码',
  `company_code` varchar(64) DEFAULT NULL COMMENT '企业编码',
  `remark` text COMMENT '备注',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `del_flag` int(1) DEFAULT '0' COMMENT '逻辑删除 0有效，1被删除；默认0',
  PRIMARY KEY (`data_update_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COMMENT='数据修改记录 ';

/*Table structure for table `dict_data` */

DROP TABLE IF EXISTS `dict_data`;

CREATE TABLE `dict_data` (
  `dict_data_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `dict_type_id` bigint(20) DEFAULT NULL COMMENT '字典类型',
  `dict_data_code` varchar(64) DEFAULT NULL COMMENT '字典内容编码：默认DATA开头',
  `dict_data_name` varchar(64) DEFAULT NULL COMMENT '字典名称',
  `parent_id` bigint(20) DEFAULT NULL COMMENT '父级Id',
  `order_num` int(1) DEFAULT NULL COMMENT '排序 排序字段',
  `status` int(1) DEFAULT '1' COMMENT '状态0禁用，1启用；默认1',
  `tenement_code` varchar(64) DEFAULT NULL COMMENT '租户编码',
  `project_code` varchar(64) DEFAULT NULL COMMENT '园区编码',
  `company_code` varchar(64) DEFAULT NULL COMMENT '企业编码',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `del_flag` int(1) DEFAULT '0' COMMENT '逻辑删除 0有效，1被删除；默认0',
  PRIMARY KEY (`dict_data_id`)
) ENGINE=InnoDB AUTO_INCREMENT=258 DEFAULT CHARSET=utf8mb4 COMMENT='字典数据';

/*Table structure for table `dict_type` */

DROP TABLE IF EXISTS `dict_type`;

CREATE TABLE `dict_type` (
  `dict_type_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `dict_class_code` varchar(64) DEFAULT NULL COMMENT '项目分类：public公共分类',
  `light_app_id` bigint(20) DEFAULT NULL COMMENT '轻应用Id',
  `dict_type_code` varchar(64) DEFAULT NULL COMMENT '类型代码',
  `dict_type_name` varchar(64) DEFAULT NULL COMMENT '类型名称',
  `order_num` int(1) DEFAULT NULL COMMENT '排序 排序字段',
  `status` int(1) DEFAULT '1' COMMENT '状态 0禁用，1启用；默认1',
  `tenement_code` varchar(64) DEFAULT NULL COMMENT '租户编码',
  `project_code` varchar(64) DEFAULT NULL COMMENT '园区编码',
  `company_code` varchar(64) DEFAULT NULL COMMENT '企业编码',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `del_flag` int(1) DEFAULT '0' COMMENT '逻辑删除 0有效，1被删除；默认0',
  PRIMARY KEY (`dict_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=169 DEFAULT CHARSET=utf8mb4 COMMENT='字典类型';

/*Table structure for table `form_inst_relation` */

DROP TABLE IF EXISTS `form_inst_relation`;

CREATE TABLE `form_inst_relation` (
  `rel_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '关联关系ID',
  `inst_id` varchar(64) DEFAULT NULL COMMENT '主键',
  `alisa` varchar(64) NOT NULL COMMENT '表单别名',
  `data_id` varchar(64) NOT NULL COMMENT '数据ID',
  `light_app_id` bigint(20) DEFAULT NULL COMMENT '轻应用id',
  `user_phone` varchar(64) DEFAULT NULL COMMENT '报单人-手机号',
  `user_code` varchar(64) DEFAULT NULL COMMENT '报单人-用户编码',
  `app_mark_type_code` varchar(32) DEFAULT NULL COMMENT '应用类型',
  `inst_little_type_code` varchar(32) DEFAULT NULL COMMENT '子类型类别',
  `create_by` varchar(64) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL COMMENT '创建人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`rel_id`),
  UNIQUE KEY `uk_alias_data_id` (`alisa`,`data_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=623 DEFAULT CHARSET=utf8mb4 COMMENT='表单流程数据关联信息';

/*Table structure for table `light_app` */

DROP TABLE IF EXISTS `light_app`;

CREATE TABLE `light_app` (
  `light_app_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `app_market_code` varchar(64) DEFAULT NULL COMMENT '应用服务代码',
  `app_little_type` varchar(64) DEFAULT NULL COMMENT '应用小分类编码',
  `task_type_code` varchar(64) DEFAULT NULL COMMENT '任务中心唯一标识码',
  `exist_task_centre_code` int(1) DEFAULT '0' COMMENT '是否存在任务中心编码',
  `app_market_type_code` varchar(64) DEFAULT NULL COMMENT '应用服务类型 冗余',
  `app_flag_type` varchar(64) DEFAULT NULL COMMENT '应用标志(投诉：complaint；建议：suggest)',
  `light_app_code` varchar(64) DEFAULT NULL COMMENT '轻应用代码',
  `light_app_name` varchar(64) DEFAULT NULL COMMENT '轻应用名称',
  `light_app_type` varchar(64) DEFAULT 'draft' COMMENT '工单状态 draft草稿，test测试，upline上线，下线downline',
  `icon_url` varchar(512) DEFAULT NULL COMMENT '图标',
  `order_num` int(1) DEFAULT NULL COMMENT '排序 排序字段',
  `status` int(1) DEFAULT '1' COMMENT '状态 0禁用，1启用；默认1',
  `release_open_state` int(1) DEFAULT '1' COMMENT '【发布测试】状态是否开启 o未开启;1启用',
  `tenement_code` varchar(64) DEFAULT NULL COMMENT '租户编码',
  `project_code` varchar(64) DEFAULT NULL COMMENT '园区编码',
  `company_code` varchar(64) DEFAULT NULL COMMENT '企业编码',
  `remark` text COMMENT '备注',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `del_flag` int(1) DEFAULT '0' COMMENT '逻辑删除 0有效，1被删除；默认0',
  PRIMARY KEY (`light_app_id`)
) ENGINE=InnoDB AUTO_INCREMENT=418 DEFAULT CHARSET=utf8mb4 COMMENT='轻应用';

/*Table structure for table `light_app_activity` */

DROP TABLE IF EXISTS `light_app_activity`;

CREATE TABLE `light_app_activity` (
  `activity_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `light_app_id` bigint(20) DEFAULT NULL COMMENT '轻应用Id 关联轻应用Id',
  `task_type_code` varchar(64) DEFAULT NULL COMMENT '任务中心唯一标识码',
  `exist_task_centre_code` int(1) DEFAULT '0' COMMENT '是否存在任务中心编码',
  `app_market_type_code` varchar(64) DEFAULT NULL COMMENT '应用服务类型代码',
  `activity_code` varchar(64) DEFAULT NULL COMMENT '活动编号',
  `activity_name` varchar(64) DEFAULT NULL COMMENT '活动名称',
  `icon_url` varchar(512) DEFAULT NULL COMMENT '活动Log图片地址',
  `activity_address` varchar(500) DEFAULT NULL COMMENT '活动地址',
  `activity_content` text COMMENT '活动内容',
  `form_id` varchar(64) DEFAULT NULL COMMENT '关联表单Id 关联表单Id',
  `process_id` varchar(64) DEFAULT NULL COMMENT '流程Id',
  `need_sign` int(1) DEFAULT NULL COMMENT '是否需要签到 0不需要，1需要',
  `sign_start_time` datetime DEFAULT NULL COMMENT '签到开始时间',
  `sign_end_time` datetime DEFAULT NULL COMMENT '签到结束时间',
  `start_time` datetime DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `server_launch_user` varchar(64) DEFAULT NULL COMMENT '参与条件 tourist游客   commonUser普通用户   companyEmployee企业员工   companyManager企业管理员,多种类型英文逗号隔开',
  `online_status` varchar(32) DEFAULT NULL COMMENT '在线状态：online 上线中，offline 下线中， null 无在线状态',
  `description` varchar(512) DEFAULT NULL COMMENT '参与条件描述',
  `activity_type` varchar(64) DEFAULT NULL COMMENT '活动状态 draft草稿，notStart未开始，underWay进行中，suspend暂停中，finish已结束',
  `order_num` int(1) DEFAULT NULL COMMENT '排序 排序字段',
  `status` int(1) DEFAULT '1' COMMENT '是否禁用 0禁用，1启用；默认1',
  `tenement_code` varchar(64) DEFAULT NULL COMMENT '租户编码',
  `project_code` varchar(64) DEFAULT NULL COMMENT '园区编码',
  `company_code` varchar(64) DEFAULT NULL COMMENT '企业编码',
  `read_count` int(11) DEFAULT '0' COMMENT '查看数',
  `remark` text COMMENT '备注',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `del_flag` int(1) DEFAULT '0' COMMENT '逻辑删除 0有效，1被删除；默认0',
  PRIMARY KEY (`activity_id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COMMENT='活动 ';

/*Table structure for table `light_app_category` */

DROP TABLE IF EXISTS `light_app_category`;

CREATE TABLE `light_app_category` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `category_id` varchar(64) DEFAULT NULL COMMENT 'spaas分类Id',
  `alias` varchar(64) DEFAULT NULL COMMENT '别名',
  `order_num` int(1) DEFAULT NULL COMMENT '排序 排序字段',
  `STATUS` int(1) DEFAULT '1' COMMENT '是否禁用 0禁用，1启用；默认1',
  `tenement_code` varchar(64) DEFAULT NULL COMMENT '租户编码',
  `project_code` varchar(64) DEFAULT NULL COMMENT '园区编码',
  `company_code` varchar(64) DEFAULT NULL COMMENT '企业编码',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `del_flag` int(1) DEFAULT '0' COMMENT '逻辑删除 0有效，1被删除；默认0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COMMENT='Spaas分类信息存储';

/*Table structure for table `light_app_module` */

DROP TABLE IF EXISTS `light_app_module`;

CREATE TABLE `light_app_module` (
  `light_app_module_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `light_app_id` bigint(20) DEFAULT NULL COMMENT '轻应用',
  `app_market_type_code` varchar(64) DEFAULT NULL COMMENT '应用类型',
  `relevancy_id` bigint(20) DEFAULT NULL COMMENT '关联Id',
  `light_app_module_code` varchar(64) DEFAULT NULL COMMENT '轻应用模块代码',
  `light_app_module_name` varchar(64) DEFAULT NULL COMMENT '模块名称',
  `light_app_module_type_code` varchar(64) DEFAULT NULL COMMENT '模块类型',
  `order_num` int(1) DEFAULT NULL COMMENT '排序 排序字段',
  `status` int(1) DEFAULT '1' COMMENT '状态 0禁用，1启用；默认1',
  `tenement_code` varchar(64) DEFAULT NULL COMMENT '租户编码',
  `project_code` varchar(64) DEFAULT NULL COMMENT '园区编码',
  `company_code` varchar(64) DEFAULT NULL COMMENT '企业编码',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `del_flag` int(1) DEFAULT '0' COMMENT '逻辑删除 0有效，1被删除；默认0',
  PRIMARY KEY (`light_app_module_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1978 DEFAULT CHARSET=utf8mb4 COMMENT='轻应用模块';

/*Table structure for table `light_app_module_type` */

DROP TABLE IF EXISTS `light_app_module_type`;

CREATE TABLE `light_app_module_type` (
  `light_app_module_type_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `light_app_module_type_name` varchar(64) DEFAULT NULL COMMENT '模板名称',
  `light_app_module_type_code` varchar(64) DEFAULT NULL COMMENT '模板类型',
  `apply_app_type` varchar(128) DEFAULT '0' COMMENT '适用应用服务 workerOrder工单等等，多个英文逗号隔开',
  `order_num` int(1) DEFAULT NULL COMMENT '排序 排序字段',
  `status` int(1) DEFAULT '1' COMMENT '状态 0禁用，1启用；默认1',
  `tenement_code` varchar(64) DEFAULT NULL COMMENT '租户编码',
  `project_code` varchar(64) DEFAULT NULL COMMENT '园区编码',
  `company_code` varchar(64) DEFAULT NULL COMMENT '企业编码',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `del_flag` int(1) DEFAULT '0' COMMENT '逻辑删除 0有效，1被删除；默认0',
  PRIMARY KEY (`light_app_module_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COMMENT='轻应用模块-模板';

/*Table structure for table `light_app_server` */

DROP TABLE IF EXISTS `light_app_server`;

CREATE TABLE `light_app_server` (
  `server_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `light_app_id` bigint(20) DEFAULT NULL COMMENT '轻应用Id',
  `app_little_type` varchar(64) DEFAULT NULL COMMENT '轻应用小分类',
  `server_code` varchar(64) DEFAULT NULL COMMENT '服务代码',
  `server_name` varchar(64) DEFAULT NULL COMMENT '服务名称',
  `task_type_code` varchar(64) DEFAULT NULL COMMENT '任务中心唯一编码',
  `server_type_id` varchar(64) DEFAULT NULL COMMENT '服务分类',
  `server_icon` text COMMENT '服务海报',
  `tag_hint` int(1) DEFAULT NULL COMMENT '标签提示 1不显示，2免费，3价格面议',
  `goods_code` varchar(64) DEFAULT NULL COMMENT '商品编号',
  `goods_name` varchar(64) DEFAULT NULL COMMENT '商品名称',
  `goods_detail` text COMMENT '商品详情的JSON',
  `specification` varchar(64) DEFAULT NULL COMMENT '规格',
  `unit_name` varchar(64) DEFAULT NULL COMMENT '单位',
  `price_type` int(1) DEFAULT '1' COMMENT '是否固定定价 价格类型：1固定定价，2沟通定价',
  `price` varchar(64) DEFAULT NULL COMMENT '标准单价',
  `hotline` varchar(64) DEFAULT NULL COMMENT '咨询电话',
  `formula` varchar(64) DEFAULT NULL COMMENT '计算公式',
  `photo_list` text COMMENT '图片 多个图片用英文逗号隔开',
  `server_state` varchar(64) DEFAULT 'draft' COMMENT '服务状态 draft草稿，upLine上架，downLine下架',
  `open_content` int(1) DEFAULT '1' COMMENT '服务内容是否开启 0不开启，1开启；默认开启',
  `server_content` text COMMENT '服务内容',
  `open_issue` int(1) DEFAULT '1' COMMENT '常见问题是否开启 0不开启，1开启；默认开启',
  `issue` text COMMENT '常见问题',
  `order_num` int(1) DEFAULT NULL COMMENT '排序 排序字段',
  `STATUS` int(1) DEFAULT '1' COMMENT '是否禁用 0禁用，1启用；默认1',
  `tenement_code` varchar(64) DEFAULT NULL COMMENT '租户编码',
  `project_code` varchar(64) DEFAULT NULL COMMENT '园区编码',
  `company_code` varchar(64) DEFAULT NULL COMMENT '企业编码',
  `remark` text COMMENT '备注',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `del_flag` int(1) DEFAULT '0' COMMENT '逻辑删除 0有效，1被删除；默认0',
  PRIMARY KEY (`server_id`)
) ENGINE=InnoDB AUTO_INCREMENT=110 DEFAULT CHARSET=utf8mb4 COMMENT='服务设置 ';

/*Table structure for table `light_app_server_data` */

DROP TABLE IF EXISTS `light_app_server_data`;

CREATE TABLE `light_app_server_data` (
  `server_data_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `light_app_id` bigint(20) DEFAULT NULL COMMENT '轻应用Id',
  `light_app_module_id` bigint(20) DEFAULT NULL COMMENT '表单模块Id',
  `app_market_type_code` varchar(64) DEFAULT NULL COMMENT '轻应用类型',
  `app_little_type` varchar(64) DEFAULT NULL COMMENT '轻应用小分类',
  `server_id` bigint(20) DEFAULT NULL COMMENT '服务Id',
  `subscribe` varchar(20) DEFAULT NULL COMMENT '是否订阅:未订阅 已订阅',
  `open_id` varchar(64) DEFAULT NULL COMMENT 'openId',
  `ext_order_code` varchar(64) DEFAULT NULL COMMENT '外部订单编号',
  `customer_name` varchar(64) DEFAULT NULL COMMENT '客户姓名',
  `customer_phone` varchar(64) DEFAULT NULL COMMENT '手机号码',
  `customer_address` varchar(500) DEFAULT NULL COMMENT '客户企业地址',
  `receive_detail` text COMMENT '收货详情',
  `pay_way` varchar(64) DEFAULT NULL COMMENT '结算方式：cashPay现结，companyPay企业周期结算',
  `payment_way` int(1) DEFAULT NULL COMMENT '支付方式：1线上支付，2线下支付',
  `pay_company` varchar(200) DEFAULT NULL COMMENT '支付企业',
  `buy_num` int(10) DEFAULT NULL COMMENT '购买数量',
  `duration` int(4) DEFAULT NULL COMMENT '服务时长',
  `specification` varchar(64) DEFAULT NULL COMMENT '商品规格',
  `formula` varchar(64) DEFAULT NULL COMMENT '计算公式',
  `order_money` decimal(32,2) DEFAULT NULL COMMENT '订单价格',
  `buy_money` decimal(32,2) DEFAULT NULL COMMENT '应付金额',
  `order_code` varchar(64) DEFAULT NULL COMMENT '单据编码',
  `form_set_id` varchar(64) DEFAULT NULL COMMENT '表单设置Id',
  `form_id` varchar(64) DEFAULT NULL COMMENT '表单Id',
  `source` int(1) DEFAULT NULL COMMENT '单据来源 1内部单，2客户下单，3代客下单',
  `content` varchar(64) DEFAULT NULL COMMENT '工单内容',
  `process_id` varchar(64) DEFAULT NULL COMMENT '流程Id',
  `process_ins_id` varchar(64) DEFAULT NULL COMMENT '流程实例Id',
  `process_set_id` bigint(20) DEFAULT NULL COMMENT '流程设置Id',
  `process_node_user_detail` text COMMENT '用户详情',
  `process_node_user` varchar(1024) DEFAULT NULL COMMENT '当前节点处理人',
  `data_id` varchar(64) DEFAULT NULL COMMENT '对应数据Id 关联实际填答数据',
  `app_code` varchar(64) DEFAULT NULL COMMENT '应用编码',
  `business_state` varchar(64) DEFAULT NULL COMMENT '业务状态 1待审核，2待支付，3不通过，4待支付,5退款中,6已完成',
  `process_state` int(1) DEFAULT NULL COMMENT '工单状态 工单状态（1待受理，2处理中，3已完成，4已关闭，5待回访，6已取消）',
  `process_start_status` int(1) DEFAULT NULL COMMENT '流程启动结果 流程启动结果，1-启动成功，-1-启动失败，0-未启动流程',
  `task_id` varchar(64) DEFAULT NULL COMMENT '任务Id',
  `space_info` varchar(64) DEFAULT NULL COMMENT '空间地址信息',
  `space_code` varchar(64) DEFAULT NULL COMMENT '空间地址信息编码',
  `create_order_status` tinyint(1) DEFAULT NULL COMMENT '订单中心创建订单结果 1-创建成功，-1-创建失败，0-未创建',
  `order_num` int(1) DEFAULT NULL COMMENT '排序 排序字段',
  `STATUS` int(1) DEFAULT '1' COMMENT '是否禁用 0禁用，1启用；默认1',
  `tenement_code` varchar(64) DEFAULT NULL COMMENT '租户编码',
  `project_code` varchar(64) DEFAULT NULL COMMENT '园区编码',
  `company_code` varchar(64) DEFAULT NULL COMMENT '企业编码',
  `remark` text COMMENT '备注',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `del_flag` int(1) DEFAULT '0' COMMENT '逻辑删除 0有效，1被删除；默认0',
  `tax_status` tinyint(2) DEFAULT '0' COMMENT '结算状态',
  PRIMARY KEY (`server_data_id`)
) ENGINE=InnoDB AUTO_INCREMENT=531 DEFAULT CHARSET=utf8mb4 COMMENT='填答服务数据 ';

/*Table structure for table `light_app_server_data_detail` */

DROP TABLE IF EXISTS `light_app_server_data_detail`;

CREATE TABLE `light_app_server_data_detail` (
  `server_data_detail_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `light_app_id` bigint(20) DEFAULT NULL COMMENT '轻应用Id',
  `app_market_type_code` varchar(64) DEFAULT NULL COMMENT '轻应用类型',
  `app_little_type` varchar(64) DEFAULT NULL COMMENT '轻应用小分类',
  `server_id` bigint(20) DEFAULT NULL COMMENT '服务Id',
  `server_data_id` bigint(20) DEFAULT NULL COMMENT '下单数据Id',
  `order_type` varchar(64) DEFAULT NULL COMMENT '单据类型 支付，退款，周期结算',
  `order_detail` text COMMENT '详情',
  `order_code` varchar(64) DEFAULT NULL COMMENT '单据编码（对外） 对应类型不同的单据',
  `file_url` varchar(255) DEFAULT NULL COMMENT '附件图片',
  `money` decimal(10,2) DEFAULT NULL COMMENT '对应金额',
  `data_type` varchar(64) DEFAULT NULL COMMENT '数据状态 0失败，1成功，2进行中',
  `process_key` varchar(64) DEFAULT NULL COMMENT '流程key',
  `process_ins_id` varchar(64) DEFAULT NULL COMMENT '流程定义Id',
  `form_id` varchar(64) DEFAULT NULL COMMENT '表单Id',
  `order_num` int(1) DEFAULT NULL COMMENT '排序 排序字段',
  `STATUS` int(1) DEFAULT '1' COMMENT '是否禁用 0禁用，1启用；默认1',
  `tenement_code` varchar(64) DEFAULT NULL COMMENT '租户编码',
  `project_code` varchar(64) DEFAULT NULL COMMENT '园区编码',
  `company_code` varchar(64) DEFAULT NULL COMMENT '企业编码',
  `remark` text COMMENT '备注',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `del_flag` int(1) DEFAULT '0' COMMENT '逻辑删除 0有效，1被删除；默认0',
  PRIMARY KEY (`server_data_detail_id`)
) ENGINE=InnoDB AUTO_INCREMENT=812 DEFAULT CHARSET=utf8mb4 COMMENT='服务下单详情 ';

/*Table structure for table `light_app_server_type` */

DROP TABLE IF EXISTS `light_app_server_type`;

CREATE TABLE `light_app_server_type` (
  `server_type_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `light_app_id` bigint(20) DEFAULT NULL COMMENT '轻应用Id',
  `app_market_type_code` varchar(64) DEFAULT NULL COMMENT '应用类型',
  `server_type_name` varchar(64) DEFAULT NULL COMMENT '服务类型名称',
  `server_type_code` varchar(64) DEFAULT NULL COMMENT '服务类型编码',
  `task_type_code` varchar(64) DEFAULT NULL COMMENT '任务中心唯一标识码',
  `exist_task_centre_code` tinyint(1) DEFAULT '0' COMMENT '任务中心存在编码标识',
  `process_key` varchar(64) DEFAULT NULL COMMENT '流程Key',
  `exist_spaas_process` tinyint(1) DEFAULT '0' COMMENT '是否存在流程。0不存在，1存在。',
  `form_id` varchar(64) DEFAULT NULL COMMENT '关联表单ID',
  `alias` varchar(64) DEFAULT NULL COMMENT '关联表单别名',
  `order_num` int(1) DEFAULT NULL COMMENT '排序 排序字段',
  `STATUS` int(1) DEFAULT '1' COMMENT '是否禁用 0禁用，1启用；默认1',
  `tenement_code` varchar(64) DEFAULT NULL COMMENT '租户编码',
  `project_code` varchar(64) DEFAULT NULL COMMENT '园区编码',
  `company_code` varchar(64) DEFAULT NULL COMMENT '企业编码',
  `remark` text COMMENT '备注',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `del_flag` int(1) DEFAULT '0' COMMENT '逻辑删除 0有效，1被删除；默认0',
  PRIMARY KEY (`server_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COMMENT='服务分类 ';

/*Table structure for table `light_app_survey` */

DROP TABLE IF EXISTS `light_app_survey`;

CREATE TABLE `light_app_survey` (
  `survey_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `light_app_id` bigint(20) DEFAULT NULL COMMENT '轻应用Id 关联轻应用Id',
  `task_type_code` varchar(64) DEFAULT NULL COMMENT '任务中心唯一标识码',
  `exist_task_centre_code` int(1) DEFAULT '0' COMMENT '是否存在任务中心编码',
  `app_market_type_code` varchar(64) DEFAULT NULL COMMENT '应用服务类型代码',
  `process_id` varchar(64) DEFAULT NULL COMMENT '流程Id',
  `form_id` varchar(64) DEFAULT NULL COMMENT '关联表单Id 关联表单Id',
  `survey_type` varchar(64) DEFAULT NULL COMMENT 'draft草稿，notStart未开始，underWay进行中，suspend暂停中，finish已结束',
  `survey_code` varchar(64) DEFAULT NULL COMMENT '问卷编号',
  `survey_name` varchar(64) DEFAULT NULL COMMENT '问卷名称',
  `survey_aim` varchar(512) DEFAULT NULL COMMENT '问卷目的',
  `start_time` datetime DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `server_launch_user` varchar(64) DEFAULT NULL COMMENT '参与条件 tourist游客   commonUser普通用户   companyEmployee企业员工   companyManager企业管理员,多种类型英文逗号隔开',
  `foreword` varchar(1000) DEFAULT NULL COMMENT '前言',
  `tag` varchar(1000) DEFAULT NULL COMMENT '结束语',
  `display_mode` varchar(64) DEFAULT NULL COMMENT '展示方式 1一页显示，2每题一页',
  `survey_time` decimal(4,2) DEFAULT NULL COMMENT '填写问卷的总时长',
  `show_number` int(1) DEFAULT '1' COMMENT '是否显示题号 0不显示，1显示',
  `show_item_type` int(1) DEFAULT '1' COMMENT '是否显示题型 0不显示，1显示',
  `online_status` varchar(32) DEFAULT NULL COMMENT '在线状态：online 上线中，offline 下线中， null 无在线状态',
  `order_num` int(1) DEFAULT NULL COMMENT '排序 排序字段',
  `status` int(1) DEFAULT '1' COMMENT '是否禁用 0禁用，1启用；默认1',
  `tenement_code` varchar(64) DEFAULT NULL COMMENT '租户编码',
  `project_code` varchar(64) DEFAULT NULL COMMENT '园区编码',
  `company_code` varchar(64) DEFAULT NULL COMMENT '企业编码',
  `remark` text COMMENT '备注',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `del_flag` int(1) DEFAULT '0' COMMENT '逻辑删除 0有效，1被删除；默认0',
  PRIMARY KEY (`survey_id`)
) ENGINE=InnoDB AUTO_INCREMENT=206 DEFAULT CHARSET=utf8mb4 COMMENT='问卷';

/*Table structure for table `light_app_survey_data` */

DROP TABLE IF EXISTS `light_app_survey_data`;

CREATE TABLE `light_app_survey_data` (
  `survey_data_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `light_app_id` bigint(20) DEFAULT NULL COMMENT '轻应用Id',
  `light_app_module_id` bigint(20) DEFAULT NULL COMMENT '轻应用模块Id',
  `app_market_type_code` varchar(64) DEFAULT NULL COMMENT '轻应用类型',
  `survey_id` bigint(20) DEFAULT NULL COMMENT '问卷Id',
  `answer_code` varchar(64) DEFAULT NULL COMMENT '答卷人Code',
  `answer_name` varchar(64) DEFAULT NULL COMMENT '答卷人',
  `answer_company` varchar(64) DEFAULT NULL COMMENT '答卷人企业',
  `answer_machine` varchar(64) DEFAULT NULL COMMENT '答卷机器',
  `start_time` datetime DEFAULT NULL COMMENT '开始填答时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `source` varchar(64) DEFAULT NULL COMMENT '单据来源：1内部单，2客户下单，3代客下单',
  `order_code` varchar(64) DEFAULT NULL COMMENT '单据编码',
  `form_set_id` varchar(64) DEFAULT NULL COMMENT '表单设置Id',
  `form_id` varchar(64) DEFAULT NULL COMMENT '表单Id',
  `content` varchar(64) DEFAULT NULL COMMENT '工单内容',
  `process_ins_id` varchar(64) DEFAULT NULL COMMENT '流程实例Id',
  `process_set_id` varchar(64) DEFAULT NULL COMMENT '流程设置Id',
  `process_id` varchar(64) DEFAULT NULL COMMENT '流程Id',
  `process_node_user` varchar(1024) DEFAULT NULL COMMENT '当前节点处理人',
  `process_node_user_detail` text COMMENT '当前节点处理人详情',
  `data_id` varchar(64) DEFAULT NULL COMMENT '对应数据Id 关联实际填答数据',
  `app_code` varchar(64) DEFAULT NULL COMMENT '应用编码',
  `business_state` varchar(64) DEFAULT NULL COMMENT '业务状态',
  `process_state` int(1) DEFAULT NULL COMMENT '工单状态 工单状态（1待受理，2处理中，3已完成，4已关闭，5待回访，6已取消）',
  `process_start_status` int(1) DEFAULT NULL COMMENT '流程启动结果 流程启动结果，1-启动成功，-1-启动失败，0-未启动流程',
  `task_id` varchar(64) DEFAULT NULL COMMENT '任务Id',
  `space_info` varchar(64) DEFAULT NULL COMMENT '空间地址信息',
  `space_code` varchar(64) DEFAULT NULL COMMENT '空间地址信息编码',
  `order_num` int(1) DEFAULT NULL COMMENT '排序 排序字段',
  `status` int(1) DEFAULT '1' COMMENT '是否禁用 0禁用，1启用；默认1',
  `tenement_code` varchar(64) DEFAULT NULL COMMENT '租户编码',
  `project_code` varchar(64) DEFAULT NULL COMMENT '园区编码',
  `company_code` varchar(64) DEFAULT NULL COMMENT '企业编码',
  `remark` text COMMENT '备注',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `del_flag` int(1) DEFAULT '0' COMMENT '逻辑删除 0有效，1被删除；默认0',
  PRIMARY KEY (`survey_data_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COMMENT='填答问卷数据 ';

/*Table structure for table `public_process` */

DROP TABLE IF EXISTS `public_process`;

CREATE TABLE `public_process` (
  `public_process_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `process_type` varchar(64) DEFAULT NULL COMMENT '流程分类 settle-企业结算流程，refund-退款流程',
  `form_id` varchar(64) DEFAULT NULL COMMENT '表单 默认表单的Id',
  `alias` varchar(64) DEFAULT NULL COMMENT '表单别名 表单别名',
  `process_key` varchar(64) DEFAULT NULL COMMENT '流程key 对应Spaas的流程key，暂时手动维护',
  `order_num` int(1) DEFAULT NULL COMMENT '排序 排序字段',
  `STATUS` int(1) DEFAULT '1' COMMENT '是否禁用 0禁用，1启用；默认1',
  `tenement_code` varchar(64) DEFAULT NULL COMMENT '租户编码',
  `project_code` varchar(64) DEFAULT NULL COMMENT '园区编码',
  `company_code` varchar(64) DEFAULT NULL COMMENT '企业编码',
  `remark` text COMMENT '备注',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `del_flag` int(1) DEFAULT '0' COMMENT '逻辑删除 0有效，1被删除；默认0',
  PRIMARY KEY (`public_process_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COMMENT='公共流程 ';

/*Table structure for table `push_active_set` */

DROP TABLE IF EXISTS `push_active_set`;

CREATE TABLE `push_active_set` (
  `push_active_set_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `light_app_module_id` bigint(20) DEFAULT NULL COMMENT '发布模块id',
  `light_app_id` bigint(20) DEFAULT NULL COMMENT '轻应用Id 冗余',
  `active_project_code` varchar(64) DEFAULT NULL COMMENT '启用项目代码',
  `active_project_name` varchar(64) DEFAULT NULL COMMENT '启用项目名称',
  `order_num` int(1) DEFAULT NULL COMMENT '排序 排序字段',
  `status` int(1) DEFAULT '1' COMMENT '状态 0禁用，1启用；默认1',
  `tenement_code` varchar(64) DEFAULT NULL COMMENT '租户编码',
  `project_code` varchar(64) DEFAULT NULL COMMENT '园区编码',
  `company_code` varchar(64) DEFAULT NULL COMMENT '企业编码',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `del_flag` int(1) DEFAULT '0' COMMENT '逻辑删除 0有效，1被删除；默认0',
  PRIMARY KEY (`push_active_set_id`)
) ENGINE=InnoDB AUTO_INCREMENT=181 DEFAULT CHARSET=utf8mb4 COMMENT='发布启用设置';

/*Table structure for table `push_advanced_set` */

DROP TABLE IF EXISTS `push_advanced_set`;

CREATE TABLE `push_advanced_set` (
  `push_advanced_set_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `light_app_module_id` bigint(20) DEFAULT NULL COMMENT '应用模块Id',
  `light_app_id` bigint(20) DEFAULT NULL COMMENT '轻应用Id 冗余',
  `server_launch_role` varchar(64) DEFAULT NULL COMMENT '服务发起角色 client客户使用，inside内部使用,多个用英文逗号隔开',
  `server_launch_user` varchar(64) DEFAULT NULL COMMENT 'C端用户发起最低等级 tourist游客   commonUser普通用户   companyEmployee企业员工   companyManager企业管理员,多种类型英文逗号隔开',
  `see_employee_data` int(1) DEFAULT '0' COMMENT '企业管理员可见员工数据 0否，1是',
  `rep_guest_order` int(1) DEFAULT '0' COMMENT '是否允许代客录单 0否，1是',
  `need_print_template` int(1) DEFAULT '0' COMMENT '是否需要打印模板 0否 1是',
  `print_template_code` varchar(64) DEFAULT NULL COMMENT '打印模板编号',
  `operator` int(1) DEFAULT '1' COMMENT '单选（1自营，2第三方）',
  `pay_way` varchar(64) DEFAULT 'cashPay,companyPay' COMMENT 'cashPay现结，companyPay企业周期结算，多选英文逗号隔开',
  `past_time_num` int(1) DEFAULT '1' COMMENT '限时数值（正整数）',
  `past_time_unit` varchar(32) DEFAULT 'hour' COMMENT '月month，天day，小时hour，分钟minute，秒second',
  `open_send_time` int(1) DEFAULT '0' COMMENT '是否开启配送时间：0不开启，1开启',
  `send_time` varchar(512) DEFAULT NULL COMMENT '配送时间输入框',
  `send_start_time` datetime DEFAULT NULL COMMENT ' 配送起始时间',
  `send_end_time` datetime DEFAULT NULL COMMENT '配送终止时间',
  `need_check` int(1) DEFAULT '1' COMMENT '是否需要审核（0 不需要，1需要）',
  `order_num` int(1) DEFAULT NULL COMMENT '排序 排序字段',
  `status` int(1) DEFAULT '1' COMMENT '是否禁用 0禁用，1启用；默认1',
  `tenement_code` varchar(64) DEFAULT NULL COMMENT '租户编码',
  `project_code` varchar(64) DEFAULT NULL COMMENT '园区编码',
  `company_code` varchar(64) DEFAULT NULL COMMENT '企业编码',
  `remark` text COMMENT '备注',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `del_flag` int(1) DEFAULT '0' COMMENT '逻辑删除 0有效，1被删除；默认0',
  PRIMARY KEY (`push_advanced_set_id`)
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=utf8mb4 COMMENT='高级设置';

/*Table structure for table `push_advertising_set` */

DROP TABLE IF EXISTS `push_advertising_set`;

CREATE TABLE `push_advertising_set` (
  `advertising_set_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `light_app_id` bigint(20) DEFAULT NULL COMMENT '轻应用Id',
  `app_market_type_code` varchar(64) DEFAULT NULL COMMENT '应用服务类型代码',
  `relevancy_id` bigint(20) DEFAULT NULL COMMENT '关联Id',
  `message_id` bigint(20) DEFAULT NULL COMMENT '消息id',
  `push_message` int(1) DEFAULT '0' COMMENT '是否推送到消息中心：0否 1是',
  `advertising_channel` varchar(64) DEFAULT NULL COMMENT '发布渠道 上架渠道以及排序，statusType全民:ORANGE_MANILA，中介报备:REPORT，运营:OPERATOR_MANAGE；排序showOrder',
  `advertising_name` varchar(64) DEFAULT NULL COMMENT '广告名称',
  `news_type` varchar(64) DEFAULT '0' COMMENT '发布位置 发布位置：0 Banner图',
  `jump_type` varchar(64) DEFAULT NULL COMMENT '广告跳转类型 0 项目详情、1 H5页面',
  `jump_url` varchar(128) DEFAULT NULL COMMENT '跳转链接 广告跳转地址，项目详情传ProjectCode',
  `project_codes` varchar(64) DEFAULT NULL COMMENT '发布范围,逗号隔开',
  `long_term` int(1) DEFAULT '1' COMMENT '生效策略 1规定时间，2长期',
  `start_time` datetime DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '到期时间',
  `end_date` datetime DEFAULT NULL COMMENT '到期时间',
  `effect_date` datetime DEFAULT NULL COMMENT '生效时间',
  `img_url` varchar(512) DEFAULT NULL COMMENT '广告图片',
  `show_order` int(1) DEFAULT NULL COMMENT '排序 排序字段',
  `STATUS` int(1) DEFAULT '1' COMMENT '是否禁用 0禁用，1启用；默认1',
  `tenement_code` varchar(64) DEFAULT NULL COMMENT '租户编码',
  `project_code` varchar(64) DEFAULT NULL COMMENT '园区编码',
  `company_code` varchar(64) DEFAULT NULL COMMENT '企业编码',
  `remark` text COMMENT '备注',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `del_flag` int(1) DEFAULT '0' COMMENT '逻辑删除 0有效，1被删除；默认0',
  PRIMARY KEY (`advertising_set_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COMMENT='发布广告 ';

/*Table structure for table `push_apply_data` */

DROP TABLE IF EXISTS `push_apply_data`;

CREATE TABLE `push_apply_data` (
  `apply_data_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `light_app_id` bigint(20) DEFAULT NULL COMMENT '轻应用Id',
  `light_app_module_id` bigint(20) DEFAULT NULL COMMENT '轻应用模块Id',
  `app_market_type_code` varchar(64) DEFAULT NULL COMMENT '轻应用类型',
  `activity_id` int(64) DEFAULT NULL COMMENT '活动Id',
  `user_name` varchar(64) DEFAULT NULL COMMENT '报名人名称',
  `activity_machine` varchar(64) DEFAULT NULL COMMENT '活动报名机器',
  `avatar_url` varchar(255) DEFAULT NULL COMMENT '报名头像url',
  `user_phone` varchar(20) DEFAULT NULL COMMENT '用户手机号',
  `user_code` varchar(64) DEFAULT NULL COMMENT '报名人编码',
  `bill_user_detail` text COMMENT '提表人详情',
  `company_name` varchar(64) DEFAULT NULL COMMENT '报名人企业名称',
  `need_money` int(1) DEFAULT '0' COMMENT '是否需要付费 0不需要，1需要',
  `pay_type` varchar(64) DEFAULT NULL COMMENT '付费状态 待支出，支付失败，支付完成',
  `pay_id` varchar(64) DEFAULT NULL COMMENT '关联付费Id',
  `apply_type` int(1) DEFAULT '0' COMMENT '报名状态 1报名成功，0报名失败',
  `apply_time` datetime DEFAULT NULL COMMENT '报名时间',
  `sign_type` int(1) DEFAULT '0' COMMENT '签到状态 1已签到，0未签到',
  `sign_time` datetime DEFAULT NULL COMMENT '签到时间',
  `source` int(1) DEFAULT NULL COMMENT '单据来源：1内部单，2客户下单，3代客下单',
  `order_code` varchar(64) DEFAULT NULL COMMENT '单据编码',
  `form_set_id` varchar(64) DEFAULT NULL COMMENT '表单设置Id',
  `form_id` varchar(64) DEFAULT NULL COMMENT '表单Id',
  `content` varchar(64) DEFAULT NULL COMMENT '工单内容',
  `process_ins_id` varchar(64) DEFAULT NULL COMMENT '流程实例Id',
  `process_set_id` varchar(64) DEFAULT NULL COMMENT '流程设置Id',
  `process_id` varchar(64) DEFAULT NULL COMMENT '流程Id',
  `process_node_user` varchar(1024) DEFAULT NULL COMMENT '当前节点处理人',
  `process_node_user_detail` text COMMENT '当前节点处理人详情',
  `data_id` varchar(64) DEFAULT NULL COMMENT '对应数据Id',
  `app_code` varchar(64) DEFAULT NULL COMMENT '应用编码',
  `business_state` varchar(64) DEFAULT NULL COMMENT '业务状态(1待支付，2已报名，3报名待审核中，4已签到，5退款中，6退款失败，7退款成功，8报名审核不通过)',
  `process_state` int(1) DEFAULT NULL COMMENT '工单状态 工单状态（1待受理，2处理中，3已完成，4已关闭，5待回访，6已取消）',
  `process_start_status` int(1) DEFAULT NULL COMMENT '流程启动结果 流程启动结果，1-启动成功，-1-启动失败，0-未启动流程',
  `task_id` varchar(64) DEFAULT NULL COMMENT '任务Id',
  `space_info` varchar(64) DEFAULT NULL COMMENT '空间地址信息',
  `space_code` varchar(64) DEFAULT NULL COMMENT '空间地址信息编码',
  `order_num` int(1) DEFAULT NULL COMMENT '排序 排序字段',
  `status` int(1) DEFAULT '1' COMMENT '是否禁用 0禁用，1启用；默认1',
  `tenement_code` varchar(64) DEFAULT NULL COMMENT '租户编码',
  `project_code` varchar(64) DEFAULT NULL COMMENT '园区编码',
  `company_code` varchar(64) DEFAULT NULL COMMENT '企业编码',
  `remark` text COMMENT '备注',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `del_flag` int(1) DEFAULT '0' COMMENT '逻辑删除 0有效，1被删除；默认0',
  PRIMARY KEY (`apply_data_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COMMENT='报名数据 ';

/*Table structure for table `push_apply_set` */

DROP TABLE IF EXISTS `push_apply_set`;

CREATE TABLE `push_apply_set` (
  `apply_set_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `light_app_id` bigint(20) DEFAULT NULL COMMENT '轻应用Id',
  `app_market_type_code` varchar(64) DEFAULT NULL COMMENT '轻应用类型',
  `activity_id` varchar(64) DEFAULT NULL COMMENT '活动Id',
  `form_id` varchar(64) DEFAULT NULL COMMENT '表单Id',
  `limit_number` int(1) DEFAULT NULL COMMENT '报名人数上限',
  `start_time` datetime DEFAULT NULL COMMENT '报名开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '报名结束时间',
  `need_apply` int(1) DEFAULT '1' COMMENT '是否需要报名：0不需要，1需要',
  `need_money` int(11) DEFAULT '0' COMMENT '是否需要报名费用 0不需要，1需要',
  `money` decimal(10,2) DEFAULT NULL COMMENT '费用金额',
  `process_id` varchar(64) DEFAULT NULL COMMENT '流程Id',
  `need_info` int(1) DEFAULT NULL COMMENT '是否需要填写信息 0需要，1不需要',
  `order_num` int(1) DEFAULT NULL COMMENT '排序 排序字段',
  `status` int(1) DEFAULT '1' COMMENT '是否禁用 0禁用，1启用；默认1',
  `tenement_code` varchar(64) DEFAULT NULL COMMENT '租户编码',
  `project_code` varchar(64) DEFAULT NULL COMMENT '园区编码',
  `company_code` varchar(64) DEFAULT NULL COMMENT '企业编码',
  `remark` text COMMENT '备注',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `del_flag` int(1) DEFAULT '0' COMMENT '逻辑删除 0有效，1被删除；默认0',
  PRIMARY KEY (`apply_set_id`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8mb4 COMMENT=' ';

/*Table structure for table `push_form_data` */

DROP TABLE IF EXISTS `push_form_data`;

CREATE TABLE `push_form_data` (
  `form_data_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `light_app_id` bigint(20) DEFAULT NULL COMMENT '轻应用Id',
  `light_app_module_id` bigint(20) DEFAULT NULL COMMENT '轻应用模块Id',
  `app_market_type_code` varchar(64) DEFAULT NULL COMMENT '轻应用类型',
  `data_tag` varchar(64) DEFAULT NULL COMMENT '工单标签 测',
  `source` int(1) DEFAULT NULL COMMENT '单据来源：1内部单，2客户下单，3代客下单',
  `order_code` varchar(64) DEFAULT NULL COMMENT '单据编码 工单编码',
  `form_set_id` bigint(20) DEFAULT NULL COMMENT '表单设置Id',
  `form_id` varchar(64) DEFAULT NULL COMMENT '表单Id 对接表单系统',
  `content` varchar(64) DEFAULT NULL COMMENT '工单内容',
  `process_id` varchar(64) DEFAULT NULL COMMENT '流程Id',
  `process_set_id` varchar(64) DEFAULT NULL COMMENT '流程设置Id',
  `process_ins_id` varchar(64) DEFAULT NULL COMMENT '流程实例ID',
  `process_node_user` varchar(1024) DEFAULT NULL COMMENT '当前节点处理人',
  `process_node_user_detail` text COMMENT '当前节点处理人详情',
  `bill_user` varchar(64) DEFAULT NULL COMMENT '提单人',
  `bill_user_detail` text COMMENT '提单人详情',
  `data_id` varchar(64) DEFAULT NULL COMMENT '对应数据Id 对应存储表单数据',
  `app_code` varchar(64) DEFAULT NULL COMMENT '应用编码',
  `business_state` varchar(64) DEFAULT NULL COMMENT '业务状态',
  `process_state` int(1) DEFAULT NULL COMMENT '工单状态 工单状态（1待受理，2处理中，3已完成，4已关闭，5待回访，6已取消）',
  `process_start_status` int(1) DEFAULT NULL COMMENT '流程启动结果 流程启动结果，1-启动成功，-1-启动失败，0-未启动流程',
  `task_id` varchar(64) DEFAULT NULL COMMENT '任务Id',
  `space_info` varchar(64) DEFAULT NULL COMMENT '空间地址信息',
  `space_code` varchar(64) DEFAULT NULL COMMENT '空间地址信息编码',
  `order_num` int(1) DEFAULT NULL COMMENT '排序 排序字段',
  `status` int(1) DEFAULT '1' COMMENT '状态 0禁用，1启用；默认1',
  `tenement_code` varchar(64) DEFAULT NULL COMMENT '租户编码',
  `project_code` varchar(64) DEFAULT NULL COMMENT '园区编码',
  `company_code` varchar(64) DEFAULT NULL COMMENT '企业编码',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `del_flag` int(1) DEFAULT '0' COMMENT '逻辑删除 0有效，1被删除；默认0',
  PRIMARY KEY (`form_data_id`)
) ENGINE=InnoDB AUTO_INCREMENT=259 DEFAULT CHARSET=utf8mb4 COMMENT='表单数据 ';

/*Table structure for table `push_form_field` */

DROP TABLE IF EXISTS `push_form_field`;

CREATE TABLE `push_form_field` (
  `form_field_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `light_app_id` varchar(64) DEFAULT NULL COMMENT '轻应用Id',
  `light_app_module_id` varchar(64) DEFAULT NULL COMMENT '轻应用模块Id',
  `form_field_code` varchar(64) DEFAULT NULL COMMENT '数据库字段',
  `form_field_name` varchar(64) DEFAULT NULL COMMENT '中文名称',
  `form_field_type` varchar(64) DEFAULT NULL COMMENT '字段类型 字段类型 0基础字段，1表单字段',
  `show_state` varchar(64) DEFAULT NULL COMMENT '列表是否显示 列表是否显示 0不显示 1显示',
  `order_num` int(1) DEFAULT NULL COMMENT '排序 排序字段',
  `status` int(1) DEFAULT '1' COMMENT '是否禁用 0禁用，1启用；默认1',
  `tenement_code` varchar(64) DEFAULT NULL COMMENT '租户编码',
  `project_code` varchar(64) DEFAULT NULL COMMENT '园区编码',
  `company_code` varchar(64) DEFAULT NULL COMMENT '企业编码',
  `remark` text COMMENT '备注',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `del_flag` int(1) DEFAULT '0' COMMENT '逻辑删除 0有效，1被删除；默认0',
  PRIMARY KEY (`form_field_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT=' ';

/*Table structure for table `push_form_set` */

DROP TABLE IF EXISTS `push_form_set`;

CREATE TABLE `push_form_set` (
  `form_set_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `light_app_id` bigint(20) DEFAULT NULL COMMENT '轻应用Id',
  `light_app_module_id` bigint(20) DEFAULT NULL COMMENT '轻应用模块Id',
  `form_id` varchar(64) DEFAULT NULL COMMENT '表单Id 对接表单系统',
  `alias` varchar(64) DEFAULT NULL COMMENT '表单别名 对接表单系统',
  `sql_table_name` varchar(64) DEFAULT NULL COMMENT '存储表名称',
  `order_num` int(1) DEFAULT NULL COMMENT '排序 排序字段',
  `status` int(1) DEFAULT '1' COMMENT '状态 0禁用，1启用；默认1',
  `tenement_code` varchar(64) DEFAULT NULL COMMENT '租户编码',
  `project_code` varchar(64) DEFAULT NULL COMMENT '园区编码',
  `company_code` varchar(64) DEFAULT NULL COMMENT '企业编码',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `del_flag` int(1) DEFAULT '0' COMMENT '逻辑删除 0有效，1被删除；默认0',
  PRIMARY KEY (`form_set_id`)
) ENGINE=InnoDB AUTO_INCREMENT=457 DEFAULT CHARSET=utf8mb4 COMMENT='表单设置';

/*Table structure for table `push_function_set` */

DROP TABLE IF EXISTS `push_function_set`;

CREATE TABLE `push_function_set` (
  `function_set_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `light_app_id` bigint(20) DEFAULT NULL COMMENT '轻应用Id',
  `app_market_type_code` varchar(64) DEFAULT NULL COMMENT '应用服务类型代码 survey问卷，active活动',
  `relevancy_id` bigint(20) DEFAULT NULL COMMENT '关联Id',
  `push_ditch` varchar(32) DEFAULT NULL COMMENT '填写渠道',
  `write_time` varchar(32) DEFAULT NULL COMMENT '限制用户填写次数类型：仅限 once；每天 day;每周 week；每月 month',
  `write_time_count` int(1) DEFAULT NULL COMMENT '填写次数',
  `share_friends` int(1) DEFAULT '0' COMMENT '是否允许分享到朋友圈：0不允许，1允许',
  `share_friend` int(1) DEFAULT '0' COMMENT '是否允许发送给朋友：0不允许，1允许',
  `order_num` int(1) DEFAULT NULL COMMENT '排序 排序字段',
  `status` int(1) DEFAULT '1' COMMENT '是否禁用 0禁用，1启用；默认1',
  `tenement_code` varchar(64) DEFAULT NULL COMMENT '租户编码',
  `project_code` varchar(64) DEFAULT NULL COMMENT '园区编码',
  `company_code` varchar(64) DEFAULT NULL COMMENT '企业编码',
  `remark` text COMMENT '备注',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `del_flag` int(1) DEFAULT '0' COMMENT '逻辑删除 0有效，1被删除；默认0',
  PRIMARY KEY (`function_set_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COMMENT='功能设置';

/*Table structure for table `push_information_set` */

DROP TABLE IF EXISTS `push_information_set`;

CREATE TABLE `push_information_set` (
  `information_set_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `light_app_id` bigint(20) DEFAULT NULL COMMENT '轻应用Id',
  `app_market_type_code` varchar(64) DEFAULT NULL COMMENT '应用服务类型代码',
  `relevancy_id` bigint(20) DEFAULT NULL COMMENT '关联Id',
  `message_id` bigint(20) DEFAULT NULL COMMENT '消息id',
  `push_message` int(1) DEFAULT '0' COMMENT '是否推送到消息中心：0否 1是',
  `release_channel` varchar(128) DEFAULT NULL COMMENT '发布渠道 发布渠道  key  value 微信小程序（物业运营） OPERATOR_MANAGE APP  APP',
  `release_locations` varchar(512) DEFAULT NULL COMMENT '发布位置 发布位置 多选时List<String>数组 目前只需要单选',
  `project_codes` varchar(512) DEFAULT NULL COMMENT '发布范围--',
  `long_term` int(1) DEFAULT NULL COMMENT '是否长期 是否长期  0否 1是',
  `release_time` datetime DEFAULT NULL COMMENT '发布时间',
  `end_time` datetime DEFAULT NULL COMMENT '到期时间',
  `info_title` varchar(128) DEFAULT NULL COMMENT '资讯标题',
  `info_resouse` varchar(512) DEFAULT NULL COMMENT '资讯来源',
  `sharing_lead` varchar(512) DEFAULT NULL COMMENT '分享导语',
  `info_form` int(1) DEFAULT NULL COMMENT '资讯形式 资讯形式 0:文章 1:链接',
  `shelf_status` int(1) DEFAULT NULL COMMENT '上架状态 0上架 1下架 2待上架',
  `show_type` int(1) DEFAULT NULL COMMENT '展示样式 （0无图模式,1小图模式,2大图模式,3三图模式）',
  `info_tag` varchar(64) DEFAULT NULL COMMENT '资讯标签--',
  `cover_urls` varchar(1024) DEFAULT NULL COMMENT '资讯封面',
  `info_content` varchar(512) DEFAULT NULL COMMENT '发布内容/链接路径 资讯内容/链接路径 根据资讯形式来存储',
  `attachment_urls` varchar(512) DEFAULT NULL COMMENT '附件url',
  `order_num` int(1) DEFAULT NULL COMMENT '排序 排序字段',
  `STATUS` int(1) DEFAULT '1' COMMENT '是否禁用 0禁用，1启用；默认1',
  `tenement_code` varchar(64) DEFAULT NULL COMMENT '租户编码',
  `project_code` varchar(64) DEFAULT NULL COMMENT '园区编码',
  `company_code` varchar(64) DEFAULT NULL COMMENT '企业编码',
  `remark` text COMMENT '备注',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `del_flag` int(1) DEFAULT '0' COMMENT '逻辑删除 0有效，1被删除；默认0',
  PRIMARY KEY (`information_set_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COMMENT='发布资讯 ';

/*Table structure for table `push_process_set` */

DROP TABLE IF EXISTS `push_process_set`;

CREATE TABLE `push_process_set` (
  `process_set_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `light_app_id` bigint(20) DEFAULT NULL COMMENT '轻应用Id',
  `task_type_code` varchar(64) DEFAULT NULL COMMENT '任务中心唯一标识码',
  `light_app_module_id` bigint(20) DEFAULT NULL COMMENT '轻应用模块Id',
  `process_id` varchar(64) DEFAULT NULL COMMENT '流程Id-key',
  `definition_id` varchar(64) DEFAULT NULL COMMENT '流程定义Id',
  `process_name` varchar(64) DEFAULT NULL COMMENT '流程名称',
  `order_num` int(1) DEFAULT NULL COMMENT '排序 排序字段',
  `status` int(1) DEFAULT '1' COMMENT '状态 0禁用，1启用；默认1',
  `tenement_code` varchar(64) DEFAULT NULL COMMENT '租户编码',
  `project_code` varchar(64) DEFAULT NULL COMMENT '园区编码',
  `company_code` varchar(64) DEFAULT NULL COMMENT '企业编码',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `del_flag` int(1) DEFAULT '0' COMMENT '逻辑删除 0有效，1被删除；默认0',
  PRIMARY KEY (`process_set_id`)
) ENGINE=InnoDB AUTO_INCREMENT=201 DEFAULT CHARSET=utf8mb4 COMMENT='流程设置';

/*Table structure for table `push_tester_set` */

DROP TABLE IF EXISTS `push_tester_set`;

CREATE TABLE `push_tester_set` (
  `push_tester_set_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `light_app_module_id` bigint(20) DEFAULT NULL COMMENT '应用模块Id',
  `light_app_id` bigint(20) DEFAULT NULL COMMENT '轻应用Id 冗余',
  `user_type` varchar(64) DEFAULT NULL COMMENT '数据类型 user用户，role角色，company企业，group用户组',
  `user_code` varchar(64) DEFAULT NULL COMMENT '对应类型代码',
  `user_name` varchar(64) DEFAULT NULL COMMENT '对应名称',
  `order_num` int(1) DEFAULT NULL COMMENT '排序 排序字段',
  `status` int(1) DEFAULT '1' COMMENT '状态 0禁用，1启用；默认1',
  `tenement_code` varchar(64) DEFAULT NULL COMMENT '租户编码',
  `project_code` varchar(64) DEFAULT NULL COMMENT '园区编码',
  `company_code` varchar(64) DEFAULT NULL COMMENT '企业编码',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `del_flag` int(1) DEFAULT '0' COMMENT '逻辑删除 0有效，1被删除；默认0',
  PRIMARY KEY (`push_tester_set_id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COMMENT='测试人员';

/*Table structure for table `sys_operator_log` */

DROP TABLE IF EXISTS `sys_operator_log`;

CREATE TABLE `sys_operator_log` (
  `operator_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `module_code` varchar(64) DEFAULT NULL COMMENT '应用代码',
  `title` varchar(64) DEFAULT NULL COMMENT '模块标题',
  `operator_type` varchar(64) DEFAULT NULL COMMENT '操作类型 add，delete，update，import，export，other',
  `method` varchar(512) DEFAULT NULL COMMENT '方法名称',
  `request_method` varchar(64) DEFAULT NULL COMMENT '请求方式',
  `operator_url` varchar(512) DEFAULT NULL COMMENT '请求URL',
  `operator_ip` varchar(512) DEFAULT NULL COMMENT '主机地址',
  `operator_location` varchar(512) DEFAULT NULL COMMENT '操作地点',
  `operator_param` text COMMENT '请求参数',
  `json_result` text COMMENT '返回参数',
  `operator_state` varchar(64) DEFAULT NULL COMMENT '操作状态 normal-正常，exception-异常',
  `error_msg` text COMMENT '错误消息',
  `tenement_code` varchar(64) DEFAULT NULL COMMENT '租户编码',
  `project_code` varchar(64) DEFAULT NULL COMMENT '园区编码',
  `company_code` varchar(64) DEFAULT NULL COMMENT '企业编码',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`operator_id`)
) ENGINE=InnoDB AUTO_INCREMENT=45709 DEFAULT CHARSET=utf8mb4 COMMENT='系统操作日志';

/* Procedure structure for procedure `proc_clean_data` */

/*!50003 DROP PROCEDURE IF EXISTS  `proc_clean_data` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`%` PROCEDURE `proc_clean_data`()
BEGIN
	DECLARE g_lightAppIds text DEFAULT '';
	SELECT GROUP_CONCAT(light_app_id) into g_lightAppIds FROM light_app WHERE STATUS=0;
	select g_lightAppIds;
	if g_lightAppIds!="" || g_lightAppIds is not null then
		SET @SQL=CONCAT("DELETE FROM `light_app` WHERE light_app_id  in(",g_lightAppIds,")");
		PREPARE stmtsql FROM @SQL; EXECUTE stmtsql;
		SET @SQL=CONCAT("DELETE da FROM dict_data  da , dict_type tp WHERE da.`dict_type_id`=tp.`dict_type_id`
			AND tp.light_app_id  in(",g_lightAppIds,")");
		PREPARE stmtsql FROM @SQL; EXECUTE stmtsql;
		SET @SQL=CONCAT("DELETE FROM `dict_type` WHERE light_app_id  in(",g_lightAppIds,")");
		PREPARE stmtsql FROM @SQL; EXECUTE stmtsql;
		SET @SQL=CONCAT("DELETE FROM `light_app_activity` WHERE light_app_id  in(",g_lightAppIds,")");
		PREPARE stmtsql FROM @SQL; EXECUTE stmtsql;
		SET @SQL=CONCAT("DELETE FROM `light_app_module` WHERE light_app_id  in(",g_lightAppIds,")");
		PREPARE stmtsql FROM @SQL; EXECUTE stmtsql;
		SET @SQL=CONCAT("DELETE FROM `light_app_survey` WHERE light_app_id  in(",g_lightAppIds,")");
		PREPARE stmtsql FROM @SQL; EXECUTE stmtsql;
		SET @SQL=CONCAT("DELETE FROM `light_app_survey_data` WHERE light_app_id  in(",g_lightAppIds,")");
		PREPARE stmtsql FROM @SQL; EXECUTE stmtsql;
		SET @SQL=CONCAT("DELETE FROM `push_active_set` WHERE light_app_id  in(",g_lightAppIds,")");
		PREPARE stmtsql FROM @SQL; EXECUTE stmtsql;
		SET @SQL=CONCAT("DELETE FROM `push_advanced_set` WHERE light_app_id  in(",g_lightAppIds,")");
		PREPARE stmtsql FROM @SQL; EXECUTE stmtsql;
		SET @SQL=CONCAT("DELETE FROM `push_advertising_set` WHERE light_app_id  in(",g_lightAppIds,")");
		PREPARE stmtsql FROM @SQL; EXECUTE stmtsql;
		SET @SQL=CONCAT("DELETE FROM `push_apply_data` WHERE light_app_id  in(",g_lightAppIds,")");
		PREPARE stmtsql FROM @SQL; EXECUTE stmtsql;
		SET @SQL=CONCAT("DELETE FROM `push_apply_set` WHERE light_app_id  in(",g_lightAppIds,")");
		PREPARE stmtsql FROM @SQL; EXECUTE stmtsql;
		SET @SQL=CONCAT("DELETE FROM `push_form_data` WHERE light_app_id  in(",g_lightAppIds,")");
		PREPARE stmtsql FROM @SQL; EXECUTE stmtsql;
		SET @SQL=CONCAT("DELETE FROM `push_form_field` WHERE light_app_id  in(",g_lightAppIds,")");
		PREPARE stmtsql FROM @SQL; EXECUTE stmtsql;
		SET @SQL=CONCAT("DELETE FROM `push_form_set` WHERE light_app_id  in(",g_lightAppIds,")");
		PREPARE stmtsql FROM @SQL; EXECUTE stmtsql;
		SET @SQL=CONCAT("DELETE FROM `push_function_set` WHERE light_app_id  in(",g_lightAppIds,")");
		PREPARE stmtsql FROM @SQL; EXECUTE stmtsql;
		SET @SQL=CONCAT("DELETE FROM `push_information_set` WHERE light_app_id  in(",g_lightAppIds,")");
		PREPARE stmtsql FROM @SQL; EXECUTE stmtsql;
		SET @SQL=CONCAT("DELETE FROM `push_process_set` WHERE light_app_id  in(",g_lightAppIds,")");
		PREPARE stmtsql FROM @SQL; EXECUTE stmtsql;
		SET @SQL=CONCAT("DELETE FROM `push_tester_set` WHERE light_app_id  in(",g_lightAppIds,")");
		PREPARE stmtsql FROM @SQL; EXECUTE stmtsql;
		SET @SQL=CONCAT("DELETE FROM `light_app_server` WHERE light_app_id  in(",g_lightAppIds,")");
		PREPARE stmtsql FROM @SQL; EXECUTE stmtsql;
		SET @SQL=CONCAT("DELETE FROM `light_app_server_data` WHERE light_app_id  in(",g_lightAppIds,")");
		PREPARE stmtsql FROM @SQL; EXECUTE stmtsql;
		SET @SQL=CONCAT("DELETE FROM `light_app_server_data_detail` WHERE light_app_id  in(",g_lightAppIds,")");
		PREPARE stmtsql FROM @SQL; EXECUTE stmtsql;
		SET @SQL=CONCAT("DELETE FROM `light_app_server_type` WHERE light_app_id  in(",g_lightAppIds,")");
		PREPARE stmtsql FROM @SQL; EXECUTE stmtsql;
	end if;

    END */$$
DELIMITER ;

/* Procedure structure for procedure `proc_clean_table` */

/*!50003 DROP PROCEDURE IF EXISTS  `proc_clean_table` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`%` PROCEDURE `proc_clean_table`()
BEGIN
	declare i int default 0;
	DECLARE num INT DEFAULT 0;

	SELECT COUNT(*) INTO num FROM(SELECT table_name  FROM information_schema.tables
	WHERE table_schema='osms_light_app'
	AND table_name LIKE "t_light_app%" ) a WHERE a.table_name  NOT IN(SELECT a.table_name FROM (SELECT CONCAT("t_light_app",a.alias)  table_name FROM push_form_set a) a) ;

	WHILE i<num do
		SELECT GROUP_CONCAT('drop table ', a.table_name, ';') into @SQLTEST  FROM (SELECT * FROM(SELECT table_name  FROM information_schema.tables
		WHERE table_schema='osms_light_app'
		AND table_name LIKE "t_light_app%") a WHERE a.table_name  NOT IN(SELECT a.table_name FROM (SELECT CONCAT("t_light_app",a.alias)  table_name FROM push_form_set a) a) LIMIT 1 )a;
		PREPARE stmtsql FROM @SQLTEST;
		EXECUTE stmtsql;
		set i=i+1;
	END WHILE;
    END */$$
DELIMITER ;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

package com.space.coupon.controller;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * CouponUseControllerTest
 *
 * @Author kangmj
 * @date 2021-09-29 17:05
 * @Version 1.0
 */
class CouponUseControllerTest {

    @Test
    void queryListByOrder() {
    }

    @Test
    void getCouponUseInformation() {
    }

    @Test
    void couponUse() {
    }
}
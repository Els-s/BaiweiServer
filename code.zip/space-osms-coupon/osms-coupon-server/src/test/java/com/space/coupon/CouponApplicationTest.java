package com.space.coupon;

import static org.junit.jupiter.api.Assertions.*;

import javax.ws.rs.ApplicationPath;
import org.junit.jupiter.api.Test;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-09-29 17:20
 * @Version 1.0
 */
class CouponApplicationTest {

}
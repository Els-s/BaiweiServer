package com.space.coupon.controller;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * CouponRuleControllerTest
 *
 * @Author kangmj
 * @date 2021-09-29 17:04
 * @Version 1.0
 */
class CouponRuleControllerTest {

    @Test
    void list() {
    }

    @Test
    void getInfo() {
    }

    @Test
    void add() {
    }

    @Test
    void remove() {
    }

    @Test
    void testRemove() {
    }
}
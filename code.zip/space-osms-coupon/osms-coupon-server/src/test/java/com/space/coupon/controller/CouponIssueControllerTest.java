package com.space.coupon.controller;

import cn.space.portal.sdk.holder.UserHolder;
import cn.space.portal.sdk.io.LoginUserAccountInfo;
import com.space.coupon.entity.CouponIssueLogEntity;
import com.space.coupon.service.CouponIssueService;
import com.space.coupon.util.UtilTest;
import com.space.coupon.vo.RspPageVo;
import com.space.coupon.vo.couponvo.reqvo.QueryIssueListVo;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * CouponIssueControllerTest
 *
 * @Author kangmj
 * @date 2021-09-29 17:03
 * @Version 1.0
 */
@SpringBootTest
class CouponIssueControllerTest {

    @Autowired
    CouponIssueService issueService;

    @Test
    void list() {
        QueryIssueListVo reqPageVo = new QueryIssueListVo();
        LoginUserAccountInfo loginUserInfo = UserHolder.get();
        loginUserInfo = UtilTest.test(loginUserInfo);
        RspPageVo<List<CouponIssueLogEntity>> data = issueService.queryPage(reqPageVo, loginUserInfo);
        Assertions.assertTrue(data.getData().size() > 0);
    }

    @Test
    void add() {
    }

    @Test
    void getDesignatedUserInfo() {
    }

    @Test
    void getInfo() {
    }
}
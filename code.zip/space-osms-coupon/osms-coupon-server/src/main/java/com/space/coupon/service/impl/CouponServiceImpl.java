package com.space.coupon.service.impl;

import org.springframework.stereotype.Service;

@Service
public class CouponServiceImpl {

}

package com.space.coupon.vo.couponvo.rspvo;

import com.space.coupon.entity.CouponCiEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-10-14 9:30
 * @Version 1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class OpenApiCiRspVo extends CouponCiEntity {

    @ApiModelProperty("卡券类型Vo")
    private String couponTypeVo;

    @ApiModelProperty("优惠类型Vo：1 折扣券，2 金额券，3 时长券")
    private String discountTypeVo;
}

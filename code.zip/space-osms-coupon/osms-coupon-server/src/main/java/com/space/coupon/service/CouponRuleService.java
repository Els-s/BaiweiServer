package com.space.coupon.service;

import cn.space.portal.sdk.io.LoginUserAccountInfo;
import com.space.coupon.entity.CouponRuleEntity;
import com.space.coupon.enums.CouponStatusEnum;
import com.space.coupon.vo.RspPageVo;
import com.space.coupon.vo.couponvo.reqvo.QueryRuleListVo;
import com.space.coupon.vo.couponvo.reqvo.RuleAddReqVo;

import java.util.List;

/**
 * 卡券模板Service接口
 *
 * @author kangmj
 * @date 2021-09-10
 */
public interface CouponRuleService {

    /**
     * 新增卡券模板
     *
     * @param couponRuleEntity 卡券模板
     * @param loginUserInfo    .
     * @return 结果
     */
    int addCouponRule(RuleAddReqVo couponRuleEntity, LoginUserAccountInfo loginUserInfo);

    /**
     * 批量删除卡券模板
     *
     * @param ids           需要删除的卡券模板主键集合
     * @param loginUserInfo
     * @return 结果
     */
    int deleteCouponRuleByIds(List<Integer> ids, LoginUserAccountInfo loginUserInfo);

    /**
     * 查询卡券模板列表
     *
     * @param reqPageVo            .
     * @param loginUserAccountInfo .
     */
    RspPageVo<List<CouponRuleEntity>> queryPage(QueryRuleListVo reqPageVo, LoginUserAccountInfo loginUserAccountInfo);

    /**
     * 查询卡券模板详情
     *
     * @param id .
     * @return CouponRuleEntity
     */
    CouponRuleEntity queryDetailsById(Long id);

    /**
     * 复制
     *
     * @param id
     * @return
     */
    RuleAddReqVo copyRule(Long id);

    /**
     * updateRuleStatus
     *
     * @param ruleId
     * @param online
     * @return
     */
    int updateRuleStatus(Long ruleId, CouponStatusEnum online);
}

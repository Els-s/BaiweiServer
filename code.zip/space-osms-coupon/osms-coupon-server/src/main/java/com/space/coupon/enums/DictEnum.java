package com.space.coupon.enums;

/**
 * 卡券字典项
 *
 * @Author kangmj
 * @date 2021-09-15 20:01
 * @Version 1.0
 */
public enum DictEnum {
    // 优惠券类型
    COUPON_TEMPLATE_COUPON(1, "coupon_template_coupon", "优惠券", "COUPON_TEMPLATE_TYPE"),

    // 优惠类型
    OFFER_DISCOUNT_COUPON(1, "offer_discount_coupon", "折扣券", "OFFER_TYPE"),
    OFFER_CASH_COUPON(2, "offer_cash_coupon", "金额券", "OFFER_TYPE"),
    OFFER_DURATION_COUPON(3, "offer_duration_coupon", "时长券", "OFFER_TYPE"),

    SPACE_VENUE_RESERVE(1, "space_venue_reserve", "场地预订", "APPLICATION_SCENARIO"),
    ;

    private Integer code;
    private String key;
    private String name;
    private String type;

    public Integer getCode() {
        return code;
    }

    public String getKey() {
        return key;
    }

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    DictEnum(Integer code, String key, String name, String type) {
        this.code = code;
        this.key = key;
        this.name = name;
        this.type = type;
    }
}

package com.space.coupon.service.impl;

import cn.hutool.core.util.StrUtil;
import cn.space.base.core.page.PageFactory;
import cn.space.portal.sdk.io.LoginUserAccountInfo;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.space.coupon.common.CouponConstants;
import com.space.coupon.entity.CouponCiEntity;
import com.space.coupon.enums.CouponStatusEnum;
import com.space.coupon.mapper.CouponCiMapper;
import com.space.coupon.service.CouponObjectService;
import com.space.coupon.util.CommonUtils;
import com.space.coupon.vo.RspPageVo;
import com.space.coupon.vo.couponvo.reqvo.ObjectListReqVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-09-17 16:26
 * @Version 1.0
 */
@Service
public class CouponObjectServiceImpl implements CouponObjectService {

    @Autowired
    CouponCiMapper ciMapper;

    @Override
    public RspPageVo<List<CouponCiEntity>> queryListByObject(ObjectListReqVo reqVo,
            LoginUserAccountInfo loginUserInfo) {
        Page<CouponCiEntity> page = PageFactory.defaultPage();
        QueryWrapper<CouponCiEntity> wrapper = getCouponCiEntities(reqVo.getSearchType(), reqVo.getCompanyId(),
                reqVo.getPersonCode(),
                reqVo.getType(), loginUserInfo);
        Page<CouponCiEntity> iPage = ciMapper.selectPage(page, wrapper);
        List<CouponCiEntity> cis = iPage.getRecords();
        cis.forEach(x -> x.setDescription(CommonUtils.getCiDes(x)));
        return new RspPageVo<>(iPage.getCurrent(), iPage.getSize(), iPage.getPages(), iPage.getTotal(),
                iPage.getRecords());
    }

    @Override
    public QueryWrapper<CouponCiEntity> getCouponCiEntities(Integer searchType, String companyId,
            String personCode, String type, LoginUserAccountInfo loginUserInfo) {
        QueryWrapper<CouponCiEntity> wrapper = new QueryWrapper<>();
        wrapper.eq(CouponConstants.TENEMENT_CODE_STR, loginUserInfo.getTenementCode());
        wrapper.eq(CouponConstants.DEL_FLAG_STR, CouponConstants.DEL_FLAG_FALSE);
        wrapper.eq(CouponConstants.SHOW_STATUS_STR, CouponConstants.SHOW_STATUS_YES);
        switch (searchType) {
            case 1:
                if (StrUtil.isBlank(companyId)) {
                    wrapper.eq(CouponConstants.OBJECT_TYPE_STR,
                                    CouponStatusEnum.OBJECTTYPE_PERSON.getCode())
                            .eq(CouponConstants.OBJECT_ID_STR, personCode);
                } else {
                    wrapper.and(x -> x.and(
                            z -> z.eq(CouponConstants.OBJECT_TYPE_STR, CouponStatusEnum.OBJECTTYPE_COMPANY.getCode())
                                    .eq(CouponConstants.OBJECT_ID_STR, companyId)
                                    .or(y -> y.eq(CouponConstants.OBJECT_TYPE_STR,
                                                    CouponStatusEnum.OBJECTTYPE_PERSON.getCode())
                                            .eq(CouponConstants.OBJECT_ID_STR, personCode))));
                }
                break;
            case 2:
                wrapper.eq(CouponConstants.OBJECT_TYPE_STR, CouponStatusEnum.OBJECTTYPE_PERSON.getCode());
                wrapper.eq(CouponConstants.OBJECT_ID_STR, personCode);
                break;
            case 3:
                wrapper.eq(CouponConstants.OBJECT_TYPE_STR, CouponStatusEnum.OBJECTTYPE_COMPANY.getCode());
                wrapper.eq(CouponConstants.OBJECT_ID_STR, companyId);
                break;
            default:
                break;
        }
        // 状态 可使用/已使用/已过期
        Integer useStatus = Integer.valueOf(type);
        wrapper.eq("use_status", useStatus);
        /* 排序
        1）可使用：默认个人在前企业在后，均按有效期结束时间从早到晚排序
        2）已使用：按使用顺序，最新使用放第1
        3）已过期：按过期顺序，最新过期放第1 */
        if (CouponStatusEnum.CI_USE_STATUS_UNUSED.getCode().equals(useStatus)) {
            wrapper.orderByDesc("valid_period_end_time", CouponConstants.OBJECT_TYPE_STR, "id");
        } else if (CouponStatusEnum.CI_USE_STATUS_USED.getCode().equals(useStatus)) {
            wrapper.orderByDesc("used_time");
        } else if (CouponStatusEnum.CI_USE_STATUS_EXPIRED.getCode().equals(useStatus)) {
            wrapper.orderByDesc("valid_period_end_time");
        }
        return wrapper;
    }
}

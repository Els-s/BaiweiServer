package com.space.coupon.controller;

import cn.space.portal.sdk.holder.UserHolder;
import cn.space.portal.sdk.io.LoginUserAccountInfo;
import com.space.coupon.entity.CouponCiEntity;
import com.space.coupon.service.CouponCiService;
import com.space.coupon.vo.RspPageVo;
import com.space.coupon.vo.ReqPageVo;
import com.space.coupon.vo.RspVo;
import com.space.coupon.vo.couponvo.reqvo.CiDeleteReqVo;
import com.space.coupon.vo.couponvo.reqvo.QueryCiListVo;
import com.space.coupon.vo.couponvo.rspvo.CiStatusNumRspVo;
import com.space.log.annotation.OperaLog;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpHeaders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 卡券Controller
 *
 * @author kangmj
 * @date 2021-09-10
 */
@RestController
@RequestMapping("/ci")
@Api(tags = "卡券服务：卡券使用管理-PC")
@Slf4j
public class CouponCiController {

    @Autowired
    CouponCiService ciService;

    @ApiOperation("管理员卡券使用情况列表-PC")
    @PostMapping("/queryListByAdmin")
    public RspVo<RspPageVo<List<CouponCiEntity>>> list(
            @RequestHeader(HttpHeaders.AUTHORIZATION) String token,
            @RequestBody QueryCiListVo reqPageVo) {
//            @ApiParam(value = "查类型：‘0’全部，‘1’未使用，‘2’已使用，‘3’已过期，‘4’作废")
        log.info("查看PC卡券使用情况列表请求参数：{}", reqPageVo);
        LoginUserAccountInfo loginUserInfo = UserHolder.get();
        RspPageVo<List<CouponCiEntity>> data = ciService.queryPage(reqPageVo, loginUserInfo);
        return RspVo.success("ok", data);
    }

    @ApiOperation("管理员卡券使用状态数量展示-PC")
    @PostMapping("/queryCouponStatusNum")
    public RspVo<CiStatusNumRspVo> queryStatusNum(@RequestBody ReqPageVo reqPageVo) {
        LoginUserAccountInfo loginUserInfo = UserHolder.get();
        CiStatusNumRspVo data = ciService.queryStatusNum(reqPageVo, loginUserInfo);
        return RspVo.success("ok", data);
    }

    /**
     * 获取卡券模板详细信息
     */
    @ApiOperation("获取卡券详细信息")
    @GetMapping(value = "/queryDetails")
    public RspVo<CouponCiEntity> getInfo(
            @ApiParam(value = "卡券ID") @RequestParam(name = "id") Long id) {
        log.info("获取卡券详细信息请求参数：{}", id);
        CouponCiEntity ci = ciService.queryDetailsById(id);

        return RspVo.success("ok", ci);
    }

    /**
     * 删除卡券
     */
    @ApiOperation("批量删除卡券")
    @OperaLog(opType = "删除", opInfo = "批量删除卡券")
    @PostMapping("/delete")
    public RspVo<Integer> remove(@ApiParam(value = "卡券模板ID") @RequestBody CiDeleteReqVo reqVo) {
        log.info("删除卡券模板请求参数：{}", reqVo);
        LoginUserAccountInfo loginUserInfo = UserHolder.get();
        int result = ciService.deleteCiByIds(reqVo.getIds(), loginUserInfo);
        return RspVo.success("删除成功：" + result + "条", result);
    }
}

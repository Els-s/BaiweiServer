package com.space.coupon.enums;

/**
 * 卡券状态
 *
 * @Author kangmj
 * @date 2021-09-14 21:08
 * @Version 1.0
 */
public enum CouponStatusEnum {
    // 模板状态
    OFFLINE(1, "未上线"),
    ONLINE(2, "上线中"),
    EXPIRED(3, "已过期"),

    // 模板发放频次
    FREQUENCY_ONCE(1, "一次性"),
    FREQUENCY_REPEAT(0, "重复"),

    // 模板发放对象类型
    OBJECTTYPE_COMPANY(0, "企业"),
    OBJECTTYPE_PERSON(1, "个人"),

    // 卡券使用状态
    CI_USE_STATUS_UNUSED(1, "未使用"),
    CI_USE_STATUS_USED(2, "已使用"),
    CI_USE_STATUS_EXPIRED(3, "已过期"),
    CI_USE_STATUS_VOID(4, "作废"),

    // 模板是否固定时间发放
    RULE_VALIDITYPERIODTYPE_NOT_FIXED(0, "非固定"),
    RULE_VALIDITYPERIODTYPE_FIXED(1, "固定"),
    ;

    private Integer code;

    private String value;

    CouponStatusEnum(Integer code, String value) {
        this.code = code;
        this.value = value;
    }

    public Integer getCode() {
        return code;
    }

    public String getValue() {
        return value;
    }
}

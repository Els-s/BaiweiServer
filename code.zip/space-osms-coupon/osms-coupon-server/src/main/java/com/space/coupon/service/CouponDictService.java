package com.space.coupon.service;

import com.space.coupon.entity.CouponDictEntity;

import java.util.List;

/**
 * 字典明细Service接口
 *
 * @author kangmj
 * @date 2021-09-14
 */
public interface CouponDictService {

    /**
     * 获取卡券服务字典项
     *
     * @param type //typeCode
     * @return List
     */
    List<CouponDictEntity> queryDictInfo(String type);
}

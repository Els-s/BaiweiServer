package com.space.coupon.service;

import cn.space.portal.sdk.io.LoginUserAccountInfo;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.space.coupon.entity.CouponCiEntity;
import com.space.coupon.vo.RspPageVo;
import com.space.coupon.vo.couponvo.reqvo.ObjectListReqVo;

import java.util.List;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-09-17 16:26
 * @Version 1.0
 */
public interface CouponObjectService {

    /**
     * queryListByObject
     *
     * @param reqVo         。
     * @param loginUserInfo 。
     * @return
     */
    RspPageVo<List<CouponCiEntity>> queryListByObject(ObjectListReqVo reqVo, LoginUserAccountInfo loginUserInfo);

    /**
     * getCouponCiEntities
     *
     * @param searchType
     * @param companyId
     * @param personCode
     * @param type
     * @param loginUserInfo
     * @return
     */
    QueryWrapper<CouponCiEntity> getCouponCiEntities(Integer searchType, String companyId,
            String personCode, String type, LoginUserAccountInfo loginUserInfo);
}

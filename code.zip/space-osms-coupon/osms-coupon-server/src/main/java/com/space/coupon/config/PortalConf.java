package com.space.coupon.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Getter
@Setter
@Component
@ConfigurationProperties(prefix = "portal")
public class PortalConf {

    private String host;
    private String queryUserByCode = "/portal/v1/user/queryUserByCode";
    private String queryUserByAuth = "/portal/v1/api/checkAccessToken";
    private String queryUserByPhone = "/portal/v1/user/queryUserAccountByPhone";

    // 发送验证码
    private String sendVerificationCode = "/portal/v1/sms/sendVerificationCode";
    private String bindUri = "/portal/v1/api/account/bind";
    private String loginUri = "/portal/v1/api/account/login";

    private String queryCompanyList = "/portal/v1/api/getCompanyEntityList";
    private String queryAccountRelProject = "/portal/v1/api/queryAccountRelProject";

    private String appletAccountStatistics = "portal/v1/api/open/appletAccountStatistics";

    private String sdkResetPassword = "/portal/v1/user/resetPassword";  //重置密码
    private String sdkAddCompanyAdmin = "/portal/v1/api/addEnterpriseAdmin";//添加企业管理员
    private String sdkAddTransferEnterpriseAdmin = "/portal/v1/api/addTransferEnterpriseAdmin";//新增移交企业管理员
    private String sdkSelectTransferEnterpriseAdmin = "/portal/v1/api/selectTransferEnterpriseAdmin";//选择移交管理员
    private String sdkCancelAuthentication = "/portal/v1/api/cancelAuthentication"; //解绑
    private String sdkQueryUserRelEnterpriseList = "/portal/v1/api/queryUserRelEnterpriseList"; //查询用户已认证企业（关联企业）
    private String sdkQueryCustomerAddr = "/portal/v1/api/queryCustomerAddr";       //查询企业地址列表
    private String sdkQueryEnterpriseList = "/portal/v1/api/queryEnterpriseList"; //查询企业列表
    //    账号类型（逗号分隔）：0 总管理员 1子管理员 3普通员工
    private String sdkQueryCustomerAccountList = "/portal/v1/customerDetail/queryCustomerAccountList";//查询企业管理员列表
    //  账号类型：0超级管理员 1子管理员 2普通账号 3企业账号 5游客
    private String sdkQueryAccountAttributeList = "/portal/v1/api/queryAccountAttributeList";//查询企业管理员列表
    private String sdkQueryCustomerDetailByCode = "/portal/v1/customerDetail/queryCustomerDetailByCode"; //查询企业详细信息

    private String sdkQueryEnterpriseAccount = "/portal/v1/api/queryEnterpriseAccount"; //查询人员信息详情（personCode）
    private String sdkQueryUserAccountByPhone = "/portal/v1/api/queryUserAccountByPhone"; //查询人员信息详情（phone）

    private String sdkQueryAuthRecordList = "/portal/v1/api/queryAuthRecordList"; //查询员工认证记录
    private String sdkUpdateEnterpriseAdmin = "/portal/v1/api/updateEnterpriseAdmin"; //修改企业管理员信息

    //派单人员过滤查询接口
    private String sdkQueryUserByGroupId = "/portal/v1/api/queryUserByPositionAndProject";
    private String sdkCheckUserRelProject = "/portal/v1/api/checkUserRelProject";

    //PC端，企业管理员的园区查询，企业查询
    private String sdkQueryAdminRelEnterpriseList = "/portal/v1/api/queryAdminRelEnterpriseList";
    private String sdkQueryAdminRelProjectList = "/portal/v1/api/queryAdminRelProjectList";

    //员工认证，消息事件通知接口
    private String sdkProcessSubmitAuthRecord = "/portal/v1/api/open/submitAuthRecord";
    private String sdkProcessUpdateAuthRecord = "/portal/v1/api/open/updateAuthRecord";

//    private String httpQueryCusList = "/portal/v1/customerDetail/queryCustomerDetailList";//查询企业列表

}

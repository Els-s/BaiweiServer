package com.space.coupon.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.util.Date;

/**
 * 活动对象 coupon_campaigns
 *
 * @author kangmj
 * @date 2021-09-10
 */
@EqualsAndHashCode(callSuper = true)
@Data
@TableName("coupon_campaigns")
public class CouponCampaignsEntity extends CouponBaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 活动名称
     */
    @ApiModelProperty("活动名称")
    private String title;

    /**
     * 活动类型
     */
    @ApiModelProperty("活动类型")
    private String campaignType;

    /**
     * 活动状态
     */
    @ApiModelProperty("活动状态")
    private Integer status;

    /**
     * 卡券模板ID
     */
    @ApiModelProperty("卡券模板ID")
    private Long ruleId;

    /**
     * 卡券数量
     */
    @ApiModelProperty("卡券数量")
    private Long couponTotal;

    /**
     * 活动发送时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date sendAt;

    /**
     * 活动开始日期
     */
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date dateStart;

    /**
     * 活动结束日期
     */
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date dateEnd;

    /**
     * 活动详情
     */
    @ApiModelProperty("活动详情")
    private String detail;

    /**
     * 是否已终止
     */
    @ApiModelProperty("是否已终止")
    private Integer isStop;

    /**
     * 券发放量
     */
    @ApiModelProperty("券发放量")
    private Long sendCoupons;

    /**
     * 券使用量
     */
    @ApiModelProperty("券使用量")
    private Long usedCoupons;

    /**
     * 券回收率
     */
    @ApiModelProperty("券回收率")
    private Long couponUsedRatio;

    /**
     * 带动交易笔数
     */
    @ApiModelProperty("带动交易笔数")
    private Long bringTradeCount;

    /**
     * 带动交易金额
     */
    @ApiModelProperty("带动交易金额")
    private Long bringTradeAmount;

    /**
     * 带动实收
     */
    @ApiModelProperty("带动实收")
    private Long bringTradeCash;

    /**
     * 券抵扣金额
     */
    @ApiModelProperty("券抵扣金额")
    private Long couponAmount;

    /**
     * 发起商户
     */
    @ApiModelProperty("发起商户")
    private String issueMerchant;

    /**
     * 乐观锁
     */
    @ApiModelProperty("乐观锁")
    private Integer revision;

    /**
     * 删除符
     */
    @JsonIgnore
    private Boolean delFlag;

    /**
     * 搜索列
     */
    @ApiModelProperty("搜索列")
    @JsonIgnore
    private String searchInfo;

    /**
     * 修改时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date updateTime;
    /**
     * 修改人
     */
    private String updateBy;
}

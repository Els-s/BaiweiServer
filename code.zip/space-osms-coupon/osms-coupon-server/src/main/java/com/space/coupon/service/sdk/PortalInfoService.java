package com.space.coupon.service.sdk;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-09-22 13:52
 * @Version 1.0
 */
@Slf4j
@Component
public class PortalInfoService {

}

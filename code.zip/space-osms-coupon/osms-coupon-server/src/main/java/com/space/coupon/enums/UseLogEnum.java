package com.space.coupon.enums;

/**
 * UseLogEnum
 *
 * @Author kangmj
 * @date 2021-10-15 19:20
 * @Version 1.0
 */
public enum UseLogEnum {
    // 使用记录 使用状态
    使用("used"),
    退还("return"),
    ;

    private String code;

    UseLogEnum(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}

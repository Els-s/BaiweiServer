package com.space.coupon.service.sdk;


import cn.space.base.result.Response;
import cn.space.portal.sdk.BaseRequest;
import cn.space.portal.sdk.PortalClient;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * 门户SDK服务
 */
@Slf4j
@Component
public abstract class BaseSdkService {

    /**
     * SDK 查询
     *
     * @param portalUrl
     * @param token
     * @param paramsVo
     * @param <T>
     * @return
     */
    protected <T extends Response> Response execQuery(String portalUrl, String token, BaseRequest<T> paramsVo) {
        log.info("请求路径：portalUrl = {}, token = {}, paramVo={}\n "
                , portalUrl, token, JSONObject.toJSONString(paramsVo));
        PortalClient portalClient = new PortalClient(portalUrl);
        try {
            Response response = portalClient.execute(paramsVo, token);
            log.info("请求门户返回结果：response = {} \n", JSONObject.toJSONString(response));
            return response;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            e.printStackTrace();
        }
        return Response.error("500", "门户接口调用异常");
    }

}

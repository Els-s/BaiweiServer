package com.space.coupon.mapper;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.space.coupon.entity.CouponRuleEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * 卡券模板表
 *
 * @author kangmj
 * @email kangmingjing@qq.com
 * @date 2021-09-13 14:57:31
 */
@Mapper
public interface CouponRuleMapper extends BaseMapper<CouponRuleEntity> {

    IPage<CouponRuleEntity> queryRulePage(Page<CouponRuleEntity> page,
            @Param(Constants.WRAPPER) QueryWrapper<CouponRuleEntity> wrapper);

    CouponRuleEntity queryDetailsById(@Param("id") Long id);
}

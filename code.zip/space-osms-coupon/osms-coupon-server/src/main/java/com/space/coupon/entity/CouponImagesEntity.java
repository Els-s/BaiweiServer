package com.space.coupon.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.util.Date;

/**
 * 卡券图片表
 *
 * @author kangmj
 * @email kangmingjing@qq.com
 * @date 2021-09-13 14:57:31
 */
@EqualsAndHashCode(callSuper = true)
@Data
@TableName("coupon_images")
public class CouponImagesEntity extends CouponBaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 模板id
     */
    private Long ruleId;
    /**
     * 图片素材URL
     */
    private String imageUrl;
    /**
     * 是否是优惠券的封面
     */
    private Integer isIcon;
    /**
     * 创建人
     */
    private String createBy;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 更新人
     */
    private String updateBy;
    /**
     * 更新时间
     */
    private Date updateTime;

}

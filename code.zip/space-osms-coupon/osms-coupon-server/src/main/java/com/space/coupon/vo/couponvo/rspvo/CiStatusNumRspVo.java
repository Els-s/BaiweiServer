package com.space.coupon.vo.couponvo.rspvo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-09-18 15:41
 * @Version 1.0
 */
@Data
@ApiModel(value = "卡券状态数量Vo")
public class CiStatusNumRspVo {

    @ApiModelProperty("全部")
    private Integer allNum;
    @ApiModelProperty("未使用")
    private Integer unusedNum;
    @ApiModelProperty("已使用")
    private Integer usedNum;
    @ApiModelProperty("已过期")
    private Integer expiredNum;
    @ApiModelProperty("作废")
    private Integer voidNum;

    public CiStatusNumRspVo() {
    }

    public CiStatusNumRspVo(Integer allNum, Integer unusedNum, Integer usedNum, Integer expiredNum, Integer voidNum) {
        this.allNum = allNum;
        this.unusedNum = unusedNum;
        this.usedNum = usedNum;
        this.expiredNum = expiredNum;
        this.voidNum = voidNum;
    }
}

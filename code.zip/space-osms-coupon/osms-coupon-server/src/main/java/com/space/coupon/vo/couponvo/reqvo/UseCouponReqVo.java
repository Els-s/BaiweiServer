package com.space.coupon.vo.couponvo.reqvo;

import com.space.coupon.vo.ReqPageVo;
import com.space.coupon.vo.couponvo.ProductVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.util.List;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-09-16 21:48
 * @Version 1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(value = "卡券可用查询对象")
public class UseCouponReqVo extends ReqPageVo {

    /*
        {
        orderTotalPrice:订单总价
        结算方式:
        支付方式:
        是否个人结算：false
        结算单位：
        商品信息：{
            productId：
            productName：
            productPrice：商品价格

        }

        }
    **/
    @ApiModelProperty("订单总价")
    private BigDecimal orderTotalPrice;
    @ApiModelProperty("结算方式")
    private String settlementMethod;
    @ApiModelProperty("支付方式")
    private String paymentMethod;
    @ApiModelProperty("是否个人结算")
    private Boolean isPersonalSettlement;
    @ApiModelProperty("结算单位")
    private String settlementCompany;
    @ApiModelProperty("商品信息")
    private List<ProductVo> productInfo;
    @ApiModelProperty("应用场景：场地预定 1")
    private Integer scenes;
    //      搜索信息:‘1’全部，‘2’个人，‘3’企业"
    //      查类型 type：‘1’可使用，‘2’已使用，‘3’已过期")
    @ApiModelProperty("卡券类型： 1全部，2 个人，3 企业")
    private Integer searchType;
    @ApiModelProperty("用户类型code： 暂为搜索企业id")
    private String searchObjectCode;
}

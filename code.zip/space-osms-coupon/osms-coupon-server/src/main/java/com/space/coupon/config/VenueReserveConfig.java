package com.space.coupon.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * 场地服务配置
 *
 * @Author kangmj
 * @date 2021-10-09 17:49
 * @Version 1.0
 */
@Getter
@Setter
@Component
@ConfigurationProperties(prefix = "venue.reserve")
public class VenueReserveConfig {

    private String host;
    private String venueTypeTree = "/space/resourceManage/treeResource";
    private String querySpace = "/space/dubbo/querySpace";
}

package com.space.coupon.vo.couponvo.rspvo;

import com.space.coupon.vo.couponvo.ScopeVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;
import lombok.experimental.Accessors;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-09-22 9:02
 * @Version 1.0
 */
@Data
@Accessors(chain = true)
@ApiModel(value = "获取指定用户信息Vo")
public class UserInfoRspVo {

    @ApiModelProperty("有效号码")
    private List<String> validPhone;
    @ApiModelProperty("无效号码")
    private List<String> invalidPhone;
    @ApiModelProperty("输入数量")
    private Integer inputNum;
    @ApiModelProperty("有效数量")
    private Integer validNum;
    @ApiModelProperty("无效数量")
    private Integer invalidNum;
    @ApiModelProperty("有效号码集合--传参")
    private List<ScopeVo> scope;
}

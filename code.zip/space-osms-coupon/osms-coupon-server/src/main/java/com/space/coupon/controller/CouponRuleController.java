package com.space.coupon.controller;

import cn.space.portal.sdk.holder.UserHolder;
import cn.space.portal.sdk.io.LoginUserAccountInfo;
import com.space.coupon.entity.CouponRuleEntity;
import com.space.coupon.service.CouponRuleService;
import com.space.coupon.vo.RspPageVo;
import com.space.coupon.vo.RspVo;
import com.space.coupon.vo.couponvo.reqvo.QueryRuleListVo;
import com.space.coupon.vo.couponvo.reqvo.RuleAddReqVo;
import com.space.coupon.vo.couponvo.reqvo.RuleDelReqVo;
import com.space.log.annotation.OperaLog;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpHeaders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 卡券模板Controller
 *
 * @author kangmj
 * @date 2021-09-10
 */
@RestController
@RequestMapping("/rule")
@Api(tags = "卡券服务：卡券模板管理-PC")
@Slf4j
public class CouponRuleController {

    @Autowired
    CouponRuleService ruleService;

    /**
     * 查询卡券模板列表
     */
    @ApiOperation("查询卡券模板列表")
    @PostMapping("/queryList")
    public RspVo<RspPageVo<List<CouponRuleEntity>>> list(@RequestHeader(HttpHeaders.AUTHORIZATION) String token,
            @RequestBody QueryRuleListVo reqPageVo) {
        log.info("查询卡券模板列表请求参数：{}", reqPageVo);
        LoginUserAccountInfo loginUserAccountInfo = UserHolder.get();
        RspPageVo<List<CouponRuleEntity>> vo = ruleService.queryPage(reqPageVo, loginUserAccountInfo);
        return RspVo.success("ok", vo);
    }

    /**
     * 获取卡券模板详细信息
     */
    @ApiOperation("获取卡券模板详细信息")
    @GetMapping(value = "/queryDetails")
    public RspVo<CouponRuleEntity> getInfo(
            @ApiParam(value = "卡券模板ID") @RequestParam(name = "id") Long id) {
        log.info("获取卡券模板详细信息请求参数：{}", id);
        CouponRuleEntity ruleEntity = ruleService.queryDetailsById(id);
        return RspVo.success("ok", ruleEntity);
    }

    /**
     * 新增卡券模板
     */
    @ApiOperation("新增卡券模板")
    @OperaLog(opType = "新增", opInfo = "新增卡券模板")
    @PostMapping(value = "/add")
    public RspVo<Integer> add(@ApiParam(value = "新增卡券模板参数") @RequestBody RuleAddReqVo ruleAddReqVo) {
        log.info("新增卡券模板请求参数：{}", ruleAddReqVo);
        LoginUserAccountInfo loginUserInfo = UserHolder.get();
        int result = ruleService.addCouponRule(ruleAddReqVo, loginUserInfo);
        return RspVo.success("", result);
    }

    /**
     * 删除卡券模板
     */
    @ApiOperation("删除卡券模板")
    @OperaLog(opType = "删除", opInfo = "删除卡券模板")
    @PostMapping("/delete")
    public RspVo<Integer> remove(@ApiParam(value = "卡券模板ID集合") @RequestBody RuleDelReqVo delReqVo) {
        log.info("删除卡券模板请求参数：{}", delReqVo.getIds());
        LoginUserAccountInfo loginUserInfo = UserHolder.get();
        int result = ruleService.deleteCouponRuleByIds(delReqVo.getIds(), loginUserInfo);
        return RspVo.success("删除成功：" + result + "条", result);
    }

    /**
     * 复制卡券模板
     */
    @ApiOperation("复制卡券模板")
    @GetMapping("/copy")
    public RspVo<RuleAddReqVo> remove(@ApiParam(value = "卡券模板ID") @RequestParam(name = "id") Long id) {
        log.info("复制卡券模板请求参数：{}", id);
        RuleAddReqVo ruleEntity = ruleService.copyRule(id);
        return RspVo.success("ok", ruleEntity);
    }
}

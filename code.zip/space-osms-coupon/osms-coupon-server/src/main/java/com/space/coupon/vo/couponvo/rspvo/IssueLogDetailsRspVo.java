package com.space.coupon.vo.couponvo.rspvo;

import com.space.coupon.entity.CouponIssueLogEntity;
import com.space.coupon.entity.CouponRuleEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-09-26 15:39
 * @Version 1.0
 */
@Data
@ApiModel(value = "卡券状态数量Vo")
public class IssueLogDetailsRspVo {

    @ApiModelProperty("模板信息")
    private CouponRuleEntity rule;
    @ApiModelProperty("发放信息")
    private CouponIssueLogEntity issueLog;

    public IssueLogDetailsRspVo() {
    }

    public IssueLogDetailsRspVo(CouponRuleEntity rule, CouponIssueLogEntity issueLog) {
        this.rule = rule;
        this.issueLog = issueLog;
    }
}

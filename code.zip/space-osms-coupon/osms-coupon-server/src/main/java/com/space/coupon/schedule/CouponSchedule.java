package com.space.coupon.schedule;

import com.space.coupon.service.CouponIssueService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * 定时任务
 *
 * @Author kangmj
 * @date 2021-09-24 16:55
 * @Version 1.0
 */
@Component
@Slf4j
public class CouponSchedule {

    @Autowired
    CouponIssueService issueService;

    /**
     * 每日处理重复发放的ci
     */
    @Scheduled(cron = "0 5 0 * * ?")
    private void handleIssueCi() {
        log.info("Daily handle Issue Ci start=====");
        issueService.dailyHandleIssueCi();
        log.info("Daily handle Issue Ci end=====");
    }
}

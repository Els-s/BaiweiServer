package com.space.coupon.service.impl;

import cn.hutool.core.util.ObjectUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.space.coupon.entity.CouponDictEntity;
import com.space.coupon.mapper.CouponDictMapper;
import com.space.coupon.service.CouponDictService;
import com.space.coupon.util.CacheManager;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-09-14 14:39
 * @Version 1.0
 */
@Service
@Slf4j
public class CouponDictServiceImpl implements CouponDictService {

    @Autowired
    CouponDictMapper dictMapper;

    @Override
    public List<CouponDictEntity> queryDictInfo(String type) {
        List<CouponDictEntity> dictEntities = null;
        if (CacheManager.containsKey(type)) {
            dictEntities = (List<CouponDictEntity>) CacheManager.getValue(type);
        }
        if (ObjectUtil.isEmpty(dictEntities)) {
            // 是否增加租户条件
            dictEntities = dictMapper.selectList(new QueryWrapper<CouponDictEntity>().lambda()
                    .eq(CouponDictEntity::getTypeCode, type)
                    .orderByAsc(CouponDictEntity::getOrderNum));
            CacheManager.cache(type, dictEntities, 120);
        }
        return dictEntities;
    }
}

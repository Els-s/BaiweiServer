package com.space.coupon.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 卡券模板对象 coupon_rule
 *
 * @author kangmj
 * @date 2021-09-10
 */
@EqualsAndHashCode(callSuper = true)
@Data
@TableName("coupon_rule")
@ApiModel(value = "卡券模板")
public class CouponRuleEntity extends CouponBaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 模板名称
     */
    @ApiModelProperty("模板名称")
    private String ruleName;

    /**
     * 模板ID
     */
    @ApiModelProperty("模板Code")
    private String ruleCode;

    /**
     * 发放频次
     */
    @ApiModelProperty("发放频次：0=重复；1=一次性")
    private Integer frequency;


    /**
     * 卡券类型
     */
    @ApiModelProperty("卡券类型:1=优惠券")
    private Integer couponType;

    /**
     * 优惠类型
     */
    @ApiModelProperty("优惠类型:1=折扣券;2=金额券;3=时长券")
    private Integer discountType;

    /**
     * 卡券面值
     */
    @ApiModelProperty("卡券面值")
    private Float faceValue;

    /**
     * 是否有门槛
     */
    @ApiModelProperty("是否有门槛")
    private Boolean threshold;

    /**
     * 门槛值
     */
    @ApiModelProperty("门槛值")
    private Float thresholdValue;

    /**
     * 有效期限方式
     */
    @ApiModelProperty("有效期限方式:1=固定；0=非固定")
    private Integer validityPeriodType;

    /**
     * 非固定有效期值
     */
    @ApiModelProperty("非固定时有效期值")
    private Integer validityPeriodValue;

    /**
     * 有效期开始时间
     */
    @ApiModelProperty("有效期开始时间:yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date validPeriodStartTime;

    /**
     * 有效期结束时间
     */
    @ApiModelProperty("有效期结束时间:yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date validPeriodEndTime;

    /**
     * 发放开始日期
     */
    @ApiModelProperty("发放开始日期:yyyy-MM-dd")
    private String issueStartDate;

    /**
     * 发放结束日期
     */
    @ApiModelProperty("发放结束日期:yyyy-MM-dd")
    private String issueEndDate;

    /**
     * 定时发放时间
     */
    @ApiModelProperty("定时发放时间:HH:mm:ss")
    private String timedReleaseTime;

    /**
     * 应用场景
     */
    @ApiModelProperty("应用场景")
    private Integer scenes;
    /**
     * 模板状态
     */
    @ApiModelProperty("模板状态:1 未上线;2 已上线;3 已过期")
    private Integer useStatus;

    /**
     * 是否过期
     */
    @ApiModelProperty("是否过期")
    private Boolean expiredStatu;

    /**
     * 发放商户
     */
    @ApiModelProperty("发放商户")
    private String issueMerchant;

    /**
     * 活动ID
     */
    @ApiModelProperty("活动ID")
    private Long campaignsId;

    @ApiModelProperty("用户名称")
    private String personName;

    /**
     * 备注
     */
    @ApiModelProperty("备注")
    private String remark;

    /**
     * 发放数量
     */
    @ApiModelProperty("发放数量")
    private Integer issueNum;

    /**
     * 发放对象类型
     */
    @ApiModelProperty("发放对象类型")
    private Integer issueObjectType;

    /**
     * 搜索列
     */
    @ApiModelProperty("搜索列")
    @JsonIgnore
    private String searchInfo;

    /**
     * 删除标记
     */
    @JsonIgnore
    private Boolean delFlag;

    /**
     * 修改时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date updateTime;

    /**
     * 修改人
     */
    private String updateBy;

    @TableField(exist = false)
    @ApiModelProperty("产品信息--集合")
    private List<CouponProductEntity> productEntityList;

    @TableField(exist = false)
    @ApiModelProperty("卡券发放规则")
    private CouponRuleCycleEntity ruleCycle;

    @TableField(exist = false)
    @ApiModelProperty("重复频次：每月每日")
    private String repetitionFrequency;

    /**
     * 卡券面值Vo
     */
    @TableField(exist = false)
    @ApiModelProperty("卡券面值Vo")
    private String faceValueVo;

    /**
     * 门槛值Vo
     */
    @TableField(exist = false)
    @ApiModelProperty("门槛值Vo")
    private String thresholdValueVo;

    /**
     * 有效期数据list
     */
    @TableField(exist = false)
    @ApiModelProperty("有效期数据list")
    private List<String> validPeriodDate;

    /**
     * 发放起止日期数据list
     */
    @TableField(exist = false)
    @ApiModelProperty("发放起止日期数据list")
    private List<String> issueDate;

    /**
     * 是否可发放vo
     */
    @TableField(exist = false)
    @ApiModelProperty("是否可发放vo")
    private Boolean showIssue;
}

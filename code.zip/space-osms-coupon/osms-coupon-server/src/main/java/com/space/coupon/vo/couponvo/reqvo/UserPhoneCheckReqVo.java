package com.space.coupon.vo.couponvo.reqvo;

import com.space.coupon.vo.ReqPageVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;


/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-09-18 17:38
 * @Version 1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(value = "手机号码筛选Vo")
public class UserPhoneCheckReqVo extends ReqPageVo {

    @ApiModelProperty("手机号码集合")
    private List<String> phoneNos;
    @ApiModelProperty("发放渠道: 字典项")
    private Integer issueApp;
}

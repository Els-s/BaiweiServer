package com.space.coupon.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-09-10 16:40
 * @Version 1.0
 */
@Data
@ApiModel(value = "分页查询返回数据")
public class RspPageVo<T> {

    @ApiModelProperty("页码")
    private Long pageNo;
    @ApiModelProperty("每页数量")
    private Long pageSize;
    @ApiModelProperty("总数量")
    private Long total;
    @ApiModelProperty("页数")
    private Long pages;
    @ApiModelProperty("返回数据")
    private T data;

    public RspPageVo() {
    }

    public RspPageVo(Long pageNo, Long pageSize, Long pages, Long total, T date) {
        this.pageNo = pageNo;
        this.pageSize = pageSize;
        this.pages = pages;
        this.total = total;
        this.data = date;
    }
}

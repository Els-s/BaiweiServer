package com.space.coupon.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

/**
 * 卡券发放规则对象 coupon_rule_cycle
 *
 * @author kangmj
 * @date 2021-09-10
 */
@Data
@TableName("coupon_rule_cycle")
@ApiModel(value = "卡券发放规则模型")
public class CouponRuleCycleEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    /**
     * 卡券模板ID
     */
    @ApiModelProperty("卡券模板ID")
    private Long ruleId;

    /**
     * 发放频次;重复/一次性
     */
    @ApiModelProperty("发放频次;0=重复；1=一次性")
    private Integer frequency;

    /**
     * 重复频率
     */
    @ApiModelProperty("重复频率：MONTH_DAY=按日/月；WEEK=按周; CYCLE=按周期")
    private String repeatFrequency;

    /**
     * 日
     */
    @ApiModelProperty("日:‘ALL’每日，其他：‘1,2,3...31’字符串隔开字符集合")
    private String workDay;

    /**
     * 月
     */
    @ApiModelProperty("月:‘ALL’每月，其他：‘1,2,3...12’字符串隔开字符集合")
    private String workMonth;

    /**
     * 周
     */
    @ApiModelProperty("周：‘1,2,3...7’字符串隔开字符集合")
    private String workWeek;

    /**
     * 周期设置：非自定义
     */
    @ApiModelProperty("周期设置：CUSTOM_DAY=自定义；WEEK=按周；MONTH=按月；SEASON=按季；HALF_YEAR=按半年；YEAR=按年")
    private String cycleTime;

    /**
     * 自定义周期
     */
    @ApiModelProperty("自定义周期")
    private Integer customTime;

    /**
     * 定时发放时间
     */
    @ApiModelProperty("定时发放时间")
    private String timedReleaseTime;

    /**
     * 发放商户
     */
    @ApiModelProperty("发放商户")
    private String issueMerchant;

    /**
     * 活动ID
     */
    @ApiModelProperty("活动ID")
    private Long campaignsId;

    /**
     * 是否过期
     */
    @ApiModelProperty("是否过期")
    private Boolean expiredStatu;

    /**
     * 重复频率信息
     */
//    @ApiModelProperty("重复频率信息:每月每日")
//    private String repetitionFrequencyInfo;
}

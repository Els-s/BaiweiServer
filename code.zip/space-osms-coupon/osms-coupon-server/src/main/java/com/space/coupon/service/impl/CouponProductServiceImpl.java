package com.space.coupon.service.impl;

import cn.space.base.core.page.PageFactory;
import cn.space.base.utils.ToolUtil;
import cn.space.portal.sdk.io.LoginUserAccountInfo;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.space.coupon.common.CouponConstants;
import com.space.coupon.entity.CouponProductEntity;
import com.space.coupon.mapper.CouponProductMapper;
import com.space.coupon.service.CouponProductService;
import com.space.coupon.vo.RspPageVo;
import com.space.coupon.vo.couponvo.reqvo.ProductListReqVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-09-17 19:16
 * @Version 1.0
 */
@Service
@Slf4j
public class CouponProductServiceImpl implements CouponProductService {

    @Autowired
    private CouponProductMapper productMapper;

    @Override
    public RspPageVo<List<CouponProductEntity>> queryPage(ProductListReqVo reqPageVo,
            LoginUserAccountInfo loginUserInfo) {
        Page<CouponProductEntity> page = PageFactory.defaultPage();
        LambdaQueryWrapper<CouponProductEntity> queryWrapper = new QueryWrapper<CouponProductEntity>()
                .lambda().eq(CouponProductEntity::getRuleId, reqPageVo.getRuleId())
                .eq(ToolUtil.isNotEmpty(reqPageVo.getSelectProjectId()), CouponProductEntity::getProjectCode,
                        reqPageVo.getSelectProjectId())
                .like(ToolUtil.isNotEmpty(reqPageVo.getSearchInfo()), CouponProductEntity::getProductName,
                        reqPageVo.getSearchInfo())
                .orderByDesc(CouponProductEntity::getId);
        //查询数据
        IPage<CouponProductEntity> iPage = productMapper.selectPage(page, queryWrapper);
        return new RspPageVo<>(iPage.getCurrent(), iPage.getSize(), iPage.getPages(), iPage.getTotal(),
                iPage.getRecords());
    }
}

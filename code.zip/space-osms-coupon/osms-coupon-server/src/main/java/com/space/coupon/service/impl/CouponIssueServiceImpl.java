package com.space.coupon.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.PageUtil;
import cn.space.base.core.page.PageFactory;
import cn.space.base.result.Response;
import cn.space.base.utils.ToolUtil;
import cn.space.portal.sdk.io.LoginUserAccountInfo;
import cn.space.portal.sdk.request.QueryCustomerAccountRequest;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.space.coupon.common.CouponConstants;
import com.space.coupon.entity.*;
import com.space.coupon.enums.CouponStatusEnum;
import com.space.coupon.exception.CouponException;
import com.space.coupon.mapper.*;
import com.space.coupon.service.CouponIssueService;
import com.space.coupon.service.CouponRuleService;
import com.space.coupon.service.AsyncService;
import com.space.coupon.service.PortalService;
import com.space.coupon.service.sdk.PortalSdkService;
import com.space.coupon.util.CommonUtils;
import com.space.coupon.vo.RspPageVo;
import com.space.coupon.vo.couponvo.reqvo.IssueReqVo;
import com.space.coupon.vo.couponvo.ScopeVo;
import com.space.coupon.vo.couponvo.reqvo.QueryIssueListVo;
import com.space.coupon.vo.couponvo.reqvo.UserPhoneCheckReqVo;
import com.space.coupon.vo.couponvo.rspvo.IssueLogDetailsRspVo;
import com.space.coupon.vo.couponvo.rspvo.UserInfoRspVo;
import java.util.HashSet;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-09-15 14:23
 * @Version 1.0
 */
@Slf4j
@Service
public class CouponIssueServiceImpl implements CouponIssueService {

    @Autowired
    private CouponRuleMapper ruleMapper;

    @Autowired
    private CouponObjectMapper objectMapper;

    @Autowired
    private CouponCiMapper ciMapper;

    @Autowired
    private CouponIssueLogMapper issueLogMapper;

    @Autowired
    private CouponRuleService ruleService;

    @Autowired
    private AsyncService asyncService;

    @Autowired
    private PortalSdkService portalSdkService;

    @Autowired
    private PortalService portalService;

    /*
   {
       id:1, //卡券的id值
       object:1, //发放对象。  0 企业，1个人
       isAllScope:"0" //范围是否全部   "0"否，“1”是
       issueApp:1,   //发放应用: 字典项
       personType:1,  //用户类型：1 企业管理员 2 企业员工 3普通用户 4指定用户
        //发放范围 为企业和企业用户时，范围为对象集合{object:"companyId企业ID编码", name:"深圳XX科技有限公司1"}；普通用户时为空；制定用户{object:"手机号", name:""}
       scope:[
           {object:"", name:""},   //对象 //对象名称
           {object:"", name:""},
           {object:"", name:""}
       ]
       issueNum:"",    //发放数量
   }
   * */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void addIssue(String token, IssueReqVo map, LoginUserAccountInfo loginUserInfo) {
        Long ruleId = map.getId();
        // 判断卡券状态
        CouponRuleEntity ruleEntity = ruleMapper.selectById(ruleId);
        if (!CouponStatusEnum.OFFLINE.getCode().equals(ruleEntity.getUseStatus())) {
            throw new CouponException(CouponConstants.FAILED_CODE, "卡券模板已被发放，无法重复发放");
        }
        Integer objectType = map.getObjectType();
        Integer issueNum = map.getIssueNum();
        // 更新卡券状态
        updateRule(ruleId, objectType, issueNum);
        if (CouponStatusEnum.OBJECTTYPE_COMPANY.getCode().equals(objectType)) {
            // 企业
            List<ScopeVo> scopeVos = map.getScope();
            List<CouponObjectEntity> objectEntityList = new ArrayList<>(16);
            handleScopeBase(ruleId, objectType, issueNum, loginUserInfo, scopeVos, objectEntityList);
            asyncService.issueCouponTask(objectEntityList, loginUserInfo);
        } else {
            // 用户
            handleIssuePerson(ruleId, objectType, issueNum, map, loginUserInfo, token);
        }
    }

    private void handleIssuePerson(Long ruleId, Integer objectType, Integer issueNum,
            IssueReqVo map, LoginUserAccountInfo loginUserInfo, String token) {
        // personType:1,  //用户类型：1 企业管理员 2 企业员工 3普通用户 4指定用户
        List<ScopeVo> scopeVos = map.getScope();
        List<CouponObjectEntity> objectEntityList = new ArrayList<>(16);
        switch (map.getPersonType()) {
            case 1:
                scopeVos.forEach(x -> {
                    // 获取企业管理员用户
                    getCompanyUserInfo("0,1", ruleId, objectType, issueNum, loginUserInfo, token, objectEntityList, x);
                });
                asyncService.issueCouponTask(objectEntityList, loginUserInfo);
                break;
            case 2:
                scopeVos.forEach(x -> {
                    // 获取企业普通用户
                    getCompanyUserInfo("3", ruleId, objectType, issueNum, loginUserInfo, token, objectEntityList, x);
                });
                asyncService.issueCouponTask(objectEntityList, loginUserInfo);
                break;
            case 3:
                // 所有普通用户
                JSONObject body = new JSONObject()
                        .fluentPut("accountTypes", "2")
                        .fluentPut("pageNo", 1)
                        .fluentPut("pageSize", CouponConstants.PAGE_SIZE_BATCH);
                Response response = portalService.queryAccountAttributeList(token, body);
                JSONObject jsonObject = JSONObject.parseObject(JSON.toJSONString(response.getData()));
                Integer totalCount = jsonObject.getInteger("totalCount");
                log.info("=======================portal queryAccountAttributeList totalCount={}", totalCount);
                handleNormalUser(ruleId, objectType, issueNum, loginUserInfo, jsonObject);
                if (totalCount > CouponConstants.PAGE_SIZE_BATCH) {
                    int totalPage = PageUtil.totalPage(totalCount, CouponConstants.PAGE_SIZE_BATCH);
                    for (int i = 2; i < totalPage; i++) {
                        log.info("=======================portal queryAccountAttributeList totalPage={}", i);
                        body.put("pageNo", i);
                        Response res = portalService.queryAccountAttributeList(token, body);
                        JSONObject data = JSONObject.parseObject(JSON.toJSONString(res.getData()));
                        handleNormalUser(ruleId, objectType, issueNum, loginUserInfo, data);
                    }
                }
                break;
            case 4:
                // 指定用户
                handleScopeBase(ruleId, objectType, issueNum, loginUserInfo, scopeVos, objectEntityList);
                asyncService.issueCouponTask(objectEntityList, loginUserInfo);
                break;
            default:
                break;
        }
    }

    private void handleScopeBase(Long ruleId, Integer objectType, Integer issueNum, LoginUserAccountInfo loginUserInfo,
            List<ScopeVo> scopeVos, List<CouponObjectEntity> objectEntityList) {
        scopeVos.forEach(x -> {
            CouponObjectEntity objectEntity = new CouponObjectEntity();
            objectEntity.setRuleId(ruleId);
            objectEntity.setTenementCode(loginUserInfo.getTenementCode());
            objectEntity.setCreateBy(loginUserInfo.getPersonCode());
            objectEntity.setObjectType(objectType);
            objectEntity.setObjectId(x.getObjectId());
            objectEntity.setObjectName(x.getName());
            objectEntity.setRemainNum(issueNum);
            // 发放状态
            objectEntity.setIssuedNum(issueNum);
            // 卡券类型
            objectMapper.insert(objectEntity);
            objectEntityList.add(objectEntity);
        });
    }

    private void handleNormalUser(Long ruleId, Integer objectType, Integer issueNum, LoginUserAccountInfo loginUserInfo,
            JSONObject data) {
        List<JSONObject> users = getList(data);
        List<CouponObjectEntity> objectEntityList = new ArrayList<>(16);
        getUserInfo(ruleId, objectType, issueNum, loginUserInfo, users, objectEntityList);
        asyncService.issueCouponTask(objectEntityList, loginUserInfo);
    }

    private List<JSONObject> getList(JSONObject data) {
        return JSONObject.parseArray(JSON.toJSONString(data.getJSONArray("list")),
                JSONObject.class);
    }

    private void getUserInfo(Long ruleId, Integer objectType, Integer issueNum, LoginUserAccountInfo loginUserInfo,
            List<JSONObject> users, List<CouponObjectEntity> objectEntityList) {
        users.forEach(x -> {
            CouponObjectEntity objectEntity = new CouponObjectEntity();
            objectEntity.setRuleId(ruleId);
            objectEntity.setTenementCode(loginUserInfo.getTenementCode());
            objectEntity.setCreateBy(loginUserInfo.getPersonCode());
            objectEntity.setObjectType(objectType);
            objectEntity.setObjectId(x.getString("personCode"));
            objectEntity.setObjectName(x.getString("realName"));
            objectEntity.setRemainNum(issueNum);
            // 发放状态
            objectEntity.setIssuedNum(issueNum);
            // 卡券类型
            objectMapper.insert(objectEntity);
            objectEntityList.add(objectEntity);
        });
    }

    private void getCompanyUserInfo(String userType, Long ruleId, Integer objectType, Integer issueNum,
            LoginUserAccountInfo loginUserInfo,
            String token, List<CouponObjectEntity> objectEntityList, ScopeVo x) {
        QueryCustomerAccountRequest paramsSdkVo = new QueryCustomerAccountRequest();
        paramsSdkVo.setAccountType(userType);
        paramsSdkVo.setCustomerCode(x.getObjectId());
        Response response = portalSdkService.queryCustomerAccountList(token, paramsSdkVo);
        if (!CouponConstants.SUCCESS_CODE.equals(response.getCode())) {
            // 异常判断
            log.error("getCompanyUserInfo 查询企业账号====查询门户数据异常={}", response);
            throw CouponException.creat("查询门户数据异常");
        }
        JSONObject jsonObject = JSONObject.parseObject(JSON.toJSONString(response.getData()));
        List<JSONObject> users = getList(jsonObject);
        if (CollUtil.isNotEmpty(users)) {
            getUserInfo(ruleId, objectType, issueNum, loginUserInfo, users, objectEntityList);
        }
    }

    @Override
    public RspPageVo<List<CouponIssueLogEntity>> queryPage(QueryIssueListVo reqPageVo,
            LoginUserAccountInfo loginUserInfo) {
        Page<CouponIssueLogEntity> page = PageFactory.defaultPage();
        QueryWrapper<CouponIssueLogEntity> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("t1.tenement_code", loginUserInfo.getTenementCode());
        queryWrapper.eq("t1.show_status", CouponConstants.SHOW_STATUS_YES);
        queryWrapper.eq(ToolUtil.isNotEmpty(reqPageVo.getDiscountType()), "t1.discount_type",
                reqPageVo.getDiscountType());
        queryWrapper.eq(ToolUtil.isNotEmpty(reqPageVo.getThreshold()), "t1.threshold",
                reqPageVo.getThreshold());
        queryWrapper.eq(ToolUtil.isNotEmpty(reqPageVo.getValidityPeriodType()),
                "t1.validity_period_type", reqPageVo.getValidityPeriodType());
        queryWrapper.eq(ToolUtil.isNotEmpty(reqPageVo.getScenes()), "t1.scenes",
                reqPageVo.getScenes());
        queryWrapper.eq(ToolUtil.isNotEmpty(reqPageVo.getUseStatus()), "t1.use_status",
                reqPageVo.getUseStatus());
        queryWrapper.like(ToolUtil.isNotEmpty(reqPageVo.getSearchInfo()), "t2.search_info",
                reqPageVo.getSearchInfo());
        wrapperValidDate(reqPageVo, queryWrapper);

        queryWrapper.orderByDesc("t1.id");
        //查询数据
        IPage<CouponIssueLogEntity> iPage = issueLogMapper.queryPage(page, queryWrapper);
        List<CouponIssueLogEntity> issueLogList = iPage.getRecords();
        issueLogList.forEach(this::handleIssueLogVo);
        return new RspPageVo<>(iPage.getCurrent(), iPage.getSize(), iPage.getPages(),
                iPage.getTotal(), issueLogList);
    }

    private void wrapperValidDate(QueryIssueListVo reqPageVo, QueryWrapper<CouponIssueLogEntity> queryWrapper) {
        if (ToolUtil.isNotEmpty(reqPageVo.getValidPeriodDate())) {
            // 开始时间小于搜索结束时间&结束时间大于开始时间即满足
            List<String> validPeriodDate = reqPageVo.getValidPeriodDate();
            CommonUtils.sortTimeStr(validPeriodDate);
            DateTime startTime = DateUtil.parse(validPeriodDate.get(0));
            DateTime endTime = DateUtil.parse(validPeriodDate.get(1));
            queryWrapper.apply(
                    "date_format (t1.valid_period_start_time,'%Y-%m-%d') <= date_format('" + endTime
                            + "','%Y-%m-%d')");
            queryWrapper.apply(
                    "date_format (t1.valid_period_end_time,'%Y-%m-%d') >= date_format('" + startTime
                            + "','%Y-%m-%d')");
        }
    }

    private void handleIssueLogVo(CouponIssueLogEntity x) {
        List<String> validPeriodList = new ArrayList<>(2);
        validPeriodList.add(new DateTime(x.getValidPeriodStartTime()).toString());
        validPeriodList.add(new DateTime(x.getValidPeriodEndTime()).toString());
        x.setValidPeriodDate(validPeriodList);
        Float faceValue = x.getFaceValue();
        Float thresholdValue = x.getThresholdValue();
        Boolean isThreshold = x.getThreshold();
        String faceValueVo = "";
        String thresholdValueVo = "";
        switch (x.getDiscountType()) {
            case CouponConstants.OFFER_DISCOUNT_COUPON:
                faceValueVo = CommonUtils.handleFloatStr(faceValue / 10) + "折";
                thresholdValueVo = isThreshold ? CommonUtils.handleFloatStr(thresholdValue) + "元" : "无";
                break;
            case CouponConstants.OFFER_CASH_COUPON:
                faceValueVo = CommonUtils.handleFloatStr(faceValue) + "元";
                thresholdValueVo = isThreshold ? CommonUtils.handleFloatStr(thresholdValue) + "元" : "无";
                break;
            case CouponConstants.OFFER_DURATION_COUPON:
                faceValueVo = CommonUtils.handleFloatStr(faceValue) + "小时";
                thresholdValueVo = isThreshold ? CommonUtils.handleFloatStr(thresholdValue) + "小时" : "无";
                break;
            default:
                break;
        }
        x.setFaceValueVo(faceValueVo);
        x.setThresholdValueVo(thresholdValueVo);
        // 发放范围数量
        x.setObjectsNum(1);
    }

    @Override
    public IssueLogDetailsRspVo queryDetailsById(Long id, LoginUserAccountInfo loginUserInfo) {
        //查询数据
        CouponIssueLogEntity issueLog = issueLogMapper.queryDetailsById(id,
                loginUserInfo.getTenementCode());
        issueLog.setIssueObjectVo("企业内部共用");
//        handleIssueLogVo(issueLog);
        if (ObjectUtil.isEmpty(issueLog)) {
            throw new CouponException(CouponConstants.FAILED_CODE, "此条数据已被删除");
        }
        List<CouponObjectEntity> objects = objectMapper.selectList(
                new QueryWrapper<CouponObjectEntity>().lambda()
                        .eq(CouponObjectEntity::getRuleId, issueLog.getRuleId()));
        issueLog.setObjectList(objects);
        CouponRuleEntity ruleEntity = ruleService.queryDetailsById(issueLog.getRuleId());
        return new IssueLogDetailsRspVo(ruleEntity, issueLog);
    }

    @Override
    public UserInfoRspVo getDesignatedUserInfo(UserPhoneCheckReqVo map,
            LoginUserAccountInfo loginUserInfo, String token) {
        List<String> phones = map.getPhoneNos();
        Set<String> phoneSet = new HashSet<>(phones);
        List<String> validPhone = new ArrayList<>(CouponConstants.LIST_INIT_LENGTH);
        List<String> invalidPhone = new ArrayList<>(CouponConstants.LIST_INIT_LENGTH);
        List<ScopeVo> scope = new ArrayList<>(CouponConstants.LIST_INIT_LENGTH);
        phoneSet.forEach(x -> {
            JSONObject param = new JSONObject().fluentPut("phone", x);
            JSONObject object = JSONObject.parseObject(
                    JSON.toJSONString(portalService.queryAccountAttributeList(token, param).getData()));
            Integer total = object.getInteger("totalCount");
            if (total > 0) {
                validPhone.add(x);
                List<JSONObject> users = getList(object);
                scope.add(new ScopeVo().setObjectId(users.get(0).getString("personCode"))
                        .setName(users.get(0).getString("realName")));
            } else {
                invalidPhone.add(x);
            }
        });
        UserInfoRspVo userInfoRspVo = new UserInfoRspVo()
                .setScope(scope)
                .setInputNum(phones.size())
                .setValidNum(validPhone.size())
                .setInvalidNum(invalidPhone.size())
                .setValidPhone(validPhone)
                .setInvalidPhone(invalidPhone);
        return userInfoRspVo;
    }

    @Override
    public void dailyHandleIssueCi() {
        DateTime nowTime = new DateTime();
        DateTime beginOfDay = DateUtil.beginOfDay(nowTime);
        DateTime endOfDay = DateUtil.endOfDay(nowTime);
        QueryWrapper<CouponCiEntity> wrapper = new QueryWrapper<>();
        wrapper.apply("date_format (issue_time,'%Y-%m-%d') >= date_format('" + beginOfDay
                + "','%Y-%m-%d')");
        wrapper.apply("date_format (issue_time,'%Y-%m-%d') <= date_format('" + endOfDay
                + "','%Y-%m-%d')");
        wrapper.eq(CouponConstants.DEL_FLAG_STR, CouponConstants.DEL_FLAG_FALSE);
        wrapper.eq(CouponConstants.SHOW_STATUS_STR, CouponConstants.SHOW_STATUS_NO);
        CouponCiEntity ciEntity = new CouponCiEntity();
        ciEntity.setShowStatus(1);
        int updateCi = ciMapper.update(ciEntity, wrapper);
        log.info("==============每日处理ci数据=={}条", updateCi);
        // 发放记录更新
        updateLog(beginOfDay, endOfDay);
    }

    private void updateLog(DateTime beginOfDay, DateTime endOfDay) {
        QueryWrapper<CouponIssueLogEntity> logWrapper = new QueryWrapper<>();
        logWrapper.apply("date_format (issue_time,'%Y-%m-%d') >= date_format('" + beginOfDay
                + "','%Y-%m-%d')");
        logWrapper.apply("date_format (issue_time,'%Y-%m-%d') <= date_format('" + endOfDay
                + "','%Y-%m-%d')");
        logWrapper.eq(CouponConstants.SHOW_STATUS_STR, CouponConstants.SHOW_STATUS_NO);
        CouponIssueLogEntity logEntity = new CouponIssueLogEntity();
        logEntity.setShowStatus(1);
        logEntity.setIssueTime(new DateTime());
        int updateLog = issueLogMapper.update(logEntity, logWrapper);
        log.info("==============每日处理log数据=={}条", updateLog);
    }

    private void updateRule(Long ruleId, Integer objectType, Integer issueNum) {
        CouponRuleEntity ruleEntity = new CouponRuleEntity();
        ruleEntity.setId(ruleId);
        ruleEntity.setIssueObjectType(objectType);
        // 更新卡券已上线
        ruleEntity.setUseStatus(CouponStatusEnum.ONLINE.getCode());
//        ruleEntity.setIssueNum(issueNum);
        int result = ruleMapper.updateById(ruleEntity);
    }
}

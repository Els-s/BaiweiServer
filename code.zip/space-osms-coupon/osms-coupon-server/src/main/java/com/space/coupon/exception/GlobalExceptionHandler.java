package com.space.coupon.exception;

import cn.space.base.result.Response;
import com.space.coupon.vo.RspVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * GlobalExceptionHandler
 *
 * @Author kangmj
 * @date 2021-09-27 16:56
 * @Version 1.0
 */
@ControllerAdvice
@Order(1)
@Slf4j
public class GlobalExceptionHandler {

    @ExceptionHandler(CouponException.class)
    @ResponseBody
    @ResponseStatus(HttpStatus.OK)
    public Response handleCouponException(CouponException couponException) {
        log.error(couponException.getMessage(), couponException);
        return Response.error(couponException.getCode(), couponException.getMsg());
    }

    @ExceptionHandler(Exception.class)
    @ResponseBody
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public Response handleException(Exception ex) {
        log.error(ex.getMessage(), ex);
        return Response.error("服务异常，请稍后重试");
    }
}

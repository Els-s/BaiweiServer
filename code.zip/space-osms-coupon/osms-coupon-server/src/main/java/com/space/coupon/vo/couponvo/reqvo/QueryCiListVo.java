package com.space.coupon.vo.couponvo.reqvo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.space.coupon.vo.ReqPageVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.util.List;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-09-23 14:32
 * @Version 1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(value = "卡券列表查询")
public class QueryCiListVo extends ReqPageVo {

    @ApiModelProperty("优惠类型:1=金额券;2=时长券;3=折扣券,null=全部")
    private Integer discountType;
    @ApiModelProperty("使用门槛:0=没有，1=有，null=全部")
    private Integer threshold;
    @ApiModelProperty("应用场景：1=场景预定")
    private Integer scenes;
    @ApiModelProperty("卡券状态")
    private Integer useStatus;
    @ApiModelProperty("有效期搜索")
    private List<String> validPeriodDate;

    @Override
    public String toString() {
        return "QueryCiListVo{" +
                "discountType=" + discountType +
                ", threshold=" + threshold +
                ", scenes=" + scenes +
                ", validPeriodDate=" + validPeriodDate +
                "} " + super.toString();
    }
}

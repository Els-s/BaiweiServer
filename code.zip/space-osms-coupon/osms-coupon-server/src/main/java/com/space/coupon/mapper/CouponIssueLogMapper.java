package com.space.coupon.mapper;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.space.coupon.entity.CouponIssueLogEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * 卡券发放记录表
 *
 * @author kangmj
 * @email kangmingjing@qq.com
 * @date 2021-09-13 14:57:31
 */
@Mapper
public interface CouponIssueLogMapper extends BaseMapper<CouponIssueLogEntity> {

    IPage<CouponIssueLogEntity> queryPage(Page<CouponIssueLogEntity> page,
            @Param(Constants.WRAPPER) QueryWrapper<CouponIssueLogEntity> wrapper);

    CouponIssueLogEntity queryDetailsById(@Param("id") Long id, @Param("tenementCode") String tenementCode);
}

package com.space.coupon.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-09-09 11:28
 * @Version 1.0
 */
@Data
@ApiModel(value = "分页查询")
public class ReqPageVo {

    @ApiModelProperty("页码")
    private Integer pageNo;
    @ApiModelProperty("每页数量")
    private Integer pageSize;
    @ApiModelProperty("搜索信息")
    private String searchInfo;
    @ApiModelProperty("租户ID编码")
    private String tenementCode;
    @ApiModelProperty("园区ID编码")
    private String projectCode;
    @ApiModelProperty("企业ID编码")
    private String companyId;
    @ApiModelProperty("租客类型")
    private String cusType;
    @ApiModelProperty("手机号")
    private String phone;
    @ApiModelProperty("用户编码")
    private String personCode;
    /**
     * 请求状态
     */
    @ApiModelProperty("请求状态")
    private String type;
}

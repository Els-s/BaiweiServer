package com.space.coupon.exception;

import com.space.coupon.common.CouponConstants;
import com.space.coupon.enums.ErrorEnum;
import lombok.Getter;
import lombok.Setter;

/**
 * CouponException
 *
 * @Author kangmj
 * @date 2021-09-15 15:49
 * @Version 1.0
 */
@Getter
@Setter
public class CouponException extends RuntimeException {

    private static final long serialVersionUID = 1L;
    private String msg;
    private String code;

    public CouponException() {
    }

    /**
     * CouponException
     *
     * @param code code
     * @param msg  msg
     */
    public CouponException(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    /**
     * CouponException
     *
     * @param errorEnum errorEnum
     */
    public CouponException(ErrorEnum errorEnum) {
        this.code = String.valueOf(errorEnum.getCode());
        this.msg = errorEnum.getMsg();
    }

    public static CouponException creat(String msg) {
        return new CouponException(CouponConstants.FAILED_CODE, msg);
    }
}

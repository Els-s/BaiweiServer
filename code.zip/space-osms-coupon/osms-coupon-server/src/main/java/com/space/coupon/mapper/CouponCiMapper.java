package com.space.coupon.mapper;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.space.coupon.entity.CouponCiEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * 卡券表
 *
 * @author kangmj
 * @email kangmingjing@qq.com
 * @date 2021-09-13 14:57:31
 */
@Mapper
public interface CouponCiMapper extends BaseMapper<CouponCiEntity> {

    IPage<CouponCiEntity> queryRulePage(Page<CouponCiEntity> page,
            @Param(Constants.WRAPPER) QueryWrapper<CouponCiEntity> queryWrapper);

    CouponCiEntity selectByIdProduct(@Param("id") Long id);
}

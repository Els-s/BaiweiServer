package com.space.coupon.vo.couponvo;

import com.space.coupon.entity.CouponCiEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-09-10 18:25
 * @Version 1.0
 */
@Data
@ApiModel(value = "个人&企业优惠券列表数据")
public class CouponObjectVo {

    @ApiModelProperty("优惠券列表信息")
    private List<CouponCiEntity> coupons;
    @ApiModelProperty("可用优惠券数量：下单时返回")
    private int availableCouponNum;
}

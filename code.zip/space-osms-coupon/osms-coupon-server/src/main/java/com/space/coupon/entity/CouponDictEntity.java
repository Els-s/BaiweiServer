package com.space.coupon.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 字典明细对象 coupon_dict
 *
 * @author kangmj
 * @date 2021-09-14
 */
@Data
@TableName("coupon_dict")
@ApiModel(value = "字典项")
public class CouponDictEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId
    private Long id;

    /**
     * 数据字典应用code
     */
    @ApiModelProperty("数据字典应用code")
    private Integer code;

    /**
     * 数据字典key
     */
    @ApiModelProperty("数据字典key")
    private String valueKey;

    /**
     * 数据字典value对应名字
     */
    @ApiModelProperty("数据字典value对应名字")
    private String valueName;

    /**
     * 数据字典业务代码
     */
    @ApiModelProperty("数据字典业务代码")
    private String typeCode;

    /**
     * 上级id
     */
    @ApiModelProperty("上级id")
    private Long parentId;

    /**
     * 排序
     */
    @ApiModelProperty("排序")
    private Integer orderNum;

    /**
     * 租户编码
     */
    @ApiModelProperty("租户编码")
    private String tenementCode;
}

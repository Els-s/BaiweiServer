package com.space.coupon.vo.couponvo.reqvo;

import com.space.coupon.vo.ReqPageVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-09-26 16:10
 * @Version 1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(value = "删除卡券信息")
public class RuleDelReqVo extends ReqPageVo {

    @ApiModelProperty("模板ID集合")
    List<Integer> ids;
}

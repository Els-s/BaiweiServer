package com.space.coupon.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

/**
 * 卡券适用产品对象 coupon_product
 *
 * @author kangmj
 * @date 2021-09-10
 */
@EqualsAndHashCode(callSuper = true)
@Data
@TableName("coupon_product")
@ApiModel(value = "产品模型")
public class CouponProductEntity extends CouponBaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 卡券模板ID
     */
    @ApiModelProperty("卡券模板ID")
    private Long ruleId;

    /**
     * 产品ID
     */
    @ApiModelProperty("产品ID")
    private String productId;

    /**
     * 产品名称
     */
    @ApiModelProperty("产品名称")
    private String productName;

    /**
     * 产品信息
     */
    @ApiModelProperty("产品信息")
    private String productInfo;

    /**
     * 活动ID
     */
    @ApiModelProperty("活动ID")
    private Long campaignsId;

    /**
     * 发放商户
     */
    @ApiModelProperty("发放商户")
    private String issueMerchant;

    /**
     * 卡券类型
     */
    @ApiModelProperty("卡券类型")
    private Integer couponType;

    /**
     * 删除标记
     */
    @JsonIgnore
    private Boolean delFlag;

    /**
     * 搜索列
     */
    @ApiModelProperty("搜索列")
    @JsonIgnore
    private String searchInfo;
}

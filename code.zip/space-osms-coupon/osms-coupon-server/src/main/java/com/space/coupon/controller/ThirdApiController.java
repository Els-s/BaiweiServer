package com.space.coupon.controller;

import cn.hutool.core.util.StrUtil;
import cn.space.base.result.Response;
import cn.space.portal.sdk.holder.UserHolder;
import cn.space.portal.sdk.io.LoginUserAccountInfo;
import com.alibaba.fastjson.JSONObject;
import com.space.coupon.service.PortalService;
import com.space.coupon.service.VenueReserveService;
import com.space.coupon.vo.RspVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpHeaders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 外部API接口
 *
 * @Author kangmj
 * @date 2021-10-09 17:45
 * @Version 1.0
 */
@RestController
@RequestMapping("/openapi")
@Api(tags = "卡券服务：外部API接口")
@Slf4j
public class ThirdApiController {

    @Autowired
    private VenueReserveService venueReserveService;

    @Autowired
    private PortalService portalService;

    @ApiOperation("查询场地类型树")
    @PostMapping("/venue/getVenueTypeTree")
    public JSONObject getVenueTypeTree(@RequestHeader(HttpHeaders.AUTHORIZATION) String token,
            @RequestBody JSONObject params) {
        log.info("查询场地类型树请求参数：{}", params);
        if (StrUtil.isBlank(params.getString("projectCode"))) {
            params.put("projectCode", "ZH_00001_XM_00000001");
        }
        return venueReserveService.getVenueTypeTree(token, params);
    }

    @ApiOperation("查询场地列")
    @PostMapping("/venue/querySpace")
    public JSONObject querySpace(@RequestHeader(HttpHeaders.AUTHORIZATION) String token,
            @RequestBody JSONObject params) {
        log.info("查询场地列请求参数：{}", params);
        return venueReserveService.querySpace(token, params);
    }

    /**
     * 查询用户关联项目
     */
    @ApiOperation("查询用户关联项目")
    @RequestMapping("/portal/queryAccountRelProject")
    public Response queryAccountRelProject(@RequestHeader(HttpHeaders.AUTHORIZATION) String token,
            @RequestBody JSONObject params) {
        return portalService.queryAccountRelProject(token, params);
    }

    /**
     * 查询企业列表
     */
    @ApiOperation("查询企业列表")
    @RequestMapping("/portal/queryEnterpriseList")
    public Response queryEnterpriseList(@RequestHeader(HttpHeaders.AUTHORIZATION) String token,
            @RequestBody JSONObject params) {
        return portalService.queryEnterpriseList(token, params);
    }
}

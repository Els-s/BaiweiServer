package com.space.coupon.service;

import cn.space.portal.sdk.io.LoginUserAccountInfo;
import com.alibaba.fastjson.JSONObject;
import com.space.coupon.entity.CouponCiEntity;
import com.space.coupon.vo.RspPageVo;
import com.space.coupon.vo.ReqPageVo;
import com.space.coupon.vo.couponvo.reqvo.QueryCiListVo;
import com.space.coupon.vo.couponvo.rspvo.CiStatusNumRspVo;

import com.space.coupon.vo.couponvo.rspvo.OpenApiCiRspVo;
import java.util.List;

/**
 * 卡券Service接口
 *
 * @author kangmj
 * @date 2021-09-10
 */
public interface CouponCiService {

    /**
     * queryPage
     *
     * @param reqPageVo     .
     * @param loginUserInfo .
     * @return PageVo
     */
    RspPageVo<List<CouponCiEntity>> queryPage(QueryCiListVo reqPageVo, LoginUserAccountInfo loginUserInfo);

    /**
     * queryDetailsById
     *
     * @param id .
     * @return
     */
    CouponCiEntity queryDetailsById(Long id);

    /**
     * deleteCiByIds
     *
     * @param ids
     * @param loginUserInfo
     * @return
     */
    int deleteCiByIds(List<Integer> ids, LoginUserAccountInfo loginUserInfo);

    /**
     * queryStatusNum
     *
     * @param reqPageVo
     * @param loginUserInfo
     * @return
     */
    CiStatusNumRspVo queryStatusNum(ReqPageVo reqPageVo, LoginUserAccountInfo loginUserInfo);

    /**
     * queryDetailsVo
     *
     * @param map
     * @return
     */
    OpenApiCiRspVo queryDetailsVo(JSONObject map);
}

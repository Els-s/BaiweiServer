package com.space.coupon.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.space.coupon.entity.CouponDictEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * 字典明细Mapper接口
 *
 * @author kangmj
 * @date 2021-09-14
 */
@Mapper
public interface CouponDictMapper extends BaseMapper<CouponDictEntity> {

}

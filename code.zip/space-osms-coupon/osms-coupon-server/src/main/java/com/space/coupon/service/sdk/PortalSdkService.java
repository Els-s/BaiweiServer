package com.space.coupon.service.sdk;


import cn.space.base.result.Response;
import cn.space.portal.sdk.PortalClient;
import cn.space.portal.sdk.request.*;
import cn.space.portal.sdk.response.QueryCustomerAccountResponse;
import cn.space.portal.sdk.response.QueryCustomerAccountResponse.ListItem;
import com.alibaba.fastjson.JSONObject;
import com.space.coupon.config.PortalConf;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * 门户SDK服务
 */
@Slf4j
@Component
public class PortalSdkService extends BaseSdkService {

    @Resource
    private PortalConf portalConf;

    /**
     * 添加企业账号
     *
     * @param token
     * @param paramsSdkVo
     * @return
     */
    public Response addEnterpriseAdmin(String token, AddEnterpriseAccountRequest paramsSdkVo) {

        String portalUrl = portalConf.getHost() + portalConf.getSdkAddCompanyAdmin();
        return execQuery(portalUrl, token, paramsSdkVo);
    }

    /**
     * 查询企业账号
     *
     * @param token
     * @param paramsSdkVo
     * @return
     */
    public Response queryCustomerAccountList(String token, QueryCustomerAccountRequest paramsSdkVo) {

        String portalUrl = portalConf.getHost() + portalConf.getSdkQueryCustomerAccountList();
        return execQuery(portalUrl, token, paramsSdkVo);
    }

    /**
     * 新增移交企业管理员
     */
    public Response addTransferEnterpriseAdmin(String token, AddTransferEnterpriseAdminRequest paramsSdkVo) {

        String portalUrl = portalConf.getHost() + portalConf.getSdkAddTransferEnterpriseAdmin();
        return execQuery(portalUrl, token, paramsSdkVo);

    }

    /**
     * 选择移交企业管理员
     */
    public Response selectTransferEnterpriseAdmin(String token, SelectTransferEnterpriseAdminRequest paramsSdkVo) {
        String portalUrl = portalConf.getHost() + portalConf.getSdkSelectTransferEnterpriseAdmin();
        return execQuery(portalUrl, token, paramsSdkVo);
    }

    /**
     * 重置密码
     */
    public Response resetPassword(String token, ResetPasswordRequest paramsSdkVo) {

        String portalUrl = portalConf.getHost() + portalConf.getSdkResetPassword();
        return execQuery(portalUrl, token, paramsSdkVo);
    }

    /**
     * 解绑企业
     */
    public Response cancelAuthentication(String token, CancelAuthenticationRequest paramsSdkVo) {

        String portalUrl = portalConf.getHost() + portalConf.getSdkCancelAuthentication();
        return execQuery(portalUrl, token, paramsSdkVo);
    }

    /**
     * 查询用户关联企业 1.手机号关联 2.用户编码关联
     */
    public Response queryUserRelEnterpriseList(String token, QueryUserRelEnterpriseListRequest paramsSdkVo) {
        String portalUrl = portalConf.getHost() + portalConf.getSdkQueryUserRelEnterpriseList();
        return execQuery(portalUrl, token, paramsSdkVo);
    }

    /**
     * 查询企业地址
     */
    public Response queryCustomerAddr(String token, QueryCustomerAddrRequest paramsSdkVo) {
        String portalUrl = portalConf.getHost() + portalConf.getSdkQueryCustomerAddr();
        return execQuery(portalUrl, token, paramsSdkVo);
    }

    /**
     * 查询企业列表
     */
    public Response queryEnterpriseList(String token, QueryEnterpriseListRequest paramsSdkVo) {
        String portalUrl = portalConf.getHost() + portalConf.getSdkQueryEnterpriseList();
        return execQuery(portalUrl, token, paramsSdkVo);
    }

    /**
     * 查询企业详细信息
     *
     * @param token
     * @param paramsSdkVo
     * @return
     */
    public Response queryCustomerDetailByCode(String token, QueryCustomerDetailByCodeRequest paramsSdkVo) {
        String portalUrl = portalConf.getHost() + portalConf.getSdkQueryCustomerDetailByCode();
        return execQuery(portalUrl, token, paramsSdkVo);
    }

    /**
     * 查询用户详细信息
     *
     * @param token
     * @param paramsSdkVo
     * @return
     */
    public Response queryEnterpriseAccount(String token, QueryUserRelEnterpriseListRequest paramsSdkVo) {
        String portalUrl = portalConf.getHost() + portalConf.getSdkQueryEnterpriseAccount();
        return execQuery(portalUrl, token, paramsSdkVo);
    }

    /**
     * 查询用户详细信息
     *
     * @param token
     * @param paramsSdkVo
     * @return
     */
    public Response queryUserAccountByPhone(String token, QueryUserAccountByPhoneRequest paramsSdkVo) {
        String portalUrl = portalConf.getHost() + portalConf.getSdkQueryUserAccountByPhone();
        return execQuery(portalUrl, token, paramsSdkVo);
    }

    /**
     * 根据岗位ID和园区ID,查询人员列表
     */
    public Response queryUserByPositionAndProject(String token, QueryUserByPositionAndProjectRequest paramsSdkVo) {
        String portalUrl = portalConf.getHost() + portalConf.getSdkQueryUserByGroupId();
        return execQuery(portalUrl, token, paramsSdkVo);
    }

    /**
     * 根据人员ID和园区ID,判断人员和园区关联关系
     */
    public Response checkUserRelProject(String token, CheckUserRelProjectRequest paramsSdkVo) {
        String portalUrl = portalConf.getHost() + portalConf.getSdkCheckUserRelProject();
        return execQuery(portalUrl, token, paramsSdkVo);
    }

    /**
     * 查询企业管理员的企业列表
     */
    public Response queryAdminRelEnterpriseList(String token, QueryAdminRelEnterpriseListRequest paramsSdkVo) {
        String portalUrl = portalConf.getHost() + portalConf.getSdkQueryAdminRelEnterpriseList();
        return execQuery(portalUrl, token, paramsSdkVo);
    }

    /**
     * 查询企业管理员的园区列表
     */
    public Response queryAdminRelProjectList(String token, QueryAdminRelProjectListRequest paramsSdkVo) {
        String portalUrl = portalConf.getHost() + portalConf.getSdkQueryAdminRelProjectList();
        return execQuery(portalUrl, token, paramsSdkVo);
    }


    /**
     * 查询员工认证记录（小程序区分认证状态）
     */
    public Response queryAuthRecordList(String token, QueryAuthRecordListRequest paramsSdkVo) {
        String portalUrl = portalConf.getHost() + portalConf.getSdkQueryAuthRecordList();
        return execQuery(portalUrl, token, paramsSdkVo);
    }

    /**
     * 员工认证 添加
     */
    public Response submitAuthRecord(String token, SubmitAuthRecordRequest paramsSdkVo) {
        String portalUrl = portalConf.getHost() + portalConf.getSdkProcessSubmitAuthRecord();
        return execQuery(portalUrl, token, paramsSdkVo);
    }


    /**
     * 员工认证 修改
     */
    public Response updateAuthRecord(String token, UpdateAuthRecordStatusRequest paramsSdkVo) {
        String portalUrl = portalConf.getHost() + portalConf.getSdkProcessUpdateAuthRecord();
        return execQuery(portalUrl, token, paramsSdkVo);
    }
}

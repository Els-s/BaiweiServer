package com.space.coupon.vo.couponvo.reqvo;

import com.space.coupon.vo.ReqPageVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-09-17 16:18
 * @Version 1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(value = "用户卡包查询")
public class ObjectListReqVo extends ReqPageVo {

    @ApiModelProperty("卡券类型： 1全部，2 个人，3 企业")
    private Integer searchType;
    @ApiModelProperty("用户类型code： 暂为搜索企业id")
    private String searchObjectCode;

    @Override
    public String toString() {
        return "ObjectListReqVo{" +
                "searchType=" + searchType +
                ", searchObjectCode='" + searchObjectCode + '\'' +
                "} " + super.toString();
    }
}

package com.space.coupon.controller;

import cn.space.portal.sdk.holder.UserHolder;
import cn.space.portal.sdk.io.LoginUserAccountInfo;
import com.space.coupon.entity.CouponIssueLogEntity;
import com.space.coupon.service.CouponIssueService;
import com.space.coupon.vo.RspPageVo;
import com.space.coupon.vo.RspVo;
import com.space.coupon.vo.couponvo.reqvo.IssueReqVo;
import com.space.coupon.vo.couponvo.reqvo.QueryIssueListVo;
import com.space.coupon.vo.couponvo.reqvo.UserPhoneCheckReqVo;
import com.space.coupon.vo.couponvo.rspvo.IssueLogDetailsRspVo;
import com.space.coupon.vo.couponvo.rspvo.UserInfoRspVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpHeaders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 卡券发放规则Controller
 *
 * @author kangmj
 * @date 2021-09-10
 */
@RestController
@RequestMapping("/issue")
@Api(tags = "卡券服务：卡券发放管理-PC")
@Slf4j
public class CouponIssueController {

    @Autowired
    CouponIssueService issueService;

    /**
     * 卡券发放
     */
    /*
    {
        id:1, //卡券的id值
        object:1, //发放对象。  0 企业，1个人
        isAllScope:"0" //范围是否全部   "0"否，“1”是
        scope:[         //发放范围
            {object:"", name:""},   //对象 //对象名称
            {object:"", name:""},
            {object:"", name:""}
        ]
        issueNum:"",    //发放数量
    }
    * */
    @ApiOperation("卡券发放新增")
    @PostMapping("/add")
    public RspVo<?> add(@RequestHeader(HttpHeaders.AUTHORIZATION) String token,
            @ApiParam(value = "卡券发放参数") @RequestBody IssueReqVo map) {
        log.info("卡券发放新增请求参数：{}", map);
        LoginUserAccountInfo loginUserAccountInfo = UserHolder.get();
        issueService.addIssue(token, map, loginUserAccountInfo);
        return RspVo.success("");
    }

    @ApiOperation("指定用户手机号码筛选")
    @PostMapping("/user/designatedUserInfo")
    public RspVo<UserInfoRspVo> getDesignatedUserInfo(@RequestHeader(HttpHeaders.AUTHORIZATION) String token,
            @ApiParam(value = "指定用户手机号码筛选参数") @RequestBody UserPhoneCheckReqVo map) {
        log.info("指定用户手机号码筛选请求参数：{}", map);
        LoginUserAccountInfo loginUserAccountInfo = UserHolder.get();
        UserInfoRspVo userInfoRspVo = issueService.getDesignatedUserInfo(map, loginUserAccountInfo, token);

        return RspVo.success("ok", userInfoRspVo);
    }

    /**
     * 卡券发放列表
     */
    @ApiOperation("卡券发放列表")
    @PostMapping("/queryList")
    public RspVo<RspPageVo<List<CouponIssueLogEntity>>> list(
            @RequestHeader(HttpHeaders.AUTHORIZATION) String token,
            @RequestBody QueryIssueListVo reqPageVo) {
        log.info("查看卡券发放列表请求参数：{}", reqPageVo);
        LoginUserAccountInfo loginUserInfo = UserHolder.get();
        RspPageVo<List<CouponIssueLogEntity>> data = issueService.queryPage(reqPageVo, loginUserInfo);
        return RspVo.success("ok", data);
    }

    /**
     * 获取卡券发放详情
     */
    @ApiOperation("获取卡券发放详情")
    @GetMapping(value = "/queryDetails")
    public RspVo<IssueLogDetailsRspVo> getInfo(
            @ApiParam(value = "卡券发放列表数据ID") @RequestParam(name = "id") Long id) {
        log.info("查看卡券发放列表请求参数：{}", id);
        LoginUserAccountInfo loginUserInfo = UserHolder.get();
        IssueLogDetailsRspVo data = issueService.queryDetailsById(id, loginUserInfo);
        return RspVo.success("ok", data);
    }
}

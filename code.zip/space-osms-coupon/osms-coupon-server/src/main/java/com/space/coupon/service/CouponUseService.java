package com.space.coupon.service;

import cn.space.portal.sdk.io.LoginUserAccountInfo;
import com.alibaba.fastjson.JSONObject;
import com.space.coupon.entity.CouponCiEntity;
import com.space.coupon.vo.couponvo.CouponObjectVo;
import com.space.coupon.vo.couponvo.reqvo.UseCouponReqVo;

import java.util.List;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-09-16 21:31
 * @Version 1.0
 */
public interface CouponUseService {

    /**
     * queryListByOrder
     *
     * @param reqPageVo
     * @param loginUserInfo
     * @return
     */
    CouponObjectVo queryListByOrder(UseCouponReqVo reqPageVo, LoginUserAccountInfo loginUserInfo);

    /**
     * getCouponUseInformation
     *
     * @param map
     * @param loginUserInfo
     * @return
     */
    List<CouponCiEntity> getCouponUseInformation(JSONObject map, LoginUserAccountInfo loginUserInfo);

    /**
     * couponUse
     *
     * @param map
     * @param loginUserInfo
     * @return
     */
    List<CouponCiEntity> couponUse(JSONObject map, LoginUserAccountInfo loginUserInfo);

    /**
     * couponReturn
     *
     * @param map
     * @param loginUserInfo
     * @return
     */
    List<CouponCiEntity> couponReturn(JSONObject map, LoginUserAccountInfo loginUserInfo);
}

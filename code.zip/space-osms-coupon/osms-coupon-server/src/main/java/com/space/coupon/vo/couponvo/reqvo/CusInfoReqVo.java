package com.space.coupon.vo.couponvo.reqvo;

import com.space.coupon.vo.ReqPageVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-09-22 17:11
 * @Version 1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(value = "获取租客信息Vo")
public class CusInfoReqVo extends ReqPageVo {

    @ApiModelProperty("项目ID信息")
    private List<String> projectIdList;

    @Override
    public String toString() {
        return "CusInfoReqVo{" +
                "projectIdList=" + projectIdList +
                "} " + super.toString();
    }
}

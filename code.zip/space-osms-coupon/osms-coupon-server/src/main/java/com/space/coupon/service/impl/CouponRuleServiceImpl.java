package com.space.coupon.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.ArrayUtil;
import cn.hutool.core.util.StrUtil;
import cn.space.base.core.page.PageFactory;
import cn.space.base.utils.ToolUtil;
import cn.space.portal.sdk.io.LoginUserAccountInfo;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.space.coupon.common.CouponConstants;
import com.space.coupon.entity.CouponCiEntity;
import com.space.coupon.entity.CouponProductEntity;
import com.space.coupon.entity.CouponRuleCycleEntity;
import com.space.coupon.entity.CouponRuleEntity;
import com.space.coupon.enums.CouponStatusEnum;
import com.space.coupon.enums.ErrorEnum;
import com.space.coupon.exception.CouponException;
import com.space.coupon.mapper.CouponCiMapper;
import com.space.coupon.mapper.CouponProductMapper;
import com.space.coupon.mapper.CouponRuleCycleMapper;
import com.space.coupon.mapper.CouponRuleMapper;
import com.space.coupon.service.CouponRuleService;
import com.space.coupon.util.CommonUtils;
import com.space.coupon.vo.RspPageVo;
import com.space.coupon.vo.couponvo.reqvo.QueryRuleListVo;
import com.space.coupon.vo.couponvo.reqvo.RuleAddReqVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-09-14 11:27
 * @Version 1.0
 */
@Service
@Slf4j
public class CouponRuleServiceImpl implements CouponRuleService {

    @Autowired
    CouponRuleMapper ruleMapper;
    @Autowired
    CouponCiMapper ciMapper;
    @Autowired
    CouponProductMapper productMapper;
    @Autowired
    CouponRuleCycleMapper ruleCycleMapper;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int addCouponRule(RuleAddReqVo ruleAddReqVo, LoginUserAccountInfo loginUserInfo) {
        if (CollUtil.isEmpty(ruleAddReqVo.getProductEntityList())) {
            throw new CouponException(ErrorEnum.PRODUCT_ERROR);
        }
        int insert;
        // 插入rule
        String ruleCode = handleRuleCode(loginUserInfo, ruleAddReqVo);

        ruleAddReqVo.setRuleCode(ruleCode);
        ruleAddReqVo.setUseStatus(CouponStatusEnum.OFFLINE.getCode());
        ruleAddReqVo.setTenementCode(loginUserInfo.getTenementCode());
        ruleAddReqVo.setPersonName(loginUserInfo.getRealName());
        ruleAddReqVo.setCreateBy(loginUserInfo.getPersonCode());
        ruleAddReqVo.setDelFlag(Boolean.FALSE);
        ruleAddReqVo.setSearchInfo(ruleCode.concat(ruleAddReqVo.getRuleName()));

        setIssueDate(ruleAddReqVo);

        // 有效期时间
        handleRuleValidDate(ruleAddReqVo);

        insert = ruleMapper.insert(ruleAddReqVo);
        handleResult(insert, "rule");

        // 插入ruleCycle
        CouponRuleCycleEntity ruleCycle = getRuleCycle(ruleAddReqVo);
        insert = ruleCycleMapper.insert(ruleCycle);
        handleResult(insert, "ruleCycle");
        // 插入产品信息
        for (CouponProductEntity x : ruleAddReqVo.getProductEntityList()) {
            x.setRuleId(ruleAddReqVo.getId());
            x.setCouponType(ruleAddReqVo.getCouponType());
            x.setTenementCode(loginUserInfo.getTenementCode());
            int result = productMapper.insert(x);
            handleResult(result, "product");
        }
        return insert;
    }

    private void setIssueDate(RuleAddReqVo ruleAddReqVo) {
        List<String> issueDate = ruleAddReqVo.getIssueDate();
        if (CollUtil.isNotEmpty(issueDate)) {
            CommonUtils.sortTimeStr(issueDate);
            ruleAddReqVo.setIssueStartDate(issueDate.get(0));
            ruleAddReqVo.setIssueEndDate(issueDate.get(1));
        }
        List<String> validDate = ruleAddReqVo.getValidPeriodDate();
        if (CollUtil.isNotEmpty(validDate)) {
            CommonUtils.sortTimeStr(validDate);
            ruleAddReqVo.setValidPeriodStartTime(DateUtil.parse(validDate.get(0)));
            ruleAddReqVo.setValidPeriodEndTime(DateUtil.parse(validDate.get(1)));
        }
    }

    private CouponRuleCycleEntity getRuleCycle(RuleAddReqVo ruleAddReqVo) {
        CouponRuleCycleEntity ruleCycle = new CouponRuleCycleEntity();
        ruleCycle.setRuleId(ruleAddReqVo.getId());
        ruleCycle.setFrequency(ruleAddReqVo.getFrequency());
        if (CouponStatusEnum.FREQUENCY_REPEAT.getCode().equals(ruleAddReqVo.getFrequency())) {
            // 重复发放
            ruleCycle.setRepeatFrequency(ruleAddReqVo.getRepeatFrequency());
            switch (ruleAddReqVo.getRepeatFrequency()) {
                case "MONTH_DAY":
                    ruleCycle.setWorkDay(ruleAddReqVo.getEveryDay() ? "ALL"
                            : ArrayUtil.join(ruleAddReqVo.getExecutionDays(),
                                    CouponConstants.STR_SPLIT_DB));
                    if (ruleAddReqVo.getEveryMonth()) {
                        ruleCycle.setWorkMonth("ALL");
                    } else {
                        int[] months = ruleAddReqVo.getExecutionMonths();
                        int[] its = new int[months.length];
                        for (int i = 0; i < months.length; i++) {
                            its[i] = months[i] - 1;
                        }
                        ruleCycle.setWorkMonth(ArrayUtil.join(its, CouponConstants.STR_SPLIT_DB));
                    }
                    break;
                case "WEEK":
                    int[] weekdays = ruleAddReqVo.getExecutionWeekdays();
                    int[] its = new int[weekdays.length];
                    for (int i = 0; i < weekdays.length; i++) {
                        its[i] = 7 == weekdays[i] ? 1 : weekdays[i] + 1;
                    }
                    ruleCycle.setWorkWeek(ArrayUtil.join(its, CouponConstants.STR_SPLIT_DB));
                    break;
                case "CYCLE":
                    ruleCycle.setCycleTime(ruleAddReqVo.getCycleTime());
                    if ("CUSTOM_DAY".equals(ruleAddReqVo.getCycleTime())) {
                        ruleCycle.setCustomTime(ruleAddReqVo.getCustomTime());
                    }
                    break;
                default:
                    break;
            }
        }
        return ruleCycle;
    }

    private void handleRuleValidDate(CouponRuleEntity rule) {
        if (CouponStatusEnum.RULE_VALIDITYPERIODTYPE_NOT_FIXED.getCode()
                .equals(rule.getValidityPeriodType())) {
            DateTime startTime = DateUtil.parse(
                    rule.getIssueStartDate().concat(" ").concat(rule.getTimedReleaseTime()));
            rule.setValidPeriodStartTime(startTime);

            DateTime end = DateUtil.parse(
                    rule.getIssueEndDate().concat(" ").concat(rule.getTimedReleaseTime()));
            DateTime endTime = DateUtil.offsetDay(end, rule.getValidityPeriodValue());
            rule.setValidPeriodEndTime(endTime);
        }
    }

    /**
     * 建立卡券模板ID
     *
     * @param loginUserInfo .
     * @param couponRule    .
     * @return 模板ID
     */
    private String handleRuleCode(LoginUserAccountInfo loginUserInfo, RuleAddReqVo couponRule) {
        String dataStr = new DateTime().toString(DatePattern.PURE_DATE_PATTERN);
        QueryWrapper<CouponRuleEntity> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq(CouponConstants.TENEMENT_CODE_STR, loginUserInfo.getTenementCode());
//        queryWrapper.eq(CouponConstants.PROJECT_CODE_STR, couponRule.getProjectCode());
        queryWrapper.likeRight("rule_code", dataStr);
        queryWrapper.orderByDesc("id");
        Page<CouponRuleEntity> page = PageFactory.defaultPage();
        page.setSize(1L);
        Page<CouponRuleEntity> rulePage = ruleMapper.selectPage(page, queryWrapper);
        if (CollectionUtil.isEmpty(rulePage.getRecords())) {
            return dataStr.concat("001");
        } else {
            // 20210811004
            String substring = rulePage.getRecords().get(0).getRuleCode().substring(8);
            int num = Integer.parseInt(substring) + 1;
            String str = StrUtil.padPre(String.valueOf(num), 3, "0");
            return dataStr.concat(str);
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int deleteCouponRuleByIds(List<Integer> ids, LoginUserAccountInfo loginUserInfo) {
        AtomicInteger res = new AtomicInteger();
        ids.forEach(x -> {
            CouponRuleEntity rule = new CouponRuleEntity();
            rule.setDelFlag(true);
            QueryWrapper<CouponRuleEntity> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq(CouponConstants.ID_SRT, x);
            queryWrapper.eq(CouponConstants.TENEMENT_CODE_STR, loginUserInfo.getTenementCode());
            int result = ruleMapper.update(rule, queryWrapper);
            if (1 == result) {
                res.getAndIncrement();
                log.info("删除卡券模板成功，CouponRuleEntity ID={}", x);
            } else {
                log.error("删除卡券模板失败，CouponRuleEntity ID={}, result={}", x, result);
            }
            // 未完成发放卡券处理
            log.info("delete data ====={}", rule);
            handleDelRule(x, loginUserInfo);
        });
        return res.get();
    }

    private void handleDelRule(Integer ruleId, LoginUserAccountInfo loginUserInfo) {
        QueryWrapper<CouponCiEntity> queryWrapper = new QueryWrapper<CouponCiEntity>()
                .eq(CouponConstants.RULE_ID_STR, ruleId)
                .eq(CouponConstants.SHOW_STATUS_STR, CouponConstants.SHOW_STATUS_NO)
                .eq(CouponConstants.TENEMENT_CODE_STR, loginUserInfo.getTenementCode());
        CouponCiEntity ci = new CouponCiEntity();
        ci.setDelFlag(Boolean.TRUE);
        int result = ciMapper.update(ci, queryWrapper);
        log.info("handleDelRule====ruleId={}, result={}", ruleId, result);
    }

    @Override
    public RspPageVo<List<CouponRuleEntity>> queryPage(QueryRuleListVo reqPageVo,
            LoginUserAccountInfo loginUserInfo) {
        //分页
        Page<CouponRuleEntity> page = PageFactory.defaultPage();
        QueryWrapper<CouponRuleEntity> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq(CouponConstants.TENEMENT_CODE_STR, loginUserInfo.getTenementCode());
        queryWrapper.eq(CouponConstants.DEL_FLAG_STR, CouponConstants.DEL_FLAG_FALSE);
        queryWrapper.eq(ToolUtil.isNotEmpty(reqPageVo.getDiscountType()), "discount_type",
                reqPageVo.getDiscountType());
        queryWrapper.eq(ToolUtil.isNotEmpty(reqPageVo.getThreshold()), "threshold",
                reqPageVo.getThreshold());
        queryWrapper.eq(ToolUtil.isNotEmpty(reqPageVo.getUseStatus()), "use_status",
                reqPageVo.getUseStatus());
        queryWrapper.eq(ToolUtil.isNotEmpty(reqPageVo.getValidityPeriodType()),
                "validity_period_type",
                reqPageVo.getValidityPeriodType());
        queryWrapper.eq(ToolUtil.isNotEmpty(reqPageVo.getScenes()), "scenes",
                reqPageVo.getScenes());
        queryWrapper.eq(ToolUtil.isNotEmpty(reqPageVo.getFrequency()), "frequency",
                reqPageVo.getFrequency());
        wrapperValidDate(reqPageVo, queryWrapper);
        wrapperIssueDate(reqPageVo, queryWrapper);
        wrapperCreatDate(reqPageVo, queryWrapper);

//        queryWrapper.eq(CouponConstants.PROJECT_CODE_STR, reqPageVo.getProjectId());
        queryWrapper.like(ToolUtil.isNotEmpty(reqPageVo.getSearchInfo()),
                CouponConstants.SEARCH_INFO_STR, reqPageVo.getSearchInfo());
        queryWrapper.orderByDesc(CouponConstants.ID_SRT);
        // 查询数据
        IPage<CouponRuleEntity> iPage = ruleMapper.queryRulePage(page, queryWrapper);
        // 数据展示
        List<CouponRuleEntity> ruleList = iPage.getRecords();
        ruleList.forEach(this::handleRuleVo);
        return new RspPageVo<>(iPage.getCurrent(), iPage.getSize(), iPage.getPages(),
                iPage.getTotal(),
                ruleList);
    }

    private void wrapperCreatDate(QueryRuleListVo reqPageVo, QueryWrapper<CouponRuleEntity> queryWrapper) {
        if (ToolUtil.isNotEmpty(reqPageVo.getCreatDate())) {
            List<String> creatDate = reqPageVo.getCreatDate();
            CommonUtils.sortTimeStr(creatDate);
            DateTime startTime = DateUtil.parse(creatDate.get(0));
            DateTime endTime = DateUtil.parse(creatDate.get(1));
            queryWrapper.apply(
                    "date_format (create_time,'%Y-%m-%d') >= date_format('" + startTime
                            + "','%Y-%m-%d')");
            queryWrapper.apply(
                    "date_format (create_time,'%Y-%m-%d') <= date_format('" + endTime
                            + "','%Y-%m-%d')");
        }

    }

    private void wrapperIssueDate(QueryRuleListVo reqPageVo, QueryWrapper<CouponRuleEntity> queryWrapper) {
        if (ToolUtil.isNotEmpty(reqPageVo.getIssueDate())) {
            List<String> issueDate = reqPageVo.getIssueDate();
            CommonUtils.sortTimeStr(issueDate);
            String startTime = DateUtil.parse(issueDate.get(0)).toString(DatePattern.NORM_DATE_PATTERN);
            String endTime = DateUtil.parse(issueDate.get(1)).toString(DatePattern.NORM_DATE_PATTERN);
            queryWrapper.isNotNull("issue_start_date");
            // 开始时间小于搜索结束时间&结束时间大于开始时间即满足
            queryWrapper.le("issue_start_date", endTime);
            queryWrapper.ge("issue_end_date", startTime);
        }
    }

    private void handleRuleVo(CouponRuleEntity x) {
        List<String> validPeriodList = new ArrayList<>(2);
        validPeriodList.add(new DateTime(x.getValidPeriodStartTime()).toString());
        validPeriodList.add(new DateTime(x.getValidPeriodEndTime()).toString());
        x.setValidPeriodDate(validPeriodList);
        if (StrUtil.isNotBlank(x.getIssueStartDate())) {
            List<String> issueDateList = new ArrayList<>(2);
            issueDateList.add(
                    DateUtil.parse(x.getIssueStartDate()).toString(DatePattern.NORM_DATE_PATTERN));
            issueDateList.add(
                    DateUtil.parse(x.getIssueEndDate()).toString(DatePattern.NORM_DATE_PATTERN));
            x.setIssueDate(issueDateList);
        }
        Float faceValue = x.getFaceValue();
        Float thresholdValue = x.getThresholdValue();
        Boolean isThreshold = x.getThreshold();
        String faceValueVo = "";
        String thresholdValueVo = "";
        switch (x.getDiscountType()) {
            case CouponConstants.OFFER_DISCOUNT_COUPON:
                faceValueVo = CommonUtils.handleFloatStr(faceValue / 10) + "折";
                thresholdValueVo = isThreshold ? CommonUtils.handleFloatStr(thresholdValue) + "元" : "无";
                break;
            case CouponConstants.OFFER_CASH_COUPON:
                faceValueVo = CommonUtils.handleFloatStr(faceValue) + "元";
                thresholdValueVo = isThreshold ? CommonUtils.handleFloatStr(thresholdValue) + "元" : "无";
                break;
            case CouponConstants.OFFER_DURATION_COUPON:
                faceValueVo = CommonUtils.handleFloatStr(faceValue) + "小时";
                thresholdValueVo = isThreshold ? CommonUtils.handleFloatStr(thresholdValue) + "小时" : "无";
                break;
            default:
                break;
        }
        x.setFaceValueVo(faceValueVo);
        x.setThresholdValueVo(thresholdValueVo);
        // 发放状态判断
        x.setShowIssue(CouponStatusEnum.OFFLINE.getCode().equals(x.getUseStatus()));
    }

    private void wrapperValidDate(QueryRuleListVo reqPageVo, QueryWrapper<CouponRuleEntity> queryWrapper) {
        if (ToolUtil.isNotEmpty(reqPageVo.getValidPeriodDate())) {
            // 开始时间小于搜索结束时间&结束时间大于开始时间即满足
            List<String> validPeriodDate = reqPageVo.getValidPeriodDate();
            CommonUtils.sortTimeStr(validPeriodDate);
            DateTime startTime = DateUtil.parse(validPeriodDate.get(0));
            DateTime endTime = DateUtil.parse(validPeriodDate.get(1));
            queryWrapper.apply(
                    "date_format (valid_period_start_time,'%Y-%m-%d') <= date_format('" + endTime
                            + "','%Y-%m-%d')");
            queryWrapper.apply(
                    "date_format (valid_period_end_time,'%Y-%m-%d') >= date_format('" + startTime
                            + "','%Y-%m-%d')");
        }
    }

    @Override
    public CouponRuleEntity queryDetailsById(Long id) {
        CouponRuleEntity ruleEntity = ruleMapper.queryDetailsById(id);
        ruleEntity.setRepetitionFrequency(isFreqOnce(ruleEntity) ? "-" : handleCycleStr(
                ruleCycleMapper.selectOne(
                        new QueryWrapper<>(new CouponRuleCycleEntity()).eq(
                                CouponConstants.RULE_ID_STR, ruleEntity.getId()))));
        handleRuleVo(ruleEntity);
        return ruleEntity;
    }

    @Override
    public RuleAddReqVo copyRule(Long id) {
        CouponRuleEntity ruleEntity = ruleMapper.selectById(id);
        handleRuleVo(ruleEntity);
        RuleAddReqVo addReqVo = JSONObject.parseObject(JSON.toJSONString(ruleEntity),
                RuleAddReqVo.class);
        if (CouponStatusEnum.FREQUENCY_REPEAT.getCode().equals(addReqVo.getFrequency())) {
            // 重复发放
            CouponRuleCycleEntity cycle = ruleCycleMapper.selectOne(new QueryWrapper<>(
                    new CouponRuleCycleEntity()).eq(CouponConstants.RULE_ID_STR,
                    ruleEntity.getId()));
            addReqVo.setRepeatFrequency(cycle.getRepeatFrequency());
            switch (cycle.getRepeatFrequency()) {
                case "MONTH_DAY":
                    boolean everyDay = "ALL".equals(cycle.getWorkDay());
                    boolean everyMonth = "ALL".equals(cycle.getWorkMonth());
                    addReqVo.setEveryDay(everyDay);
                    addReqVo.setEveryMonth(everyMonth);
                    if (!everyDay) {
                        String[] days = cycle.getWorkDay().split(CouponConstants.STR_SPLIT_DB);
                        int[] workDays = new int[days.length];
                        for (int i = 0; i < days.length; i++) {
                            workDays[i] = Integer.parseInt(days[i]);
                        }
                        addReqVo.setExecutionDays(workDays);
                    }
                    if (!everyMonth) {
                        String[] monthStr = cycle.getWorkMonth()
                                .split(CouponConstants.STR_SPLIT_DB);
                        int[] months = new int[monthStr.length];
                        for (int i = 0; i < monthStr.length; i++) {
                            months[i] = Integer.parseInt(monthStr[i]) + 1;
                        }
                        addReqVo.setExecutionMonths(months);
                    }
                    break;
                case "WEEK":
                    String[] weekStr = cycle.getWorkWeek().split(CouponConstants.STR_SPLIT_DB);
                    int[] weeks = new int[weekStr.length];
                    for (int i = 0; i < weekStr.length; i++) {
                        int parseInt = Integer.parseInt(weekStr[i]);
                        weeks[i] = 1 == parseInt ? 7 : parseInt - 1;
                    }
                    addReqVo.setExecutionWeekdays(weeks);
                    break;
                case "CYCLE":
                    addReqVo.setCycleTime(cycle.getCycleTime());
                    if ("CUSTOM_DAY".equals(cycle.getCycleTime())) {
                        addReqVo.setCustomTime(cycle.getCustomTime());
                    }
                    break;
                default:
                    break;
            }
        }
        return addReqVo;
    }

    @Override
    public int updateRuleStatus(Long ruleId, CouponStatusEnum couponStatusEnum) {
        CouponRuleEntity rule = new CouponRuleEntity();
        rule.setId(ruleId);
        rule.setUseStatus(couponStatusEnum.getCode());
        return ruleMapper.updateById(rule);
    }

    private void handleResult(int insert, String msg) {
        if (insert != 1) {
            log.error("insert couponRule error" + msg);
            throw new CouponException(CouponConstants.FAILED_CODE, "insert couponRule error" + msg);
        }
    }

    private boolean isFreqOnce(CouponRuleEntity ruleEntity) {
        return CouponStatusEnum.FREQUENCY_ONCE.getCode().equals(ruleEntity.getFrequency());
    }

    private String handleCycleStr(CouponRuleCycleEntity cycle) {
        StringBuilder strBd = new StringBuilder();
        // 重复频率拼接
        switch (cycle.getRepeatFrequency()) {
            case "MONTH_DAY":
                getDayStrB(cycle, strBd);
                break;
            case "WEEK":
                strBd.append("每周");
                String[] weekStr = cycle.getWorkWeek().split(CouponConstants.STR_SPLIT_DB);
                int[] weeks = new int[weekStr.length];
                for (int i = 0; i < weekStr.length; i++) {
                    int parseInt = Integer.parseInt(weekStr[i]);
                    weeks[i] = 1 == parseInt ? 7 : parseInt - 1;
                    switch (weeks[i]) {
                        case 1:
                            strBd.append("日");
                            break;
                        case 2:
                            strBd.append("一");
                            break;
                        case 3:
                            strBd.append("二");
                            break;
                        case 4:
                            strBd.append("三");
                            break;
                        case 5:
                            strBd.append("四");
                            break;
                        case 6:
                            strBd.append("五");
                            break;
                        case 7:
                            strBd.append("六");
                            break;
                        default:
                            break;
                    }
                }
                break;
            case "CYCLE":
                getCycleStarB(cycle, strBd);
            default:
                break;
        }
        return strBd.toString();
    }

    private void getCycleStarB(CouponRuleCycleEntity cycle, StringBuilder strBd) {
        switch (cycle.getCycleTime()) {
            case "CUSTOM_DAY":
                strBd.append("每").append(cycle.getCustomTime()).append("天");
                break;
            case "WEEK":
                strBd.append("按周");
                break;
            case "MONTH":
                strBd.append("按月");
                break;
            case "SEASON":
                strBd.append("按季");
                break;
            case "HALF_YEAR":
                strBd.append("按半年");
                break;
            case "YEAR":
                strBd.append("按年");
                break;
            default:
                break;
        }
        return;
    }

    private void getDayStrB(CouponRuleCycleEntity cycle, StringBuilder strBd) {
        boolean everyDay = "ALL".equals(cycle.getWorkDay());
        boolean everyMonth = "ALL".equals(cycle.getWorkMonth());
        if (everyMonth) {
            strBd.append("每月");
        } else {
            String[] monthStr = cycle.getWorkMonth().split(CouponConstants.STR_SPLIT_DB);
            int[] months = new int[monthStr.length];
            for (int i = 0; i < monthStr.length; i++) {
                months[i] = Integer.parseInt(monthStr[i]) + 1;
            }
            strBd.append("每").append(ArrayUtil.join(months, ",")).append("月");
        }
        if (everyDay) {
            strBd.append("每日");
        } else {
            String[] days = cycle.getWorkDay().split(CouponConstants.STR_SPLIT_DB);
            int[] workDays = new int[days.length];
            for (int i = 0; i < days.length; i++) {
                workDays[i] = Integer.parseInt(days[i]);
            }
            strBd.append(ArrayUtil.join(workDays, ",")).append("日");
        }
    }
}

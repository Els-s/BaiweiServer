package com.space.coupon.service.impl;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import cn.space.base.core.page.PageFactory;
import cn.space.base.utils.ToolUtil;
import cn.space.portal.sdk.io.LoginUserAccountInfo;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.space.coupon.common.CouponConstants;
import com.space.coupon.entity.CouponCiEntity;
import com.space.coupon.entity.CouponDictEntity;
import com.space.coupon.enums.CouponStatusEnum;
import com.space.coupon.exception.CouponException;
import com.space.coupon.mapper.CouponCiMapper;
import com.space.coupon.mapper.CouponDictMapper;
import com.space.coupon.service.CouponCiService;
import com.space.coupon.util.CommonUtils;
import com.space.coupon.util.DozerBeanUtils;
import com.space.coupon.vo.RspPageVo;
import com.space.coupon.vo.ReqPageVo;
import com.space.coupon.vo.couponvo.reqvo.QueryCiListVo;
import com.space.coupon.vo.couponvo.rspvo.CiStatusNumRspVo;
import com.space.coupon.vo.couponvo.rspvo.OpenApiCiRspVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-09-13 19:42
 * @Version 1.0
 */
@Service
@Slf4j
public class CouponCiServiceImpl implements CouponCiService {

    @Autowired
    CouponCiMapper ciMapper;

    @Autowired
    CouponDictMapper dictMapper;

    @Override
    public RspPageVo<List<CouponCiEntity>> queryPage(QueryCiListVo reqPageVo,
            LoginUserAccountInfo loginUserInfo) {
        // 分页
        Page<CouponCiEntity> page = PageFactory.defaultPage();
        QueryWrapper<CouponCiEntity> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq(CouponConstants.TENEMENT_CODE_STR, loginUserInfo.getTenementCode());
        queryWrapper.eq(CouponConstants.DEL_FLAG_STR, CouponConstants.DEL_FLAG_FALSE);
        queryWrapper.eq(CouponConstants.SHOW_STATUS_STR, CouponConstants.SHOW_STATUS_YES);

        queryWrapper.eq(ToolUtil.isNotEmpty(reqPageVo.getDiscountType()), "discount_type",
                reqPageVo.getDiscountType());
        queryWrapper.eq(ToolUtil.isNotEmpty(reqPageVo.getThreshold()), "threshold",
                reqPageVo.getThreshold());
        queryWrapper.eq(ToolUtil.isNotEmpty(reqPageVo.getScenes()), "scenes",
                reqPageVo.getScenes());
        // 状态
        queryWrapper.eq(StrUtil.isNotBlank(reqPageVo.getType()) && !"0".equals(reqPageVo.getType()),
                "use_status", Integer.valueOf(reqPageVo.getType()));

        wrapperValidDate(reqPageVo, queryWrapper);

        queryWrapper.like(ToolUtil.isNotEmpty(reqPageVo.getSearchInfo()),
                CouponConstants.SEARCH_INFO_STR, reqPageVo.getSearchInfo());
        queryWrapper.orderByDesc(CouponConstants.ID_SRT);
        //查询数据
        IPage<CouponCiEntity> iPage = ciMapper.queryRulePage(page, queryWrapper);
        // 数据展示
        List<CouponCiEntity> ciList = iPage.getRecords();
        ciList.forEach(this::handleCiVo);
        return new RspPageVo<>(iPage.getCurrent(), iPage.getSize(), iPage.getPages(),
                iPage.getTotal(), ciList);
    }

    private void wrapperValidDate(QueryCiListVo reqPageVo, QueryWrapper<CouponCiEntity> queryWrapper) {
        if (ToolUtil.isNotEmpty(reqPageVo.getValidPeriodDate())) {
            // 开始时间小于搜索结束时间&结束时间大于开始时间即满足
            List<String> validPeriodDate = reqPageVo.getValidPeriodDate();
            CommonUtils.sortTimeStr(validPeriodDate);
            DateTime startTime = DateUtil.parse(validPeriodDate.get(0));
            DateTime endTime = DateUtil.parse(validPeriodDate.get(1));
            queryWrapper.apply(
                    "date_format (valid_period_start_time,'%Y-%m-%d') <= date_format('" + endTime
                            + "','%Y-%m-%d')");
            queryWrapper.apply(
                    "date_format (valid_period_end_time,'%Y-%m-%d') >= date_format('" + startTime
                            + "','%Y-%m-%d')");
        }
    }

    private void handleCiVo(CouponCiEntity x) {
        List<String> validPeriodList = new ArrayList<>(2);
        validPeriodList.add(new DateTime(x.getValidPeriodStartTime()).toString());
        validPeriodList.add(new DateTime(x.getValidPeriodEndTime()).toString());
        x.setValidPeriodDate(validPeriodList);
        Float faceValue = x.getFaceValue();
        Float thresholdValue = x.getThresholdValue();
        Boolean isThreshold = x.getThreshold();
        String faceValueVo = "";
        String thresholdValueVo = "";
        switch (x.getDiscountType()) {
            case CouponConstants.OFFER_DISCOUNT_COUPON:
                faceValueVo = CommonUtils.handleFloatStr(faceValue / 10) + "折";
                thresholdValueVo = isThreshold ? CommonUtils.handleFloatStr(thresholdValue) + "元" : "无";
                break;
            case CouponConstants.OFFER_CASH_COUPON:
                faceValueVo = CommonUtils.handleFloatStr(faceValue) + "元";
                thresholdValueVo = isThreshold ? CommonUtils.handleFloatStr(thresholdValue) + "元" : "无";
                break;
            case CouponConstants.OFFER_DURATION_COUPON:
                faceValueVo = CommonUtils.handleFloatStr(faceValue) + "小时";
                thresholdValueVo = isThreshold ? CommonUtils.handleFloatStr(thresholdValue) + "小时" : "无";
                break;
            default:
                break;
        }
        x.setFaceValueVo(faceValueVo);
        x.setThresholdValueVo(thresholdValueVo);
        x.setDescription(CommonUtils.getCiDes(x));
    }

    @Override
    public CouponCiEntity queryDetailsById(Long id) {
//        CouponCiEntity ci = ciMapper.selectById(id);
        CouponCiEntity ci = ciMapper.selectByIdProduct(id);
        // 需求其他信息完善
        handleCiVo(ci);
        return ci;
    }

    @Override
    public int deleteCiByIds(List<Integer> ids, LoginUserAccountInfo loginUserInfo) {
        AtomicInteger res = new AtomicInteger();
        ids.forEach(x -> {
            CouponCiEntity ci = new CouponCiEntity();
            ci.setDelFlag(true);
            int result = ciMapper.update(ci, new QueryWrapper<CouponCiEntity>().lambda()
                    .eq(CouponCiEntity::getId, x)
                    .eq(CouponCiEntity::getTenementCode, loginUserInfo.getTenementCode())
                    .eq(CouponCiEntity::getUseStatus, CouponStatusEnum.CI_USE_STATUS_UNUSED.getCode()));
            if (1 == result) {
                res.getAndIncrement();
                log.info("删除卡券成功，CouponCiEntity ID={}", x);
            } else {
                log.error("删除卡券失败，CouponCiEntity ID={}, result={}", x, result);
            }
        });
        return res.get();
    }

    @Override
    public CiStatusNumRspVo queryStatusNum(ReqPageVo reqPageVo,
            LoginUserAccountInfo loginUserInfo) {
        QueryWrapper<CouponCiEntity> ciAll = new QueryWrapper<>();
        ciAll.eq(CouponConstants.TENEMENT_CODE_STR, loginUserInfo.getTenementCode());
        ciAll.eq(CouponConstants.DEL_FLAG_STR, CouponConstants.DEL_FLAG_FALSE);
        ciAll.eq(CouponConstants.SHOW_STATUS_STR, CouponConstants.SHOW_STATUS_YES);

        QueryWrapper<CouponCiEntity> unusedNum = getCiQueryWrapper(loginUserInfo,
                CouponStatusEnum.CI_USE_STATUS_UNUSED);
        QueryWrapper<CouponCiEntity> usedNum = getCiQueryWrapper(loginUserInfo,
                CouponStatusEnum.CI_USE_STATUS_USED);
        QueryWrapper<CouponCiEntity> expiredNum = getCiQueryWrapper(loginUserInfo,
                CouponStatusEnum.CI_USE_STATUS_EXPIRED);
        QueryWrapper<CouponCiEntity> voidNum = getCiQueryWrapper(loginUserInfo,
                CouponStatusEnum.CI_USE_STATUS_VOID);

        return new CiStatusNumRspVo(ciMapper.selectCount(ciAll),
                ciMapper.selectCount(unusedNum),
                ciMapper.selectCount(usedNum),
                ciMapper.selectCount(expiredNum),
                ciMapper.selectCount(voidNum)
        );
    }

    @Override
    public OpenApiCiRspVo queryDetailsVo(JSONObject params) {
        String couponCode = params.getString("couponCiCode");
        if (StrUtil.isBlank(couponCode)) {
            throw CouponException.creat("卡券编码为空：couponCiCode");
        }
        CouponCiEntity ci = ciMapper.selectOne(
                new QueryWrapper<CouponCiEntity>().eq("coupon_code", couponCode));
        if (ci == null) {
            throw CouponException.creat("无法查询此卡券信息，卡券编码：" + couponCode);
        }
        // 需求其他信息完善
        handleCiVo(ci);
        // 增加vo
        OpenApiCiRspVo openApiCiRspVo = DozerBeanUtils.transitionType(ci, OpenApiCiRspVo.class);
        handleCiRspVo(openApiCiRspVo);
        return openApiCiRspVo;
    }

    private void handleCiRspVo(OpenApiCiRspVo openApiCiRspVo) {
        QueryWrapper<CouponDictEntity> wrapper = new QueryWrapper<>();
        wrapper.eq("type_code", CouponConstants.COUPON_TEMPLATE_COUPON);
        wrapper.eq("code", openApiCiRspVo.getCouponType());
        CouponDictEntity couponTypeDict = dictMapper.selectOne(wrapper);
        openApiCiRspVo.setCouponTypeVo(couponTypeDict.getValueName());

        QueryWrapper<CouponDictEntity> offerTypeWrapper = new QueryWrapper<>();
        offerTypeWrapper.eq("type_code", CouponConstants.OFFER_TYPE);
        offerTypeWrapper.eq("code", openApiCiRspVo.getDiscountType());
        CouponDictEntity offerTypeWrapperDict = dictMapper.selectOne(offerTypeWrapper);
        openApiCiRspVo.setDiscountTypeVo(offerTypeWrapperDict.getValueName());
    }

    private QueryWrapper<CouponCiEntity> getCiQueryWrapper(LoginUserAccountInfo loginUserInfo,
            CouponStatusEnum couponStatusEnum) {
        QueryWrapper<CouponCiEntity> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq(CouponConstants.TENEMENT_CODE_STR, loginUserInfo.getTenementCode());
        queryWrapper.eq(CouponConstants.DEL_FLAG_STR, CouponConstants.DEL_FLAG_FALSE);
        queryWrapper.eq(CouponConstants.SHOW_STATUS_STR, CouponConstants.SHOW_STATUS_YES);
        queryWrapper.eq("use_status", couponStatusEnum.getCode());
        return queryWrapper;
    }
}

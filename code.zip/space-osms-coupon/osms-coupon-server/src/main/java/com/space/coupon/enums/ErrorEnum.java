package com.space.coupon.enums;

import cn.space.base.enums.exception.AbstractBaseExceptionEnum;

/**
 * 异常
 *
 * @Author kangmj
 * @date 2021-09-15 15:53
 * @Version 1.0
 */
public enum ErrorEnum implements AbstractBaseExceptionEnum {
    /**
     * DEFAULT_ERROR
     */
    DEFAULT_ERROR(300, "业务异常"),
    /**
     * DUPLICATE_NAME
     */
    DUPLICATE_NAME(1001, "名称重复"),
    PRODUCT_ERROR(1002, "产品信息不能为空。");

    ErrorEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    private Integer code;

    private String msg;


    @Override
    public Integer getCode() {
        return code;
    }

    @Override
    public String getMsg() {
        return msg;
    }

    public void setMsg(String message) {
        this.msg = message;
    }
}

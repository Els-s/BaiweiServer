package com.space.coupon.controller;

import cn.space.base.result.Response;
import com.alibaba.fastjson.JSONObject;
import com.space.coupon.service.CouponCiService;
import com.space.coupon.vo.couponvo.rspvo.OpenApiCiRspVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpHeaders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 卡券服务OpenApi
 *
 * @Author kangmj
 * @date 2021-10-14 9:20
 * @Version 1.0
 */
@RestController
@RequestMapping("/v1/openApi")
@Api(tags = "卡券服务OpenApi")
@Slf4j
public class CouponOpenApiController {

    @Autowired
    CouponCiService ciService;

    /**
     * 获取卡券详细信息
     */
    @ApiOperation("OpenApi-获取卡券详细信息Vo")
    @PostMapping(value = "/queryCiDetails")
    public Response getInfo(@RequestHeader(HttpHeaders.AUTHORIZATION) String token,
            @RequestBody JSONObject map) {
        log.info("OpenApi-获取卡券详细信息Vo：{}", map);
        OpenApiCiRspVo ci = ciService.queryDetailsVo(map);

        return Response.success(ci);
    }
}

package com.space.coupon.vo.couponvo.reqvo;

import com.space.coupon.entity.CouponRuleEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-09-26 19:13
 * @Version 1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(value = "卡券模板新增Vo")
public class RuleAddReqVo extends CouponRuleEntity {

    @ApiModelProperty("按日/月:MONTH_DAY / WEEK / CYCLE")
    private String repeatFrequency;

    @ApiModelProperty("是否每月")
    private Boolean everyMonth;

    @ApiModelProperty("指定月")
    private int[] executionMonths;

    @ApiModelProperty("是否每日")
    private Boolean everyDay;

    @ApiModelProperty("指定日")
    private int[] executionDays;

    @ApiModelProperty("按周")
    private int[] executionWeekdays;

    @ApiModelProperty("按周期:WEEK / MONTH / SEASON /  HALF_YEAR /  YEAR /  CUSTOM_DAY")
    private String cycleTime;

    @ApiModelProperty("自定义周期值")
    private Integer customTime;
}

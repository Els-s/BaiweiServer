package com.space.coupon.util;

import cn.hutool.core.collection.ListUtil;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.space.coupon.common.CouponConstants;
import com.space.coupon.entity.CouponCiEntity;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-09-28 17:51
 * @Version 1.0
 */
public class CommonUtils {

    /**
     * 处理float末位数
     *
     * @param num Float
     * @return String
     */
    public static String handleFloatStr(Float num) {
        return new DecimalFormat("###.##").format(num);
    }

    /**
     * 时间字符串数组排序
     *
     * @param dateList List<String>
     */
    public static void sortTimeStr(List<String> dateList) {
//        Collections.sort(dateList);
    }

    /**
     * 优惠卷使用条件说明
     *
     * @param ciEntity
     * @return
     */
    public static String getCiDes(CouponCiEntity ciEntity) {
        String ciDes = "";
        if (ciEntity.getThreshold()) {
            String thresholdValue = handleFloatStr(ciEntity.getThresholdValue());
            switch (ciEntity.getDiscountType()) {
                case CouponConstants.OFFER_DISCOUNT_COUPON:
                case CouponConstants.OFFER_CASH_COUPON:
                    ciDes = "满" + thresholdValue + "元可用";
                    break;
                case CouponConstants.OFFER_DURATION_COUPON:
                    ciDes = "满" + thresholdValue + "小时可用";
                    break;
                default:
                    break;
            }
        } else {
            ciDes = "无门槛通用券";
        }
        return ciDes;
    }

    public static String getCidDetailVo(CouponCiEntity ciEntity) {
        StringBuilder ciDes = new StringBuilder();
        String faceValueVo = "";
        Float faceValue = ciEntity.getFaceValue();
        switch (ciEntity.getDiscountType()) {
            case CouponConstants.OFFER_DISCOUNT_COUPON:
                faceValueVo = CommonUtils.handleFloatStr(faceValue / 10) + "折";
                break;
            case CouponConstants.OFFER_CASH_COUPON:
                faceValueVo = CommonUtils.handleFloatStr(faceValue) + "元";
                break;
            case CouponConstants.OFFER_DURATION_COUPON:
                faceValueVo = CommonUtils.handleFloatStr(faceValue) + "小时";
                break;
            default:
                break;
        }
        ciDes.append(faceValueVo);
        String ciDe = "";
        if (ciEntity.getThreshold()) {
            String thresholdValue = handleFloatStr(ciEntity.getThresholdValue());
            switch (ciEntity.getDiscountType()) {
                case CouponConstants.OFFER_DISCOUNT_COUPON:
                    ciDe = "（满" + thresholdValue + "元）";
                    break;
                case CouponConstants.OFFER_CASH_COUPON:
                    ciDe = "（满" + thresholdValue + "元减" + CommonUtils.handleFloatStr(faceValue) + "元）";
                    break;
                case CouponConstants.OFFER_DURATION_COUPON:
                    ciDe = "（满" + thresholdValue + "小时）";
                    break;
                default:
                    break;
            }
        } else {
            ciDe = "（无门槛通用券）";
        }
        ciDes.append(ciDe);
        return ciDes.toString();
    }
}

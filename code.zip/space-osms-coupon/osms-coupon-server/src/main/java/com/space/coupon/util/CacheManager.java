package com.space.coupon.util;

import cn.hutool.cache.Cache;
import cn.hutool.cache.CacheUtil;
import cn.hutool.core.date.DateUnit;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-09-28 19:11
 * @Version 1.0
 */
public class CacheManager {

    private static final Cache<String, Object> lfuCache = CacheUtil.newLFUCache(4096);

    public static void cache(String key, Object value) {
        lfuCache.put(key, value);
    }

    /**
     * cache
     *
     * @param key           key
     * @param value         value
     * @param timeOutSecond 秒
     */
    public static void cache(String key, Object value, int timeOutSecond) {
        lfuCache.put(key, value, timeOutSecond * DateUnit.SECOND.getMillis());
    }

    public static Object getValue(String key) {
        return lfuCache.get(key, false);
    }

    public static boolean containsKey(String key) {
        return lfuCache.containsKey(key);
    }

    public static void remove(String key) {
        lfuCache.remove(key);
    }
}

package com.space.coupon.service.impl;

import cn.hutool.core.codec.Base64;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.crypto.SecureUtil;
import cn.hutool.crypto.symmetric.AES;
import cn.space.portal.sdk.io.LoginUserAccountInfo;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.space.coupon.common.CouponConstants;
import com.space.coupon.entity.CouponCiEntity;
import com.space.coupon.entity.CouponProductEntity;
import com.space.coupon.entity.CouponUseLogEntity;
import com.space.coupon.enums.CouponStatusEnum;
import com.space.coupon.enums.UseLogEnum;
import com.space.coupon.exception.CouponException;
import com.space.coupon.mapper.CouponCiMapper;
import com.space.coupon.mapper.CouponProductMapper;
import com.space.coupon.mapper.CouponUseLogMapper;
import com.space.coupon.service.CouponUseService;
import com.space.coupon.service.CouponObjectService;
import com.space.coupon.util.CommonUtils;
import com.space.coupon.vo.couponvo.CouponObjectVo;
import com.space.coupon.vo.couponvo.ProductVo;
import com.space.coupon.vo.couponvo.reqvo.UseCouponReqVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import org.springframework.transaction.annotation.Transactional;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-09-16 21:33
 * @Version 1.0
 */
@Service
@Slf4j
public class CouponUseServiceImpl implements CouponUseService {

    @Autowired
    CouponCiMapper ciMapper;

    @Autowired
    CouponUseLogMapper useLogMapper;

    @Autowired
    CouponProductMapper productMapper;

    @Autowired
    private CouponObjectService objectService;

    @Override
    public CouponObjectVo queryListByOrder(UseCouponReqVo reqVo, LoginUserAccountInfo loginUserInfo) {
        CouponObjectVo objectVo = new CouponObjectVo();
        if (reqVo.getSearchType().equals(3) && StrUtil.isBlank(reqVo.getCompanyId())) {
            return objectVo;
        }
        QueryWrapper<CouponCiEntity> wrapper = objectService.getCouponCiEntities(reqVo.getSearchType(),
                reqVo.getCompanyId(),
                reqVo.getPersonCode(), reqVo.getType(), loginUserInfo);
        // 增加场景
        wrapper.eq("scenes", reqVo.getScenes());
        List<CouponCiEntity> allCis = ciMapper.selectList(wrapper);
        if (CollUtil.isNotEmpty(allCis)) {
            // 状态 可使用/已使用/已过期
            boolean isUseStatus = CouponStatusEnum.CI_USE_STATUS_UNUSED.getCode()
                    .equals(Integer.valueOf(reqVo.getType()));
            if (isUseStatus) {
                // 选择可用的券
                List<ProductVo> productInfo = reqVo.getProductInfo();
                List<CouponCiEntity> inUseCis = handleCis(productInfo, allCis);
                objectVo.setAvailableCouponNum(inUseCis.size());
            }
            objectVo.setCoupons(allCis);
        }
        return objectVo;
    }

    @Override
    public List<CouponCiEntity> getCouponUseInformation(JSONObject map, LoginUserAccountInfo loginUserInfo) {
        JSONArray couponCodeList = map.getJSONArray("couponCode");
        List<String> codeList = JSONArray.parseArray(JSON.toJSONString(couponCodeList), String.class);
        ArrayList<CouponCiEntity> cis = new ArrayList<>();
        codeList.forEach(x -> {
            CouponCiEntity ci = getCouponCi(x);
            AES saltAes = SecureUtil.aes(Base64.decode(CouponConstants.CI_SLAT_DATA));
            String saltStr = ci.getSalt();
            String salt = saltAes.decryptStr(saltStr);
            AES aes = SecureUtil.aes(Base64.decode(CouponConstants.CI_INFO_DATA));
            String encryptInfo = aes.encryptHex(salt);
            ci.setUseCode(encryptInfo);
            cis.add(ci);
        });
        return cis;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public List<CouponCiEntity> couponUse(JSONObject map, LoginUserAccountInfo loginUserInfo) {
        JSONArray couponCodeList = map.getJSONArray("couponCiVoList");
        List<CouponCiEntity> ciList = JSONArray.parseArray(JSON.toJSONString(couponCodeList), CouponCiEntity.class);
        DateTime nowTime = new DateTime();
        ciList.forEach(x -> {
            String couponCode = x.getCouponCode();
            CouponCiEntity ci = getCouponCi(couponCode);
            AES saltAes = SecureUtil.aes(Base64.decode(CouponConstants.CI_SLAT_DATA));
            String salt = saltAes.decryptStr(ci.getSalt());
            AES aes = SecureUtil.aes(Base64.decode(CouponConstants.CI_INFO_DATA));
            String encryptInfo = aes.decryptStr(x.getUseCode());
            if (!salt.equals(encryptInfo)) {
                throw new CouponException(CouponConstants.FAILED_CODE, "此券使用码异常请确认：" + couponCode);
            }
            // 使用优惠券
            CouponCiEntity updateCi = new CouponCiEntity();
            updateCi.setId(ci.getId());
            updateCi.setUseStatus(CouponStatusEnum.CI_USE_STATUS_USED.getCode());
            // 锁定券
            updateCi.setUseLock(Boolean.TRUE);
            updateCi.setUsePerson(loginUserInfo.getPersonCode());
            updateCi.setUsedTime(nowTime);
            updateCi.setOrderNum(map.getString("orderNum"));
            ciMapper.updateById(updateCi);
            // 使用记录
            insertCiUseLog(map, loginUserInfo, ci, UseLogEnum.使用);
        });
        return ciList;
    }

    private CouponCiEntity getCouponCi(String couponCode) {
        CouponCiEntity ci = ciMapper.selectOne(new QueryWrapper<CouponCiEntity>()
                .lambda().eq(CouponCiEntity::getCouponCode, couponCode)
                .eq(CouponCiEntity::getUseStatus, CouponStatusEnum.CI_USE_STATUS_UNUSED.getCode())
                .eq(CouponCiEntity::getDelFlag, CouponConstants.DEL_FLAG_FALSE)
                .eq(CouponCiEntity::getShowStatus, CouponConstants.SHOW_STATUS_YES));
        if (ObjectUtil.isEmpty(ci)) {
            throw new CouponException(CouponConstants.FAILED_CODE, "此券码已被使用：" + couponCode);
        }
        return ci;
    }

    @Override
    public List<CouponCiEntity> couponReturn(JSONObject map, LoginUserAccountInfo loginUserInfo) {
        JSONArray couponCodeList = map.getJSONArray("couponCiVoList");
        List<CouponCiEntity> ciList = JSONArray.parseArray(JSON.toJSONString(couponCodeList), CouponCiEntity.class);
        ciList.forEach(x -> {
            String couponCode = x.getCouponCode();
            CouponCiEntity ci = ciMapper.selectOne(new QueryWrapper<CouponCiEntity>()
                    .lambda().eq(CouponCiEntity::getCouponCode, couponCode)
                    .eq(CouponCiEntity::getDelFlag, CouponConstants.DEL_FLAG_FALSE)
                    .eq(CouponCiEntity::getShowStatus, CouponConstants.SHOW_STATUS_YES));
            if (ObjectUtil.isEmpty(ci)) {
                throw new CouponException(CouponConstants.FAILED_CODE, "此券码不存在：" + couponCode);
            }
            // 退还优惠券
            CouponCiEntity updateCi = new CouponCiEntity();
            updateCi.setId(ci.getId());
            updateCi.setUseStatus(CouponStatusEnum.CI_USE_STATUS_UNUSED.getCode());
            updateCi.setUseLock(Boolean.TRUE);
//            updateCi.setUsePerson(loginUserInfo.getPersonCode());
//            updateCi.setUsedTime(nowTime);
            ciMapper.updateById(updateCi);
            // 使用记录
            insertCiUseLog(map, loginUserInfo, ci, UseLogEnum.退还);
        });
        return ciList;


    }

    private void insertCiUseLog(JSONObject map, LoginUserAccountInfo loginUserInfo, CouponCiEntity ci,
            UseLogEnum useLogEnum) {
        CouponUseLogEntity useLog = new CouponUseLogEntity();
        useLog.setCouponCode(ci.getCouponCode());
        useLog.setRuleCode(ci.getRuleCode());
        useLog.setTenementCode(ci.getTenementCode());
        useLog.setOrderNum(map.getString("orderNum"));
        useLog.setCreatedByUname(map.getString("createdByUname"));
        useLog.setUserCode(loginUserInfo.getPersonCode());
        useLog.setStatus(useLogEnum.getCode());
        useLogMapper.insert(useLog);
    }

    private List<CouponCiEntity> handleCis(List<ProductVo> productInfo, List<CouponCiEntity> allCis) {
        List<CouponCiEntity> useCi = new ArrayList<>(16);
        productInfo.forEach(y -> {
            // 可使用判别
            Set<Long> ruleSet = new HashSet<>();
            allCis.forEach(x -> ruleSet.add(x.getRuleId()));
            // 此产品可用券
            List<CouponProductEntity> products = productMapper.selectList(
                    new QueryWrapper<CouponProductEntity>()
                            .lambda().eq(CouponProductEntity::getProductId, y.getProductId()));
            products.forEach(x -> {
                if (ruleSet.contains(x.getRuleId())) {
                    // 可用模板->可用CI
                    List<CouponCiEntity> ciInOneRule = allCis.stream().filter(z -> z.getRuleId().equals(x.getRuleId()))
                            .collect(Collectors.toList());
                    CouponCiEntity oneCi = ciInOneRule.get(0);
                    // 判断条件
                    if (!oneCi.getThreshold()) {
                        // 无门槛
                        if (!isDayTimePay(y, oneCi)) {
                            useCi.addAll(ciInOneRule);
                        }
                    } else {
                        // 门槛
                        Float thresholdValue = oneCi.getThresholdValue();
                        switch (oneCi.getDiscountType()) {
                            case CouponConstants.OFFER_DISCOUNT_COUPON:
                            case CouponConstants.OFFER_CASH_COUPON:
                                BigDecimal paidPrice = y.getProductPaidPrice();
                                if (paidPrice.floatValue() >= thresholdValue) {
                                    useCi.addAll(ciInOneRule);
                                }
                                break;
                            case CouponConstants.OFFER_DURATION_COUPON:
                                if (ObjectUtil.isNotEmpty(y.getProductReservationTime()) &&
                                        y.getProductReservationTime() >= thresholdValue) {
                                    useCi.addAll(ciInOneRule);
                                }
                                break;
                            default:
                                break;
                        }
                    }
                }
            });
        });
        allCis.forEach(x -> {
            boolean isInUse = useCi.contains(x);
            if (isInUse) {
                x.setMeetCondition(Boolean.TRUE);
                x.setCiDetailVo(CommonUtils.getCidDetailVo(x));
            } else {
                x.setMeetCondition(Boolean.FALSE);
                x.setUnusableInfo("不满足使用门槛");
            }
            x.setDescription(CommonUtils.getCiDes(x));
        });
        return useCi;
    }

    private boolean isDayTimePay(ProductVo y, CouponCiEntity oneCi) {
        if (ObjectUtil.isEmpty(y.getProductReservationTime()) || y.getProductReservationTime() <= 0) {
            // 去除时长券--没有时间
            return CouponConstants.OFFER_DURATION_COUPON == oneCi.getDiscountType();
        }
        return false;
    }
}

package com.space.coupon.controller;

import cn.space.portal.sdk.holder.UserHolder;
import cn.space.portal.sdk.io.LoginUserAccountInfo;
import com.space.coupon.entity.CouponProductEntity;
import com.space.coupon.service.CouponProductService;
import com.space.coupon.vo.RspPageVo;
import com.space.coupon.vo.RspVo;
import com.space.coupon.vo.couponvo.reqvo.ProductListReqVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpHeaders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 卡券适用产品Controller
 *
 * @author kangmj
 * @date 2021-09-10
 */
@RestController
@RequestMapping("/product")
@Api(tags = "卡券服务：卡券产品信息管理")
@Slf4j
public class CouponProductController {

    @Autowired
    private CouponProductService productService;

    /**
     * 查询卡券适用产品列表
     */
    @ApiOperation("查询卡券可用范围")
    @PostMapping("/queryList")
    public RspVo<RspPageVo<List<CouponProductEntity>>> list(
            @RequestHeader(HttpHeaders.AUTHORIZATION) String token,
            @RequestBody ProductListReqVo reqPageVo) {
        log.info("查看PC卡券使用情况列表请求参数：{}", reqPageVo);
        LoginUserAccountInfo loginUserInfo = UserHolder.get();
        RspPageVo<List<CouponProductEntity>> data = productService.queryPage(reqPageVo, loginUserInfo);
        return RspVo.success("ok", data);
    }
}

package com.space.coupon.service.dubbo;

import cn.space.base.result.Response;
import cn.space.portal.sdk.io.LoginUserAccountInfo;
import com.space.coupon.responsevo.CouponUseReqVo;
import com.space.coupon.service.CouponOpenService;
import com.space.coupon.service.CouponUseService;
import com.space.coupon.service.impl.CouponServiceImpl;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * dubboService
 *
 * @Author kangmj
 * @date 2021-10-12 9:31
 * @Version 1.0
 */
//@DubboService
@Service("dubboService")
public class CouponOpenServiceImpl implements CouponOpenService {

    @Autowired
    private CouponServiceImpl couponService;

    @Autowired
    CouponUseService couponUseService;

    @Override
    public Response couponUse(CouponUseReqVo reqVo, LoginUserAccountInfo loginUserInfo) {
//        List<CouponCiEntity> vo = couponUseService.couponUse(map, loginUserInfo);

        return null;
    }

    @Override
    public Response getCouponUseInformation(List<String> couponCode, LoginUserAccountInfo loginUserInfo) {
        System.out.println("getCouponUseInformationgetCouponUseInformation-======");
        return null;
    }
}

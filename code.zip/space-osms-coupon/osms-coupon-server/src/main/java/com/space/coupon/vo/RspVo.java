package com.space.coupon.vo;

import com.space.coupon.common.CouponConstants;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-09-07 13:39
 * @Version 1.0
 */
@Data
@ApiModel(value = "响应类")
public class RspVo<T> {

    @ApiModelProperty("响应消息")
    private String msg;
    @ApiModelProperty("响应码:'200'=成功，'300'=失败")
    private String code;
    @ApiModelProperty("成功标志")
    private Boolean success;
    @ApiModelProperty("返回数据")
    private T data;

    public RspVo() {
    }

    public RspVo(T date) {
        this.data = date;
    }

    public RspVo(Boolean success, String msg, String code, T date) {
        this.success = success;
        this.msg = msg;
        this.code = code;
        this.data = date;
    }

    public RspVo(Boolean success, String msg, String code) {
        this.success = success;
        this.msg = msg;
        this.code = code;
    }

    public static RspVo<?> success(String msg) {
        return new RspVo<>(true, msg, CouponConstants.SUCCESS_CODE);
    }

    public static <T> RspVo<T> success(String msg, T date) {
        return new RspVo<>(true, msg, CouponConstants.SUCCESS_CODE, date);
    }

    public static <T> RspVo<T> error(String msg) {
        return new RspVo<>(false, msg, "300");
    }
}

package com.space.coupon.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.cloud.common.utils.HttpUtils;
import com.space.coupon.config.VenueReserveConfig;
import com.space.coupon.service.VenueReserveService;
import com.space.coupon.vo.RspVo;
import java.util.HashMap;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-10-09 17:51
 * @Version 1.0
 */
@Service
@Slf4j
public class VenueReserveServiceImpl implements VenueReserveService {

    @Autowired
    private VenueReserveConfig venueReserveConfig;

    @Override
    public JSONObject getVenueTypeTree(String token, JSONObject params) {
        JSONObject response = getVenueResponse(token, venueReserveConfig.getVenueTypeTree(), params.toJSONString());
        return response;
    }

    @Override
    public JSONObject querySpace(String token, JSONObject params) {
        JSONObject response = getVenueResponse(token, venueReserveConfig.getQuerySpace(), params.toJSONString());
        return response;
    }

    private JSONObject getVenueResponse(String token, String url, String body) {
        HashMap<String, String> header = new HashMap<>();
        header.put(HttpHeaders.AUTHORIZATION, token);
        header.put(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        HttpResponse response;
        String responseStr = "";
        try {
            response = HttpUtils.doPost(venueReserveConfig.getHost(),
                    url, "POST", header, null, body);
            log.info("调用场地服务，请求地址:{}  请求参数: {} ", venueReserveConfig.getHost() + url, body);
            HttpEntity entity = response.getEntity();
            response.getStatusLine().getStatusCode();
            responseStr = EntityUtils.toString(response.getEntity());

            log.info("请求场地服务返回结果：response = {} \n", responseStr);
            return JSONObject.parseObject(responseStr);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            e.printStackTrace();
        }
        return JSONObject.parseObject(JSON.toJSONString(RspVo.error("场地服务接口调用异常")));
    }
}

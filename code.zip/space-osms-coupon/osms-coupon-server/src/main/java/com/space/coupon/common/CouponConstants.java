package com.space.coupon.common;

/**
 * 卡券服务常量
 *
 * @Author kangmj
 * @date 2021-09-14 21:22
 * @Version 1.0
 */
public class CouponConstants {

    public static final String RULE_ID_STR = "rule_id";
    public static final String ID_SRT = "id";
    public static final String RULE_CODE_STR = "rule_code";
    public static final String SEARCH_INFO_STR = "search_info";
    public static final String PROJECT_CODE_STR = "project_code";
    public static final String TENEMENT_CODE_STR = "tenement_code";
    public static final String OBJECT_TYPE_STR = "object_type";
    public static final String OBJECT_ID_STR = "object_id";
    public static final String SUCCESS_CODE = "200";
    public static final String FAILED_CODE = "300";
    public static final String CI_SLAT_DATA = "Fk+aAk3cCNXzl9G+QGLj0Q==";
    public static final String DEL_FLAG_STR = "del_flag";
    public static final int DEL_FLAG_FALSE = 0;
    public static final int DEL_FLAG_YES = 1;
    public static final String SHOW_STATUS_STR = "show_status";
    public static final String STR_SPLIT_DB = ",";
    public static final int SHOW_STATUS_NO = 0;
    public static final int SHOW_STATUS_YES = 1;
    /**
     * 优惠类型:1=折扣券;2=金额券;3=时长券
     */
    public static final int OFFER_DISCOUNT_COUPON = 1;
    public static final int OFFER_CASH_COUPON = 2;
    public static final int OFFER_DURATION_COUPON = 3;
    public static final int PAGE_SIZE_BATCH = 500;
    public static final int LIST_INIT_LENGTH = 16;
    public static final String CI_INFO_DATA = "NitonheVM5eEE+lVLoT+aQ==";
    public static final String COUPON_TEMPLATE_COUPON = "COUPON_TEMPLATE_COUPON";
    public static final String OFFER_TYPE = "OFFER_TYPE";
}

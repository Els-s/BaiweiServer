package com.space.coupon.vo.couponvo;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-09-15 18:49
 * @Version 1.0
 */
@Data
@Accessors(chain = true)
@ApiModel(value = "发放范围对象")
public class ScopeVo {

    private String objectId;
    private String name;
}

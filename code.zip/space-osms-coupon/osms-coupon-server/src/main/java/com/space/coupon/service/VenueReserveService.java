package com.space.coupon.service;

import com.alibaba.fastjson.JSONObject;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-10-09 17:51
 * @Version 1.0
 */
public interface VenueReserveService {

    /**
     * getVenueTypeTree
     *
     * @param token  token
     * @param params
     * @return JsonObject
     */
    JSONObject getVenueTypeTree(String token, JSONObject params);

    /**
     * querySpace
     *
     * @param token
     * @param params
     * @return
     */
    JSONObject querySpace(String token, JSONObject params);
}

package com.space.coupon.vo.couponvo;

import com.alibaba.fastjson.JSONObject;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-09-17 10:45
 * @Version 1.0
 */
@Data
@ApiModel(value = "商品")
public class ProductVo {

    @ApiModelProperty("产品ID")
    private String productId;

    @ApiModelProperty("产品名称")
    private String productName;

    @ApiModelProperty("产品支付价格")
    private BigDecimal productPaidPrice;

    @ApiModelProperty("产品价格")
    private BigDecimal productTotalPrice;

    @ApiModelProperty("产品预定时长:单位 小时")
    private Float productReservationTime;
}

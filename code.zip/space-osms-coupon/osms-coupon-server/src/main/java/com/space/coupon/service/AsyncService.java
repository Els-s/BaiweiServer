package com.space.coupon.service;

import cn.space.portal.sdk.io.LoginUserAccountInfo;
import com.space.coupon.entity.CouponObjectEntity;

import java.util.List;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-09-27 16:05
 * @Version 1.0
 */
public interface AsyncService {

    /**
     * 发放卡券线程
     *
     * @param objectEntities
     * @param loginUserInfo
     */
    void issueCouponTask(List<CouponObjectEntity> objectEntities,
            LoginUserAccountInfo loginUserInfo);
}

package com.space.coupon.service;

import cn.space.portal.sdk.io.LoginUserAccountInfo;
import com.space.coupon.entity.CouponProductEntity;
import com.space.coupon.vo.RspPageVo;
import com.space.coupon.vo.couponvo.reqvo.ProductListReqVo;

import java.util.List;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-09-17 19:16
 * @Version 1.0
 */
public interface CouponProductService {

    /**
     * queryPage
     *
     * @param reqPageVo     ,
     * @param loginUserInfo ,
     * @return
     */
    RspPageVo<List<CouponProductEntity>> queryPage(ProductListReqVo reqPageVo, LoginUserAccountInfo loginUserInfo);
}

package com.space.coupon.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 字典分类对象 coupon_dict_type
 *
 * @author kangmj
 * @date 2021-09-14
 */
@Data
@TableName("coupon_dict_type")
@ApiModel(value = "字典项类型说明")
public class CouponDictTypeEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * ID
     */
    @TableId
    private Long id;

    /**
     * 数据字典名称
     */
    @ApiModelProperty("数据字典名称")
    private String typeName;

    /**
     * 字典表类型值
     */
    @ApiModelProperty("字典表类型值")
    private String typeValue;

    /**
     * 租户编码
     */
    @ApiModelProperty("租户编码")
    private String tenementCode;
}

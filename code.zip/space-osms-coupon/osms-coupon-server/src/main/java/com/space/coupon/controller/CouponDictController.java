package com.space.coupon.controller;

import com.space.coupon.entity.CouponDictEntity;
import com.space.coupon.service.CouponDictService;
import com.space.coupon.vo.RspVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 字典明细Controller
 *
 * @author kangmj
 * @date 2021-09-14
 */
@RestController
@RequestMapping("/dict")
@Api(tags = "卡券服务：卡券服务字典项查询")
public class CouponDictController {

    @Autowired
    private CouponDictService dictService;

    @ApiOperation("查询服务字典项")
    @GetMapping("/queryDict")
    public RspVo<List<CouponDictEntity>> list(
            @ApiParam(value = "字典项类型--业务标识") @RequestParam(name = "typeCode") String typeCode) {
        List<CouponDictEntity> dictEntities = dictService.queryDictInfo(typeCode);
        return RspVo.success("ok", dictEntities);
    }
}

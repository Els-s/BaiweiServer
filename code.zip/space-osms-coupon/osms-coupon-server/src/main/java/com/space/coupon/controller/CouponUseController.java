package com.space.coupon.controller;

import cn.space.portal.sdk.holder.UserHolder;
import cn.space.portal.sdk.io.LoginUserAccountInfo;
import com.alibaba.fastjson.JSONObject;
import com.space.coupon.entity.CouponCiEntity;
import com.space.coupon.service.CouponUseService;
import com.space.coupon.vo.couponvo.CouponObjectVo;
import com.space.coupon.vo.RspVo;
import com.space.coupon.vo.couponvo.reqvo.UseCouponReqVo;
import com.space.log.annotation.OperaLog;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpHeaders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 卡券服务：卡券应用
 *
 * @Author kangmj
 * @date 2021-09-10 18:21
 * @Version 1.0
 */
@RestController
@RequestMapping("/use")
@Api(tags = "卡券服务：卡券应用")
@Slf4j
public class CouponUseController {

    @Autowired
    CouponUseService couponUseService;

    @ApiOperation("查询订单可用优惠券信息")
    @OperaLog(opType = "查询", opInfo = "查询订单可用优惠券信息")
    @PostMapping("/queryListByOrder")
    public RspVo<CouponObjectVo> queryListByOrder(
            /*搜索信息:‘1’全部，‘2’个人，‘3’全部"
             type 查类型：‘1’可使用，‘2’已使用，‘3’已过期"*/
            @RequestHeader(HttpHeaders.AUTHORIZATION) String token,
            @RequestBody UseCouponReqVo reqPageVo) {
        log.info("查询订单优惠券信息请求参数：{}", reqPageVo);
        LoginUserAccountInfo loginUserInfo = UserHolder.get();
        CouponObjectVo vo = couponUseService.queryListByOrder(reqPageVo, loginUserInfo);
        return RspVo.success("ok", vo);
    }

    @ApiOperation("选则优惠券使用，获取优惠券密码锁--锁定优惠券防止别人重复使用")
    @OperaLog(opType = "选择优惠券", opInfo = "获取优惠券使用码")
    @PostMapping("/getCouponUseInfo")
    public RspVo<List<CouponCiEntity>> getCouponUseInformation(
            @RequestHeader(HttpHeaders.AUTHORIZATION) String token, @RequestBody JSONObject map) {
        // {couponCode:[] }
        log.info("选则优惠券使用请求参数：{}", map);
        LoginUserAccountInfo loginUserInfo = UserHolder.get();
        List<CouponCiEntity> vo = couponUseService.getCouponUseInformation(map, loginUserInfo);
        return RspVo.success("ok", vo);
    }

    @ApiOperation("使用优惠券")
    @OperaLog(opType = "使用优惠券", opInfo = "使用优惠券信息")
    @PostMapping("/couponUse")
    public RspVo<?> couponUse(
            @RequestHeader(HttpHeaders.AUTHORIZATION) String token, @RequestBody JSONObject map) {
        // {couponCiVoList:[] , orderNum:, createdByUname}
        log.info("使用优惠券优惠券请求参数：{}", map);
        LoginUserAccountInfo loginUserInfo = UserHolder.get();
        List<CouponCiEntity> vo = couponUseService.couponUse(map, loginUserInfo);
        return RspVo.success("优惠卷使用成功", vo);
    }

    @ApiOperation("优惠券退还")
    @OperaLog(opType = "退还", opInfo = "优惠券退还")
    @PostMapping("/couponReturn")
    public RspVo<?> couponReturn(
            @RequestHeader(HttpHeaders.AUTHORIZATION) String token, @RequestBody JSONObject map) {
        // {couponCiVoList:[] , orderNum:, createdByUname}
        log.info("使用优惠券优惠券请求参数：{}", map);
        LoginUserAccountInfo loginUserInfo = UserHolder.get();
        List<CouponCiEntity> vo = couponUseService.couponReturn(map, loginUserInfo);
        return RspVo.success("优惠卷退还成功", vo);
    }
}

package com.space.coupon.service.impl;

import cn.space.base.result.Response;
import com.alibaba.fastjson.JSONObject;
import com.cloud.common.utils.RestTemplateUtilsV2;
import com.space.coupon.common.CouponConstants;
import com.space.coupon.config.PortalConf;
import com.space.coupon.exception.CouponException;
import com.space.coupon.service.PortalService;
import javax.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-10-11 17:47
 * @Version 1.0
 */
@Service
@Slf4j
public class PortalServiceImpl implements PortalService {

    @Resource
    private PortalConf portalConf;

    @Override
    public Response queryAccountRelProject(String token, JSONObject params) {
        // 查询用户关联项目
        String url = portalConf.getHost() + portalConf.getQueryAccountRelProject();
        return getResponse(url, params, token);
    }

    @Override
    public Response queryEnterpriseList(String token, JSONObject params) {
        // 查询企业列表
        String portalUrl = portalConf.getHost() + portalConf.getSdkQueryEnterpriseList();
        return getResponse(portalUrl, params, token);
    }

    @Override
    public Response queryAccountAttributeList(String token, JSONObject params) {
        String portalUrl = portalConf.getHost() + portalConf.getSdkQueryAccountAttributeList();
        // 查询企业管理员列表
        Response response = getResponse(portalUrl, params, token);
        if (!CouponConstants.SUCCESS_CODE.equals(response.getCode())) {
            // 异常判断
            log.error("查询企业管理员列表==查询门户数据异常={}", response);
            throw CouponException.creat("查询门户数据异常");
        }
        return response;
    }

    /**
     * @description: 构造返回数据
     * @param: url 请求地址
     * @param: body 返回数据
     * @return: cn.space.base.result.Response
     * @author zhengyanan
     * @date: 2021/9/27 11:59
     */
    private Response getResponse(String url, JSONObject body, String token) {
        try {
//            HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
            HttpHeaders requestHeaders = new HttpHeaders();
            requestHeaders.add(HttpHeaders.AUTHORIZATION, token);
            requestHeaders.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
            log.info("调用门户，请求地址:{}  请求参数: {} ", url, body);
            ResponseEntity<JSONObject> response = RestTemplateUtilsV2.post(url, requestHeaders, body, JSONObject.class);
            log.info("调用门户，返回数据 ： {} " + JSONObject.toJSONString(response.getBody()));
            return JSONObject.parseObject(JSONObject.toJSONString(response.getBody()), Response.class);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return Response.error("500", "门户接口调用异常");
        }
    }
}

package com.space.coupon.vo.couponvo.reqvo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.space.coupon.vo.ReqPageVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-09-22 22:11
 * @Version 1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(value = "卡券模板列表查询")
public class QueryRuleListVo extends ReqPageVo {

    @ApiModelProperty("优惠类型:1=金额券;2=时长券;3=折扣券,null=全部")
    private Integer discountType;
    @ApiModelProperty("使用门槛:0=没有，1=有，null=全部")
    private Integer threshold;
    @ApiModelProperty("有效期限计算方式：1=固定；0=非固定，null=全部")
    private Integer validityPeriodType;
    @ApiModelProperty("应用场景：1=场景预定")
    private Integer scenes;
    @ApiModelProperty("发放频次：0=重复；1=一次性")
    private Integer frequency;
    @ApiModelProperty("模板状态:1 未上线;2 已上线;3 已过期")
    private Integer useStatus;
    @ApiModelProperty("有效期搜索")
    private List<String> validPeriodDate;
    @ApiModelProperty("发放起止日期搜索")
    private List<String> issueDate;
    @ApiModelProperty("创建时间搜索")
    private List<String> creatDate;

    @Override
    public String toString() {
        return "QueryRuleListVo{" +
                "discountType='" + discountType + '\'' +
                ", threshold='" + threshold + '\'' +
                ", validityPeriodType='" + validityPeriodType + '\'' +
                ", scenes='" + scenes + '\'' +
                ", frequency='" + frequency + '\'' +
                ", validPeriodDate=" + validPeriodDate +
                ", issueDate=" + issueDate +
                ", creatDate=" + creatDate +
                "} " + super.toString();
    }
}

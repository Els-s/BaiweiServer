package com.space.coupon.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

/**
 * 卡券核销记录对象 coupon_use_log
 *
 * @author kangmj
 * @date 2021-09-10
 */
@EqualsAndHashCode(callSuper = true)
@Data
@TableName("coupon_use_log")
public class CouponUseLogEntity extends CouponBaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 卡券编码
     */
    @ApiModelProperty("卡券编码")
    private String couponCode;

    /**
     * 使用状态
     */
    @ApiModelProperty("使用状态")
    private String status;

    /**
     * 商品号
     */
    @ApiModelProperty("商品号")
    private String productId;

    /**
     * 卡券模板ID
     */
    @ApiModelProperty("卡券模板ID")
    private Long ruleId;

    /**
     * 模板ID
     */
    @ApiModelProperty("模板Code")
    private String ruleCode;

    /**
     * 卡券名称
     */
    @ApiModelProperty("卡券名称")
    private String ruleName;

    /**
     * 订单号
     */
    @ApiModelProperty("订单号")
    private String orderNum;

    /**
     * 核销店员
     */
    @ApiModelProperty("核销店员")
    private String createdByUname;

    /**
     * 使用人
     */
    @ApiModelProperty("使用人")
    private String userCode;

    /**
     * 退款单号
     */
    @ApiModelProperty("退款单号")
    private String refundFormNum;

    /**
     * 支付商户号
     */
    @ApiModelProperty("支付商户号")
    private String mchId;

    /**
     * 发起商户
     */
    @ApiModelProperty("发起商户")
    private String issueMerchant;

    /**
     * 删除符
     */
    @JsonIgnore
    private Boolean delFlag;

    /**
     * 搜索列
     */
    @ApiModelProperty("搜索列")
    @JsonIgnore
    private String searchInfo;
}

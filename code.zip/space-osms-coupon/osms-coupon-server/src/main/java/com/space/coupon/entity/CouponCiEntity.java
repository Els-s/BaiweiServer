package com.space.coupon.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 卡券对象 coupon_ci
 *
 * @author kangmj
 * @date 2021-09-10
 */
@EqualsAndHashCode(callSuper = true)
@Data
@TableName("coupon_ci")
@ApiModel(value = "卡券模型")
public class CouponCiEntity extends CouponBaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 卡券模板ID
     */
    @ApiModelProperty("卡券模板ID")
    private Long ruleId;

    @ApiModelProperty("模板Code")
    private String ruleCode;

    /**
     * 卡券名称
     */
    @ApiModelProperty("卡券名称")
    private String ruleName;

    /**
     * 卡券编码
     */
    @ApiModelProperty("卡券编码")
    private String couponCode;

    /**
     * 对象类型
     */
    @ApiModelProperty("对象类型:0 企业，1 个人")
    private Integer objectType;

    /**
     * 接收对象
     */
    @ApiModelProperty("接收对象")
    private String objectId;

    /**
     * 接收对象
     */
    @ApiModelProperty("对象名称")
    private String objectName;

    /**
     * 使用状态
     */
    @ApiModelProperty("使用状态：1 未使用，2 已使用，3 已过期，4 作废")
    private Integer useStatus;
    /**
     * 卡券面值
     */
    @ApiModelProperty("卡券面值")
    private Float faceValue;

    /**
     * 是否有门槛
     */
    @ApiModelProperty("是否有门槛")
    private Boolean threshold;

    /**
     * 门槛值
     */
    @ApiModelProperty("门槛值")
    private Float thresholdValue;


    /**
     * 有效期开始时间
     */
    @ApiModelProperty("有效期开始时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date validPeriodStartTime;

    /**
     * 有效期结束时间
     */
    @ApiModelProperty("有效期结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date validPeriodEndTime;


    /**
     * 展示状态：发放时展示
     */
    @ApiModelProperty("展示状态")
    @JsonIgnore
    private Integer showStatus;

    /**
     * 应用场景
     */
    @ApiModelProperty("应用场景")
    private Integer scenes;

    /**
     * 发放时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty("发放时间")
    private Date issueTime;

    @ApiModelProperty("发放人")
    private String issuer;
    /**
     * 使用时间
     */
    @ApiModelProperty("使用时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date usedTime;

    @ApiModelProperty("使用人")
    private String usePerson;

    @ApiModelProperty("订单号")
    private String orderNum;

    /**
     * 卡券类型
     */
    @ApiModelProperty("卡券类型")
    private Integer couponType;

    /**
     * 优惠类型
     */
    @ApiModelProperty("优惠类型：1 折扣券，2 金额券，3 时长券")
    private Integer discountType;

    /**
     * 是否指定商品可用
     */
    @ApiModelProperty("是否指定商品可用")
    private Boolean isSingle;

    /**
     * 使用锁
     */
    @ApiModelProperty("使用锁")
    @JsonIgnore
    private Boolean useLock;

    /**
     * 删除标记
     */
    @JsonIgnore
    private Boolean delFlag;

    /**
     * 活动ID
     */
    @ApiModelProperty("活动ID")
    private Long campaignsId;

    /**
     * 发放商户
     */
    @ApiModelProperty("发放商户")
    private String issueMerchant;

    /**
     * 搜索列
     */
    @ApiModelProperty("搜索列")
    @JsonIgnore
    private String searchInfo;

    /**
     * 盐值
     */
    @ApiModelProperty("盐值")
    @JsonIgnore
    private String salt;

    /**
     * 修改时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date updateTime;
    /**
     * 修改人
     */
    private String updateBy;

    @TableField(exist = false)
    @ApiModelProperty("产品信息--集合")
    private List<CouponProductEntity> productEntityList;

    /**
     * 券使用规则
     */
    @ApiModelProperty("券使用规则")
    @TableField(exist = false)
    private String description;

    /**
     * 卡券面值Vo
     */
    @TableField(exist = false)
    @ApiModelProperty("卡券面值Vo")
    private String faceValueVo;

    /**
     * 门槛值Vo
     */
    @TableField(exist = false)
    @ApiModelProperty("门槛值Vo")
    private String thresholdValueVo;

    @TableField(exist = false)
    @ApiModelProperty("有效期数据list")
    private List<String> validPeriodDate;

    @TableField(exist = false)
    @ApiModelProperty("是否可使用状态时:true 满足使用条件，false不满足使用条件")
    private Boolean meetCondition;

    @TableField(exist = false)
    @ApiModelProperty("不可使用原因")
    private String unusableInfo;

    @TableField(exist = false)
    @ApiModelProperty("使用码")
    private String useCode;

    @TableField(exist = false)
    @ApiModelProperty("优惠卷展示信息")
    private String ciDetailVo;
}

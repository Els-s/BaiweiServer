package com.space.coupon.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import lombok.EqualsAndHashCode;

/**
 * 卡券批次统计对象 coupon_batch
 *
 * @author
 * @date 2021-09-10
 */
@EqualsAndHashCode(callSuper = true)
@Data
@TableName("coupon_batch")
public class CouponBatchEntity extends CouponBaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 模板ID
     */
    @ApiModelProperty("模板ID")
    private Long ruleId;

    /**
     * 活动ID
     */
    @ApiModelProperty("活动ID")
    private Long campaignsId;

    /**
     * 发放商户
     */
    @ApiModelProperty("发放商户")
    private String issueMerchant;

    /**
     * 卡券类型
     */
    @ApiModelProperty("卡券类型")
    private Integer couponType;

    /**
     * 优惠类型
     */
    @ApiModelProperty("优惠类型")
    private Integer discountType;

    /**
     * 卡券面值
     */
    @ApiModelProperty("卡券面值")
    private Float faceValue;

    /**
     * 是否已终止
     */
    @ApiModelProperty("是否已终止")
    private Integer isStop;

    /**
     * 券发放量
     */
    @ApiModelProperty("券发放量")
    private Long sendCoupons;

    /**
     * 券使用量
     */
    @ApiModelProperty("券使用量")
    private Long usedCoupons;

    /**
     * 带动交易笔数
     */
    @ApiModelProperty("带动交易笔数")
    private Long bringTradeCount;

    /**
     * 带动交易金额
     */
    @ApiModelProperty("带动交易金额")
    private Long bringTradeAmount;

    /**
     * 带动实收
     */
    @ApiModelProperty("带动实收")
    private Long bringTradeCash;

    /**
     * 券抵扣金额
     */
    @ApiModelProperty("券抵扣金额")
    private Long couponAmount;

    /**
     * 搜索列
     */
    @ApiModelProperty("搜索列")
    @JsonIgnore
    private String searchInfo;
}

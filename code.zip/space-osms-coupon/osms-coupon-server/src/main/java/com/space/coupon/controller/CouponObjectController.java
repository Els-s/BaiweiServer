package com.space.coupon.controller;

import cn.space.portal.sdk.holder.UserHolder;
import cn.space.portal.sdk.io.LoginUserAccountInfo;
import com.space.coupon.entity.CouponCiEntity;
import com.space.coupon.service.CouponObjectService;
import com.space.coupon.vo.RspPageVo;
import com.space.coupon.vo.RspVo;
import com.space.coupon.vo.couponvo.reqvo.ObjectListReqVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpHeaders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 卡包Controller
 *
 * @author kangmj
 * @date 2021-09-10
 */
@RestController
@RequestMapping("/object")
@Api(tags = "卡券服务：卡包管理")
@Slf4j
public class CouponObjectController {

    @Autowired
    private CouponObjectService objectService;

    @ApiOperation("查询我的优惠券信息")
    @PostMapping("/queryListByObject")
    public RspVo<RspPageVo<List<CouponCiEntity>>> queryListByObject(
//      @ApiParam(value = "查类型：‘1’可使用，‘2’已使用，‘3’已过期") @RequestParam(name = "type") Integer type
            @RequestHeader(HttpHeaders.AUTHORIZATION) String token,
            @RequestBody ObjectListReqVo reqVo) {
        log.info("查询我的优惠券请求参数：{}", reqVo);
        LoginUserAccountInfo loginUserInfo = UserHolder.get();
        RspPageVo<List<CouponCiEntity>> vo = objectService.queryListByObject(reqVo, loginUserInfo);
        return RspVo.success("ok", vo);
    }
}

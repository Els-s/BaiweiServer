package com.space.coupon.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.space.coupon.entity.CouponBatchEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * 卡券批次统计表
 *
 * @author kangmj
 * @email kangmingjing@qq.com
 * @date 2021-09-13 14:57:31
 */
@Mapper
public interface CouponBatchMapper extends BaseMapper<CouponBatchEntity> {

}

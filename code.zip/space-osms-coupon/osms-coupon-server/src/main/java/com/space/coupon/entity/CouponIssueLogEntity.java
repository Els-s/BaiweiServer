package com.space.coupon.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 卡券发放记录对象 coupon_issue_log
 *
 * @author kangmj
 * @date 2021-09-10
 */
@EqualsAndHashCode(callSuper = true)
@Data
@TableName("coupon_issue_log")
public class CouponIssueLogEntity extends CouponBaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 卡券模板ID
     */
    @ApiModelProperty("卡券模板ID")
    private Long ruleId;

    /**
     * 模板ID
     */
    @ApiModelProperty("模板Code")
    private String ruleCode;

    /**
     * 发放数量
     */
    @ApiModelProperty("发放数量")
    private Integer issuedNum;

    /**
     * 对象类型
     */
    @ApiModelProperty("对象类型:0 企业，1 个人")
    private Integer objectType;

    @ApiModelProperty("用户类型：1 企业管理员 2 企业员工 3普通用户 4指定用户")
    private Integer personType;

    /**
     * 活动ID
     */
    @ApiModelProperty("活动ID")
    private Long campaignsId;

    /**
     * 发放商户
     */
    @ApiModelProperty("发放商户")
    private String issueMerchant;

    /**
     * 卡券类型
     */
    @ApiModelProperty("卡券类型")
    private Integer couponType;

    /**
     * 卡券类型
     */
    @ApiModelProperty("优惠类型")
    private Integer discountType;

    /**
     * 展示状态
     */
    @ApiModelProperty("展示状态")
    private Integer showStatus;

    /**
     * 发放时间
     */
    @ApiModelProperty("发放时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date issueTime;

    /**
     * 模板名称
     */
    @ApiModelProperty("模板名称")
    @TableField(exist = false)
    private String ruleName;

    @ApiModelProperty("卡券面值")
    @TableField(exist = false)
    private Float faceValue;

    @ApiModelProperty("门槛值")
    @TableField(exist = false)
    private Float thresholdValue;

    @ApiModelProperty("是否有门槛")
    @TableField(exist = false)
    private Boolean threshold;

    @ApiModelProperty("有效期限方式:1=固定；0=非固定")
    @TableField(exist = false)
    private Integer validityPeriodType;

    @ApiModelProperty("非固定时有效期值")
    @TableField(exist = false)
    private Integer validityPeriodValue;

    @TableField(exist = false)
    @ApiModelProperty("有效期开始时间:yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date validPeriodStartTime;

    @TableField(exist = false)
    @ApiModelProperty("有效期结束时间:yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date validPeriodEndTime;

    @ApiModelProperty("应用场景")
    @TableField(exist = false)
    private Integer scenes;

    @ApiModelProperty("卡券状态")
    @TableField(exist = false)
    private Integer useStatus;

    @ApiModelProperty("发放人")
    @TableField(exist = false)
    private String personName;

    /**
     * 卡券面值Vo
     */
    @TableField(exist = false)
    @ApiModelProperty("卡券面值Vo")
    private String faceValueVo;

    /**
     * 门槛值Vo
     */
    @TableField(exist = false)
    @ApiModelProperty("门槛值Vo")
    private String thresholdValueVo;

    /**
     * 有效期数据list
     */
    @TableField(exist = false)
    @ApiModelProperty("有效期数据list")
    private List<String> validPeriodDate;

    @TableField(exist = false)
    @ApiModelProperty("发放范围信息--集合")
    private List<CouponObjectEntity> objectList;

    @TableField(exist = false)
    @ApiModelProperty("发放范围数量")
    private Integer objectsNum;

    @TableField(exist = false)
    @ApiModelProperty("发放对象Vo")
    private String issueObjectVo;
}

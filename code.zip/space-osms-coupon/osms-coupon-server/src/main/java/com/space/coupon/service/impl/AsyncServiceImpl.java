package com.space.coupon.service.impl;

import cn.hutool.core.codec.Base64;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.crypto.SecureUtil;
import cn.hutool.crypto.symmetric.AES;
import cn.space.portal.sdk.io.LoginUserAccountInfo;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.space.coupon.common.CouponConstants;
import com.space.coupon.entity.*;
import com.space.coupon.enums.CouponStatusEnum;
import com.space.coupon.enums.DictEnum;
import com.space.coupon.mapper.*;
import com.space.coupon.service.AsyncService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * 异步处理
 *
 * @Author kangmj
 * @date 2021-09-27 16:05
 * @Version 1.0
 */
@Component
@Slf4j
public class AsyncServiceImpl implements AsyncService {

    @Autowired
    CouponRuleMapper ruleMapper;

    @Autowired
    CouponCiMapper ciMapper;

    @Autowired
    CouponIssueLogMapper issueLogMapper;

    @Autowired
    CouponRuleCycleMapper ruleCycleMapper;

    @Autowired
    CouponObjectMapper objectMapper;

    @Override
    @Async
    public void issueCouponTask(List<CouponObjectEntity> objectEntities,
            LoginUserAccountInfo loginUserInfo) {
        log.info("========发放开始");
        if (ObjectUtil.isEmpty(objectEntities)) {
            log.error("======issueCouponTask objectEntities was empty.");
            return;
        }
        CouponRuleEntity ruleEntity = ruleMapper.selectById(objectEntities.get(0).getRuleId());

        if (CouponStatusEnum.FREQUENCY_ONCE.getCode().equals(ruleEntity.getFrequency())) {
            // 一次性
            addCouponsOnce(ruleEntity, true, objectEntities, true, loginUserInfo);
        } else {
            // 重复发放
            handleIssueCiBatch(ruleEntity, objectEntities, loginUserInfo);
        }
        // *需有效期开始后进行状态更新
        updateRuleStatus(ruleEntity.getId(), CouponStatusEnum.ONLINE);
    }

    private void addCouponsOnce(CouponRuleEntity ruleEntity, boolean isEndIssue,
            List<CouponObjectEntity> objectEntities, boolean isStartIssue,
            LoginUserAccountInfo loginUserInfo) {
        String couponCodePre = getCouponCodePre(ruleEntity);
        DateTime nowTime = new DateTime();
        objectEntities.forEach(x -> {
            CouponCiEntity ci = getCiModel(ruleEntity, x, loginUserInfo);
            ci.setShowStatus(1);
            ci.setIssueTime(nowTime);
            // 处理有效期
            handleCiTime(ruleEntity, ci);
            AddCiDate(couponCodePre, x, ci);
        });
        // 增加发放记录
        addIssueLog(ruleEntity, objectEntities, true, nowTime);
    }

    private void addIssueLog(CouponRuleEntity ruleEntity, List<CouponObjectEntity> objectEntities, boolean isShow,
            DateTime time) {
        CouponIssueLogEntity issueLog = new CouponIssueLogEntity();
        issueLog.setRuleId(ruleEntity.getId());
        issueLog.setIssuedNum(objectEntities.get(0).getIssuedNum());
        issueLog.setRuleCode(ruleEntity.getRuleCode());
        issueLog.setCouponType(ruleEntity.getCouponType());
        issueLog.setDiscountType(ruleEntity.getDiscountType());
        issueLog.setCreateBy(objectEntities.get(0).getCreateBy());
        issueLog.setTenementCode(ruleEntity.getTenementCode());
        issueLog.setShowStatus(isShow ? 1 : 0);
        issueLog.setIssueTime(time);
        issueLogMapper.insert(issueLog);
    }

    private void AddCiDate(String couponCodePre, CouponObjectEntity x, CouponCiEntity ci) {
        for (int i = 0; i < x.getIssuedNum(); i++) {
            // 添加随机数
            AES aes = SecureUtil.aes(Base64.decode(CouponConstants.CI_SLAT_DATA));
            ci.setSalt(aes.encryptHex(IdUtil.randomUUID().substring(0, 16)));
            ci.setCouponCode(couponCodePre.concat(IdUtil.objectId()).toUpperCase(Locale.ROOT));
            ci.setSearchInfo(ci.getRuleCode().concat(ci.getCouponCode()).concat(x.getObjectName()));
            ciMapper.insert(ci);
        }
    }

    private void handleCiTime(CouponRuleEntity ruleEntity, CouponCiEntity ci) {
        // 一次性
        if (CouponStatusEnum.RULE_VALIDITYPERIODTYPE_FIXED.getCode().equals(ruleEntity.getValidityPeriodType())) {
            // 固定
            ci.setValidPeriodStartTime(ruleEntity.getValidPeriodStartTime());
            ci.setValidPeriodEndTime(ruleEntity.getValidPeriodEndTime());
        } else {
            // 非固定
            ci.setValidPeriodStartTime(ruleEntity.getValidPeriodStartTime());
            ci.setValidPeriodEndTime(
                    DateUtil.offsetDay(ruleEntity.getValidPeriodStartTime(), ruleEntity.getValidityPeriodValue()));
        }
    }

    private void handleIssueCiBatch(CouponRuleEntity ruleEntity, List<CouponObjectEntity> objects,
            LoginUserAccountInfo loginUserInfo) {
        CouponRuleCycleEntity cycle = ruleCycleMapper.selectOne(new QueryWrapper<CouponRuleCycleEntity>()
                .lambda().eq(CouponRuleCycleEntity::getRuleId, ruleEntity.getId()));
        DateTime startTime;
        DateTime endTime;
        boolean isFixedDate = CouponStatusEnum.RULE_VALIDITYPERIODTYPE_FIXED.getCode()
                .equals(ruleEntity.getValidityPeriodType());
        if (isFixedDate) {
            // 固定
            startTime = new DateTime(ruleEntity.getValidPeriodStartTime());
            endTime = new DateTime(ruleEntity.getValidPeriodEndTime());
        } else {
            // 非固定
            startTime = DateUtil.parse(ruleEntity.getIssueStartDate() + " " + ruleEntity.getTimedReleaseTime());
            endTime = DateUtil.parse(ruleEntity.getIssueEndDate() + " " + ruleEntity.getTimedReleaseTime());
        }
        int betweenDay = (int) DateUtil.betweenDay(startTime, endTime, true);
        // 重复频率：1=按日/月；2=按周；3=按周期
        switch (cycle.getRepeatFrequency()) {
            case "MONTH_DAY":
                List<Integer> monthList = getMonthList(cycle);
                List<Integer> dayList = getDayList(cycle);
                for (int i = 0; i <= betweenDay; i++) {
                    // 发放时间
                    DateTime time = DateUtil.offsetDay(startTime, i);
                    int month = time.month();
                    int day = time.dayOfMonth();
                    if ((monthList.isEmpty() || monthList.contains(month)) &&
                            (dayList.isEmpty() || dayList.contains(day))) {
                        addCisEveryDay(ruleEntity, objects, isFixedDate, time,
                                0 == DateUtil.betweenDay(new DateTime(), time, false), true, loginUserInfo);
                    }
                }
                break;
            case "WEEK":
                List<Integer> weekDayList = getWeekDayList(cycle);
                for (int i = 0; i <= betweenDay; i++) {
                    // 发放时间
                    DateTime time = DateUtil.offsetDay(startTime, i);
                    int dayOfWeek = time.dayOfWeek();
                    if (weekDayList.contains(dayOfWeek)) {
                        // 时间合适
                        addCisEveryDay(ruleEntity, objects, isFixedDate, time,
                                0 == DateUtil.betweenDay(new DateTime(), time, false), true, loginUserInfo);
                    }
                }
                break;
            case "CYCLE":
                handleCycleTime(ruleEntity, betweenDay, startTime, cycle, objects, isFixedDate, loginUserInfo);
                break;
            default:
                break;
        }
    }

    private void handleCycleTime(CouponRuleEntity ruleEntity, int betweenDay, DateTime startTime,
            CouponRuleCycleEntity cycle, List<CouponObjectEntity> objects, boolean isFixedDate,
            LoginUserAccountInfo loginUserInfo) {
        // 周期设置：CUSTOM_DAY=自定义；WEEK=按周；MONTH=按月；SEASON=按季；HALF_YEAR=按半年；YEAR=按年
        switch (cycle.getCycleTime()) {
            case "CUSTOM_DAY":
                Integer customTime = cycle.getCustomTime();
                issueByCycleTimeCustom(ruleEntity, betweenDay, startTime, objects, isFixedDate, customTime,
                        loginUserInfo);
                break;
            case "WEEK":
                issueByCycleTimeCustom(ruleEntity, betweenDay, startTime, objects, isFixedDate, 7, loginUserInfo);
                break;
            case "MONTH":
                // 第一次发放
                addCisEveryDay(ruleEntity, objects, isFixedDate, startTime, true, true, loginUserInfo);
                int dayOfMonth = startTime.dayOfMonth();
                // 是否最后一天
                boolean isEndDayOfMonth = DateUtil.endOfMonth(startTime).dayOfMonth() == dayOfMonth;
                for (int i = 20; i <= betweenDay; i++) {
                    DateTime time = DateUtil.offsetDay(startTime, i);
                    int endOfMonthDay = DateUtil.endOfMonth(time).dayOfMonth();
                    if (isEndDayOfMonth && endOfMonthDay == time.dayOfMonth()) {
                        addCisEveryDay(ruleEntity, objects, isFixedDate, time, false, true, loginUserInfo);
                    } else {
                        if (time.dayOfMonth() == dayOfMonth) {
                            addCisEveryDay(ruleEntity, objects, isFixedDate, time, false, true, loginUserInfo);
                        }
                    }
                    if (!isEndDayOfMonth && endOfMonthDay < dayOfMonth) {
                        // 这个月时间不足， 使用最后一天
                        DateTime monthEndTime = DateUtil.endOfMonth(time);
                        int offset = (int) DateUtil.betweenDay(time, monthEndTime, true);
                        DateTime offsetDay = DateUtil.offsetDay(time, offset);
                        addCisEveryDay(ruleEntity, objects, isFixedDate, offsetDay, false, true, loginUserInfo);
                        i = i + offset + 1;
                    }
                }
                break;
            case "SEASON":
                handleOverMonthTime(ruleEntity, betweenDay, startTime, objects, isFixedDate, 3, loginUserInfo);
                break;
            case "HALF_YEAR":
                handleOverMonthTime(ruleEntity, betweenDay, startTime, objects, isFixedDate, 6, loginUserInfo);
                break;
            case "YEAR":
                handleOverMonthTime(ruleEntity, betweenDay, startTime, objects, isFixedDate, 12, loginUserInfo);
                break;
            default:
                break;
        }
    }

    private void issueByCycleTimeCustom(CouponRuleEntity ruleEntity, int betweenDay, DateTime startTime,
            List<CouponObjectEntity> objects, boolean isFixedDate, Integer customTime,
            LoginUserAccountInfo loginUserInfo) {
        addCisEveryDay(ruleEntity, objects, isFixedDate, startTime, true, true, loginUserInfo);
        for (int i = 1; i <= betweenDay; i++) {
            if (0 == i % customTime) {
                DateTime time = DateUtil.offsetDay(startTime, i);
                addCisEveryDay(ruleEntity, objects, isFixedDate, time, false, true, loginUserInfo);
            }
        }
    }

    private void handleOverMonthTime(CouponRuleEntity ruleEntity, int betweenDay, DateTime startTime,
            List<CouponObjectEntity> objects, boolean isFixedDate, int betweenMonth,
            LoginUserAccountInfo loginUserInfo) {
        // 第一次发放
        addCisEveryDay(ruleEntity, objects, isFixedDate, startTime, true, true, loginUserInfo);
        int quarter = startTime.month() % betweenMonth;
        int dayOfMonth = startTime.dayOfMonth();
        // 是否最后一天
        boolean isEndDayOfMonth = DateUtil.endOfMonth(startTime).dayOfMonth() == dayOfMonth;
        for (int i = 60; i <= betweenDay; i++) {
            DateTime time = DateUtil.offsetDay(startTime, i);
            if (quarter == startTime.month() % betweenMonth) {
                int endOfMonthDay = DateUtil.endOfMonth(time).dayOfMonth();
                if (isEndDayOfMonth && endOfMonthDay == time.dayOfMonth()) {
                    addCisEveryDay(ruleEntity, objects, isFixedDate, time, false, true, loginUserInfo);
                    i = i + 31;
                } else {
                    if (time.dayOfMonth() == dayOfMonth) {
                        addCisEveryDay(ruleEntity, objects, isFixedDate, time, false, true, loginUserInfo);
                        i = i + 31;
                    }
                }
                if (!isEndDayOfMonth && endOfMonthDay < dayOfMonth) {
                    // 这个月时间不足， 使用最后一天
                    DateTime monthEndTime = DateUtil.endOfMonth(time);
                    int offset = (int) DateUtil.betweenDay(time, monthEndTime, true);
                    DateTime offsetDay = DateUtil.offsetDay(time, offset);
                    addCisEveryDay(ruleEntity, objects, isFixedDate, offsetDay, false, true, loginUserInfo);
                    i = i + 31;
                }
            }
        }
    }

    private void addCisEveryDay(CouponRuleEntity ruleEntity, List<CouponObjectEntity> objects, boolean isFixedDate,
            DateTime time, boolean isShow, boolean isStartIssue, LoginUserAccountInfo loginUserInfo) {
        String couponCodePre = getCouponCodePre(ruleEntity);
        int showStatus = isShow ? 1 : 0;
        objects.forEach(x -> {
            CouponCiEntity ci = getCiModel(ruleEntity, x, loginUserInfo);
            // 处理有效期
            ci.setIssueTime(time);
            if (isFixedDate) {
                // 固定
                ci.setValidPeriodStartTime(ruleEntity.getValidPeriodStartTime());
                ci.setValidPeriodEndTime(ruleEntity.getValidPeriodEndTime());
            } else {
                // 非固定
                ci.setValidPeriodStartTime(time);
                ci.setValidPeriodEndTime(DateUtil.offsetDay(time, ruleEntity.getValidityPeriodValue()));
            }
            // 展示状态
            ci.setShowStatus(showStatus);
            AddCiDate(couponCodePre, x, ci);
        });
        // 增加发放记录
        addIssueLog(ruleEntity, objects, isShow, time);
    }

    private List<Integer> getDayList(CouponRuleCycleEntity cycle) {
        List<Integer> list = new ArrayList<>(16);
        if (!"ALL".equals(cycle.getWorkDay())) {
            String[] strings = cycle.getWorkDay().split(CouponConstants.STR_SPLIT_DB);
            for (String month : strings) {
                list.add(Integer.valueOf(month));
            }
        }
        return list;
    }

    private List<Integer> getMonthList(CouponRuleCycleEntity cycle) {
        List<Integer> list = new ArrayList<>(16);
        if (!"ALL".equals(cycle.getWorkMonth())) {
            String[] strings = cycle.getWorkMonth().split(CouponConstants.STR_SPLIT_DB);
            for (String month : strings) {
                list.add(Integer.valueOf(month));
            }
        }
        return list;
    }

    private List<Integer> getWeekDayList(CouponRuleCycleEntity cycle) {
        List<Integer> list = new ArrayList<>(16);
        String[] strings = cycle.getWorkWeek().split(CouponConstants.STR_SPLIT_DB);
        for (String month : strings) {
            list.add(Integer.valueOf(month));
        }
        return list;
    }

    private CouponCiEntity getCiModel(CouponRuleEntity ruleEntity, CouponObjectEntity x,
            LoginUserAccountInfo loginUserInfo) {
        CouponCiEntity ci = new CouponCiEntity();
        ci.setRuleId(ruleEntity.getId());
        ci.setTenementCode(ruleEntity.getTenementCode());
        ci.setScenes(ruleEntity.getScenes());
        ci.setIssuer(loginUserInfo.getRealName());
        ci.setCreateBy(loginUserInfo.getPersonCode());
        ci.setRuleCode(ruleEntity.getRuleCode());
        ci.setRuleName(ruleEntity.getRuleName());
        ci.setFaceValue(ruleEntity.getFaceValue());
        ci.setThreshold(ruleEntity.getThreshold());
        ci.setThresholdValue(ruleEntity.getThresholdValue());
        ci.setObjectId(x.getObjectId());
        ci.setObjectName(x.getObjectName());
        ci.setObjectType(x.getObjectType());
        ci.setUseStatus(CouponStatusEnum.CI_USE_STATUS_UNUSED.getCode());
        ci.setCouponType(ruleEntity.getCouponType());
        ci.setDiscountType(ruleEntity.getDiscountType());
        ci.setIsSingle(true);
        ci.setDelFlag(false);
        return ci;
    }

    private String getCouponCodePre(CouponRuleEntity ruleEntity) {
        // 卡券规则：优惠券A开头 + 折扣券1；金额券2 + 时长券3
        StringBuilder str = new StringBuilder();
        if (DictEnum.OFFER_DISCOUNT_COUPON.getCode().equals(ruleEntity.getCouponType())) {
            str.append("A");
            switch (ruleEntity.getDiscountType()) {
                case CouponConstants.OFFER_DISCOUNT_COUPON:
                    str.append("1");
                    break;
                case CouponConstants.OFFER_CASH_COUPON:
                    str.append("2");
                    break;
                case CouponConstants.OFFER_DURATION_COUPON:
                    str.append("3");
                    break;
                default:
                    break;
            }
        }
        return str.toString();
    }

    private void updateRuleStatus(Long id, CouponStatusEnum ruleStatusEnum) {
        CouponRuleEntity rule = new CouponRuleEntity();
        rule.setId(id);
        rule.setUseStatus(ruleStatusEnum.getCode());
        ruleMapper.updateById(rule);
    }
}

package com.space.coupon.vo.couponvo.reqvo;

import com.space.coupon.vo.ReqPageVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-09-17 19:24
 * @Version 1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@ApiModel(value = "商品列表查询")
public class ProductListReqVo extends ReqPageVo {

    @ApiModelProperty("卡券ruleId")
    private Integer ruleId;
    @ApiModelProperty("选择的项目id")
    private Integer selectProjectId;

    @Override
    public String toString() {
        return "ProductListReqVo{" +
                "ruleId=" + ruleId +
                ", selectProjectId=" + selectProjectId +
                "} " + super.toString();
    }
}

package com.space.coupon.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

/**
 * 卡包对象 coupon_object
 *
 * @author kangmj
 * @date 2021-09-10
 */
@EqualsAndHashCode(callSuper = true)
@Data
@TableName("coupon_object")
@ApiModel(value = "卡包对象模型")
public class CouponObjectEntity extends CouponBaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 卡券模板ID
     */
    @ApiModelProperty("卡券模板ID")
    private Long ruleId;

    /**
     * 对象类型
     */
    @ApiModelProperty("对象类型:0 企业，1个人")
    private Integer objectType;

    /**
     * 对象ID
     */
    @ApiModelProperty("对象ID")
    private String objectId;

    /**
     * 对象名称
     */
    @ApiModelProperty("对象名称")
    private String objectName;

    /**
     * 剩余数量
     */
    @ApiModelProperty("剩余数量")
    private Integer remainNum;

    /**
     * 发放状态
     */
    @ApiModelProperty("发放状态")
    private Integer issueStatus;

    /**
     * 发放数量
     */
    @ApiModelProperty("发放数量")
    private Integer issuedNum;

    /**
     * 活动ID
     */
    @ApiModelProperty("活动ID")
    private Long campaignsId;

    /**
     * 发放商户
     */
    @ApiModelProperty("发放商户")
    private String issueMerchant;

    /**
     * 卡券类型
     */
    @ApiModelProperty("卡券类型")
    private Integer couponType;

    /**
     * 删除标记
     */
    @JsonIgnore
    private Boolean delFlag;
}

package com.space.coupon.util;

import com.github.dozermapper.core.DozerBeanMapperBuilder;
import com.github.dozermapper.core.Mapper;
import java.util.ArrayList;
import java.util.List;

/**
 * 对Dozer封装一层，防止转换创建多个对象
 *
 * @Author ChenYou
 * @date 2021-09-26 19:09
 * @Version 1.0
 */
public class DozerBeanUtils {

    public static Mapper mapper = DozerBeanMapperBuilder.buildDefault();

    /**
     * 对象拷贝，相同名称的对象值拷贝
     *
     * @param dest 拷贝的目标对象
     * @param src  拷贝返回的对象
     */
    public static void copyProperties(Object dest, Object src) {
        mapper.map(dest, src);
    }

    /**
     * 对象拷贝，相同名称的对象值拷贝
     *
     * @param dest  拷贝的目标对象
     * @param clazz 拷贝到对象的Class
     * @return 返回拷贝后的对象
     */
    public static <T> T transitionType(Object dest, Class<T> clazz) {
        return mapper.map(dest, clazz);
    }

    /**
     * 对象列表的类型转换
     *
     * @param tags   原对象
     * @param sClass 目标对象的class
     * @return 目标对象的List
     */
    public static <T, S> List<S> transitionTypeList(List<T> tags, Class<S> sClass) {
        List<S> ts = new ArrayList<>();
        tags.forEach(d ->
                ts.add(transitionType(d, sClass))
        );
        return ts;
    }
}

package com.space.coupon.service;

import cn.space.base.result.Response;
import com.alibaba.fastjson.JSONObject;

/**
 * TODO
 *
 * @Author kangmj
 * @date 2021-10-11 17:46
 * @Version 1.0
 */
public interface PortalService {

    /**
     * queryAccountRelProject
     *
     * @param token
     * @param params
     * @return
     */
    Response queryAccountRelProject(String token, JSONObject params);

    /**
     * 查企业列表
     *
     * @param token
     * @param params
     * @return
     */
    Response queryEnterpriseList(String token, JSONObject params);

    /**
     * 查用户信息
     *
     * @param token
     * @param body
     * @return
     */
    Response queryAccountAttributeList(String token, JSONObject body);
}

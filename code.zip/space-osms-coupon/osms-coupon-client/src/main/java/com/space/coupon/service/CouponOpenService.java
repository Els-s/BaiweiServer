package com.space.coupon.service;

import cn.space.base.result.Response;
import cn.space.portal.sdk.io.LoginUserAccountInfo;
import com.space.coupon.responsevo.CouponUseReqVo;
import java.util.List;

/**
 * @author peng.li
 * @date 2021/9/13
 */
public interface CouponOpenService {

    /**
     * 使用&消费优惠券
     *
     * @param reqVo 请求参
     * @param loginUserInfo loginUserInfo
     * @return 优惠券使用信息
     */
    Response couponUse(CouponUseReqVo reqVo, LoginUserAccountInfo loginUserInfo);

    /**
     * 选则优惠券使用，获取优惠券使用码
     *
     * @param couponCode token
     * @param loginUserInfo 请求参
     * @return RspVo
     */
    Response getCouponUseInformation(List<String> couponCode, LoginUserAccountInfo loginUserInfo);
}

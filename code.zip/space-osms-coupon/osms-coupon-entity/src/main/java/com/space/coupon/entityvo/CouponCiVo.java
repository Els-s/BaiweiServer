package com.space.coupon.entityvo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import lombok.Data;

/**
 * 卡券对象 coupon_ci
 *
 * @author kangmj
 * @date 2021-09-10
 */
@Data
public class CouponCiVo implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 卡券模板ID
     */
    private Long ruleId;
    /**
     * 模板Code
     */
    private String ruleCode;

    /**
     * 卡券名称
     */
    private String ruleName;

    /**
     * 卡券编码
     */
    private String couponCode;

    /**
     * 对象类型:0 企业，1 个人
     */
    private Integer objectType;

    /**
     * 接收对象
     */
    private String objectId;

    /**
     * 接收对象
     */
    private String objectName;

    /**
     * 使用状态：1 未使用，2 已使用，3 已过期，4 作废
     */
    private Integer useStatus;
    /**
     * 卡券面值
     */
    private Float faceValue;

    /**
     * 是否有门槛
     */
    private Boolean threshold;

    /**
     * 门槛值
     */
    private Float thresholdValue;


    /**
     * 有效期开始时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date validPeriodStartTime;

    /**
     * 有效期结束时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date validPeriodEndTime;

    /**
     * 使用时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date usedTime;

    /**
     * 展示状态
     */
    @JsonIgnore
    private Integer showStatus;

    /**
     * 应用场景
     */
    private Integer scenes;

    /**
     * 发放时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date issueTime;
    /**
     * 发放人
     */
    private String issuer;
    /**
     * 使用人
     */
    private String usePerson;

    /**
     * 卡券类型
     */
    private Integer couponType;

    /**
     * 优惠类型：1 折扣券，2 金额券，3 时长券
     */
    private Integer discountType;

    /**
     * 是否指定商品可用
     */
    private Boolean isSingle;


    /**
     * 活动ID
     */
    private Long campaignsId;

    /**
     * 发放商户
     */
    private String issueMerchant;


    /**
     * 修改时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date updateTime;
    /**
     * 修改人
     */
    private String updateBy;
    /**
     * 产品信息--集合
     */
    private List<CouponProductVo> productEntityList;

    /**
     * 券使用规则
     */
    private String description;

    /**
     * 卡券面值Vo
     */
    private String faceValueVo;

    /**
     * 门槛值Vo
     */
    private String thresholdValueVo;
    /**
     * 有效期数据list
     */
    private List<String> validPeriodDate;
    /**
     * 可使用状态时是否满足条件:true 满足使用条件，false 不满足使用条件的未使用券码
     */
    private Boolean isMeetCondition;
    /**
     * 使用码
     */
    private String useCode;
}

package com.space.coupon.entityvo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * IssueLogListVo
 *
 * @Author kangmj
 * @date 2021-09-16 16:05
 * @Version 1.0
 */
@Getter
@Setter
public class IssueLogListVo {

    private Long id;

    /**
     * 卡券模板ID
     */
    @ApiModelProperty("卡券模板ID")
    private Long ruleId;

    /**
     * 模板ID
     */
    @ApiModelProperty("模板Code")
    private String ruleCode;

    /**
     * 发放数量
     */
    @ApiModelProperty("发放数量")
    private Integer issuedNum;

    /**
     * 活动ID
     */
    @ApiModelProperty("活动ID")
    private Long campaignsId;

    /**
     * 发放商户
     */
    @ApiModelProperty("发放商户")
    private String issueMerchant;

    /**
     * 卡券类型
     */
    @ApiModelProperty("卡券类型")
    private Integer couponType;
}

package com.space.coupon.responsevo;

import com.space.coupon.entityvo.CouponCiVo;
import java.util.List;
import lombok.Data;

/**
 * @Author kangmj
 * @date 2021-10-09 9:22
 * @Version 1.0
 */
@Data
public class CouponUseReqVo {

    /**
     * 卡券CI信息集合
     */
    private List<CouponCiVo> couponCiVoList;
    /**
     * 订单号
     */
    private String orderNum;
    /**
     * 核销员
     */
    private String createdByUname;
}

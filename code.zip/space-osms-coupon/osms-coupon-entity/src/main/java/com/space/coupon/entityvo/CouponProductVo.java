package com.space.coupon.entityvo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import lombok.Data;

/**
 * CouponProductVo
 *
 * @Author kangmj
 * @date 2021-10-13 9:37
 * @Version 1.0
 */
@Data
public class CouponProductVo implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
     * 卡券模板ID
     */
    private Long ruleId;

    /**
     * 产品ID
     */
    private String productId;

    /**
     * 产品名称
     */
    private String productName;

    /**
     * 产品信息
     */
    private String productInfo;

    /**
     * 活动ID
     */
    private Long campaignsId;

    /**
     * 发放商户
     */
    private String issueMerchant;

    /**
     * 卡券类型
     */
    private Integer couponType;
}


SET
FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for coupon_batch
-- ----------------------------
DROP TABLE IF EXISTS `coupon_batch`;
CREATE TABLE `coupon_batch`
(
    `id`                 int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
    `rule_id`            varchar(32)       DEFAULT NULL COMMENT '模板ID',
    `campaigns_id`       int(11) DEFAULT NULL COMMENT '活动ID',
    `issue_merchant`     varchar(64)       DEFAULT NULL COMMENT '发放商户',
    `coupon_type`        tinyint(2) DEFAULT NULL COMMENT '卡券类型',
    `discount_type`      tinyint(2) DEFAULT NULL COMMENT '优惠类型',
    `face_value`         float             DEFAULT NULL COMMENT '卡券面值',
    `is_stop`            tinyint(1) DEFAULT '0' COMMENT '是否已终止',
    `send_coupons`       int(11) DEFAULT '0' COMMENT '券发放量',
    `used_coupons`       int(11) DEFAULT '0' COMMENT '券使用量',
    `bring_trade_count`  int(11) DEFAULT '0' COMMENT '带动交易笔数',
    `bring_trade_amount` int(11) DEFAULT '0' COMMENT '带动交易金额',
    `bring_trade_cash`   int(11) DEFAULT '0' COMMENT '带动实收',
    `coupon_amount`      int(11) DEFAULT '0' COMMENT '券抵扣金额',
    `tenement_code`      varchar(64)       DEFAULT NULL COMMENT '租户编码',
    `project_code`       varchar(64)       DEFAULT NULL COMMENT '项目编码',
    `create_by`          varchar(32)       DEFAULT NULL COMMENT '创建人',
    `create_time`        datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `search_info`        varchar(255)      DEFAULT NULL COMMENT '搜索列',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='卡券批次统计表';

-- ----------------------------
-- Records of coupon_batch
-- ----------------------------

-- ----------------------------
-- Table structure for coupon_campaigns
-- ----------------------------
DROP TABLE IF EXISTS `coupon_campaigns`;
CREATE TABLE `coupon_campaigns`
(
    `id`                int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
    `title`             varchar(64)  DEFAULT NULL COMMENT '活动名称',
    `campaign_type`     varchar(64)  DEFAULT NULL COMMENT '活动类型',
    `status`            tinyint(2) DEFAULT NULL COMMENT '活动状态',
    `rule_id`           int(11) DEFAULT NULL COMMENT '卡券模板ID',
    `coupon_total`      int(11) DEFAULT NULL COMMENT '卡券数量',
    `send_at`           datetime     DEFAULT NULL COMMENT '活动发送时间',
    `date_start`        datetime     DEFAULT NULL COMMENT '活动开始日期',
    `date_end`          datetime     DEFAULT NULL COMMENT '活动结束日期',
    `detail`            varchar(255) DEFAULT NULL COMMENT '活动详情',
    `is_stop`           tinyint(1) DEFAULT '0' COMMENT '是否已终止',
    `send_coupons`      int(11) DEFAULT '0' COMMENT '券发放量',
    `used_coupons`      int(11) DEFAULT '0' COMMENT '券使用量',
    `coupon_used_ratio` float(11, 0
) DEFAULT '0' COMMENT '券回收率',
  `bring_trade_count` int(11) DEFAULT '0' COMMENT '带动交易笔数',
  `bring_trade_amount` int(11) DEFAULT '0' COMMENT '带动交易金额',
  `bring_trade_cash` int(11) DEFAULT '0' COMMENT '带动实收',
  `coupon_amount` int(11) DEFAULT '0' COMMENT '券抵扣金额',
  `issue_merchant` varchar(64)  DEFAULT NULL COMMENT '发起商户',
  `tenement_code` varchar(64)  DEFAULT NULL COMMENT '租户编码',
  `project_code` varchar(64)  DEFAULT NULL COMMENT '项目编码',
  `create_by` varchar(32)  DEFAULT NULL COMMENT '创建人',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` varchar(32)  DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `revision` tinyint(1) DEFAULT NULL COMMENT '乐观锁',
  `del_flag` tinyint(1) DEFAULT NULL COMMENT '删除符',
  `search_info` varchar(255)  DEFAULT NULL COMMENT '搜索列',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='活动表';

-- ----------------------------
-- Records of coupon_campaigns
-- ----------------------------

-- ----------------------------
-- Table structure for coupon_ci
-- ----------------------------
DROP TABLE IF EXISTS `coupon_ci`;
CREATE TABLE `coupon_ci`
(
    `id`              int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
    `rule_id`         int(11) DEFAULT NULL COMMENT '卡券模板ID',
    `rule_code`       varchar(32) NOT NULL COMMENT '模板code',
    `rule_name`       varchar(64)  DEFAULT NULL COMMENT '卡券名称',
    `coupon_code`     varchar(64)  DEFAULT NULL COMMENT '卡券编码',
    `object_id`       varchar(64)  DEFAULT NULL COMMENT '接收对象',
    `object_name`     varchar(255) DEFAULT NULL COMMENT '对象名称',
    `face_value`      float        DEFAULT NULL COMMENT '卡券面值',
    `threshold`       tinyint(4) DEFAULT NULL COMMENT '是否有门槛',
    `threshold_value` float(11, 0
) DEFAULT NULL COMMENT '门槛值',
  `object_type` tinyint(2) DEFAULT NULL COMMENT '对象类型',
  `use_status` tinyint(2) DEFAULT NULL COMMENT '使用状态',
  `valid_period_start_time` datetime DEFAULT NULL COMMENT '有效期开始时间',
  `valid_period_end_time` datetime DEFAULT NULL COMMENT '有效期结束时间',
  `used_time` datetime DEFAULT NULL COMMENT '使用时间',
  `show_status` tinyint(2) DEFAULT '0' COMMENT '展示状态',
  `use_person` varchar(128)  DEFAULT NULL COMMENT '使用人',
  `order_num` varchar(64)  DEFAULT NULL COMMENT '订单号',
  `issuer` varchar(128)  DEFAULT NULL COMMENT '发放人',
  `issue_time` datetime DEFAULT NULL COMMENT '发放时间',
  `campaigns_id` int(11) DEFAULT NULL COMMENT '活动ID',
  `issue_merchant` varchar(64)  DEFAULT NULL COMMENT '发放商户',
  `coupon_type` tinyint(2) DEFAULT NULL COMMENT '卡券类型',
  `discount_type` tinyint(2) DEFAULT NULL COMMENT '优惠类型',
  `scenes` tinyint(2) DEFAULT NULL COMMENT '应用场景',
  `is_single` tinyint(1) DEFAULT '0' COMMENT '是否指定商品可用',
  `tenement_code` varchar(64)  DEFAULT NULL COMMENT '租户编码',
  `project_code` varchar(64)  DEFAULT NULL COMMENT '项目编码',
  `create_by` varchar(32)  DEFAULT NULL COMMENT '创建人',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_by` varchar(32)  DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `use_lock` tinyint(1) DEFAULT NULL COMMENT '使用锁',
  `del_flag` tinyint(1) DEFAULT '0' COMMENT '删除标记',
  `search_info` varchar(255)  DEFAULT NULL COMMENT '搜索列',
  `salt` varchar(255)  DEFAULT NULL COMMENT '盐值',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='卡券表';

-- ----------------------------
-- Records of coupon_ci
-- ----------------------------

-- ----------------------------
-- Table structure for coupon_dict
-- ----------------------------
DROP TABLE IF EXISTS `coupon_dict`;
CREATE TABLE `coupon_dict`
(
    `id`            int(11) NOT NULL,
    `code`          tinyint(4) DEFAULT NULL COMMENT '交互码',
    `value_key`     varchar(1024) COLLATE utf8_bin DEFAULT NULL,
    `value_name`    varchar(1024) COLLATE utf8_bin DEFAULT NULL COMMENT '数据字典value对应名字',
    `type_code`     varchar(32) COLLATE utf8_bin   DEFAULT NULL COMMENT '数据字典业务代码',
    `parent_id`     int(11) DEFAULT NULL COMMENT '上级id',
    `order_num`     int(4) DEFAULT '0' COMMENT '排序',
    `tenement_code` varchar(128) COLLATE utf8_bin  DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='字典表明细';

-- ----------------------------
-- Records of coupon_dict
-- ----------------------------
INSERT INTO `coupon_dict`
VALUES ('1', '1', 'coupon_template_coupon', '优惠券', 'COUPON_TEMPLATE_COUPON', null, '0', 'ALL');
INSERT INTO `coupon_dict`
VALUES ('2', '1', 'offer_discount_coupon', '折扣券', 'OFFER_TYPE', '1', '0', 'ALL');
INSERT INTO `coupon_dict`
VALUES ('3', '2', 'offer_cash_coupon', '金额券', 'OFFER_TYPE', '1', '0', 'ALL');
INSERT INTO `coupon_dict`
VALUES ('4', '3', 'offer_duration_coupon', '时长券', 'OFFER_TYPE', '1', '0', 'ALL');
INSERT INTO `coupon_dict`
VALUES ('5', '1', 'SPACE_VENUE_RESERVE', '场地预订', 'APPLICATION_SCENARIO', null, '0', null);

-- ----------------------------
-- Table structure for coupon_dict_type
-- ----------------------------
DROP TABLE IF EXISTS `coupon_dict_type`;
CREATE TABLE `coupon_dict_type`
(
    `id`            int(11) NOT NULL,
    `type_name`     varchar(1024) COLLATE utf8_bin DEFAULT NULL COMMENT '数据字典名称',
    `type_value`    varchar(1024) COLLATE utf8_bin DEFAULT NULL COMMENT '字典表类型值',
    `tenement_code` varchar(32) COLLATE utf8_bin   DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='字典表分类表';

-- ----------------------------
-- Records of coupon_dict_type
-- ----------------------------
INSERT INTO `coupon_dict_type`
VALUES ('1', '卡券类型', 'COUPON_TEMPLATE_COUPON', null);
INSERT INTO `coupon_dict_type`
VALUES ('2', '优惠类型', 'OFFER_TYPE', null);
INSERT INTO `coupon_dict_type`
VALUES ('3', '应用场景', 'APPLICATION_SCENARIO', null);

-- ----------------------------
-- Table structure for coupon_images
-- ----------------------------
DROP TABLE IF EXISTS `coupon_images`;
CREATE TABLE `coupon_images`
(
    `id`            int(11) NOT NULL AUTO_INCREMENT,
    `rule_id`       varchar(32)       DEFAULT NULL COMMENT '模板id',
    `image_url`     varchar(255)      DEFAULT NULL COMMENT '图片素材URL',
    `is_icon`       tinyint(4) DEFAULT NULL COMMENT '是否是优惠券的封面',
    `tenement_code` varchar(64)       DEFAULT NULL COMMENT '租户编码',
    `project_code`  varchar(64)       DEFAULT NULL COMMENT '项目编码',
    `create_by`     varchar(32)       DEFAULT NULL COMMENT '创建人',
    `create_time`   datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_by`     varchar(32)       DEFAULT NULL COMMENT '更新人',
    `update_time`   datetime          DEFAULT NULL COMMENT '更新时间',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='卡券图片表';

-- ----------------------------
-- Records of coupon_images
-- ----------------------------

-- ----------------------------
-- Table structure for coupon_issue_log
-- ----------------------------
DROP TABLE IF EXISTS `coupon_issue_log`;
CREATE TABLE `coupon_issue_log`
(
    `id`             int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
    `rule_id`        int(11) NOT NULL COMMENT '卡券模板ID',
    `rule_code`      varchar(32) NOT NULL COMMENT '模板code',
    `issued_num`     tinyint(3) DEFAULT NULL COMMENT '发放数量',
    `campaigns_id`   int(11) DEFAULT NULL COMMENT '活动ID',
    `issue_merchant` varchar(64)          DEFAULT NULL COMMENT '发放商户',
    `coupon_type`    tinyint(2) DEFAULT NULL COMMENT '卡券类型',
    `discount_type`  tinyint(2) DEFAULT NULL COMMENT '优惠类型',
    `issue_time`     datetime             DEFAULT NULL COMMENT '发放时间',
    `project_code`   varchar(64)          DEFAULT NULL COMMENT '项目编码',
    `tenement_code`  varchar(64)          DEFAULT NULL COMMENT '租户编码',
    `create_by`      varchar(32)          DEFAULT NULL COMMENT '发放人',
    `create_time`    datetime    NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `show_status`    tinyint(1) DEFAULT NULL COMMENT '展示状态',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='卡券发放记录表';

-- ----------------------------
-- Records of coupon_issue_log
-- ----------------------------

-- ----------------------------
-- Table structure for coupon_object
-- ----------------------------
DROP TABLE IF EXISTS `coupon_object`;
CREATE TABLE `coupon_object`
(
    `id`             int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
    `rule_id`        int(11) NOT NULL COMMENT '卡券模板ID',
    `object_type`    tinyint(2) DEFAULT NULL COMMENT '对象类型',
    `object_id`      varchar(64)       DEFAULT NULL COMMENT '对象ID',
    `object_name`    varchar(64)       DEFAULT NULL COMMENT '对象名称',
    `remain_num`     int(11) DEFAULT NULL COMMENT '剩余数量',
    `issue_status`   tinyint(2) DEFAULT NULL COMMENT '发放状态',
    `issued_num`     tinyint(3) DEFAULT NULL COMMENT '发放数量',
    `campaigns_id`   int(11) DEFAULT NULL COMMENT '活动ID',
    `issue_merchant` varchar(64)       DEFAULT NULL COMMENT '发放商户',
    `coupon_type`    tinyint(2) DEFAULT NULL COMMENT '卡券类型',
    `project_code`   varchar(64)       DEFAULT NULL COMMENT '项目编码',
    `tenement_code`  varchar(64)       DEFAULT NULL COMMENT '租户编码',
    `create_by`      varchar(32)       DEFAULT NULL COMMENT '创建人',
    `create_time`    datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `del_flag`       tinyint(1) DEFAULT NULL COMMENT '删除标记',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='卡包表';

-- ----------------------------
-- Records of coupon_object
-- ----------------------------

-- ----------------------------
-- Table structure for coupon_product
-- ----------------------------
DROP TABLE IF EXISTS `coupon_product`;
CREATE TABLE `coupon_product`
(
    `id`             int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
    `rule_id`        int(11) DEFAULT NULL COMMENT '卡券模板ID',
    `product_id`     varchar(64)       DEFAULT NULL COMMENT '产品ID',
    `product_name`   varchar(64)       DEFAULT NULL COMMENT '产品名称',
    `product_info`   varchar(255)      DEFAULT NULL COMMENT '产品信息',
    `campaigns_id`   int(11) DEFAULT NULL COMMENT '活动ID',
    `issue_merchant` varchar(64)       DEFAULT NULL COMMENT '发放商户',
    `coupon_type`    tinyint(2) DEFAULT NULL COMMENT '卡券类型',
    `tenement_code`  varchar(64)       DEFAULT NULL COMMENT '租户编码',
    `project_code`   varchar(64)       DEFAULT NULL COMMENT '项目编码',
    `create_by`      varchar(32)       DEFAULT NULL COMMENT '创建人',
    `create_time`    datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `del_flag`       tinyint(1) DEFAULT NULL COMMENT '删除标记',
    `search_info`    varchar(255)      DEFAULT NULL COMMENT '搜索列',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='卡券适用产品表';

-- ----------------------------
-- Records of coupon_product
-- ----------------------------

-- ----------------------------
-- Table structure for coupon_rule
-- ----------------------------
DROP TABLE IF EXISTS `coupon_rule`;
CREATE TABLE `coupon_rule`
(
    `id`                      int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
    `rule_name`               varchar(64) NOT NULL COMMENT '模板名称',
    `rule_code`               varchar(32) NOT NULL COMMENT '模板code',
    `frequency`               tinyint(2) DEFAULT NULL COMMENT '发放频次',
    `expired_statu`           tinyint(1) DEFAULT NULL COMMENT '是否过期',
    `issue_merchant`          varchar(64)          DEFAULT NULL COMMENT '发放商户',
    `campaigns_id`            int(11) DEFAULT NULL COMMENT '活动ID',
    `coupon_type`             tinyint(2) DEFAULT NULL COMMENT '卡券类型',
    `discount_type`           tinyint(2) DEFAULT NULL COMMENT '优惠类型',
    `face_value`              float                DEFAULT NULL COMMENT '卡券面值',
    `threshold`               tinyint(1) DEFAULT NULL COMMENT '是否有门槛',
    `threshold_value`         float                DEFAULT NULL COMMENT '门槛值',
    `validity_period_type`    tinyint(2) DEFAULT NULL COMMENT '有效期限方式',
    `validity_period_value`   int(11) DEFAULT NULL COMMENT '非固定有效期值',
    `valid_period_start_time` datetime             DEFAULT NULL COMMENT '有效期开始时间',
    `valid_period_end_time`   datetime             DEFAULT NULL COMMENT '有效期结束时间',
    `issue_start_date`        varchar(64)          DEFAULT NULL COMMENT '发放开始日期',
    `issue_end_date`          varchar(64)          DEFAULT NULL COMMENT '发放结束日期',
    `timed_release_time`      varchar(64)          DEFAULT NULL COMMENT '定时发放时间',
    `scenes`                  tinyint(2) DEFAULT NULL COMMENT '应用场景',
    `remark`                  varchar(255)         DEFAULT NULL COMMENT '备注',
    `issue_num`               int(11) DEFAULT NULL COMMENT '发放数量',
    `issue_object_type`       tinyint(2) DEFAULT NULL COMMENT '发放对象类型',
    `use_status`              tinyint(2) DEFAULT NULL COMMENT '卡券状态',
    `project_code`            varchar(64)          DEFAULT NULL COMMENT '项目编码',
    `tenement_code`           varchar(64)          DEFAULT NULL COMMENT '租户编码',
    `create_by`               varchar(32)          DEFAULT NULL COMMENT '创建人',
    `person_name`             varchar(64)          DEFAULT NULL COMMENT '创建人名称',
    `create_time`             datetime    NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time`             datetime             DEFAULT NULL COMMENT '修改时间',
    `update_by`               varchar(32)          DEFAULT NULL COMMENT '修改人',
    `search_info`             varchar(255)         DEFAULT NULL COMMENT '搜索列',
    `del_flag`                tinyint(1) DEFAULT NULL COMMENT '删除标记',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='卡券模板表';

-- ----------------------------
-- Records of coupon_rule
-- ----------------------------

-- ----------------------------
-- Table structure for coupon_rule_cycle
-- ----------------------------
DROP TABLE IF EXISTS `coupon_rule_cycle`;
CREATE TABLE `coupon_rule_cycle`
(
    `id`                 int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
    `rule_id`            int(11) NOT NULL COMMENT '卡券模板ID',
    `frequency`          tinyint(2) DEFAULT NULL COMMENT '发放频次;重复/一次性',
    `repeat_frequency`   varchar(64)       DEFAULT NULL COMMENT '重复频率',
    `work_day`           varchar(255)      DEFAULT NULL COMMENT '日',
    `work_month`         varchar(64)       DEFAULT NULL COMMENT '月',
    `work_week`          varchar(64)       DEFAULT NULL COMMENT '周',
    `cycle_time`         varchar(64)       DEFAULT NULL COMMENT '周期设置',
    `custom_time`        int(11) DEFAULT NULL COMMENT '自定义周期',
    `timed_release_time` varchar(64)       DEFAULT NULL COMMENT '定时发放时间',
    `issue_merchant`     varchar(64)       DEFAULT NULL COMMENT '发放商户',
    `campaigns_id`       int(11) DEFAULT NULL COMMENT '活动ID',
    `expired_statu`      tinyint(1) DEFAULT NULL COMMENT '是否过期',
    `create_by`          varchar(32)       DEFAULT NULL COMMENT '创建人',
    `create_time`        datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='卡券发放规则表';

-- ----------------------------
-- Records of coupon_rule_cycle
-- ----------------------------

-- ----------------------------
-- Table structure for coupon_use_log
-- ----------------------------
DROP TABLE IF EXISTS `coupon_use_log`;
CREATE TABLE `coupon_use_log`
(
    `id`               int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
    `coupon_code`      varchar(64)          DEFAULT NULL COMMENT '卡券编码',
    `product_id`       varchar(64)          DEFAULT NULL COMMENT '商品号',
    `rule_id`          int(11) DEFAULT NULL COMMENT '卡券模板ID',
    `rule_code`        varchar(32) NOT NULL COMMENT '模板code',
    `status`           varchar(64)          DEFAULT NULL COMMENT '使用状态',
    `rule_name`        varchar(64)          DEFAULT NULL COMMENT '卡券名称',
    `order_num`        varchar(64)          DEFAULT NULL COMMENT '订单号',
    `created_by_uname` varchar(64)          DEFAULT NULL COMMENT '核销店员',
    `user_code`        varchar(64)          DEFAULT NULL COMMENT '使用人',
    `refund_form_num`  varchar(64)          DEFAULT NULL COMMENT '退款单号',
    `mch_id`           varchar(64)          DEFAULT NULL COMMENT '支付商户号',
    `issue_merchant`   varchar(64)          DEFAULT NULL COMMENT '发起商户',
    `tenement_code`    varchar(64)          DEFAULT NULL COMMENT '租户编码',
    `project_code`     varchar(64)          DEFAULT NULL COMMENT '项目编码',
    `create_by`        varchar(32)          DEFAULT NULL COMMENT '创建人',
    `create_time`      datetime    NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `del_flag`         tinyint(1) DEFAULT NULL COMMENT '删除符',
    `search_info`      varchar(255)         DEFAULT NULL COMMENT '搜索列',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='卡券核销记录';

-- ----------------------------
-- Records of coupon_use_log
-- ----------------------------
